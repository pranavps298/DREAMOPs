# DynamoDB Cross-Account Replication Script (US to China)

This script facilitates the replication and synchronization of DynamoDB tables and their data from a source AWS account (default: `us-east-1`) to a target AWS account in China (default: `cn-north-1`).

## Features

1.  **Table Replication (`list_and_replicate_tables`)**:

    - Lists tables in both source and target accounts.
    - Creates tables in the target account that exist in the source but not the target.
    - Replicates table structure including:
      - Key Schema
      - Attribute Definitions
      - Billing Mode (Provisioned or Pay-Per-Request)
      - Provisioned Throughput (if applicable)
      - Global Secondary Indexes (GSIs)
      - Local Secondary Indexes (LSIs) - _Note: LSIs can only be created during table creation._
      - Stream Specification

2.  **Structure Synchronization (`synchronize_existing_tables`)**:

    - Compares tables that exist in _both_ source and target accounts.
    - Adds missing Global Secondary Indexes (GSIs) to the target table to match the source.
      - Respects the DynamoDB limit of creating only one index at a time per table, waiting for each GSI to become `ACTIVE` before proceeding.
      - Ensures minimum provisioned throughput (1 RCU/WCU) if the target table uses PROVISIONED billing mode.
    - Enables Time-To-Live (TTL) on the target table if it's enabled on the source, using the same attribute name.
    - Logs warnings if LSIs exist in the source but not the target (as they cannot be added post-creation).
    - _Does not_ synchronize stream settings in this function.

3.  **Lambda Trigger Setup (`add_dynamo_triggers_to_lambda`)**:

    - Enables DynamoDB Streams (`NEW_AND_OLD_IMAGES`) on source tables if not already enabled.
    - Creates Lambda event source mappings to trigger a specified Lambda function from the DynamoDB streams of source tables.
    - Skips mapping creation if a mapping already exists for a table stream and the function.

4.  **Data Replication Lambda (`lambda_handler`)**:
    - A Lambda function handler designed to be triggered by DynamoDB Streams.
    - Processes `INSERT`, `MODIFY`, and `REMOVE` events from the stream.
    - Uses `PutItem` for `INSERT`/`MODIFY` and `DeleteItem` for `REMOVE` to replicate data changes to the corresponding table in the target China account.
    - Authenticates to the target account using credentials fetched from Secrets Manager.

## Setup

1.  **Prerequisites**:

    - Python 3
    - `boto3` library (`pip install boto3`)
    - AWS CLI (optional, for local credential management)

2.  **AWS Credentials**:

    - **Source Account (`us-east-1`)**: Configure AWS credentials locally (e.g., via `~/.aws/credentials`, environment variables, or instance profile) with permissions for:
      - `dynamodb:ListTables`, `dynamodb:DescribeTable`, `dynamodb:UpdateTable`, `dynamodb:DescribeTimeToLive`
      - `lambda:ListEventSourceMappings`, `lambda:CreateEventSourceMapping`
      - `secretsmanager:GetSecretValue` (to read the target account credentials)
    - **Target Account (`cn-north-1`)**: Store credentials (access key ID and secret access key) in AWS Secrets Manager in the **source** account (`us-east-1`).
      - Secret Name: `CNDataReplicate` (configurable in `get_secret`)
      - Secret Value (JSON): `{"access_key": "TARGET_ACCESS_KEY_ID", "secret": "TARGET_SECRET_ACCESS_KEY"}`
      - The IAM user/role associated with these credentials in the target account needs permissions for:
        - `dynamodb:ListTables`, `dynamodb:DescribeTable`, `dynamodb:CreateTable`, `dynamodb:UpdateTable`, `dynamodb:UpdateTimeToLive`, `dynamodb:DescribeTimeToLive`, `dynamodb:PutItem`, `dynamodb:DeleteItem`

3.  **Configuration**:
    - Review and adjust region names (`us-east-1`, `cn-north-1`) and the secret name (`CNDataReplicate`) in the script if needed.

## Usage

### Running Locally

You can execute the table replication, synchronization, or trigger setup functions directly from your local machine where you have configured source account credentials.

1.  **Edit `main.py`**: Uncomment the desired function call(s) at the bottom of the file within the `if __name__ == "__main__":` block (or add calls if the block is commented out).

    - `list_and_replicate_tables()`: To create missing tables.
    - `synchronize_existing_tables()`: To update the structure of existing tables.
    - `add_dynamo_triggers_to_lambda("YourLambdaFunctionName")`: To set up stream triggers for a Lambda function (replace `"YourLambdaFunctionName"`).

2.  **Run the script**:
    ```bash
    python main.py
    ```

### Deploying the Lambda Handler

1.  **Create a Lambda Function**: In the source AWS account (`us-east-1`), create a new Lambda function using Python 3.x.
2.  **Deploy Code**: Package the `main.py` script (and any dependencies like `boto3` if not using the AWS-provided runtime version) into a deployment package and upload it to the Lambda function.
3.  **Set Handler**: Configure the Lambda handler as `main.lambda_handler`.
4.  **Permissions**: Ensure the Lambda function's execution role has permissions for:
    - `secretsmanager:GetSecretValue` (for the `CNDataReplicate` secret)
    - `dynamodb:DescribeStream`, `dynamodb:GetRecords`, `dynamodb:GetShardIterator`, `dynamodb:ListStreams` (for reading from the source table streams)
    - CloudWatch Logs permissions (e.g., `logs:CreateLogGroup`, `logs:CreateLogStream`, `logs:PutLogEvents`)
5.  **Triggers**: Use the `add_dynamo_triggers_to_lambda` function (run locally) or manually configure DynamoDB stream triggers for your source tables in the Lambda console, pointing to this function.

## Important Notes

- **GSI Creation Time**: Adding GSIs via `synchronize_existing_tables` can take a significant amount of time for large tables, as the script waits for each index to become active before proceeding.
- **Costs**: Be aware of costs associated with:
  - DynamoDB Streams (charged per read request unit).
  - Lambda invocations and execution time.
  - Data transfer between regions.
  - DynamoDB provisioned capacity or pay-per-request charges in both accounts.
- **Error Handling**: The script includes basic error handling, but consider adding more specific exception handling (e.g., for `ClientError` codes) and potentially retry logic for production environments.
- **Credentials Security**: Ensure the secret in Secrets Manager and the source account credentials are properly secured.
