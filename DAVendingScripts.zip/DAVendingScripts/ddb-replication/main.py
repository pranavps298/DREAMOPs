import boto3
import json
import logging
import os
import base64
from boto3.dynamodb.types import Binary

logger = logging.getLogger()
logging.basicConfig(level=logging.INFO)
logger.setLevel(logging.INFO)


def get_secret():

    secret_name = "CNDataReplicate"
    region_name = "us-east-1"

    session = boto3.session.Session()
    client = session.client(service_name="secretsmanager", region_name=region_name)

    try:
        get_secret_value_response = client.get_secret_value(SecretId=secret_name)
    except Exception as e:

        raise e

    secret = get_secret_value_response["SecretString"]
    secret = json.loads(secret)
    return secret["access_key"], secret["secret"]


def list_tables(dynamodb):
    try:
        # Use boto3's built-in pagination
        paginator = dynamodb.get_paginator("list_tables")
        tables = []

        for page in paginator.paginate():
            tables.extend(page.get("TableNames", []))

        return tables

    except Exception as e:
        print(f"Error listing DynamoDB tables: {str(e)}")
        return []


def get_target_dynamodb_client():
    access_key_id, secret_access_key = get_secret()
    target_session = boto3.Session(
        region_name="cn-north-1",
        aws_access_key_id=access_key_id,
        aws_secret_access_key=secret_access_key,
    )

    target_dynamodb = target_session.client("dynamodb")
    return target_dynamodb


def add_dynamo_triggers_to_lambda(lambda_function_name, region="us-east-1"):

    logger.info(
        f"Setting up DynamoDB stream triggers for Lambda function {lambda_function_name}"
    )

    # Create session for source account
    session = boto3.Session(region_name=region)
    dynamodb = session.client("dynamodb")
    lambda_client = session.client("lambda")

    # Get list of tables
    source_tables = list_tables(dynamodb)
    logger.info(f"Found {len(source_tables)} tables in source account")

    # For each table, check if stream is enabled and create trigger if not already exists
    for table_name in source_tables:
        try:
            # Check if the table has streams enabled
            table_desc = dynamodb.describe_table(TableName=table_name)["Table"]

            if "StreamSpecification" not in table_desc or not table_desc.get(
                "LatestStreamArn"
            ):
                logger.info(f"Enabling streams on table {table_name}...")

                # Enable streams if not already enabled
                dynamodb.update_table(
                    TableName=table_name,
                    StreamSpecification={
                        "StreamEnabled": True,
                        "StreamViewType": "NEW_AND_OLD_IMAGES",
                    },
                )

                # Get updated description with stream ARN
                table_desc = dynamodb.describe_table(TableName=table_name)["Table"]

            stream_arn = table_desc["LatestStreamArn"]
            logger.info(f"Table {table_name} has stream ARN: {stream_arn}")

            # Check if mapping already exists
            existing_mappings = lambda_client.list_event_source_mappings(
                EventSourceArn=stream_arn, FunctionName=lambda_function_name
            )

            if existing_mappings.get("EventSourceMappings"):
                logger.info(
                    f"Table {table_name} already mapped to Lambda {lambda_function_name}"
                )
                continue

            # Create event source mapping (trigger)
            lambda_client.create_event_source_mapping(
                EventSourceArn=stream_arn,
                FunctionName=lambda_function_name,
                Enabled=True,
                BatchSize=100,
                StartingPosition="TRIM_HORIZON",
            )

            logger.info(
                f"Successfully added {table_name} as trigger for Lambda {lambda_function_name}"
            )

        except Exception as e:
            logger.error(f"Error setting up trigger for table {table_name}: {str(e)}")

    logger.info(
        f"Completed setting up DynamoDB triggers for Lambda function {lambda_function_name}"
    )

    return {
        "statusCode": 200,
        "message": f"Processed {len(source_tables)} tables as potential triggers",
    }


"""
This script lists all DynamoDB tables in the source account and replicates them to the target account.
"""


def list_and_replicate_tables():
    session = boto3.Session(region_name="us-east-1")
    source_dynamodb = session.client("dynamodb")
    source_tables = list_tables(source_dynamodb)
    logger.info(f"Found {len(source_tables)} tables in source account.")

    # Get existing tables in target account
    logger.info(f"Listing tables in target account ...")
    target_dynamodb = get_target_dynamodb_client()
    target_tables = list_tables(target_dynamodb)
    logger.info(f"Found {len(target_tables)} tables in target account.")

    # Process each table
    for table_name in source_tables:
        logger.info(f"\nProcessing table: {table_name}")

        # Check if table already exists in target account
        if table_name in target_tables:
            logger.info(
                f"Table {table_name} already exists in target account. Skipping."
            )
            continue

        try:
            # Get the table description from the source account
            table_desc = source_dynamodb.describe_table(TableName=table_name)["Table"]

            # Extract the key schema and attribute definitions
            key_schema = table_desc["KeySchema"]
            attribute_definitions = table_desc["AttributeDefinitions"]

            # Extract provisioned throughput if applicable
            billing_mode = "PAY_PER_REQUEST"  # Default to on-demand
            provisioned_throughput = None

            if "BillingModeSummary" in table_desc:
                if table_desc["BillingModeSummary"]["BillingMode"] == "PROVISIONED":
                    billing_mode = "PROVISIONED"
                    provisioned_throughput = {
                        "ReadCapacityUnits": table_desc["ProvisionedThroughput"][
                            "ReadCapacityUnits"
                        ],
                        "WriteCapacityUnits": table_desc["ProvisionedThroughput"][
                            "WriteCapacityUnits"
                        ],
                    }

            # Extract GSIs if any
            global_secondary_indexes = None
            if "GlobalSecondaryIndexes" in table_desc:
                global_secondary_indexes = []
                for gsi in table_desc["GlobalSecondaryIndexes"]:
                    gsi_def = {
                        "IndexName": gsi["IndexName"],
                        "KeySchema": gsi["KeySchema"],
                        "Projection": gsi["Projection"],
                    }

                    # Add provisioning if applicable
                    if billing_mode == "PROVISIONED":
                        gsi_def["ProvisionedThroughput"] = {
                            "ReadCapacityUnits": gsi["ProvisionedThroughput"][
                                "ReadCapacityUnits"
                            ],
                            "WriteCapacityUnits": gsi["ProvisionedThroughput"][
                                "WriteCapacityUnits"
                            ],
                        }

                    global_secondary_indexes.append(gsi_def)

            # Extract LSIs if any
            local_secondary_indexes = None
            if "LocalSecondaryIndexes" in table_desc:
                local_secondary_indexes = []
                for lsi in table_desc["LocalSecondaryIndexes"]:
                    lsi_def = {
                        "IndexName": lsi["IndexName"],
                        "KeySchema": lsi["KeySchema"],
                        "Projection": lsi["Projection"],
                    }
                    local_secondary_indexes.append(lsi_def)

            # Create table in target account
            logger.info(f"Creating {table_name} in target account...")

            create_args = {
                "TableName": table_name,
                "AttributeDefinitions": attribute_definitions,
                "KeySchema": key_schema,
                "BillingMode": billing_mode,
            }

            if billing_mode == "PROVISIONED":
                create_args["ProvisionedThroughput"] = provisioned_throughput

            if global_secondary_indexes:
                create_args["GlobalSecondaryIndexes"] = global_secondary_indexes

            if local_secondary_indexes:
                create_args["LocalSecondaryIndexes"] = local_secondary_indexes

            # Handle stream specification if it exists
            if "StreamSpecification" in table_desc:
                create_args["StreamSpecification"] = table_desc["StreamSpecification"]

            # Create the table
            target_dynamodb.create_table(**create_args)

            logger.info(f"Waiting for table {table_name} to become active...")

            # Wait for table to be created
            waiter = target_dynamodb.get_waiter("table_exists")
            waiter.wait(TableName=table_name)

            logger.info(f"Table {table_name} created successfully.")

        except Exception as e:
            logger.error(f"Error processing table {table_name}: {str(e)}")


def synchronize_existing_tables():
    """
    Synchronizes structure of existing tables in target account with source account.
    Only adds missing indexes and TTL settings to tables that already exist in both accounts.
    Does not sync stream settings, and only syncs one way (source to destination).
    Respects DynamoDB limit of one index creation/deletion at a time per table.
    """
    session = boto3.Session(region_name="us-east-1")
    source_dynamodb = session.client("dynamodb")
    source_tables = list_tables(source_dynamodb)
    logger.info(f"Found {len(source_tables)} tables in source account.")

    # Get existing tables in target account
    logger.info("Listing tables in target account...")
    target_dynamodb = get_target_dynamodb_client()
    target_tables = list_tables(target_dynamodb)
    logger.info(f"Found {len(target_tables)} tables in target account.")

    # Track tables that were updated
    updated_tables = []

    # Find common tables (exist in both source and target)
    common_tables = [table for table in source_tables if table in target_tables]
    logger.info(f"Found {len(common_tables)} tables that exist in both accounts.")

    # Process each table that exists in both accounts
    for table_name in common_tables:
        logger.info(f"\nSynchronizing structure for table: {table_name}")

        try:
            os.system(
                "ada credentials update --account=245740572399 --provider=conduit --role=IibsAdminAccess-DO-NOT-DELETE --once"
            )
            session = boto3.Session(region_name="us-east-1")
            source_dynamodb = session.client("dynamodb")

            # Get table descriptions from both accounts
            source_desc = source_dynamodb.describe_table(TableName=table_name)["Table"]
            target_desc = target_dynamodb.describe_table(TableName=table_name)["Table"]

            updates_needed = False
            updates_applied = []

            # Determine target table billing mode
            target_billing_mode = "PAY_PER_REQUEST"  # Default to on-demand
            if "BillingModeSummary" in target_desc:
                if (
                    target_desc["BillingModeSummary"].get("BillingMode")
                    == "PROVISIONED"
                ):
                    target_billing_mode = "PROVISIONED"

            # ===== SYNC GSIs =====
            source_gsis = source_desc.get("GlobalSecondaryIndexes", [])
            target_gsis = target_desc.get("GlobalSecondaryIndexes", [])

            # Create dict of existing GSIs in target by name for easy lookup
            target_gsi_names = {gsi["IndexName"]: gsi for gsi in target_gsis}

            # Check for each source GSI if it needs to be added to target
            for source_gsi in source_gsis:
                gsi_name = source_gsi["IndexName"]

                # If GSI doesn't exist in target, add it
                if gsi_name not in target_gsi_names:
                    updates_needed = True
                    updates_applied.append(f"Added GSI: {gsi_name}")

                    # Create GSI definition
                    gsi_def = {
                        "Create": {
                            "IndexName": gsi_name,
                            "KeySchema": source_gsi["KeySchema"],
                            "Projection": source_gsi["Projection"],
                        }
                    }

                    # Add provisioned throughput if applicable for PROVISIONED billing mode tables
                    if target_billing_mode == "PROVISIONED":
                        # Use minimum values of 1 for read/write capacity
                        gsi_def["Create"]["ProvisionedThroughput"] = {
                            "ReadCapacityUnits": max(
                                1,
                                source_gsi.get("ProvisionedThroughput", {}).get(
                                    "ReadCapacityUnits", 1
                                ),
                            ),
                            "WriteCapacityUnits": max(
                                1,
                                source_gsi.get("ProvisionedThroughput", {}).get(
                                    "WriteCapacityUnits", 1
                                ),
                            ),
                        }

                    # Before creating new index, check if any index operations are in progress
                    # and wait for them to complete
                    logger.info(
                        f"Checking table status before adding GSI {gsi_name} to {table_name}"
                    )

                    # Wait until there are no pending index operations
                    while True:
                        target_dynamodb = get_target_dynamodb_client()
                        current_desc = target_dynamodb.describe_table(
                            TableName=table_name
                        )["Table"]

                        # Check for any GSIs that are being created or updated
                        creating_indexes = [
                            idx["IndexName"]
                            for idx in current_desc.get("GlobalSecondaryIndexes", [])
                            if idx.get("IndexStatus") == "CREATING"
                        ]

                        if creating_indexes:
                            logger.info(
                                f"Waiting for GSIs {creating_indexes} to finish creating on table {table_name}"
                            )
                            # Wait 15 seconds before checking again
                            import time

                            time.sleep(15)
                        else:
                            # No in-progress operations, safe to proceed
                            break

                    # Now safe to create a new GSI
                    logger.info(
                        f"Starting creation of GSI {gsi_name} on table {table_name}"
                    )

                    # Update table to add the GSI
                    target_dynamodb.update_table(
                        TableName=table_name,
                        AttributeDefinitions=source_desc["AttributeDefinitions"],
                        GlobalSecondaryIndexUpdates=[gsi_def],
                    )

                    logger.info(
                        f"Initiated creation of GSI {gsi_name} on table {table_name}"
                    )

                    # Wait for this GSI to complete before processing the next one
                    logger.info(f"Waiting for GSI {gsi_name} to become active...")
                    while True:
                        target_dynamodb = get_target_dynamodb_client()
                        current_desc = target_dynamodb.describe_table(
                            TableName=table_name
                        )["Table"]
                        gsi_status = None

                        # Find the GSI we just created
                        for idx in current_desc.get("GlobalSecondaryIndexes", []):
                            if idx["IndexName"] == gsi_name:
                                gsi_status = idx.get("IndexStatus")
                                break

                        if gsi_status == "ACTIVE":
                            logger.info(f"GSI {gsi_name} is now active")
                            break
                        else:
                            logger.info(
                                f"GSI {gsi_name} status: {gsi_status}, waiting..."
                            )
                            import time

                            time.sleep(15)

            # ===== SYNC LSIs =====
            # Note: LSIs can only be created when the table is created, not added later
            # We'll log if there are LSIs that couldn't be added
            source_lsis = source_desc.get("LocalSecondaryIndexes", [])
            target_lsis = target_desc.get("LocalSecondaryIndexes", [])

            if source_lsis and not target_lsis:
                logger.warning(
                    f"Table {table_name} has LSIs in source that cannot be added to existing table in target. "
                    f"LSIs can only be created when the table is created."
                )

            # ===== SYNC TTL =====
            try:
                source_ttl = source_dynamodb.describe_time_to_live(TableName=table_name)
                target_ttl = target_dynamodb.describe_time_to_live(TableName=table_name)

                # If TTL is enabled in source but not in target
                if (
                    source_ttl.get("TimeToLiveDescription", {}).get("TimeToLiveStatus")
                    == "ENABLED"
                    and target_ttl.get("TimeToLiveDescription", {}).get(
                        "TimeToLiveStatus"
                    )
                    != "ENABLED"
                ):
                    updates_needed = True
                    ttl_attr = source_ttl["TimeToLiveDescription"]["AttributeName"]
                    updates_applied.append(f"Enabled TTL on attribute: {ttl_attr}")

                    # Enable TTL on target
                    target_dynamodb.update_time_to_live(
                        TableName=table_name,
                        TimeToLiveSpecification={
                            "Enabled": True,
                            "AttributeName": ttl_attr,
                        },
                    )

                    logger.info(
                        f"Enabled TTL on table {table_name} with attribute {ttl_attr}"
                    )

            except Exception as ttl_error:
                logger.error(
                    f"Error syncing TTL for table {table_name}: {str(ttl_error)}"
                )

            # Report update status
            if updates_needed:
                updated_tables.append(
                    {"table_name": table_name, "updates": updates_applied}
                )
                logger.info(f"Successfully updated table {table_name} structure")
            else:
                logger.info(f"No structural updates needed for {table_name}")

        except Exception as e:
            logger.error(f"Error synchronizing table {table_name}: {str(e)}")

    logger.info(
        f"Structure synchronization complete. Updated {len(updated_tables)} tables."
    )
    return {
        "statusCode": 200,
        "message": f"Updated {len(updated_tables)} tables",
        "updatedTables": updated_tables,
    }


"""
This script processes DynamoDB stream events and replicates changes to the target DynamoDB table in the China account.
"""


def lambda_handler(event, context):
    """
    Lambda handler that processes DynamoDB stream events and replicates changes
    to the target DynamoDB table in the China account.
    """
    logger.info(f"Received {len(event.get('Records', []))} records")

    target_dynamodb = get_target_dynamodb_client()

    # Process each record in the stream
    for record in event.get("Records", []):
        try:
            # Extract the DynamoDB event information
            event_name = record["eventName"]  # INSERT, MODIFY, REMOVE
            dynamodb_data = record["dynamodb"]
            table_name = record["eventSourceARN"].split("/")[1]

            logger.info(f"Processing {event_name} event for table {table_name}")

            # Handle different event types
            if event_name == "INSERT" or event_name == "MODIFY":
                # For INSERT and MODIFY events, use put_item
                new_image = dynamodb_data.get("NewImage")
                if new_image:
                    if table_name == "ADGProductDocument":
                        new_image = process_binary_fields(new_image)
                    target_dynamodb.put_item(TableName=table_name, Item=new_image)
                    logger.info(f"Successfully replicated {event_name} for item")

            elif event_name == "REMOVE":
                # For REMOVE events, use delete_item
                keys = dynamodb_data.get("Keys")
                if keys:
                    target_dynamodb.delete_item(TableName=table_name, Key=keys)
                    logger.info(f"Successfully deleted item from {table_name}")

        except Exception as e:
            # Handle client errors (e.g., throttling, permission issues)
            logger.error(f"Error processing record: {str(e)}")
            if e.response["Error"]["Code"] == "ResourceNotFoundException":
                logger.warning(f"Table {table_name} not found in target account")
            elif (
                e.response["Error"]["Code"] == "ProvisionedThroughputExceededException"
            ):
                logger.warning(
                    f"Throttling encountered, consider implementing retry with backoff"
                )
            else:
                # For other errors, re-raise to trigger Lambda retry
                raise

    return {
        "statusCode": 200,
        "body": json.dumps(
            f"Successfully processed {len(event.get('Records', []))} records"
        ),
    }


def process_binary_fields(item):
    """
    Process an item from DynamoDB to properly handle binary fields.
    Specifically, this prevents the CompressedContent field from being double-encoded.

    Args:
        item (dict): DynamoDB item with potentially binary fields

    Returns:
        dict: Processed item with properly formatted binary fields
    """
    processed_item = {}

    for key, value in item.items():
        # Process binary fields specifically
        if "B" in value:
            binary_data = value["B"]

            # Handle the binary data based on its type
            if isinstance(binary_data, str):
                # For string representation of binary data (from DynamoDB stream)
                try:
                    # Decode from base64 to get the raw binary data
                    decoded_data = base64.b64decode(binary_data)
                    # Use the raw bytes directly in the DynamoDB item
                    processed_item[key] = {"B": decoded_data}
                except Exception as e:
                    # Fallback to using the original string if decoding fails
                    processed_item[key] = {"B": binary_data}
            else:
                # If it's already bytes, use it directly
                processed_item[key] = {"B": binary_data}
        else:
            # For non-binary fields, copy as-is
            processed_item[key] = value

    return processed_item
