#!/usr/bin/env python3
"""
Clean Flask UI - Direct orchestrator calls, no stdout parsing
"""

from flask import Flask, render_template, request, jsonify, Response
import json
import sys
import os

sys.path.append('/Users/harinaar/hackathon-agentic-sde/')

app = Flask(__name__)
latest_comments = ""
publisher_response = ""

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/get_comments', methods=['GET'])
def get_comments():
    return jsonify({'comments': latest_comments})


@app.route('/get_comments_by_publisher', methods=['GET'])
def get_comments_by_publisher():
    return jsonify({'comments': publisher_response})

@app.route('/set_comments', methods=['POST'])
def set_comments():
    global latest_comments
    data = request.json
    latest_comments = data.get('comments', '')
    return jsonify({'success': True})

@app.route('/run_workflow', methods=['POST'])
def run_workflow():
    try:
        data = request.json
        package_path = data.get('package_path', '')
        prompt = data.get('prompt', '')
        
        if not package_path or not prompt:
            return jsonify({
                'success': False, 
                'error': 'Package path and prompt are required'
            })
        
        return jsonify({'success': True, 'message': 'Workflow started'})
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })

@app.route('/stream_workflow')
def stream_workflow():
    package_path = request.args.get('package_path')
    prompt = request.args.get('prompt')
    
    def generate():
        try:
            from simple_orchestrator import SimpleOrchestrator
            
            yield f"data: {json.dumps({'type': 'step', 'message': 'Starting workflow...'})}\n\n"
            
            orchestrator = SimpleOrchestrator()
            
            # Register ALL agents (same as orchestrator)
            try:
                from midway_auth_agent import MidwayAuthAgent
                orchestrator.register_agent("midway_auth_agent", MidwayAuthAgent())
                yield f"data: {json.dumps({'type': 'status', 'message': '✓ Auth agent registered'})}\n\n"
            except ImportError:
                pass
            
            from generic_ai_agent_simple import GenericAIAgent
            orchestrator.register_agent("code_agent", GenericAIAgent())
            yield f"data: {json.dumps({'type': 'status', 'message': '✓ AI agent registered'})}\n\n"
            
            from build_agent import AIBuildAgent
            orchestrator.register_agent("build_agent", AIBuildAgent())
            yield f"data: {json.dumps({'type': 'status', 'message': '✓ Build agent registered'})}\n\n"
            
            from CR_raiser_agent import CRRaiserAgent
            orchestrator.register_agent("cr_raiser_agent", CRRaiserAgent())
            yield f"data: {json.dumps({'type': 'status', 'message': '✓ CR raiser agent registered'})}\n\n"
            
            from simple_review_agent import SimpleReviewAgent
            orchestrator.register_agent("cr_review_agent", SimpleReviewAgent())
            yield f"data: {json.dumps({'type': 'status', 'message': '✓ Review agent registered'})}\n\n"
            
            from responder_agent import ResponderAgent
            orchestrator.register_agent("responder_agent", ResponderAgent())
            yield f"data: {json.dumps({'type': 'status', 'message': '✓ Responder agent registered'})}\n\n"
            
            # Execute workflow with ALL steps (same as orchestrator)
            
            # Step 0: Auth
            if "midway_auth_agent" in orchestrator.agents:
                yield f"data: {json.dumps({'type': 'step', 'message': 'Step 0: Authentication...'})}\n\n"
                auth_result = orchestrator.agents["midway_auth_agent"].ensure_auth()
                if not auth_result.get("success"):
                    yield f"data: {json.dumps({'type': 'error', 'error': 'Authentication failed'})}\n\n"
                    return
                yield f"data: {json.dumps({'type': 'status', 'message': '✓ Authentication completed'})}\n\n"
            
            # Step 1: Code generation
            yield f"data: {json.dumps({'type': 'step', 'message': 'Step 1: Writing code...'})}\n\n"
            if "code_agent" in orchestrator.agents:
                code_result = orchestrator.agents["code_agent"].process_request(prompt, package_path)
                if not code_result.get("success"):
                    yield f"data: {json.dumps({'type': 'error', 'error': 'Code generation failed'})}\n\n"
                    return
                yield f"data: {json.dumps({'type': 'status', 'message': '✓ Code generated'})}\n\n"
            
            # Step 2: Build
            yield f"data: {json.dumps({'type': 'step', 'message': 'Step 2: Building...'})}\n\n"
            if "build_agent" in orchestrator.agents:
                build_result = orchestrator.agents["build_agent"].build_package(package_path)
                if not build_result.get("success"):
                    yield f"data: {json.dumps({'type': 'error', 'error': 'Build failed'})}\n\n"
                    return
                yield f"data: {json.dumps({'type': 'status', 'message': '✓ Build completed'})}\n\n"
            
            # Step 3: Create CR
            yield f"data: {json.dumps({'type': 'step', 'message': 'Step 3: Creating CR...'})}\n\n"
            cr_url = None
            if "cr_raiser_agent" in orchestrator.agents:
                cr_result = orchestrator.agents["cr_raiser_agent"].create_review(package_path, prompt)
                if cr_result.get("success"):
                    cr_url = cr_result.get("cr_url")
                    yield f"data: {json.dumps({'type': 'cr_url', 'message': f'CR URL: {cr_url}', 'url': cr_url})}\n\n"
                else:
                    yield f"data: {json.dumps({'type': 'error', 'error': 'CR creation failed'})}\n\n"
                    return
            
            # Step 4: Review
            yield f"data: {json.dumps({'type': 'step', 'message': 'Step 4: Reviewing CR...'})}\n\n"
            review_comments = []
            if "cr_review_agent" in orchestrator.agents:
                review_result = orchestrator.agents["cr_review_agent"].review_cr(cr_url, package_path)
                if review_result.get("success"):
                    review_comments = review_result.get("comments", [])
                    yield f"data: {json.dumps({'type': 'status', 'message': '✓ Review completed'})}\n\n"
            
            # Final results
            if review_comments:
                global latest_comments, publisher_response
                prefixed_comments = [f"REVIEWER-AGENT -> {comment}" for comment in review_comments]
                latest_comments = '\n'.join(prefixed_comments)
                yield f"data: {json.dumps({'type': 'review_complete', 'comments': latest_comments})}\n\n"
                
                # Generate response using responder agent
                yield f"data: {json.dumps({'type': 'step', 'message': 'Step 5: Generating response...'})}\n\n"
                try:
                    from responder_agent import ResponderAgent
                    responder = ResponderAgent()
                    response_result = responder.generate_response(latest_comments, package_path)
                    
                    if response_result.get("success"):
                        publisher_response = f"RESPONDER-AGENT -> {response_result.get('response', '')}"
                        yield f"data: {json.dumps({'type': 'status', 'message': '✓ Response generated'})}\n\n"
                    else:
                        publisher_response = "RESPONDER-AGENT -> Thank you for the feedback! We'll address this in a future iteration."
                        yield f"data: {json.dumps({'type': 'status', 'message': '✓ Fallback response generated'})}\n\n"
                        
                except Exception as e:
                    publisher_response = "RESPONDER-AGENT -> Thank you for the feedback! We'll address this in a future iteration."
                    yield f"data: {json.dumps({'type': 'status', 'message': '✓ Default response generated'})}\n\n"
                    
            else:
                latest_comments = 'REVIEWER-AGENT -> LGTM'
                publisher_response = 'RESPONDER-AGENT -> Thank you for the review!'
                yield f"data: {json.dumps({'type': 'review_complete', 'comments': 'REVIEWER-AGENT -> LGTM'})}\n\n"
            
            yield f"data: {json.dumps({'type': 'complete', 'success': True})}\n\n"
                
        except Exception as e:
            yield f"data: {json.dumps({'type': 'error', 'error': str(e)})}\n\n"
    
    return Response(generate(), mimetype='text/event-stream', headers={
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive'
    })

if __name__ == '__main__':
    app.run(debug=True, port=5000)
