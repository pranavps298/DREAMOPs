// ==UserScript==
// @name         Conditional Auto Override & Merge
// @namespace    http://tampermonkey.net/
// @version      0.5
// @description  Auto-click based on badge and analyzer status, including Merge All Packages safely
// @match        https://code.amazon.com/reviews/CR-*
// @grant        none
// @run-at       document-idle
// ==/UserScript==

(function () {
  'use strict';

  function waitFor(selector, callback, timeout = 10000) {
    const start = Date.now();
    (function check() {
      const el = document.querySelector(selector);
      if (el) return callback(el);
      if (Date.now() - start < timeout) return setTimeout(check, 200);
    })();
  }

  function isReady() {
    const badge = document.querySelector('div[awsui-badge-region="content"] span.ng-binding');
    const status = document.querySelector('div.analyzer-status span.ng-binding');
    return badge?.textContent.trim() === 'Open';
  }

  function triggerInputEvents(el) {
    el.focus();
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.blur();
  }

  function proceed() {
    // 1. Click the "Actions" button
    const actionsBtn = [...document.querySelectorAll('button.awsui-button')]
      .find(b => b.textContent.trim() === 'Actions');
    if (!actionsBtn) return;
    actionsBtn.click();

    // 2. Click "Override & merge"
    waitFor('li.awsui-button-dropdown-item', () => {
      const mergeItem = [...document.querySelectorAll('li.awsui-button-dropdown-item')]
        .find(li => li.textContent.trim() === 'Override & merge');
      if (!mergeItem) return;
      mergeItem.click();

      // 3. Wait for textarea and fill comment
      waitFor('textarea.awsui-textarea', textarea => {
        textarea.value = 'Does not require approvals (Hackathon)';
        triggerInputEvents(textarea);

        // 4. Click "Continue"
        waitFor('button.awsui-button.awsui-button-variant-primary', btn => {
          if (btn.textContent.trim() === 'Continue') {
            btn.click();

            // 5. Wait and then click "Merge all packages"
            setTimeout(() => {
              waitFor('button.awsui-button-variant-primary', () => {
                const mergeBtn = [...document.querySelectorAll('button.awsui-button-variant-primary')]
                  .find(b =>
                    b.textContent.trim() === 'Merge all packages' &&
                    !b.disabled &&
                    b.getAttribute('aria-disabled') !== 'true'
                  );

                if (mergeBtn) {
                  mergeBtn.click();
                } else {
                  // Retry after short delay in case Angular hasn't enabled it yet
                  setTimeout(() => {
                    const retryBtn = [...document.querySelectorAll('button.awsui-button-variant-primary')]
                      .find(b =>
                        b.textContent.trim() === 'Merge all packages' &&
                        !b.disabled &&
                        b.getAttribute('aria-disabled') !== 'true'
                      );
                    if (retryBtn) retryBtn.click();
                  }, 1000);
                }
              });
            }, 1000); // 1-second delay for Angular digest cycle
          }
        });
      });
    });
  }

  function init() {
    if (isReady()) {
      setTimeout(init, 5000);
      proceed();
    } else {
      setTimeout(init, 500);
    }
  }

  window.addEventListener('load', () => setTimeout(init, 1000));
})();