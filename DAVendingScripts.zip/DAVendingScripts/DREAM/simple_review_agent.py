#!/usr/bin/env python3
"""
Simple Review Agent - Uses Q CLI for generic code review
"""

import os
import subprocess

class SimpleReviewAgent:
    """Simple agent that uses Q CLI for code review"""
    
    def review_cr(self, cr_url, package_path):
        """Review latest commit using Q CLI"""
        
        print("✓ Reviewing latest commit in: {}".format(package_path))
        
        if not os.path.exists(package_path):
            return {"success": False, "error": "Package path not found"}
        
        # Get latest commit changes
        diff_content = self._get_commit_diff(package_path)
        if not diff_content:
            return {"success": True, "comments": ["LGTM"]}
        
        # Use Q CLI to review the changes
        comment = self._review_with_q(diff_content)
        
        return {"success": True, "comments": [comment]}
    
    def _get_commit_diff(self, package_path):
        """Get diff from latest commit"""
        original_dir = os.getcwd()
        try:
            os.chdir(package_path)
            
            # Get the actual diff content
            result = subprocess.run(['git', 'show', 'HEAD'], 
                                  capture_output=True, text=True)
            
            if result.returncode == 0 and result.stdout.strip():
                return result.stdout.strip()
                
        except Exception as e:
            print(f"Error getting diff: {e}")
        finally:
            os.chdir(original_dir)
        
        return None
    
    def _review_with_q(self, diff_content):
        """Use Q CLI to review the code changes"""
        
        print(f"DEBUG: Analyzing diff with Q CLI")
        
        # Create a focused prompt for Q
        prompt = f"""Review this git diff and provide ONE specific, actionable comment. Focus on critical issues like bugs, security, or performance problems. If the code looks good, just say "LGTM".

{diff_content}

Provide exactly one bullet point comment starting with •"""

        try:
            # Use Q CLI to review the code
            result = subprocess.run(['q', 'chat', '--no-interactive', '--trust-all-tools'], 
                                  input=prompt, 
                                  capture_output=True, 
                                  text=True)
            
            if result.returncode == 0 and result.stdout.strip():
                response = result.stdout.strip()
                print(f"DEBUG: Q response: {response}")
                
                # Aggressive cleaning of Q CLI output
                import re
                clean_response = response
                
                # Remove ANSI color codes
                clean_response = re.sub(r'\x1b\[[0-9;]*m', '', clean_response)
                
                # Remove timing info like "10m>", "5s>", etc.
                clean_response = re.sub(r'\d+[ms]>\s*', '', clean_response)
                
                # Remove common Q CLI prefixes and artifacts
                clean_response = re.sub(r'^[>\s]*', '', clean_response, flags=re.MULTILINE)
                clean_response = re.sub(r'^\s*[•\-\*]\s*[•\-\*]\s*', '• ', clean_response, flags=re.MULTILINE)
                
                # Remove extra whitespace and clean up
                clean_response = re.sub(r'\s+', ' ', clean_response)
                clean_response = clean_response.strip()
                
                # Extract the first meaningful line
                lines = [line.strip() for line in clean_response.split('\n') if line.strip()]
                
                for line in lines:
                    # Skip common Q CLI intro phrases
                    if any(skip in line.lower() for skip in ['here', 'based on', 'looking at', 'i can see', 'after reviewing']):
                        continue
                        
                    # Look for actual feedback
                    if line.startswith('•'):
                        return line
                    elif any(line.lower().startswith(word) for word in ['consider', 'add', 'use', 'avoid', 'ensure', 'check']):
                        return '• ' + line
                    elif 'lgtm' in line.lower():
                        return "LGTM"
                    elif len(line) > 15:  # Meaningful content
                        return '• ' + line
                
                # Fallback to first non-empty line
                if lines:
                    first_line = lines[0]
                    if not first_line.startswith('•'):
                        return '• ' + first_line
                    return first_line
                
        except Exception as e:
            print(f"DEBUG: Error calling Q: {e}")
        
        # Fallback if Q fails
        return "LGTM"
