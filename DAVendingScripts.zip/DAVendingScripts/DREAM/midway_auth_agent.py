#!/usr/bin/env python3
"""
Midway Auth Agent - Ensures Amazon authentication before other agents run
"""

import os
import sys
import subprocess

class MidwayAuthAgent:
    """Agent that ensures Midway authentication is valid"""
    
    def ensure_auth(self):
        """Check Midway credentials and prompt for mwinit if needed"""
        
        print("Midway Auth Agent: Checking authentication...")
        
        cookie_path = os.path.expanduser('~/.midway/cookie')
        
        # Test if current auth is valid
        if not os.path.exists(cookie_path) or not self._test_auth():
            print("Midway credentials expired or missing.")
            print("Please run 'mwinit' to refresh your credentials.")
            
            raw_input("Press Enter after running mwinit... ")
            
            if not self._test_auth():
                return {
                    "success": False,
                    "error": "Midway credentials still not valid after mwinit"
                }
            
            print("Midway credentials verified")
        else:
            print("Using existing Midway credentials")
        
        return {
            "success": True,
            "message": "Midway authentication verified"
        }
    
    def _test_auth(self):
        """Test if Midway credentials are valid"""
        try:
            # Test with mwinit -s (status)
            result = subprocess.Popen(['mwinit', '-s'], 
                                    stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            stdout, stderr = result.communicate()
            
            if result.returncode == 0:
                return True
            
            # Fallback: test with Q CLI
            result = subprocess.Popen(['q', 'chat', '--no-interactive', 'test'], 
                                    stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            stdout, stderr = result.communicate()
            
            return result.returncode == 0
            
        except (OSError, subprocess.CalledProcessError):
            return False
    
    def get_auth_status(self):
        """Get current authentication status"""
        
        cookie_path = os.path.expanduser('~/.midway/cookie')
        
        return {
            "cookie_exists": os.path.exists(cookie_path),
            "auth_valid": self._test_auth(),
            "cookie_path": cookie_path
        }

def main():
    """CLI interface for auth agent"""
    
    agent = MidwayAuthAgent()
    
    if len(sys.argv) > 1 and sys.argv[1] == '--status':
        # Just check status
        status = agent.get_auth_status()
        print("Auth Status:")
        print("- Cookie exists: {}".format(status["cookie_exists"]))
        print("- Auth valid: {}".format(status["auth_valid"]))
        print("- Cookie path: {}".format(status["cookie_path"]))
    else:
        # Ensure auth
        result = agent.ensure_auth()
        
        if result["success"]:
            print("SUCCESS: {}".format(result["message"]))
            sys.exit(0)
        else:
            print("ERROR: {}".format(result["error"]))
            sys.exit(1)

if __name__ == "__main__":
    main()
