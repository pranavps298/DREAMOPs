#!/usr/bin/env python3
"""
Simple Generic AI Agent - Uses Q CLI to generate code
"""

import os
import subprocess
import re

class GenericAIAgent:
    """Simple AI agent that uses Q CLI for code generation"""
    
    def process_request(self, request, package_path):
        """Process user request and generate code using Q CLI"""
        
        print("Processing: {}".format(request))
        print("Package: {}".format(package_path))
        
        if not os.path.exists(package_path):
            return {"success": False, "error": "Package path not found"}
        
        # Get context from existing files
        context = self._get_package_context(package_path)
        
        # Create enhanced prompt for Q CLI
        prompt = f"""I need to implement: {request}

Package location: {package_path}

Existing files and structure:
{context}

IMPORTANT INSTRUCTIONS:
1. Analyze the existing files to understand the current codebase structure
2. Modify existing files where appropriate rather than creating new ones
3. If there are existing Python files, add your code to them
4. If there are test files, update them with new test cases
5. Follow the existing code style and patterns
6. Use the fs_write tool to modify files directly in the package directory
7. Make sure your changes integrate well with existing code

Please implement the requested functionality by modifying the appropriate existing files or creating new ones only if necessary."""

        # Use Q CLI to generate code
        result = self._call_q_cli(prompt)
        
        if result:
            return {"success": True, "response": result}
        else:
            return {"success": False, "error": "Q CLI failed to generate code"}
    
    def _get_package_context(self, package_path):
        """Get detailed context from existing files in the package"""
        context = []
        
        try:
            context.append(f"Package structure for: {package_path}")
            context.append("=" * 50)
            
            for root, dirs, files in os.walk(package_path):
                # Skip hidden directories and common build directories
                dirs[:] = [d for d in dirs if not d.startswith('.') and d not in ['build', 'target', '__pycache__']]
                
                level = root.replace(package_path, '').count(os.sep)
                indent = '  ' * level
                context.append(f"{indent}{os.path.basename(root)}/")
                
                subindent = '  ' * (level + 1)
                for file in files:
                    if not file.startswith('.'):
                        file_path = os.path.join(root, file)
                        rel_path = os.path.relpath(file_path, package_path)
                        
                        # Add file with basic info
                        if file.endswith(('.py', '.java', '.js', '.ts', '.cpp', '.c', '.h')):
                            try:
                                with open(file_path, 'r', encoding='utf-8') as f:
                                    content = f.read()
                                    lines = len(content.split('\n'))
                                    # Get first few lines for context
                                    preview = '\n'.join(content.split('\n')[:3])
                                    context.append(f"{subindent}{file} ({lines} lines)")
                                    context.append(f"{subindent}  Preview: {preview[:100]}...")
                            except:
                                context.append(f"{subindent}{file}")
                        else:
                            context.append(f"{subindent}{file}")
                        
                        # Limit to avoid huge context
                        if len(context) > 30:
                            context.append("  ... (more files)")
                            break
                            
                if len(context) > 30:
                    break
                    
        except Exception as e:
            print(f"Error reading package context: {e}")
            context = [f"Error reading package structure: {e}"]
            
        return '\n'.join(context)
    
    def _call_q_cli(self, prompt):
        """Call Q CLI to generate code"""
        try:
            print("Calling Q CLI...")
            
            result = subprocess.run([
                'q', 'chat', '--no-interactive', '--trust-all-tools'
            ], input=prompt, capture_output=True, text=True, timeout=120)
            
            if result.returncode == 0:
                # Clean up response
                clean_response = re.sub(r'\x1b\[[0-9;]*m', '', result.stdout.strip())
                clean_response = re.sub(r'\d+[ms]>', '', clean_response)
                print("Q CLI completed successfully")
                return clean_response.strip()
            else:
                print("Q CLI Error: {}".format(result.stderr))
                print("Q CLI stdout: {}".format(result.stdout))
                return None
                
        except subprocess.TimeoutExpired:
            print("Q CLI timeout after 60 seconds")
            return None
        except FileNotFoundError:
            print("Q CLI not found - is it installed?")
            return None
        except Exception as e:
            print("Q CLI Exception: {}".format(e))
            return None
