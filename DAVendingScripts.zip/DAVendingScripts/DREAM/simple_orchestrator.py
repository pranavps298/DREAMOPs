#!/usr/bin/env python3
"""
Simple Orchestrator - 4 agents only: Auth -> Code -> Build -> CR
"""

import os
import sys

class SimpleOrchestrator:
    """Simple orchestrator with single responsibility agents"""
    
    def __init__(self):
        self.agents = {}
    
    def register_agent(self, name, agent_instance):
        """Register an agent"""
        self.agents[name] = agent_instance
        print("Registered agent: {}".format(name))
    
    def execute_workflow(self, request, package_path):
        """Execute: Auth -> Code -> Build -> CR"""
        
        print("Starting workflow: {}".format(request))
        
        # Step 0: Auth
        if "midway_auth_agent" in self.agents:
            print("Step 0: Authentication")
            auth_result = self.agents["midway_auth_agent"].ensure_auth()
            if not auth_result.get("success"):
                return {"success": False, "error": "Auth failed"}
        
        # Step 1: Code
        if "code_agent" in self.agents:
            print("Step 1: Writing code")
            code_result = self.agents["code_agent"].process_request(request, package_path)
            if not code_result.get("success"):
                return {"success": False, "error": "Code failed"}
        
        # Step 2: Build
        if "build_agent" in self.agents:
            print("Step 2: Building")
            build_result = self.agents["build_agent"].build_package(package_path)
            if not build_result.get("success"):
                return {"success": False, "error": "Build failed"}
        
        # Step 3: CR
        cr_url = None
        if "cr_raiser_agent" in self.agents:
            print("Step 3: Creating CR")
            cr_result = self.agents["cr_raiser_agent"].create_review(package_path, request)
            print(f"DEBUG: CR result: {cr_result}")
            if cr_result.get("success"):
                cr_url = cr_result.get("cr_url")
                print("CR URL: {}".format(cr_url))
            else:
                print(f"DEBUG: CR creation failed: {cr_result}")
                return {"success": False, "error": "CR failed"}
        
        # Step 4: Review (run even if no CR URL for testing)
        review_comments = []
        if "cr_review_agent" in self.agents:
            print("Step 4: Reviewing CR")
            review_result = self.agents["cr_review_agent"].review_cr(cr_url, package_path)
            print(f"DEBUG: Review result: {review_result}")
            if review_result.get("success"):
                review_comments = review_result.get("comments", [])
                print(f"DEBUG: Got {len(review_comments)} comments from review agent: {review_comments}")
                print("Review Comments:")
                print("=" * 50)
                for comment in review_comments:
                    print(comment)
                print("=" * 50)
        
        # Step 5: Generate response to review comments
        response_comments = []
        if "responder_agent" in self.agents and review_comments:
            print("Step 5: Generating response")
            reviewer_text = '\n'.join([f"REVIEWER-AGENT -> {comment}" for comment in review_comments])
            response_result = self.agents["responder_agent"].generate_response(reviewer_text, package_path)
            if response_result.get("success"):
                response_comments = [response_result.get("response", "")]
                print(f"DEBUG: Generated response: {response_comments}")
        
        return {"success": True, "cr_url": cr_url, "review_comments": review_comments, "response_comments": response_comments}

def main():
    if len(sys.argv) < 3:
        print("Usage: python simple_orchestrator.py <package_path> '<request>'")
        sys.exit(1)
    
    package_path = sys.argv[1]
    request = sys.argv[2]
    
    orchestrator = SimpleOrchestrator()
    
    # Register all agents
    try:
        from midway_auth_agent import MidwayAuthAgent
        orchestrator.register_agent("midway_auth_agent", MidwayAuthAgent())
    except ImportError:
        pass
    
    try:
        from generic_ai_agent import GenericAIAgent
        orchestrator.register_agent("code_agent", GenericAIAgent())
    except ImportError:
        pass
    
    try:
        from build_agent import AIBuildAgent
        orchestrator.register_agent("build_agent", AIBuildAgent())
    except ImportError:
        pass
    
    try:
        from CR_raiser_agent import CRRaiserAgent
        orchestrator.register_agent("cr_raiser_agent", CRRaiserAgent())
        print("✓ CR Raiser agent registered")
    except ImportError as e:
        print(f"✗ Failed to import CR raiser agent: {e}")
    except Exception as e:
        print(f"✗ Error registering CR raiser agent: {e}")
    
    try:
        from simple_review_agent import SimpleReviewAgent
        orchestrator.register_agent("cr_review_agent", SimpleReviewAgent())
        print("✓ Simple Review agent registered")
    except ImportError as e:
        print("✗ Failed to import simple_review_agent: {}".format(e))
    except Exception as e:
        print("✗ Error registering simple_review_agent: {}".format(e))
    
    try:
        from responder_agent import ResponderAgent
        orchestrator.register_agent("responder_agent", ResponderAgent())
        print("✓ Responder agent registered")
    except ImportError as e:
        print("✗ Failed to import responder_agent: {}".format(e))
    except Exception as e:
        print("✗ Error registering responder_agent: {}".format(e))
    
    result = orchestrator.execute_workflow(request, package_path)
    print("\nResult:", result)

if __name__ == "__main__":
    main()
