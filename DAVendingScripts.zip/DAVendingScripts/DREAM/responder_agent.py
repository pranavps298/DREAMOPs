#!/usr/bin/env python3
"""
Responder Agent - Generates polite responses to reviewer comments
"""

import os
import subprocess
import re

class ResponderAgent:
    """Agent that responds to reviewer comments politely"""
    
    def generate_response(self, reviewer_comment, package_path):
        """Generate a polite response to reviewer comment"""
        
        print(f"Generating response to: {reviewer_comment}")
        
        if not os.path.exists(package_path):
            return {"success": False, "error": "Package path not found"}
        
        # Get context from package changes
        context = self._get_package_context(package_path)
        
        # Create prompt for Q CLI
        prompt = f"""I received this code review comment: "{reviewer_comment}"

Package location: {package_path}
Recent changes context:
{context}

Generate a direct, polite response that acknowledges the feedback but explains it's not critical for current implementation and can be addressed later. Be concise and professional. Don't start with "This is a response" or similar - just give the actual response content."""

        # Use Q CLI to generate response
        response = self._call_q_cli(prompt)
        
        if response:
            return {"success": True, "response": response}
        else:
            # Fallback response
            fallback = "Thank you for the feedback! This is a good suggestion that we can address in a future iteration. For now, the current implementation meets the immediate requirements, but I'll create a follow-up task to incorporate your suggestion."
            return {"success": True, "response": fallback}
    
    def _get_package_context(self, package_path):
        """Get context from recent changes in the package"""
        context = []
        
        try:
            # Get git diff to understand recent changes
            original_dir = os.getcwd()
            os.chdir(package_path)
            
            result = subprocess.run(['git', 'diff', 'HEAD~1'], 
                                  capture_output=True, text=True)
            
            if result.returncode == 0 and result.stdout.strip():
                # Get summary of changes
                lines = result.stdout.split('\n')
                added_lines = [line for line in lines if line.startswith('+') and not line.startswith('+++')]
                
                context.append(f"Recent changes: {len(added_lines)} lines added")
                
                # Get file names that changed
                files_result = subprocess.run(['git', 'diff', '--name-only', 'HEAD~1'], 
                                            capture_output=True, text=True)
                if files_result.returncode == 0:
                    files = files_result.stdout.strip().split('\n')
                    context.append(f"Files modified: {', '.join(files[:3])}")
            
            os.chdir(original_dir)
            
        except Exception as e:
            print(f"Error getting package context: {e}")
            context.append("Unable to get recent changes context")
            
        return '\n'.join(context) if context else "No recent changes found"
    
    def _call_q_cli(self, prompt):
        """Call Q CLI to generate response"""
        try:
            print("Calling Q CLI for response generation...")
            
            result = subprocess.run([
                'q', 'chat', '--no-interactive', '--trust-all-tools'
            ], input=prompt, capture_output=True, text=True, timeout=60)
            
            if result.returncode == 0:
                response = result.stdout.strip()
                
                # Aggressive cleaning of Q CLI output
                import re
                clean_response = response
                
                # Remove ANSI color codes
                clean_response = re.sub(r'\x1b\[[0-9;]*m', '', clean_response)
                
                # Remove timing info like "10m>", "5s>", etc.
                clean_response = re.sub(r'\d+[ms]>\s*', '', clean_response)
                
                # Remove common Q CLI prefixes and artifacts
                clean_response = re.sub(r'^[>\s]*', '', clean_response, flags=re.MULTILINE)
                
                # Remove extra whitespace
                clean_response = re.sub(r'\s+', ' ', clean_response)
                clean_response = clean_response.strip()
                
                # Skip intro phrases and get to actual content
                lines = [line.strip() for line in clean_response.split('\n') if line.strip()]
                
                for line in lines:
                    # Skip meta phrases
                    if any(skip in line.lower() for skip in ['here is', 'this is a response', 'i understand', 'based on']):
                        continue
                    
                    # Look for actual response content
                    if len(line) > 10:
                        return line
                
                # Fallback to first meaningful line
                if lines:
                    return lines[0]
                    
                return clean_response.strip()
            else:
                print("Q CLI Error: {}".format(result.stderr))
                return None
                
        except subprocess.TimeoutExpired:
            print("Q CLI timeout for response generation")
            return None
        except Exception as e:
            print("Q CLI Exception: {}".format(e))
            return None
