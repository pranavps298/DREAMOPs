// ==UserScript==
// @name         CR Comment Automation - Full Workflow
// @namespace    http://tampermonkey.net/
// @version      2.0
// @description  Complete workflow: reviewer comment → publish → responder reply → publish → publish review
// @match        https://code.amazon.com/reviews/CR-*
// @run-at       document-end
// @grant        GM_xmlhttpRequest
// ==/UserScript==

(function() {
    'use strict';

    // Track workflow state
    let workflowState = {
        reviewerCommentPosted: false,
        reviewerCommentPublished: false,
        responderReplyPosted: false,
        responderReplyPublished: false,
        reviewPublished: false,
        isProcessing: false
    };

    function ensureCommentsTabActive() {
        console.log("🔍 Ensuring Comments tab is active...");

        const commentsTab = document.querySelector('a[href="#/comments"]') ||
                           document.querySelector('a.awsui-tabs-tab-link[href="#/comments"]') ||
                           document.querySelector('a[role="tab"][href="#/comments"]');

        if (!commentsTab) {
            const allTabs = document.querySelectorAll('a[role="tab"]');
            for (let tab of allTabs) {
                if (tab.textContent && tab.textContent.includes('Comments')) {
                    console.log("✅ Found Comments tab by text content, clicking...");
                    tab.click();
                    setTimeout(() => {
                        console.log("✅ Comments tab clicked, starting workflow...");
                        startWorkflow();
                    }, 2000);
                    return;
                }
            }
        }

        if (commentsTab) {
            console.log("✅ Found Comments tab, clicking...");
            commentsTab.click();
            setTimeout(() => {
                console.log("✅ Comments tab clicked, starting workflow...");
                startWorkflow();
            }, 2000);
        } else {
            console.log("❌ Comments tab not found, starting workflow anyway...");
            setTimeout(startWorkflow, 1000);
        }
    }

    function startWorkflow() {
        if (workflowState.isProcessing) {
            console.log("⏸️ Workflow already in progress");
            return;
        }

        if (workflowState.reviewPublished) {
            console.log("🎉 Full workflow already completed!");
            return;
        }

        workflowState.isProcessing = true;
        console.log("🚀 Starting full CR comment workflow...");
        console.log("Current state:", workflowState);

        // Step 1: Post REVIEWER-AGENT comment
        if (!workflowState.reviewerCommentPosted) {
            checkForReviewerComment();
        }
        // Step 2: Post RESPONDER-AGENT reply (will be triggered after reviewer comment is published)
        else if (!workflowState.responderReplyPosted) {
            checkForResponderReply();
        }
        // Step 3: Publish review (will be triggered after responder reply is published)
        else if (!workflowState.reviewPublished) {
            setTimeout(() => {
                publishReview();
            }, 5000); // 5 second wait before final publish
        }
    }

    function checkForReviewerComment() {
        console.log("📝 Step 1: Checking for REVIEWER-AGENT comment...");

        GM_xmlhttpRequest({
            method: 'GET',
            url: 'http://localhost:5000/get_comments',
            timeout: 10000,
            onload: function(response) {
                try {
                    if (response.status === 200) {
                        const data = JSON.parse(response.responseText);
                        console.log('Reviewer comment data:', data);

                        if (data.comments && data.comments.trim()) {
                            console.log('✅ Got REVIEWER-AGENT comment from Flask:', data.comments);
                            postReviewerComment(data.comments);
                            return;
                        }
                    }
                } catch (e) {
                    console.log('❌ Error parsing reviewer comment response:', e);
                }

                // Fallback to localStorage
                const localComment = localStorage.getItem('reviewer_comment');
                if (localComment && localComment.trim()) {
                    console.log('✅ Got REVIEWER-AGENT comment from localStorage');
                    postReviewerComment(localComment);
                } else {
                    console.log('No REVIEWER-AGENT comment found, retrying in 10 seconds...');
                    workflowState.isProcessing = false;
                    setTimeout(startWorkflow, 10000);
                }
            },
            onerror: function(error) {
                console.log('❌ Reviewer comment request failed:', error);
                workflowState.isProcessing = false;
                setTimeout(startWorkflow, 10000);
            }
        });
    }

    function postReviewerComment(commentText) {
        console.log("📝 Posting REVIEWER-AGENT comment...");

        const addButton = document.querySelector('button.new.awsui-button-variant-normal');
        if (!addButton) {
            console.log('❌ Add Comment button not found');
            workflowState.isProcessing = false;
            return;
        }

        addButton.click();

        setTimeout(() => {
            const textarea = document.querySelector('div.comment-box.editing textarea[aria-label="edit comment"]');

            if (textarea) {
                console.log("✅ Textarea found, inserting REVIEWER-AGENT comment");
                textarea.value = commentText;

                textarea.dispatchEvent(new Event('input', { bubbles: true }));
                textarea.dispatchEvent(new Event('change', { bubbles: true }));
                textarea.dispatchEvent(new Event('keyup', { bubbles: true }));

                setTimeout(() => {
                    const saveButton = document.querySelector('div.comment-box.editing button.save.comment-action.awsui-button-variant-primary');

                    if (saveButton) {
                        console.log("✅ Save button found, clicking");
                        saveButton.click();
                        workflowState.reviewerCommentPosted = true;

                        setTimeout(() => {
                            publishComments('reviewer');
                        }, 3000);
                    } else {
                        console.log("❌ Save button not found");
                        workflowState.isProcessing = false;
                    }
                }, 2000);
            } else {
                console.log("❌ Comment textarea not found");
                workflowState.isProcessing = false;
            }
        }, 3000);
    }

    function checkForResponderReply() {
        console.log("💬 Step 2: Checking for RESPONDER-AGENT reply...");

        GM_xmlhttpRequest({
            method: 'GET',
            url: 'http://localhost:5000/get_comments_by_publisher',
            timeout: 10000,
            onload: function(response) {
                try {
                    if (response.status === 200) {
                        const data = JSON.parse(response.responseText);
                        console.log('Responder reply data:', data);

                        if (data.comments && data.comments.trim()) {
                            console.log('✅ Got RESPONDER-AGENT reply from Flask:', data.comments);
                            postResponderReply(data.comments);
                            return;
                        }
                    }
                } catch (e) {
                    console.log('❌ Error parsing responder reply response:', e);
                }

                console.log('No RESPONDER-AGENT reply found, retrying in 10 seconds...');
                workflowState.isProcessing = false;
                setTimeout(startWorkflow, 10000);
            },
            onerror: function(error) {
                console.log('❌ Responder reply request failed:', error);
                workflowState.isProcessing = false;
                setTimeout(startWorkflow, 10000);
            }
        });
    }

    function postResponderReply(replyText) {
        console.log("💬 Posting RESPONDER-AGENT reply...");

        // Find REVIEWER-AGENT comment to reply to
        const commentBodies = document.querySelectorAll('.body.markdown');

        for (let body of commentBodies) {
            const text = body.textContent || body.innerText;
            if (text.includes('REVIEWER-AGENT')) {
                console.log('✅ Found REVIEWER-AGENT comment to reply to');

                const commentContainer = body.closest('.comment') || body.closest('[class*="comment"]') || body.parentElement;
                if (commentContainer) {
                    const replyButton = commentContainer.querySelector('button.reply.comment-action') ||
                                       commentContainer.querySelector('button.reply') ||
                                       commentContainer.querySelector('button[class*="reply"]');

                    if (replyButton) {
                        console.log('✅ Found reply button, clicking...');
                        replyButton.click();

                        setTimeout(() => {
                            const replyTextarea = document.querySelector('div.comment-box.editing textarea[aria-label="edit comment"]') ||
                                                 document.querySelector('textarea');

                            if (replyTextarea) {
                                console.log('✅ Reply textarea found, inserting RESPONDER-AGENT reply');
                                replyTextarea.value = replyText;
                                replyTextarea.focus();

                                replyTextarea.dispatchEvent(new Event('input', { bubbles: true }));
                                replyTextarea.dispatchEvent(new Event('change', { bubbles: true }));
                                replyTextarea.dispatchEvent(new Event('keyup', { bubbles: true }));

                                setTimeout(() => {
                                    const saveButton = document.querySelector('div.comment-box.editing button.save.comment-action.awsui-button-variant-primary') ||
                                                      document.querySelector('button.save');

                                    if (saveButton) {
                                        console.log('✅ Reply Save button found, clicking');
                                        saveButton.click();
                                        workflowState.responderReplyPosted = true;

                                        setTimeout(() => {
                                            publishComments('responder');
                                        }, 3000);
                                    } else {
                                        console.log('❌ Reply Save button not found');
                                        workflowState.isProcessing = false;
                                    }
                                }, 2000);
                            } else {
                                console.log('❌ Reply textarea not found');
                                workflowState.isProcessing = false;
                            }
                        }, 3000);
                        return;
                    }
                }
            }
        }

        console.log('❌ No REVIEWER-AGENT comment found to reply to');
        workflowState.isProcessing = false;
    }

    function publishComments(type) {
        console.log(`📤 Publishing ${type} comments...`);

        // Wait 5 seconds before publishing
        setTimeout(() => {
            const publishButton = document.querySelector('awsui-button[click="publishComments()"] button.awsui-button-variant-normal') ||
                                 document.querySelector('button.awsui-button-variant-normal');

            // Also try finding by text content
            if (!publishButton) {
                const allButtons = document.querySelectorAll('button');
                for (let button of allButtons) {
                    const buttonText = (button.textContent || button.innerText || '').toLowerCase();
                    if (buttonText.includes('publish') && buttonText.includes('comment')) {
                        console.log('✅ Found Publish Comments button by text');
                        button.click();

                        if (type === 'reviewer') {
                            workflowState.reviewerCommentPublished = true;
                            console.log('✅ REVIEWER-AGENT comment published, proceeding to responder reply...');
                            setTimeout(() => {
                                workflowState.isProcessing = false;
                                startWorkflow();
                            }, 3000);
                        } else if (type === 'responder') {
                            workflowState.responderReplyPublished = true;
                            console.log('✅ RESPONDER-AGENT reply published, proceeding to final review publish...');
                            setTimeout(() => {
                                workflowState.isProcessing = false;
                                startWorkflow();
                            }, 3000);
                        }
                        return;
                    }
                }
            }

            if (publishButton) {
                console.log('✅ Publish Comments button found, clicking');
                publishButton.click();

                if (type === 'reviewer') {
                    workflowState.reviewerCommentPublished = true;
                    console.log('✅ REVIEWER-AGENT comment published, proceeding to responder reply...');
                    setTimeout(() => {
                        workflowState.isProcessing = false;
                        startWorkflow();
                    }, 3000);
                } else if (type === 'responder') {
                    workflowState.responderReplyPublished = true;
                    console.log('✅ RESPONDER-AGENT reply published, proceeding to final review publish...');
                    setTimeout(() => {
                        workflowState.isProcessing = false;
                        startWorkflow();
                    }, 3000);
                }
            } else {
                console.log('❌ Publish Comments button not found');
                workflowState.isProcessing = false;
            }
        }, 5000); // 5 second delay before publishing
    }

    function publishReview() {
        console.log("🎯 Step 3: Publishing review (final step)...");

        const publishReviewButton = document.querySelector('button.awsui-button.awsui-button-variant-primary[type="submit"]') ||
                                   document.querySelector('button.awsui-button-variant-primary[type="submit"]') ||
                                   document.querySelector('button.awsui-button-variant-primary');

        // Also try finding by text content
        if (!publishReviewButton) {
            const allButtons = document.querySelectorAll('button');
            for (let button of allButtons) {
                const buttonText = (button.textContent || button.innerText || '').toLowerCase();
                if (buttonText.includes('publish') && buttonText.includes('review')) {
                    console.log('✅ Found Publish Review button by text');
                    button.click();
                    workflowState.reviewPublished = true;
                    workflowState.isProcessing = false;
                    console.log('🎉 Full workflow completed! Review published.');
                    return;
                }
            }
        }

        if (publishReviewButton) {
            console.log('✅ Publish Review button found, clicking');
            publishReviewButton.click();
            workflowState.reviewPublished = true;
            workflowState.isProcessing = false;
            console.log('🎉 Full workflow completed! Review published.');
        } else {
            console.log('❌ Publish Review button not found');
            console.log('Available buttons:', document.querySelectorAll('button'));
            workflowState.isProcessing = false;
        }
    }

    // Debug functions
    window.dreamReset = function() {
        workflowState = {
            reviewerCommentPosted: false,
            reviewerCommentPublished: false,
            responderReplyPosted: false,
            responderReplyPublished: false,
            reviewPublished: false,
            isProcessing: false
        };
        localStorage.removeItem('reviewer_comment');
        sessionStorage.removeItem('reviewer_comment');
        console.log('🔄 Workflow reset - will run full sequence again');
    };

    window.dreamStatus = function() {
        console.log('=== WORKFLOW STATUS ===');
        console.log('1. Reviewer comment posted:', workflowState.reviewerCommentPosted);
        console.log('2. Reviewer comment published:', workflowState.reviewerCommentPublished);
        console.log('3. Responder reply posted:', workflowState.responderReplyPosted);
        console.log('4. Responder reply published:', workflowState.responderReplyPublished);
        console.log('5. Review published:', workflowState.reviewPublished);
        console.log('Currently processing:', workflowState.isProcessing);
    };

    window.dreamForceNext = function() {
        workflowState.isProcessing = false;
        startWorkflow();
    };

    // Initialize
    console.log("🚀 DREAM CR Full Workflow Automation started");
    console.log("💡 Workflow: REVIEWER comment → publish → RESPONDER reply → publish → wait 5s → publish review");
    console.log("💡 Commands:");
    console.log("   dreamReset() - Reset entire workflow");
    console.log("   dreamStatus() - Show workflow progress");
    console.log("   dreamForceNext() - Force next step");

    setTimeout(ensureCommentsTabActive, 5000);

    if (document.readyState === 'complete') {
        setTimeout(ensureCommentsTabActive, 2000);
    }
})();