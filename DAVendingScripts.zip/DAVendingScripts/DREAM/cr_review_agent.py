#!/usr/bin/env python3
"""
CR Review Agent - Reviews latest commit changes using Q
"""

import os
import subprocess
import json

class CRReviewAgent:
    """Reviews git changes using Q LLM"""
    
    def review_cr(self, cr_url, package_path):
        """Review latest commit changes"""
        
        print("✓ Reviewing latest commit in: {}".format(package_path))
        
        if not os.path.exists(package_path):
            return {"success": False, "error": "Package path not found"}
        
        # Get latest commit diff
        commit_diff = self._get_latest_commit_diff(package_path)
        if not commit_diff:
            return {"success": False, "error": "No commit diff found"}
        
        # Use Q to review the changes
        comments = self._review_with_q(commit_diff)
        
        return {"success": True, "comments": comments}
    
    def _get_latest_commit_diff(self, package_path):
        """Get diff from latest commit"""
        original_dir = os.getcwd()
        try:
            os.chdir(package_path)
            
            # First try to get the diff of the latest commit
            result = subprocess.run(['git', 'show', '--format=', 'HEAD'], 
                                  capture_output=True, text=True)
            
            if result.returncode == 0 and result.stdout.strip():
                print(f"DEBUG: Got latest commit diff using 'git show HEAD'")
                return result.stdout.strip()
            
            # Fallback: compare HEAD with previous commit
            result = subprocess.run(['git', 'diff', 'HEAD~1', 'HEAD'], 
                                  capture_output=True, text=True)
            
            if result.returncode == 0 and result.stdout.strip():
                print(f"DEBUG: Got diff using 'git diff HEAD~1 HEAD'")
                return result.stdout.strip()
                
        except Exception as e:
            print("Warning: Could not get commit diff: {}".format(e))
        finally:
            os.chdir(original_dir)
        
        return None
    
    def _review_with_q(self, commit_diff):
        """Use Q to review the code changes"""
        
        print(f"DEBUG: Analyzing diff with {len(commit_diff)} characters")
        
        # Create a prompt for Q to review the code
        prompt = f"""Please review this git diff and provide specific, actionable feedback. Focus only on critical issues like:
- Security vulnerabilities
- Potential bugs or logic errors
- Performance issues
- Code that could cause runtime errors

If the code looks good, just say "LGTM".

Here's the diff:
{commit_diff}

Provide your feedback as bullet points starting with •"""

        try:
            # Use Q CLI to review the code
            result = subprocess.run(['q', 'chat', '--no-input'], 
                                  input=prompt, 
                                  capture_output=True, 
                                  text=True)
            
            if result.returncode == 0 and result.stdout.strip():
                response = result.stdout.strip()
                print(f"DEBUG: Q response: {response}")
                
                # Extract bullet points from Q's response
                lines = response.split('\n')
                comments = []
                for line in lines:
                    line = line.strip()
                    if line.startswith('•') or line.startswith('-') or line.startswith('*'):
                        comments.append(line if line.startswith('•') else '• ' + line[1:].strip())
                
                # If Q says LGTM or no bullet points found, return LGTM
                if not comments or 'LGTM' in response:
                    return ["LGTM"]
                
                print(f"DEBUG: Extracted {len(comments)} comments from Q")
                return comments[:5]  # Limit to 5 comments max
                
        except Exception as e:
            print(f"DEBUG: Error calling Q: {e}")
        
        # Fallback if Q fails
        return ["LGTM - Unable to analyze with Q"]
