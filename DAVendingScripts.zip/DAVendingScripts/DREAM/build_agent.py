#!/usr/bin/env python3
"""
AI Build Agent - Analyzes build results and suggests fixes
Designed to coordinate with Code Agent for iterative fixes
"""

import os
import json
import sys
import subprocess
import re
import time


class AIBuildAgent:
    """AI agent that runs builds and analyzes failures"""
    
    def build_package(self, package_path):
        """Build package and analyze results with AI"""
        
        print("AI Build Agent: Building {}".format(package_path))
        
        if not os.path.exists(package_path):
            return {"success": False, "error": "Package not found: {}".format(package_path)}
        
        # Step 1: Run the build
        build_result = self._execute_build(package_path)
        print("Build Status: {}".format("SUCCESS" if build_result["success"] else "FAILED"))
        
        # Step 2: AI analyzes the build result
        analysis = self._ai_analyze_build_result(build_result, package_path)
        if not analysis:
            return {"success": False, "error": "AI failed to analyze build result"}
        
        print("AI Analysis: {}".format(analysis["summary"][:100] + "..." if len(analysis["summary"]) > 100 else analysis["summary"]))
        
        return {
            "success": build_result["success"],
            "build_output": build_result["output"],
            "ai_analysis": analysis["summary"],
            "suggested_fixes": analysis.get("fixes", []),
            "needs_code_changes": analysis.get("needs_code_changes", False),
            "package_path": package_path
        }
    
    def _call_q_cli(self, prompt):
        """Call Q CLI for AI analysis"""
        try:
            print("Calling Q CLI for build analysis...")
            
            result = subprocess.Popen([
                'q', 'chat', '--no-interactive', '--trust-all-tools', prompt
            ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            stdout, stderr = result.communicate()
            
            if result.returncode == 0:
                # Decode bytes to string first
                stdout_str = stdout.decode('utf-8') if isinstance(stdout, bytes) else stdout
                clean_response = re.sub(r'\x1b\[[0-9;]*m', '', stdout_str.strip())
                return clean_response
            else:
                stderr_str = stderr.decode('utf-8') if isinstance(stderr, bytes) else stderr
                print("Q CLI Error: {}".format(stderr_str))
                return None
                
        except Exception as e:
            print("Q CLI call failed: {}".format(e))
            return None
    
    def _execute_build(self, package_path):
        """Execute brazil-build and capture output"""
        try:
            print("Running brazil-build...")
            
            # # Try brazil-build first
            # result = subprocess.Popen([
            #     'brazil-build'
            # ], cwd=package_path, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            # stdout, stderr = result.communicate()
            
            # output = stdout + stderr
            # success = result.returncode == 0
            
            time.sleep(15)
            return {
                "success": True,
                "output": output,
                "return_code": result.returncode,
                "command": "brazil-build"
            }
            
        except Exception as e:
            # Fallback: simulate build for demo if brazil-build not available
            print("brazil-build not available, simulating build...")
            return self._simulate_build(package_path)
    
    def _simulate_build(self, package_path):
        """Simulate build result for demo purposes"""
        
        # Check if there are any obvious issues
        files = []
        try:
            files = os.listdir(package_path)
        except:
            pass
        
        # Simulate different build scenarios
        if 'TestClass.java' in files:
            # Check Java file for issues
            try:
                with open(os.path.join(package_path, 'TestClass.java'), 'r') as f:
                    content = f.read()
                
                if 'public static void main' not in content:
                    return {
                        "success": False,
                        "output": "BUILD FAILED\nError: TestClass.java missing main method\nCompilation failed",
                        "return_code": 1,
                        "command": "simulated brazil-build"
                    }
                else:
                    return {
                        "success": True,
                        "output": "BUILD SUCCESSFUL\nCompiled 1 Java file\nTotal time: 3.2 seconds",
                        "return_code": 0,
                        "command": "simulated brazil-build"
                    }
            except:
                pass
        
        # Default successful build
        return {
            "success": True,
            "output": "BUILD SUCCESSFUL\nNo compilation errors\nTotal time: 2.1 seconds",
            "return_code": 0,
            "command": "simulated brazil-build"
        }
    
    def _ai_analyze_build_result(self, build_result, package_path):
        """AI analyzes build output and suggests fixes"""
        
        # Get package context
        package_files = self._scan_package(package_path)
        
        prompt = """Analyze this build result and provide actionable feedback:

BUILD COMMAND: {}
BUILD SUCCESS: {}
BUILD OUTPUT:
{}

PACKAGE PATH: {}
PACKAGE FILES: {}

Analyze the build result and respond with:
1. Summary of what happened
2. If build failed, what specific fixes are needed
3. Whether code changes are required (true/false)
4. Specific actionable steps

Be specific about file names and exact changes needed.""".format(
            build_result["command"],
            build_result["success"],
            build_result["output"],
            package_path,
            ', '.join(package_files)
        )
        
        ai_response = self._call_q_cli(prompt)
        if not ai_response:
            return None
        
        return self._parse_build_analysis(ai_response, build_result)
    
    def _parse_build_analysis(self, ai_response, build_result):
        """Parse AI analysis into structured format"""
        
        response_lower = ai_response.lower()
        
        # Determine if code changes are needed
        needs_code_changes = (
            not build_result["success"] and 
            any(keyword in response_lower for keyword in [
                'fix', 'change', 'modify', 'add', 'update', 'missing'
            ])
        )
        
        # Extract suggested fixes (simple parsing)
        fixes = []
        lines = ai_response.split('\n')
        for line in lines:
            if any(word in line.lower() for word in ['fix', 'add', 'change', 'modify']):
                fixes.append(line.strip())
        
        return {
            "summary": ai_response,
            "needs_code_changes": needs_code_changes,
            "fixes": fixes[:5],  # Limit to top 5 fixes
            "build_success": build_result["success"]
        }
    
    def _scan_package(self, package_path):
        """Scan package for files"""
        files = []
        try:
            for item in os.listdir(package_path):
                if os.path.isfile(os.path.join(package_path, item)):
                    files.append(item)
        except:
            pass
        return files

def main():
    """CLI interface for build agent"""
    if len(sys.argv) < 2:
        print("Usage: python build_agent.py <package_path>")
        print("Example: python build_agent.py test-package")
        sys.exit(1)
    
    package_path = sys.argv[1]
    
    agent = AIBuildAgent()
    result = agent.build_package(package_path)
    
    print("\n" + "="*60)
    print("BUILD RESULT:")
    print(json.dumps(result, indent=2))
    
    # Show coordination hints for future orchestrator
    if not result["success"] and result.get("needs_code_changes"):
        print("\n" + "="*60)
        print("COORDINATION HINT:")
        print("Build failed and needs code changes.")
        print("Orchestrator should call Code Agent with these fixes:")
        for fix in result.get("suggested_fixes", []):
            print("- {}".format(fix))

if __name__ == "__main__":
    main()
