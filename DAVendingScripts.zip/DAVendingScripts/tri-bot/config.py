import json
from urllib.request import Request, urlopen
from extra_footer import get_extra_footer
import os
from custom_prompts.donut_ops_backlog import (
    donuts_ops_backlog_prompt,
    donuts_ops_backlog_merge_prompt,
)
from custom_prompts.manual_stamping_bpbo import get_similar_ticket_query
from os_env import os_env

ALLOWED_FOLDER_IDS = [
    "b71d5dfe-b5ac-4564-bede-7a7579e8bd55",  # Discovery Sim Queue
    "1177ced8-6bd4-4b3b-b4b9-9925ed93623b",  # DAVendingCentral Sim Queue
    "5f87f449-b807-4481-adbe-123155dda196",  # SherlockResolvers: Tickets
    "f5cd0e0a-5340-4b91-a3e1-7a7ef9f06dad",  # adg-client-discovery: Tickets
    "8c3291c7-8e4b-4d06-80d6-64c0a0017301",  # DigiPub: Tickets
    "894d636c-ba6d-4ddf-8db9-a0e551f6cdd2",  # DA Recon
    "2ceac298-3727-49cf-8c8b-4e8e11210e5a",  # DA Recon
    "41cb89a2-903a-47f0-882c-3dd3d9ef5f2d",  # DigiCat
    "5c0c5072-4106-4d3e-b267-89d933b62eb6",  # adg-submission
    "5fc65b3a-b984-458d-9677-0ede6ce4a92f",  # strider-ser
    "4a0e78a8-98fc-4ccf-99c1-e0c8468f65c7",  # ast-se
    "2e32faae-cc20-4acb-a135-119809251a99",  # aee-se
    "c8ae8f8f-b519-4928-a8c1-9470acb611d0",  # spark-data
    "24693cc2-f6e0-4c4b-990e-db1ede4780eb",  # groot-aftv-non-prod
    "703562f6-b856-488a-806b-8edeffd51baa",  # groot-aftv-dev
    "a0cf69b8-1576-43ce-81dc-1591f32953be",  # appstore-voice
    "f6c787ff-c6b6-4bdf-9de2-38d95287c33e",  # psas-ilac-dev
    "b730c0ce-bb65-4b2d-90bb-b57c6dcf06b5",  # Kindle Content Versioning
    "4c0bad97-7590-4b07-83fc-765ee9d93950",  # KCV SE
    "804abb8a-1e70-46ea-be86-311cb2bf0b67",  # santos-shanghai-barossa
    "70ca09cf-b55f-4979-bcf3-3c523b55d8be",  # KICS Post-Purchase Dev: Tickets
    "08d7afb1-20b7-4b02-9b7e-18197cd5c2d0",  # icon-tardify-devs
    "927f7f3a-3959-48ea-a441-c375ae3f2137",  # DPW SE
    "50f77b87-a9b7-40ce-904b-128c8d8c3cdb",  # Learn Infra: Tickets
    "087b98ad-6ade-4a32-ae6b-cf6d3ad26c13",  # fuse-falcons: Tickets
    "02d0f05e-eea0-4ff8-935c-d6fce2005ff9",  # amf-services
    "1abb2e86-efdb-4d8e-84c1-e601a513b3ae",  # Puss in Boots Private
    "9dfe45bd-0bb1-4916-ba68-a6fd6d090165",  # alexa-mobile-foundation
    "9c84c312-05e3-44f6-b1c6-af18107f39dd",  # vox-rn
    "d30d4a83-1fa5-4ae1-9e18-2ab0f31aafa1",  # I2C-TR: Tickets
    "c24ef751-5615-48f0-aa8b-1ff62b02c607",  # I2C-BDP: Tickets
    "7d2d077f-aa42-4b3d-886a-b478eff067f7",  # GIS-EMEA: Tickets
    "a1010e1d-bf61-4689-8253-2232840ff572",  # HEX-AWS/Customer-Issues/
    # "0cbd415b-d811-4833-bbf8-f61d4a5b3f71",  # PBX Dev: Tickets
    "86bbf0d6-cd8b-4a26-ac03-fe3779024d18",  # supernova: Tickets
    "fc3e7947-fec3-4538-87df-0ad4f8e8fe64",  # AVCX TVOD Ownership
    "af525dd7-27dd-4fb8-905c-588da64b6663",  # vas-fulfillment-ops
    "76bbf190-f510-4a69-90db-4dc192b225fe",  # GEIST-BUG
    "80533e6c-afef-4d59-ad12-cba7419088b1",  # glue-jes-resolver
    "ece0077d-c807-48a7-b696-3c0d0789e483",  # I2C-TW: Tickets
    "d30d4a83-1fa5-4ae1-9e18-2ab0f31aafa1",  # I2C-TR: Tickets
    "3dea7317-aa52-4387-9720-316aad8a3768",  # I2C-IT: Tickets
    "c24ef751-5615-48f0-aa8b-1ff62b02c607",  # I2C-BDP: Tickets
    "76d75b47-cf2e-4b65-94ae-30dc944c306f",  # GIS-EMEA-VN: Tickets
    "c0f0eff0-2cca-4126-b4af-efd5f3fabad0",  # GIS-EMEA-TW: Tickets
    "b168f906-18a8-46cf-8565-300eae4806ca",  # GIS EMEA-CH
    "fc35c8bb-70fc-4380-9b4f-0bfce7ba4d56",  # GIS-EMEA-EUDR
    "1903ffb7-cfa6-44f6-b6a8-d8ff51a0423b",  # GIS-EMEA-EU
    "0fb30b02-61af-481b-aa72-524786bdabdd",  # GIS-EMEA-FR
    "50dc9eae-e683-47f4-84ea-16ce2fe8ab20",  # GIS-EMEA-HU
    "3fbfbe85-6be6-4266-8996-9025ab4e1cde",  # GIS-EMEA-ID
    "1bbe1913-a619-469f-a907-ff4f5c93eccf",  # GIS-EMEA-TR: Tickets
    "63e898b6-0db5-44d2-aa5f-f3f9ab80232c",  # GIS-EMEA-SA: Tickets
    "c414f5a7-437f-4ead-a378-11b7d768b296",  # GIS-EMEA-PT: Tickets
    "b4d6fe70-cdaf-4f57-ad13-1bf4afa4394e",  # GIS-EMEA-PL: Tickets
    "bb04266a-6ead-427f-95b0-2cffce59deeb",  # GIS-EMEA-IT: Tickets
    "7d2d077f-aa42-4b3d-886a-b478eff067f7",  # GIS-EMEA: Tickets
    "c0f354a8-3988-4f94-92fc-b8acec5f4178",  # GIS-EMEA-KR: Tickets
    "10fe2625-4cd8-44f7-8e64-42fbdb54d9dc",  # orca-engine-dev: Tickets
    "20a861c3-4272-4b99-9880-87a8815a7057",  # A2I-SX-GENIE: Tickets
    "af191dbd-4726-4330-9cc6-0e7243be8221",  # NSS-Compliance: Tickets
    "7d7a9bb8-7497-410c-be00-77e16d041297",  # Digital Ordering eXperience
    "fdcf8f37-6b18-45ab-a357-567b4a8400ba",  # ask-dox
    "69de6668-d8b7-4060-9604-6e3e75e0cc5b",  # GlobalCatalogServices: Tickets
    "894d636c-ba6d-4ddf-8db9-a0e551f6cdd2",  # da-recon-new
    "4389b908-a653-4750-b3e9-b531360ba0ea",  # VECTOR-CUSTOMER-SUPPORT
    "404c7a3e-62ba-4189-8935-8ca53cfad339",  # Athena Capacity Management
    "6f0d0b82-dbbf-4add-802a-8ea1a18141f0",  # JP Technical Acct Manager: Tickets
    "d7f0dc14-cd44-434b-91b5-b11d85d56d5f",  # pxf-learn-lsd: Tickets
    "c7e7aaf3-c346-4ee1-a0f3-6327c68f8334",  # alexa-mobile-analytics: Tickets
    "141436ce-aa3d-42de-ad7a-7f9f90630300",  # Support-Hufflepuff
    "089b9159-f936-473b-8311-ede9dc866d7d",  # Appstore Proteus Team: Tickets
    "fc52973e-254f-48b4-bbb7-8c2b0ff2a983",  # Predictive Targeting Everyday: Tickets
    "bf672036-33ba-4011-8a21-7ecdac98f3a0",  # pv-cancellation-experience: Tickets
    "771fb8cb-5e43-49c7-8632-24c52080b614",  # Predictive Targeting: Tickets
    "024d4e43-4f72-45f1-84a7-fdba63dd5cb3",  # aws-lf-transactions-resolver: Tickets
    "d6ed011e-8523-442a-9c04-b37e95a34ac1",  # elb-pulsar
    "0a36e209-77d4-450e-85d7-6cc7aa005dd4",  # elb-pulsar-region-build
    "c2ecc98d-3422-488a-ac08-d9647ab58c63",  # sentinel-eng-dev
    "11644b35-3699-4fae-aa4d-0c295e330dfa",  # Prime Auto Targeting
    "091ecac6-0c8f-4272-b9e8-d4b7973181de",  # Ask DiCE-PW
    "70275ae4-95b0-4ff7-8c53-6e1abae130c2",  # Sponsored Products Firebird: Tickets
    "ede56fef-2b3a-48ab-adfe-c400fc102fae",  # alexa-skill-connections: Tickets
    "9cef3903-baa1-42dd-a16c-13806a45642e",  # scout-for-x: Tickets
    "a9f70584-af1b-4c51-8266-f2e1899520a3",  # mbs-arms: Tickets
    # "0803b0a9-d15f-4851-b5be-5d52ac37be48",  # DSI
    "35a4315a-9629-4ec5-a225-67a3a5b97fe0",  # reva-awsfintech: Tickets
    "3df89ef2-85e2-4842-b933-4dc39946cb7e",  # datastudio-admin: Tickets
    "6233960c-5095-4b04-9072-dd3fe4f09b2d",  # finpress-awsfintech: Tickets
    # "8978d44b-3cef-44ff-bae9-5f801006dc1f",  # jarvis-admin: Tickets
    "3f294d85-494b-4b94-9114-53f0a81560a1",  # bpbo-analytics: Tickets
    "9f4132ee-7fd6-4957-af7e-5dffa96ce28a",  # Search Services Synapse: Tickets
    "866eb699-9d1a-4481-a963-4a48e4418493",  # Search Services Lifecycle TT: Tickets
    "750d9420-1d2d-44ce-8271-38c56d5bf8b9",  # AWS Meridian - PeRC: Tickets
    "b8f28e6e-5128-46cc-802b-c0cda50f9838",  # CloudSearch Customer Resp: Tickets
    "408b8b0a-bc41-4541-9eb5-294b9d969763",  # aws-billing-non-usage-data: Tickets
    "8aca5918-7000-4304-86aa-e4d6359c06e8",  # AWS Billing Premium Support: Tickets
    "79fb3485-4347-41b4-8f23-8a5a40bcf23e",  # AWS Billing - Commitment tracking
    "db2d6f5e-871d-4398-8a98-974162e8e021",  # AWS Billing - Discounts
    "d8f3c429-298e-4855-9184-f4775d970600",  # AWS Billing - Nickel
    "7735f02c-1a98-4dd8-bb67-57e29444ca49",  # AWS Billing Credits and Promotion
    "fa3cb6e6-6d79-4cbb-9ad6-c242d882c084",  # AWS Billing Egress
    "49df8e3e-1764-48be-a4d4-32802599b40b",  # AWS Billing Spectre
    "718558e7-420a-4fda-8665-f976095afa6e",  # AWS Krypton (Billing)
    "98c2f72d-f120-4c9e-a8e5-b65eb31cba6a",  # AWS Neon  (Billing)
    "6ff3ac7a-e498-46b8-8c5a-85ef65ec5257",  # LCM-Purchase: Tickets
    "c49f73fe-56f3-4906-93cc-96e86f0233ba",  # BillCompPricingModels
    "6cf547ca-6cc4-4aca-96c7-e54437e60643",  # AWSSimulators
    "72529397-b321-4de7-bad5-784b237aa77e",  # Brand First Migration: Tickets
    "606a848c-f166-47e0-af19-74accef13da5",  # Mettle Data: Tickets
    "5163ff32-dfba-4056-9643-860a58431fbf",  # Search Services Console: Tickets
    "198a8a9f-5a0e-438d-b445-210a3261c8c3",  # Mettle Compute: Tickes
    "00cc9bbd-7140-421b-9777-0f201fd11f21",  # manual-stamping-bpbo
    "84901d39-db42-40cf-b448-248342e03e70",  # ab-moontower-dev: Tickets
    "17b97927-7680-4e14-b53c-9e63610d24f5",  # AB-AppCenter: Tickets
    "99559b92-d8ef-4191-bdb0-d5175d2ce245",  # Abuse Prevention
    "5be1be00-56b8-4109-ab7f-123ab17b0552",  # FC Investigations
    "a0bf493d-1201-4c19-9a7a-4d74a6c2bd08",  # Transparency Operations : Tickets
    "ceeb37b7-0294-41f2-ac6e-1b8d0df06a2b",  # US-ADC-Route53-P3
    "6145d53d-a878-4b4d-bbb4-51ee8e9a6c6c",  # RODS_BID
    "01425054-5015-49d0-982d-a8581b33b875",  # ar-rdst-bid
    "16e06b70-2bea-4f3b-864e-6ce75e13bab3",  # P3 Oncall Ticket Queue
    "f32c3c4b-5f3c-4f3f-9adf-4b217362235f",  # US-ADC-Route53-P3: General Team Tickets
    "6fa31f33-caaa-4706-b26e-3ef7c38ffa1d",  # AWS FinTech AMPS: Tickets
    "a38c6d34-2e28-48f2-b3c1-f67639cda55c",  # PACManager-FIRE: Tickets
    "4bfd03ce-34c1-4dbd-9721-39a59ee7e4cb",  # AFT-UCP-DataEngineering: Tickets
    "ef35ab42-ae50-4e40-a34f-7e2baf642a93",  # PACManager-UCP: Tickets
    "d6436b2f-30c1-4314-b9a3-4167d3583da3",  # AWS EBS Stats Data Apps: Tickets & Sprints
    "fc36847e-cde6-46ad-a13a-31391f698ab7",  # Books Ads SupplyX: Tickets
    # "ff6a84c9-8ac4-4a86-ab1c-2c7530c802ef",  # InfraOps Reliability Analytics
    "d01b492f-2d69-4119-a6a6-a8b5d28b55a3",  # AWS MP Seller Experiences: Tickets
    # "0befc1ca-cef3-491e-9680-7d428f8f1bb9",  # Break Fix
    "d89bfbbe-d834-4e98-8a60-59589d322e5f",  # AAE PANDAS Oncall
    "32dc5d1f-a502-4e26-948e-dedda297346e",  # HMD X-Ray Lyrics
    "a1c9b3df-6d45-47bb-aa94-ce32bf0913cf",  # S3 Table Maintenance: Tickets
    "8f4d2e28-27db-4c8c-8be9-1c1ffb933f11",  # Solitaire: Tickets
    "ecbe1585-7ef0-4939-8248-3f32d58ec295",  # Cards Platform/t.corp
    "f5cad96d-ad1c-4a20-a093-3083f80ab4fe",  # AIO Rightsizing: Tickets
    "55b91d80-956f-483c-bff0-ae9250ec6fa2",  # Spurdog CP Team
    "1819b5f8-5294-4848-859f-1e3052376ffc",  # cosmos-frontline
    "f9771dea-2348-434c-aeff-615d3cf08dc4",  # aws-paper-chasers: Tickets
]
ALLOWED_EDIT_FOLDER_IDS = [
    "b71d5dfe-b5ac-4564-bede-7a7579e8bd55",  # Discovery Sim Queue
    "1177ced8-6bd4-4b3b-b4b9-9925ed93623b",  # DAVendingCentral Sim Queue
    "5f87f449-b807-4481-adbe-123155dda196",  # SherlockResolvers: Tickets
    "f5cd0e0a-5340-4b91-a3e1-7a7ef9f06dad",  # adg-client-discovery: Tickets
    "8c3291c7-8e4b-4d06-80d6-64c0a0017301",  # DigiPub: Tickets
    "894d636c-ba6d-4ddf-8db9-a0e551f6cdd2",  # DA Recon
    "2ceac298-3727-49cf-8c8b-4e8e11210e5a",  # DA Recon
    "41cb89a2-903a-47f0-882c-3dd3d9ef5f2d",  # DigiCat
    "5c0c5072-4106-4d3e-b267-89d933b62eb6",  # adg-submission
    "5fc65b3a-b984-458d-9677-0ede6ce4a92f",  # strider-ser
    "4a0e78a8-98fc-4ccf-99c1-e0c8468f65c7",  # ast-se
    "2e32faae-cc20-4acb-a135-119809251a99",  # aee-se
    "c8ae8f8f-b519-4928-a8c1-9470acb611d0",  # spark-data
    "24693cc2-f6e0-4c4b-990e-db1ede4780eb",  # groot-aftv-non-prod
    "703562f6-b856-488a-806b-8edeffd51baa",  # groot-aftv-dev
    "a0cf69b8-1576-43ce-81dc-1591f32953be",  # appstore-voice
    "f6c787ff-c6b6-4bdf-9de2-38d95287c33e",  # psas-ilac-dev
    "b730c0ce-bb65-4b2d-90bb-b57c6dcf06b5",  # Kindle Content Versioning
    "4c0bad97-7590-4b07-83fc-765ee9d93950",  # KCV SE
    "804abb8a-1e70-46ea-be86-311cb2bf0b67",  # santos-shanghai-barossa
    "70ca09cf-b55f-4979-bcf3-3c523b55d8be",  # KICS Post-Purchase Dev: Tickets
    "08d7afb1-20b7-4b02-9b7e-18197cd5c2d0",  # icon-tardify-devs
    "927f7f3a-3959-48ea-a441-c375ae3f2137",  # DPW SE
    "50f77b87-a9b7-40ce-904b-128c8d8c3cdb",  # Learn Infra: Tickets
    "087b98ad-6ade-4a32-ae6b-cf6d3ad26c13",  # fuse-falcons: Tickets
    "02d0f05e-eea0-4ff8-935c-d6fce2005ff9",  # amf-services
    "1abb2e86-efdb-4d8e-84c1-e601a513b3ae",  # Puss in Boots Private
    "9dfe45bd-0bb1-4916-ba68-a6fd6d090165",  # alexa-mobile-foundation
    "9c84c312-05e3-44f6-b1c6-af18107f39dd",  # vox-rn
    "d30d4a83-1fa5-4ae1-9e18-2ab0f31aafa1",  # I2C-TR: Tickets
    "c24ef751-5615-48f0-aa8b-1ff62b02c607",  # I2C-BDP: Tickets
    "7d2d077f-aa42-4b3d-886a-b478eff067f7",  # GIS-EMEA: Tickets
    "a1010e1d-bf61-4689-8253-2232840ff572",  # HEX-AWS/Customer-Issues/
    # "0cbd415b-d811-4833-bbf8-f61d4a5b3f71",  # PBX Dev: Tickets
    "86bbf0d6-cd8b-4a26-ac03-fe3779024d18",  # supernova: Tickets
    "fc3e7947-fec3-4538-87df-0ad4f8e8fe64",  # AVCX TVOD Ownership
    "af525dd7-27dd-4fb8-905c-588da64b6663",  # vas-fulfillment-ops
    "76bbf190-f510-4a69-90db-4dc192b225fe",  # GEIST-BUG
    "80533e6c-afef-4d59-ad12-cba7419088b1",  # glue-jes-resolver
    "ece0077d-c807-48a7-b696-3c0d0789e483",  # I2C-TW: Tickets
    "d30d4a83-1fa5-4ae1-9e18-2ab0f31aafa1",  # I2C-TR: Tickets
    "3dea7317-aa52-4387-9720-316aad8a3768",  # I2C-IT: Tickets
    "c24ef751-5615-48f0-aa8b-1ff62b02c607",  # I2C-BDP: Tickets
    "76d75b47-cf2e-4b65-94ae-30dc944c306f",  # GIS-EMEA-VN: Tickets
    "c0f0eff0-2cca-4126-b4af-efd5f3fabad0",  # GIS-EMEA-TW: Tickets
    "b168f906-18a8-46cf-8565-300eae4806ca",  # GIS EMEA-CH
    "fc35c8bb-70fc-4380-9b4f-0bfce7ba4d56",  # GIS-EMEA-EUDR
    "1903ffb7-cfa6-44f6-b6a8-d8ff51a0423b",  # GIS-EMEA-EU
    "0fb30b02-61af-481b-aa72-524786bdabdd",  # GIS-EMEA-FR
    "50dc9eae-e683-47f4-84ea-16ce2fe8ab20",  # GIS-EMEA-HU
    "3fbfbe85-6be6-4266-8996-9025ab4e1cde",  # GIS-EMEA-ID
    "1bbe1913-a619-469f-a907-ff4f5c93eccf",  # GIS-EMEA-TR: Tickets
    "63e898b6-0db5-44d2-aa5f-f3f9ab80232c",  # GIS-EMEA-SA: Tickets
    "c414f5a7-437f-4ead-a378-11b7d768b296",  # GIS-EMEA-PT: Tickets
    "b4d6fe70-cdaf-4f57-ad13-1bf4afa4394e",  # GIS-EMEA-PL: Tickets
    "bb04266a-6ead-427f-95b0-2cffce59deeb",  # GIS-EMEA-IT: Tickets
    "7d2d077f-aa42-4b3d-886a-b478eff067f7",  # GIS-EMEA: Tickets
    "c0f354a8-3988-4f94-92fc-b8acec5f4178",  # GIS-EMEA-KR: Tickets
    "10fe2625-4cd8-44f7-8e64-42fbdb54d9dc",  # orca-engine-dev: Tickets
    "20a861c3-4272-4b99-9880-87a8815a7057",  # A2I-SX-GENIE: Tickets
    "af191dbd-4726-4330-9cc6-0e7243be8221",  # NSS-Compliance: Tickets
    "7d7a9bb8-7497-410c-be00-77e16d041297",  # Digital Ordering eXperience
    "fdcf8f37-6b18-45ab-a357-567b4a8400ba",  # ask-dox
    "69de6668-d8b7-4060-9604-6e3e75e0cc5b",  # GlobalCatalogServices: Tickets
    "894d636c-ba6d-4ddf-8db9-a0e551f6cdd2",  # da-recon-new
    "4389b908-a653-4750-b3e9-b531360ba0ea",  # VECTOR-CUSTOMER-SUPPORT
    "404c7a3e-62ba-4189-8935-8ca53cfad339",  # Athena Capacity Management
    "6f0d0b82-dbbf-4add-802a-8ea1a18141f0",  # JP Technical Acct Manager: Tickets
    "d7f0dc14-cd44-434b-91b5-b11d85d56d5f",  # pxf-learn-lsd: Tickets
    "c7e7aaf3-c346-4ee1-a0f3-6327c68f8334",  # alexa-mobile-analytics: Tickets
    "141436ce-aa3d-42de-ad7a-7f9f90630300",  # Support-Hufflepuff
    "089b9159-f936-473b-8311-ede9dc866d7d",  # Appstore Proteus Team: Tickets
    "fc52973e-254f-48b4-bbb7-8c2b0ff2a983",  # Predictive Targeting Everyday: Tickets
    "bf672036-33ba-4011-8a21-7ecdac98f3a0",  # pv-cancellation-experience: Tickets
    "771fb8cb-5e43-49c7-8632-24c52080b614",  # Predictive Targeting: Tickets
    # "024d4e43-4f72-45f1-84a7-fdba63dd5cb3",  # aws-lf-transactions-resolver: Tickets
    "d6ed011e-8523-442a-9c04-b37e95a34ac1",  # elb-pulsar
    "0a36e209-77d4-450e-85d7-6cc7aa005dd4",  # elb-pulsar-region-build
    "c2ecc98d-3422-488a-ac08-d9647ab58c63",  # sentinel-eng-dev
    "11644b35-3699-4fae-aa4d-0c295e330dfa",  # Prime Auto Targeting
    "091ecac6-0c8f-4272-b9e8-d4b7973181de",  # Ask DiCE-PW
    "70275ae4-95b0-4ff7-8c53-6e1abae130c2",  # Sponsored Products Firebird: Tickets
    "ede56fef-2b3a-48ab-adfe-c400fc102fae",  # alexa-skill-connections: Tickets
    "9cef3903-baa1-42dd-a16c-13806a45642e",  # scout-for-x: Tickets
    "a9f70584-af1b-4c51-8266-f2e1899520a3",  # mbs-arms: Tickets
    # "0803b0a9-d15f-4851-b5be-5d52ac37be48",  # DSI
    "35a4315a-9629-4ec5-a225-67a3a5b97fe0",  # reva-awsfintech: Tickets
    "3df89ef2-85e2-4842-b933-4dc39946cb7e",  # datastudio-admin: Tickets
    "6233960c-5095-4b04-9072-dd3fe4f09b2d",  # finpress-awsfintech: Tickets
    # "8978d44b-3cef-44ff-bae9-5f801006dc1f",  # jarvis-admin: Tickets
    "3f294d85-494b-4b94-9114-53f0a81560a1",  # bpbo-analytics: Tickets
    "9f4132ee-7fd6-4957-af7e-5dffa96ce28a",  # Search Services Synapse: Tickets
    "866eb699-9d1a-4481-a963-4a48e4418493",  # Search Services Lifecycle TT: Tickets
    "750d9420-1d2d-44ce-8271-38c56d5bf8b9",  # AWS Meridian - PeRC: Tickets
    "b8f28e6e-5128-46cc-802b-c0cda50f9838",  # CloudSearch Customer Resp: Tickets
    "408b8b0a-bc41-4541-9eb5-294b9d969763",  # aws-billing-non-usage-data: Tickets
    "8aca5918-7000-4304-86aa-e4d6359c06e8",  # AWS Billing Premium Support: Tickets
    "6ff3ac7a-e498-46b8-8c5a-85ef65ec5257",  # LCM-Purchase: Tickets
    "c49f73fe-56f3-4906-93cc-96e86f0233ba",  # BillCompPricingModels
    "6cf547ca-6cc4-4aca-96c7-e54437e60643",  # AWSSimulators
    "79fb3485-4347-41b4-8f23-8a5a40bcf23e",  # AWS Billing - Commitment tracking
    "db2d6f5e-871d-4398-8a98-974162e8e021",  # AWS Billing - Discounts
    "d8f3c429-298e-4855-9184-f4775d970600",  # AWS Billing - Nickel
    "7735f02c-1a98-4dd8-bb67-57e29444ca49",  # AWS Billing Credits and Promotion
    "fa3cb6e6-6d79-4cbb-9ad6-c242d882c084",  # AWS Billing Egress
    "49df8e3e-1764-48be-a4d4-32802599b40b",  # AWS Billing Spectre
    "718558e7-420a-4fda-8665-f976095afa6e",  # AWS Krypton (Billing)
    "98c2f72d-f120-4c9e-a8e5-b65eb31cba6a",  # AWS Neon  (Billing)
    "72529397-b321-4de7-bad5-784b237aa77e",  # Brand First Migration: Tickets
    "606a848c-f166-47e0-af19-74accef13da5",  # Mettle Data: Tickets,
    "5163ff32-dfba-4056-9643-860a58431fbf",  # Search Services Console: Tickets
    "198a8a9f-5a0e-438d-b445-210a3261c8c3",  # Mettle Compute: Tickes
    # "00cc9bbd-7140-421b-9777-0f201fd11f21",  # manual-stamping-bpbo
    "84901d39-db42-40cf-b448-248342e03e70",  # ab-moontower-dev: Tickets
    "17b97927-7680-4e14-b53c-9e63610d24f5",  # AB-AppCenter: Tickets
    "99559b92-d8ef-4191-bdb0-d5175d2ce245",  # Abuse Prevention
    "5be1be00-56b8-4109-ab7f-123ab17b0552",  # FC Investigations
    "a0bf493d-1201-4c19-9a7a-4d74a6c2bd08",  # Transparency Operations : Tickets
    "ceeb37b7-0294-41f2-ac6e-1b8d0df06a2b",  # US-ADC-Route53-P3
    "6145d53d-a878-4b4d-bbb4-51ee8e9a6c6c",  # RODS_BID
    "01425054-5015-49d0-982d-a8581b33b875",  # ar-rdst-bid
    "16e06b70-2bea-4f3b-864e-6ce75e13bab3",  # P3 Oncall Ticket Queue
    "f32c3c4b-5f3c-4f3f-9adf-4b217362235f",  # US-ADC-Route53-P3: General Team Tickets
    "6fa31f33-caaa-4706-b26e-3ef7c38ffa1d",  # AWS FinTech AMPS: Tickets
    "a38c6d34-2e28-48f2-b3c1-f67639cda55c",  # PACManager-FIRE: Tickets
    "4bfd03ce-34c1-4dbd-9721-39a59ee7e4cb",  # AFT-UCP-DataEngineering: Tickets
    "ef35ab42-ae50-4e40-a34f-7e2baf642a93",  # PACManager-UCP: Tickets
    "d6436b2f-30c1-4314-b9a3-4167d3583da3",  # AWS EBS Stats Data Apps: Tickets & Sprints
    "fc36847e-cde6-46ad-a13a-31391f698ab7",  # Books Ads SupplyX: Tickets
    # "ff6a84c9-8ac4-4a86-ab1c-2c7530c802ef",  # InfraOps Reliability Analytics
    "d01b492f-2d69-4119-a6a6-a8b5d28b55a3",  # AWS MP Seller Experiences: Tickets
    # "0befc1ca-cef3-491e-9680-7d428f8f1bb9",  # Break Fix
    "d89bfbbe-d834-4e98-8a60-59589d322e5f",  # AAE PANDAS Oncall
    "32dc5d1f-a502-4e26-948e-dedda297346e",  # HMD X-Ray Lyrics
    "a1c9b3df-6d45-47bb-aa94-ce32bf0913cf",  # S3 Table Maintenance: Tickets
    "8f4d2e28-27db-4c8c-8be9-1c1ffb933f11",  # Solitaire: Tickets
    "ecbe1585-7ef0-4939-8248-3f32d58ec295",  # Cards Platform/t.corp
    "f5cad96d-ad1c-4a20-a093-3083f80ab4fe",  # AIO Rightsizing: Tickets
    "55b91d80-956f-483c-bff0-ae9250ec6fa2",  # Spurdog CP Team
    "1819b5f8-5294-4848-859f-1e3052376ffc",  # cosmos-frontline
    "f9771dea-2348-434c-aeff-615d3cf08dc4",  # aws-paper-chasers: Tickets
]
ASSIGNED_GROUPS_MAPS = {
    "894d636c-ba6d-4ddf-8db9-a0e551f6cdd2": "DA Recon",
    "404c7a3e-62ba-4189-8935-8ca53cfad339": "Athena Capacity Management",
    "b730c0ce-bb65-4b2d-90bb-b57c6dcf06b5": "Kindle Content Versioning",
    "4c0bad97-7590-4b07-83fc-765ee9d93950": "KCV SE",
    "298e3dc9-6bf2-4ad8-ba77-41b0eb5a8cdb": "dci-dev",
    "5c0c5072-4106-4d3e-b267-89d933b62eb6": "adg-submission",
    "86879786-dc63-4881-ae05-c3a4c54e93d9": "ProductEligibility",
    "00cc9bbd-7140-421b-9777-0f201fd11f21": "manual-stamping-bpbo",
    "ef35ab42-ae50-4e40-a34f-7e2baf642a93": "PACManager-UCP",
}
DAILY_REMINDER_CONFIG = [
    {
        "folderId": "f5cd0e0a-5340-4b91-a3e1-7a7ef9f06dad",
        "folderName": "adg_client_discovery",
        "cti": "Appstore/Digital Goods/ADGDiscoveryService",
        "webhook": "",
        "channel": "#disco-sherlock-team",
        "active": True,
    },
    {
        "folderId": "f5cd0e0a-5340-4b91-a3e1-7a7ef9f06dad",
        "folderName": "adg_client_discovery_test",
        "cti": "Appstore/Digital Goods/ADGDiscoveryService",
        "webhook": "",
        "channel": "#kmarxlh-test",
        "active": False,
    },
    {
        "folderId": "8c3291c7-8e4b-4d06-80d6-64c0a0017301",
        "folderName": "digipub",
        "cti": "Appstore/Digital Goods/DigiPub",
        "webhook": "",
        "channel": "#digipub-high-sev-notification",
        "active": True,
    },
    {
        "folderId": "98670829-d855-423c-9e38-f69a8bfa0f1b",
        "folderName": "kindle_halcyon",
        "cti": "",
        "webhook": "",
        "channel": "#kindle-halcyon",
        "active": True,
    },
    {
        "folderId": "1c9a87b5-3f9a-4503-b440-cc0697f34806",
        "folderName": "kindle_phoenix",
        "cti": "",
        "webhook": "",
        "channel": "#kindle-phoenix",
        "active": True,
    },
    {
        "folderId": "0a796e90-e829-4e0d-b202-27a3cc0c9d61",
        "folderName": "kindle_cygnus",
        "cti": "",
        "webhook": "",
        "channel": "#kindle-cygnus",
        "active": True,
    },
    {
        "folderId": "b730c0ce-bb65-4b2d-90bb-b57c6dcf06b5",
        "folderName": "Kindle_Content_Versioning",
        "cti": "",
        "webhook": "",
        "channel": "#Kindle_Content_Versioning",
        "active": True,
    },
    {
        "folderId": "4c0bad97-7590-4b07-83fc-765ee9d93950",
        "folderName": "KCV_SE",
        "cti": "",
        "webhook": "",
        "channel": "#KCV_SE",
        "active": True,
    },
    {
        "folderId": "08d7afb1-20b7-4b02-9b7e-18197cd5c2d0",
        "folderName": "icon_tardify_devs",
        "cti": "",
        "webhook": "",
        "channel": "#icon_tardify_devs",
        "active": True,
    },
    {
        "folderId": "087b98ad-6ade-4a32-ae6b-cf6d3ad26c13",
        "folderName": "fuse_falcons",
        "cti": "",
        "webhook": "",
        "channel": "#fuse_falcons",
        "active": True,
    },
    {
        "folderId": "9dfe45bd-0bb1-4916-ba68-a6fd6d090165",
        "folderName": "alexa_mobile_foundation",
        "cti": "",
        "webhook": "",
        "channel": "#alexa_mobile_foundation",
        "active": True,
    },
    {
        "folderId": "9c84c312-05e3-44f6-b1c6-af18107f39dd",
        "folderName": "vox_rn",
        "cti": "",
        "webhook": "",
        "channel": "#vox_rn",
        "active": True,
    },
    {
        "folderId": "a1010e1d-bf61-4689-8253-2232840ff572",
        "folderName": "hex_aws",
        "cti": "",
        "webhook": "",
        "channel": "#hex_aws",
        "active": True,
    },
    {
        "folderId": "ece0077d-c807-48a7-b696-3c0d0789e483",
        "folderName": "i2c_gis_grouped",
        "cti": "",
        "webhook": "",
        "channel": "#i2c_gis_grouped",
        "active": True,
    },
    {
        "folderId": "af525dd7-27dd-4fb8-905c-588da64b6663",
        "folderName": "vas_fulfillment_ops",
        "cti": "",
        "webhook": "",
        "channel": "#vas_fulfillment_ops",
        "active": True,
    },
    {
        "folderId": "80533e6c-afef-4d59-ad12-cba7419088b1",
        "folderName": "glue_jes_resolver",
        "cti": "",
        "webhook": "",
        "channel": "#glue_jes_resolver",
        "active": True,
    },
    {
        "folderId": "af191dbd-4726-4330-9cc6-0e7243be8221",
        "folderName": "nss_compliance_vector_customer_support",
        "cti": "",
        "webhook": "",
        "channel": "#nss_compliance_vector_customer_support",
        "active": True,
    },
    {
        "folderId": "7d7a9bb8-7497-410c-be00-77e16d041297",
        "folderName": "digital_ordering_experience",
        "cti": "",
        "webhook": "",
        "channel": "#digital_ordering_experience",
        "active": True,
    },
    {
        "folderId": "894d636c-ba6d-4ddf-8db9-a0e551f6cdd2",
        "folderName": "da_recon",
        "cti": "",
        "webhook": "",
        "channel": "#da_recon",
        "active": True,
    },
    {
        "folderId": "srsudhir",
        "folderName": "srsudhir",
        "cti": "",
        "webhook": "",
        "channel": "#srsudhir",
        "active": True,
    },
    {
        "folderId": "6f0d0b82-dbbf-4add-802a-8ea1a18141f0",
        "folderName": "jp_technical_acct_manager",
        "cti": "",
        "webhook": "",
        "channel": "#jp_technical_acct_manager",
        "active": True,
    },
    {
        "folderId": "70ca09cf-b55f-4979-bcf3-3c523b55d8be",
        "folderName": "kics_post_purchase_dev",
        "cti": "",
        "webhook": "",
        "channel": "#kics_post_purchase_dev",
        "active": True,
    },
    {
        "folderId": "ff02db9a-3755-417d-9eee-b884e518f9da",
        "folderName": "fintral_tech_support",
        "cti": "",
        "webhook": "",
        "channel": "#fintral_tech_support",
        "active": True,
    },
    {
        "folderId": "c7e7aaf3-c346-4ee1-a0f3-6327c68f8334",
        "folderName": "alexa_mobile_analytics",
        "cti": "",
        "webhook": "",
        "channel": "#alexa_mobile_analytics",
        "active": True,
    },
    {
        "folderId": "089b9159-f936-473b-8311-ede9dc866d7d",
        "folderName": "appstore_proteus_team",
        "cti": "",
        "webhook": "",
        "channel": "#appstore_proteus_team",
        "active": True,
    },
    {
        "folderId": "bf672036-33ba-4011-8a21-7ecdac98f3a0",
        "folderName": "pv_cancellation_experience",
        "cti": "",
        "webhook": "",
        "channel": "#pv_cancellation_experience",
        "active": True,
    },
    {
        "folderId": "fc52973e-254f-48b4-bbb7-8c2b0ff2a983",
        "folderName": "predictive_targeting",
        "cti": "",
        "webhook": "",
        "channel": "#predictive_targeting",
        "active": True,
    },
    {
        "folderId": "024d4e43-4f72-45f1-84a7-fdba63dd5cb3",
        "folderName": "aws_lf_transactions",
        "cti": "",
        "webhook": "",
        "channel": "#aws_lf_transactions",
        "active": True,
    },
    {
        "folderId": "d6ed011e-8523-442a-9c04-b37e95a34ac1",
        "folderName": "elb_pulsar",
        "cti": "",
        "webhook": "",
        "channel": "#elb_pulsar",
        "active": True,
    },
    {
        "folderId": "5c0c5072-4106-4d3e-b267-89d933b62eb6",
        "folderName": "dc_ingestion",
        "cti": "",
        "webhook": "",
        "channel": "#dc_ingestion",
        "active": True,
    },
    {
        "folderId": "70275ae4-95b0-4ff7-8c53-6e1abae130c2",
        "folderName": "sponsored_products_firebird",
        "cti": "",
        "webhook": "",
        "channel": "#sponsored_products_firebird",
        "active": True,
    },
    {
        "folderId": "db080ba5-b593-4942-87f6-bda10ef6e156",
        "folderName": "donut_ops_backlog",
        "cti": "",
        "webhook": "",
        "channel": "#donut_ops_backlog",
        "active": True,
    },
    {
        "folderId": "3df89ef2-85e2-4842-b933-4dc39946cb7e",
        "folderName": "datastudio_admin",
        "cti": "",
        "webhook": "",
        "channel": "#datastudio_admin",
        "active": True,
    },
    {
        "folderId": "35a4315a-9629-4ec5-a225-67a3a5b97fe0",
        "folderName": "reva_awsfintech",
        "cti": "",
        "webhook": "",
        "channel": "#reva_awsfintech",
        "active": True,
    },
    {
        "folderId": "8978d44b-3cef-44ff-bae9-5f801006dc1f",
        "folderName": "jarvis_admin",
        "cti": "",
        "webhook": "",
        "channel": "#jarvis_admin",
        "active": True,
    },
    {
        "folderId": "6233960c-5095-4b04-9072-dd3fe4f09b2d",
        "folderName": "finpress_awsfintech",
        "cti": "",
        "webhook": "",
        "channel": "#finpress_awsfintech",
        "active": True,
    },
    {
        "folderId": "3f294d85-494b-4b94-9114-53f0a81560a1",
        "folderName": "bpbo_analytics",
        "cti": "",
        "webhook": "",
        "channel": "#bpbo_analytics",
        "active": True,
    },
    {
        "folderId": "9f4132ee-7fd6-4957-af7e-5dffa96ce28a",
        "folderName": "Search_Services_Synapse",
        "cti": "",
        "webhook": "",
        "channel": "#Search_Services_Synapse",
        "active": True,
    },
    {
        "folderId": "866eb699-9d1a-4481-a963-4a48e4418493",
        "folderName": "Search_Services_Lifecycle_TT",
        "cti": "",
        "webhook": "",
        "channel": "#Search_Services_Lifecycle_TT",
        "active": True,
    },
    {
        "folderId": "b8f28e6e-5128-46cc-802b-c0cda50f9838",
        "folderName": "CloudSearch_Customer_Resp",
        "cti": "",
        "webhook": "",
        "channel": "#CloudSearch_Customer_Resp",
        "active": True,
    },
    {
        "folderId": "6ff3ac7a-e498-46b8-8c5a-85ef65ec5257",
        "folderName": "LCM_Purchase",
        "cti": "",
        "webhook": "",
        "channel": "#LCM_Purchase",
        "active": True,
    },
    {
        "folderId": "606a848c-f166-47e0-af19-74accef13da5",
        "folderName": "mettle_data",
        "cti": "",
        "webhook": "",
        "channel": "#mettle_data",
        "active": True,
    },
    {
        "folderId": "5163ff32-dfba-4056-9643-860a58431fbf",
        "folderName": "Search_Services_Console",
        "cti": "",
        "webhook": "",
        "channel": "#Search_Services_Console",
        "active": True,
    },
    {
        "folderId": "198a8a9f-5a0e-438d-b445-210a3261c8c3",
        "folderName": "Mettle_Compute",
        "cti": "",
        "webhook": "",
        "channel": "#Mettle_Compute",
        "active": True,
    },
    {
        "folderId": "00cc9bbd-7140-421b-9777-0f201fd11f21",
        "folderName": "manual_stamping_bpbo",
        "cti": "",
        "webhook": "",
        "channel": "#manual_stamping_bpbo",
        "active": True,
    },
    {
        "folderId": "ceeb37b7-0294-41f2-ac6e-1b8d0df06a2b",
        "folderName": "us_adc_route_53_p3",
        "cti": "",
        "webhook": "",
        "channel": "#us_adc_route_53_p3",
        "active": True,
    },
    {
        "folderId": "6145d53d-a878-4b4d-bbb4-51ee8e9a6c6c",
        "folderName": "rods_bid",
        "cti": "",
        "webhook": "",
        "channel": "#rods_bid",
        "active": True,
    },
    {
        "folderId": "16e06b70-2bea-4f3b-864e-6ce75e13bab3",
        "folderName": "P3_Oncall_Ticket_Queue",
        "cti": "",
        "webhook": "",
        "channel": "#P3_Oncall_Ticket_Queue",
        "active": True,
    },
    {
        "folderId": "1fd740a7-8478-407f-99fe-a5c0d8a57042",
        "folderName": "AWSMP_AMI_Team",
        "cti": "",
        "webhook": "",
        "channel": "#AWSMP_AMI_Team",
        "active": True,
    },
    {
        "folderId": "6fa31f33-caaa-4706-b26e-3ef7c38ffa1d",
        "folderName": "AWS_FinTech_AMPS",
        "cti": "",
        "webhook": "",
        "channel": "#AWS_FinTech_AMPS",
        "active": True,
    },
    {
        "folderId": "ef35ab42-ae50-4e40-a34f-7e2baf642a93",
        "folderName": "PACManager_UCP",
        "cti": "",
        "webhook": "",
        "channel": "#PACManager_UCP",
        "active": True,
    },
    {
        "folderId": "fc36847e-cde6-46ad-a13a-31391f698ab7",
        "folderName": "Books_Ads_SupplyX",
        "cti": "",
        "webhook": "",
        "channel": "#Books_Ads_SupplyX",
        "active": True,
    },
    {
        "folderId": "d01b492f-2d69-4119-a6a6-a8b5d28b55a3",
        "folderName": "AWS_MP_Seller_Experiences",
        "cti": "",
        "webhook": "",
        "channel": "#AWS_MP_Seller_Experiences",
        "active": True,
    },
    {
        "folderId": "d89bfbbe-d834-4e98-8a60-59589d322e5f",
        "folderName": "AAE_PANDAS_Oncall",
        "cti": "",
        "webhook": "",
        "channel": "#AAE_PANDAS_Oncall",
        "active": True,
    },
    {
        "folderId": "a1c9b3df-6d45-47bb-aa94-ce32bf0913cf",
        "folderName": "S3_Table_Maintenance",
        "cti": "",
        "webhook": "",
        "channel": "#S3_Table_Maintenance",
        "active": True,
    },
    {
        "folderId": "8f4d2e28-27db-4c8c-8be9-1c1ffb933f11",
        "folderName": "Solitaire_Card_Platform",
        "cti": "",
        "webhook": "",
        "channel": "#Solitaire_Card_Platform",
        "active": True,
    },
    {
        "folderId": "f5cad96d-ad1c-4a20-a093-3083f80ab4fe",
        "folderName": "AIO_Rightsizing_Tickets",
        "cti": "",
        "webhook": "",
        "channel": "#AIO_Rightsizing_Tickets",
        "active": True,
    },
    {
        "folderId": "1819b5f8-5294-4848-859f-1e3052376ffc",
        "folderName": "cosmos_frontline",
        "cti": "",
        "webhook": "",
        "channel": "#cosmos_frontline",
        "active": True,
    },
]
CUSTOM_PROMPTS = {"db080ba5-b593-4942-87f6-bda10ef6e156": donuts_ops_backlog_prompt}
CUSTOM_MERGE_PROMPTS = {
    "db080ba5-b593-4942-87f6-bda10ef6e156": donuts_ops_backlog_merge_prompt
}
CUSTOM_SIMILAR_TICKETS_QUERY = {
    "00cc9bbd-7140-421b-9777-0f201fd11f21": get_similar_ticket_query
}
BARE_MINIMUM_TICKET_ANALYSIS_FOLDERS = ["00cc9bbd-7140-421b-9777-0f201fd11f21"]
NO_FOOTER = [
    # "894d636c-ba6d-4ddf-8db9-a0e551f6cdd2"  # DA Recon
]
ALLOWED_CTIS = ["Digital Media Technology|Digital Publishing"]
BOT_SIM_COMMENT_AUTHORS = [
    "Snow",
    "system",
    "fluxo:flx-jiro",
    "aws:sts::968761973157:assumed-role/da-recon-ops-user-role/da-recon-ops-session",
    "arn:aws:sts::968761973157:assumed-role/da-recon-ops-user-role/da-recon-ops-session",
]
BLACKLISTED_TICKETS = [
    "8b77d00c-ce1c-42d0-917b-4a6d328c723c",
    "d67d2021-10f0-434a-b78e-c75933a5bbab",
    "1b9f658d-cc17-4f0c-965d-de9705c3a2c9",
    # below are related to digital ordering exp tickets queue
    "e6d1b013-d464-4637-9882-a605c1d9fcb1",
    "4dcc7a35-7403-4152-bb25-8239e392c656",
    "e6ad04cb-e363-4274-9fac-0893740d9c64",
    "ab5ce08c-035b-488f-a1ba-acd85a286124",
]
ALLOWED_EDIT_PATHS = ["aliases", "description", "title", "conversation"]
SYSTEM_EDIT_AUTHOR = [
    "arn:aws:sts::968761973157:assumed-role/da-recon-ops-user-role/da-recon-ops-session",
    "arn:aws:iam::234227170609:user/AutoSIM",
    "fluxo:flx-jiro",
    "arn:aws:sts::943850100407:assumed-role/SnowEngine-Service-Role/SnowEngine-Service-Session",
    # "arn:aws:iam::873562014284:user/SmartTTBotsApplicationUser-prod"
]
DDB_TABLE_NAME = "ticket-tracker"
READ_TIMEOUT_ERR_CODE = "READ_TIMEOUT"
MAX_TITLE_SIZE = 80
MAX_SIM_TICKETS = 6
MAX_SIM_FOR_MODEL = 12
MAX_BEDROCK_CHAR = 300000
MAX_OPEN_TICKETS_LIMIT = 700
RESOLVED_STATUS = "Resolved"
FOOTER = (
    "##### Powered by [TRI BOT](https://quip-amazon.com/gljXAxZVWQpw/TRIBOT). AI responses may contain inaccuracies or hallucinations; please use discretion when relying on them. (For more details, onboarding or for providing feedback [click here](https://quip-amazon.com/gljXAxZVWQpw/Introducing-TRI-BOT-Your-On-Call-Assistant-for-Streamlined-Operations#temp:C:QRMf6340d1b660b404e8a57a8b85))"
    + "\n"
    + "-----\n##### "
    + get_extra_footer(False)
)

DAILY_REMINDER_FOOTER = (
    "Powered by TRI BOT (In active development). AI responses may contain inaccuracies or hallucinations; please use discretion when relying on them."
    + "\n\n"
    + get_extra_footer(True)
)


def is_tt_allowed(tt_details):
    return (
        tt_details.get("folderId", "") in ALLOWED_FOLDER_IDS
        or tt_details.get("cti", "") in ALLOWED_CTIS
    )


def is_tt_allowed_for_edit(tt_details):
    return tt_details.get("folderId", "") in ALLOWED_EDIT_FOLDER_IDS


def get_daily_reminder_config(folder_id):
    conf = list(
        filter(
            lambda x: x.get("folderId") == folder_id and x.get("active", False),
            DAILY_REMINDER_CONFIG,
        )
    )
    if conf and len(conf) == 1:
        conf[0]["webhook"] = os_env.get(
            conf[0]["folderName"]
        )  # os.environ.get(conf[0]["folderName"])
        return conf[0]
    else:
        raise Exception("invalid folder id provided as no config exists")


def invokeSlackEndpoint(slack_endpoint, body):
    httprequest = Request(
        slack_endpoint,
        data=json.dumps({"body": body}).encode(),
        method="POST",
        headers={"Content-Type": "application/json; charset=UTF-8"},
    )
    with urlopen(httprequest) as response:
        print(response.read().decode())
        return True
