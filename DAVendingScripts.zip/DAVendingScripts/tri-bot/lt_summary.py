from ticket_actions import get_all_open_tickets
from config import get_daily_reminder_config
from daily_summary_module import _execute_daily_summary_module
import json

lt_resolver_groups = {
    "srsudhir": [
        "DART-IAP-FRK",
        "Digital Storage OE",
        "Associates Analytics-Incidents",
        "FAS-AUTOMATION",
        "Digital Events",
        "da-gobs-tech",
        "KiCSPS Dev",
        "DCCP SE Operations",
        "DA-DMA-campaing",
        "Digital Storage SE",
        "DA TX - Storage",
        "DA Recon Test",
        "DS - Datawarehouse",
        "DSOA Seattle Ops",
        "DCCS-Compliance-Dev",
        "TOPR DCAS",
        "PSAA-Digital",
        "Digital Ordering Storage",
        "Digital Platform Hardware",
        "promo-accounting",
        "dta-tech",
        "Subscription Storage",
        "vaikor-test-resolver",
        "Digital Storage",
        "da-care-tech",
        "DRONE-test",
        "Digital Availability",
        "DA Recon",
    ]
}


def execute_lt_summarizer(leader_name, dry_run=False):
    if not leader_name or leader_name not in lt_resolver_groups:
        print(f"Leader name [{leader_name}] not found in resolver groups")
        return

    tickets_data = []
    for resolver_group in lt_resolver_groups.get(leader_name, []):
        tickets_data.extend(get_all_open_tickets("", resolver_group))

    # dump tickets_data to a file
    # with open("tickets_data.json", "w") as f:
    #     f.write(json.dumps(tickets_data))

    # # read above file
    # with open("tickets_data.json", "r") as f:
    #     tickets_data = json.loads(f.read())

    if tickets_data:
        print(f"[{leader_name}] tickets length : [{len(tickets_data)}]")
        conf = get_daily_reminder_config(leader_name)
        return _execute_daily_summary_module(
            tickets_data,
            conf.get("folderName"),
            leader_name,
            conf.get("webhook"),
            dry_run,
            True,
        )

    else:
        print("no tickets found for any of the given resolver groups")
