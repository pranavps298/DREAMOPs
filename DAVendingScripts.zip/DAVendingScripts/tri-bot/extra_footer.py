import random

# song_url = "https://tiny.amazon.com/p5c9c4ci/musiamazinalbuB0DD" #Eurydice
# song_url = "https://tiny.amazon.com/1j4ge1tgl/musiamazinalbuB09H" #Eurydice
# song_url = "https://tiny.amazon.com/8cyopnlv/musiamazinalbuB07P" #Honeybee
# song_url = "https://tiny.amazon.com/uss6f25v/musiamazinalbuB002" #Sundown
# song_url = "https://tiny.amazon.com/w5d42c8h/musiamazinalbuB0CN" #Sons and Daughters
# song_url = "https://music.amazon.in/albums/B07WRBWY9T" #PurpleHat
# song_url = "https://music.amazon.in/albums/B077SKQXGN" #BestFriend
# song_url = "https://music.amazon.in/albums/B07942B52N" #Runaways
# song_url = "https://music.amazon.in/albums/B08GWQDH6W" #Rabbit
# song_url = "https://music.amazon.in/albums/B07BXCT363" #Whole New Level
# song_url = "https://music.amazon.in/albums/B0BVDNQWMR" #Forget You
# song_url = "https://music.amazon.in/albums/B09VNWFSD7" #The Way That Lovers Do
# song_url = "https://music.amazon.in/albums/B0D6WL9C45" #Alibi
# song_url = "https://music.amazon.in/albums/B073GZT1R7" #Greatest Hits
# song_url = "https://tiny.amazon.com/bh26yg2c/musiamazinalbuB09M" #Courtside
# song_url = "https://tiny.amazon.com/nrex0n9e/musiamazinalbuB0CZ" #Tarantella
# song_url = "https://tiny.amazon.com/sghn543i/musiamazinalbuB07N" #Things of beauty
# song_url = "https://tiny.amazon.com/ay3k8dhe/musiamazinalbuB09H" # 24 Sundial
# song_url = "https://tiny.amazon.com/1jxrdr0hu/musiamazinalbuB0BV" # Heaven , Niall Horan
# song_url = "https://tiny.amazon.com/iluylzjg/musiamazinalbuB075" #Fire Away
# song_url = "https://tiny.amazon.com/ap115s8c/musiamazinalbuB073" # Youth Daughter
# song_url = "https://tiny.amazon.com/1bo3lpswo/musiamazinalbuB08G" # Star Earring : Fox Academy
# song_url = "https://tiny.amazon.com/s0f0sl9l/musiamaztracB0CQ" # true, yorai
# song_url = "https://tiny.amazon.com/ic9lkiiq/musiamazintracB0DJ" # apt rosie  bruno
# song_url = "https://tiny.amazon.com/o77aoue0/musiamaztracB07J" # softcore, neighbourhood
# song_url = "https://tiny.amazon.com/1ec3kn9iv/musiamazintracB073"  # little talks of monsters and men
# song_url = "https://tiny.amazon.com/cn3wkm52/musiamazintracB0BF" # lemon tree by fools garden
# song_url = "https://tiny.amazon.com/2flkh5m5/musiamazintracB092"  # serotonin by girl in red
# song_url = "https://tiny.amazon.com/d3vjmgue/musiamazintracB07N" # spirits, the strumbellas
# song_url = "https://tiny.amazon.com/ywruyhpi/musiamazinalbuB0B9"  # in this life, the strumbellas
# song_url = "https://tiny.amazon.com/zzlck2u5/musiamazinalbuB073" # 9 to 5, dolly parton
# song_url =  "https://tiny.amazon.com/xk38cn9b/musiamazinalbuB0BM" # Stockholmsvy
# song_url = "https://tiny.amazon.com/fn3ocy2p/musiamazinalbuB073" # chasing the sun, wanted
# song_url = "https://tiny.amazon.com/a6hc38s6/musiamazinalbuB08L"  # Minefields by Faouzia
# song_url = "https://tiny.amazon.com/1jfsg4053/musiamazinalbuB08X" # Stereo Love
# song_url = "https://tiny.amazon.com/1itjiseri/musiamazinalbuB08Q" # worlds smallest violin
# song_url = "https://tiny.amazon.com/18ww5fpaz/musiamazinalbuB08Q" # ordinarish people
# song_url = "https://tiny.amazon.com/14darrflr/musiamazinalbuB08G" #wake up in paris
# song_url = "https://tiny.amazon.com/1d77wizgr/musiamazinalbuB003" #wake up in paris
# song_url = "https://tiny.amazon.com/ila6atts/musiamazinalbuB073" # one on one , sorana
# song_url = "https://tiny.amazon.com/uqj7vel9/musiamazinalbuB073" # wavin' flag
# song_url = "https://tiny.amazon.com/cfvku4d8/musiamazinalbuB001" # Istanbul (Not Constantinople)
# song_url = "https://tiny.amazon.com/lanof237/musiamazinalbuB0BF" # nancy mulligan , the wellerman
# song_url = "https://tiny.amazon.com/155y9odyp/musiamazinalbuB004" # They Don't Care About Us
# song_url = "https://tiny.amazon.com/1ci9pmrv2/musiamazinalbuB0D7" # Bad Feeling ( Oompa Loompa )
# song_url = "https://tiny.amazon.com/c5vfm6xk/musiamazinalbuB0BB" # mary on a cross, ghost
# song_url = "https://tiny.amazon.com/1gn8z1xdv/musiamazinalbuB0DF" # this is the life, lizot
# song_url = "https://tiny.amazon.com/1gpci9tng/musiamazinalbuB08F" # pumped up kicks, madism
# song_url = "https://tiny.amazon.com/3e13jyol/musiamazinalbuB0DJ" #Hai Yorokonde
# song_url = "https://tiny.amazon.com/b1i3v7zm/musiamazinalbuB07W" # teeth, 5 days of summer
# song_url = "https://tiny.amazon.com/82abx6ji/musiamazinalbuB0DQ" # half horse, half man | OCT
# song_url = "https://tiny.amazon.com/7uv2udnj/musiamazinalbuB0CZ"  # Birds of a feather, Billie
# grammy_song_url = random.choice(
#     [
#         "https://tiny.amazon.com/sysasifs/musiamazinalbuB0CZ",
#         "https://tiny.amazon.com/7uv2udnj/musiamazinalbuB0CZ",
#         "https://tiny.amazon.com/13782oc1j/musiamazinalbuB0D3",
#         "https://tiny.amazon.com/nu32p72s/musiamazinalbuB0CC",
#         "https://tiny.amazon.com/1jlfrq40i/musiamazinalbuB0D6",
#         "https://tiny.amazon.com/1gkbr0qua/musiamazinalbuB0DG"
#     ]
# )


def get_extra_footer(is_slack=False):
    emojis = [
        "🎶",
        "🎵",
        "🎼",
        "🎧",
        "🎤",
        "🎸",
        "🥁",
        "🎹",
        "🎻",
        "📻",
        "🎷",
        "🎺",
        "🪕",
        "🎙️",
        "🕺",
        "💃",
        "🔥",
        "🚀",
        "⚡",
        "💡",
    ]
    chosen_emoji = random.choice(emojis)

    song_starts = [
        "🎧 Mood booster unlocked: [Tap Here]",
        "🎵 Your daily theme song: [Tap Here]",
        "🎤 Soundtrack of the day: [Tap Here]",
        "🎶 One click = instant vibes: [Tap Here]",
        "🎸 This song? A whole mood. [Tap Here]",
        "🎼 Upgrade your playlist now: [Tap Here]",
        "🎹 You deserve this banger: [Tap Here]",
        "🎧 A track so good, you'll replay it twice: [Tap Here]",
        "🎷 Warning: May cause spontaneous dancing. [Tap Here]",
        "🎤 Injecting 🔥 vibes into your workflow: [Tap Here]",
        "🎶 Too good to gatekeep—enjoy! [Tap Here]",
        "🎧 Your ears will thank you later: [Tap Here]",
        "🎵 Distraction? No. Productivity fuel? Yes. [Tap Here]",
        "🎤 Press play & own the day: [Tap Here]",
        "🎶 If this song were a bug fix, it’d be a game changer. [Tap Here]",
        "🎼 Certified banger alert! [Tap Here]",
        "🎸 Not all heroes wear capes, some share great music. [Tap Here]",
        "🎧 High energy, zero regrets—just tap play: [Tap Here]",
        "🔥 Your mission: Survive the workday. Your weapon: This song. [Tap Here]",
        "💃 Work like a pro, vibe like a legend: [Tap Here]",
        "🚀 Turbocharge your day with this track: [Tap Here]",
        "⚡ Electricity in a song—charge up! [Tap Here]",
        "🎙️ Don’t just code—conquer. Here’s your anthem: [Tap Here]",
        "🎵 You didn’t ask, but you NEEDED this: [Tap Here]",
        "💡 Your brain will work 10x faster after this: [Tap Here]",
        "🔥 Caution: May cause excessive head bobbing. [Tap Here]",
        "🕺 Office rave (silent edition) starts now: [Tap Here]",
    ]

    last_parts = [
        "🎶 Code, vibe, repeat! Handpicked by your fellow Amazonians.",
        "🚀 Power up your day with this track! Selected by your colleagues.",
        "🎧 Tune in, zone out, and crush your tasks! Chosen by your peers.",
        "🔥 Fuel your hustle with this banger! Handpicked by your Amazon squad.",
        "🎵 Hit play and let the innovation flow! Selected by the best in the biz.",
        "💡 Bright ideas need a great soundtrack! Curated by your fellow Amazonians.",
        "⚡ Keep the momentum going! A power track from your teammates.",
        "💻💃 Debug and dance with today’s pick! Chosen by your coding crew.",
        "🎸 Rock your workflow with this track! Selected by your fellow innovators.",
        "🏆 Level up your productivity with this tune! Picked by your Amazon family.",
        "🎼 Let the music move your code! Handpicked by those who know.",
        "☕ Start your day with the perfect mix! Selected by your Amazon squad.",
        "🚀 Blast through your tasks with this high-energy jam! Chosen by your peers.",
        "🧠 Big ideas need big beats! Brought to you by your fellow Amazonians.",
        "🕺 Get in the groove and code like a pro! Selected by your colleagues.",
        "🎤 Sing along or just vibe—this one’s for you! Picked by your fellow devs.",
        "🎚️ Fine-tune your focus with today’s track! Selected by your team.",
        "🏃‍♂️ Keep moving, keep coding, keep winning! A pick from your peers.",
        "🌟 Spark creativity with this tune! Handpicked by the Amazon family.",
        "💃 Shake off the bugs and dance your way to success! Picked by your squad.",
        "🎵 If code had a theme song, this would be it! Selected by your peers.",
        "🕶️ Stay cool, code smooth—your teammates picked this banger for you.",
        "👑 Slay your tasks like the coding royalty you are! Chosen by the best.",
        "🎶 Debugging is better with a beat! Handpicked by your Amazon crew.",
        "💥 Crush deadlines, not your vibe! This track was chosen for champions.",
        "🔥 The soundtrack to your coding montage. Selected by your fellow legends.",
        "🎶 Work hard, vibe harder! A fire track picked just for you.",
        "🦸‍♂️ Every superhero needs a theme song—here's yours! Courtesy of your squad.",
        "💼 Code like a boss, groove like a legend! Selected by your Amazon peers.",
        "😏 You didn't choose this track, but it definitely chose you. Enjoy! 🎧",
        "🎙️ Pro tip: Good music = fewer bugs. (Probably.)",
        "🎷 Why settle for silence when you can have this masterpiece?",
        "🎺 Your workflow deserves a killer soundtrack. Boom.",
        "🕺 Because coding should come with a built-in dance break.",
        "💡 A great idea starts with a great song—this is yours.",
        "🔥 You’re on fire today. Might as well have a track to match.",
        "⚡ If music was caffeine, this would be a triple shot espresso.",
    ]

    songs_list = [
        # {
        #     "song_url": "https://tiny.amazon.com/1boidr1xv/musiamazinalbuB00V",
        #     "song_name": "Bills - EP",
        # },
        # {
        #     "song_url": "https://tiny.amazon.com/15wwch8xk/musiamazinalbuB010",
        #     "song_name": "Freedom - Pharrell Williams",
        # },
        # {
        #     "song_url": "https://tiny.amazon.com/bu89hp8o/musiamazinalbuB0DF",
        #     "song_name": ":/ - Anna Shoemaker",
        # },
        #  {
        #     "song_url": "https://tiny.amazon.com/jlj3r12o/musiamazinalbuB0CD",
        #     "song_name": "Jericho - Iniko",
        # },
        #   {
        #     "song_url": "https://tiny.amazon.com/17tp9mn9f/musiamazinalbuB073",
        #     "song_name": "Pursuit Of Happiness - Kid Cudi",
        # },
        # {
        #     "song_url": "https://tiny.amazon.com/hgp3vxop/musiamazinalbuB073",
        #     "song_name": "Holding Out for a Hero - Bonnie Tyler"
        # }
        #    {
        #     "song_url": "https://tiny.amazon.com/128kyd8i5/musiamazinalbuB091",
        #     "song_name": "Drowning World - Andrew Applepie"
        # }
        #  {
        #     "song_url": "https://tiny.amazon.com/zd19i0x/musiamazinalbuB07P",
        #     "song_name": "Suis-moi - Camille, Hans Zimmer"
        # }
        # {
        #     "song_url": "https://tiny.amazon.com/d2aaomq4/musiamazinalbuB0F3",
        #     "song_name": "Blink Twice - Shaboozey"
        # },
        # {
        #     "song_url": "https://tiny.amazon.com/lvtv3ci5/musiamazinalbuB08C",
        #     "song_name": "All My Heroes - Naeleck"
        # }
        #  {
        #     "song_url": "https://tiny.amazon.com/1gjyot5sd/musiamazinalbuB0BM",
        #     "song_name": "Stockholmsvy - Hannes & Waterbaby"
        # }
        {
            "song_url": "https://tiny.amazon.com/18of09f4u/musiamazinalbuB0F5",
            "song_name": "Scared Of Screaming - Sebastian Schub",
        }
    ]
    random_song = random.choice(songs_list)
    song_name = random_song["song_name"]
    song_url = random_song["song_url"]

    if is_slack:
        return f"{random.choice(last_parts)} - {chosen_emoji} <{song_url}|{song_name}>"
    return f"{random.choice(song_starts)}({song_url}) ; {random.choice(last_parts)}"


# print(get_extra_footer(True))
# print(get_extra_footer(False))
