import re
import boto3
from datetime import datetime, timezone
from config import DDB_TABLE_NAME


def _get_ddb_table_client():
    client = boto3.resource("dynamodb")
    return client.Table(DDB_TABLE_NAME)


def put_ticket_entry(
    folder_id, ticket_id, comment_id, ticket_action, summary_done=False
):
    _get_ddb_table_client().put_item(
        Item={
            "ticketId": ticket_id,
            "folderId": folder_id,
            "ticketAction": ticket_action,
            "isSummaryDone": summary_done,
            "commentId": comment_id,
            "updatedAt": datetime.now(timezone.utc).isoformat(),
        }
    )
    return "Ticket entry added successfully"


def put_ticket_entry_for_announcement(
    folder_id,
    ticket_id,
    thread_id,
    announcement_id,
    ticket_action,
    updated_count=0,
    announcement_updated=False,
):
    _get_ddb_table_client().put_item(
        Item={
            "ticketId": ticket_id,
            "folderId": folder_id,
            "ticketAction": ticket_action,
            "threadId": thread_id,
            "announcementId": announcement_id,
            "isAnnouncementUpdated": announcement_updated,
            "updatedCount": updated_count,
            "announcementUpdatedAt": datetime.now(timezone.utc).isoformat(),
        }
    )
    return "Announcement entry added successfully"


def get_ticket_entry(ticket_id):
    data = _get_ddb_table_client().get_item(
        Key={"ticketId": ticket_id}, ConsistentRead=True
    )
    if not data or "Item" not in data:
        return None
    else:
        return data["Item"]
