import urllib.request

from prompt_constants import (
    get_daily_ticket_summary_prompt,
    get_daily_ticket_merge_summary_prompt,
    get_lt_ticket_summary_prompt,
    get_lt_ticket_merge_summary_prompt,
)
from invoke_bedrock import invoke_bedrock
from experimental_prompts import (
    get_daily_ticket_summary_prompt as get_daily_ticket_summary_prompt_exp,
)
from config import (
    invokeSlackEndpoint,
    DAILY_REMINDER_FOOTER,
    CUSTOM_PROMPTS,
    CUSTOM_MERGE_PROMPTS,
)


def _execute_daily_summary_module(
    t_data, folder_name, folder_id, webhook_url, dry_run=False, is_lt_summary=False
):
    TICKETS_TO_CHUNK = 50
    response = []
    splitted_ticket_data = [
        t_data[i : i + TICKETS_TO_CHUNK]
        for i in range(0, len(t_data), TICKETS_TO_CHUNK)
    ]
    for count, s_t_data in enumerate(splitted_ticket_data, 1):
        print(
            f"[{count}/{len(splitted_ticket_data)}] [{folder_id}] processing tickets for folder : [{folder_name}] having size : [{len(s_t_data)}]"
        )
        pmt = (
            CUSTOM_PROMPTS[folder_id](s_t_data, folder_name)
            if isinstance(folder_id, str) and folder_id in CUSTOM_PROMPTS
            else (
                get_daily_ticket_summary_prompt_exp(s_t_data, folder_name)
                if not is_lt_summary
                else get_lt_ticket_summary_prompt(s_t_data, folder_name)
            )
        )
        answer = (
            ""
            if dry_run
            else invoke_bedrock(
                folder_id, pmt, False if not is_lt_summary else False, False
            )
        )
        answer += "\n\n" + DAILY_REMINDER_FOOTER
        print(f"[{folder_name}] : {answer}")
        response.append(answer)

    if response:
        if len(response) > 1:
            pmt = (
                CUSTOM_MERGE_PROMPTS[folder_id](response)
                if folder_id in CUSTOM_MERGE_PROMPTS
                else (
                    get_daily_ticket_merge_summary_prompt(response, folder_name)
                    if not is_lt_summary
                    else get_lt_ticket_merge_summary_prompt(response, folder_name)
                )
            )
            final_response = (
                ""
                if dry_run
                else invoke_bedrock(
                    folder_id, pmt, False if not is_lt_summary else True, False
                )
            )
            print(f"[{folder_name}] : {final_response}")
        else:
            final_response = response[0]
        if not dry_run:
            invokeSlackEndpoint(webhook_url, final_response)
            pass
        return final_response
    return f"[{folder_id}] No response from module"
