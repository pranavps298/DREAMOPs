import uuid
import boto3
from botocore.awsrequest import AWSRequest
from botocore.credentials import Credentials
from botocore.endpoint import URLLib3Session
from botocore.auth import SigV4Auth

import json
import re
import urllib.parse
import urllib.request


from prompt_constants import (
    get_prompt,
    get_edit_summarizer_prompt,
    get_daily_ticket_summary_prompt,
    get_daily_ticket_merge_summary_prompt,
)
from invoke_bedrock import invoke_bedrock
from format_ticket_data import (
    format_ticket_data,
    escape_string,
    get_similar_tickets_section,
)
from config import (
    ALLOWED_FOLDER_IDS,
    NO_FOOTER,
    MAX_SIM_TICKETS,
    MAX_SIM_FOR_MODEL,
    is_tt_allowed,
    is_tt_allowed_for_edit,
    READ_TIMEOUT_ERR_CODE,
    FOOTER,
    invokeSlackEndpoint,
    get_daily_reminder_config,
    DAILY_REMINDER_FOOTER,
    MAX_BEDROCK_CHAR,
    RESOLVED_STATUS,
)
from ddb_actions import (
    put_ticket_entry,
    get_ticket_entry,
    put_ticket_entry_for_announcement,
)

from ticket_actions import (
    get_ticket_from_maxis,
    list_similar_ticket_from_maxis,
    post_comment_on_ticket_from_maxis,
    should_edit_details_from_maxis,
    post_announcement_on_ticket_from_maxis,
    update_announcement_on_ticket_from_maxis,
    is_user_announcement_present,
    get_all_open_tickets,
)
from daily_summary_module import _execute_daily_summary_module
from lt_summary import execute_lt_summarizer


def run_initial_summarizer(
    ticket_id,
    passed_t_data=None,
    document_action="",
    dry_run=False,
    existing_comment_id=None,
):
    t_data = passed_t_data if passed_t_data else get_ticket_from_maxis(ticket_id)
    s_tickets = list_similar_ticket_from_maxis(
        t_data["id"], t_data["title"], t_data["folderId"], t_data
    )
    if s_tickets and len(str(s_tickets[:MAX_SIM_FOR_MODEL])) >= MAX_BEDROCK_CHAR:
        s_tickets = s_tickets[: MAX_SIM_FOR_MODEL // 2]
    prompt = get_prompt(t_data, s_tickets[:MAX_SIM_FOR_MODEL] if s_tickets else [])
    answer = "" if dry_run else invoke_bedrock(ticket_id, prompt, False, True)
    if answer == READ_TIMEOUT_ERR_CODE:
        prompt = get_prompt(
            t_data, s_tickets[: MAX_SIM_FOR_MODEL // 2] if s_tickets else []
        )
        answer = "" if dry_run else invoke_bedrock(ticket_id, prompt, False, False)
    footer = get_similar_tickets_section(
        s_tickets, MAX_SIM_TICKETS, t_data["folderId"] not in NO_FOOTER
    )
    result = f"{answer}\n{footer}"
    if not dry_run:
        print(
            f"starting to post comment on ticket [{ticket_id}] , existing_comment_id : [{existing_comment_id}]"
        )
        comment_id = post_comment_on_ticket_from_maxis(
            t_data["id"], result, existing_comment_id
        )
        resp = put_ticket_entry(
            t_data["folderId"], t_data["id"], comment_id, document_action, True
        )
        print(f"ticket details added in ddb [{ticket_id}] : {resp}")

    return result


def run_edit_summarizer(
    ticket_id,
    passed_t_data=None,
    document_action="",
    dry_run=False,
    existing_thread_id=None,
    existing_announcement_id=None,
    updated_count=0,
):
    t_data = passed_t_data if passed_t_data else get_ticket_from_maxis(ticket_id)
    prompt = get_edit_summarizer_prompt(t_data)
    answer = "" if dry_run else invoke_bedrock(ticket_id, prompt, False, True)
    if answer == READ_TIMEOUT_ERR_CODE:
        prompt = get_edit_summarizer_prompt(t_data)
        answer = "" if dry_run else invoke_bedrock(ticket_id, prompt, False, False)
    result = f"{answer}\n{FOOTER}"
    if not dry_run:
        thread_id, announcement_id = existing_thread_id, existing_announcement_id
        print(f"starting to post announcement on ticket [{ticket_id}]")
        if existing_thread_id:
            update_announcement_on_ticket_from_maxis(
                t_data["id"], existing_thread_id, result, existing_announcement_id
            )
        else:
            thread_id, announcement_id = post_announcement_on_ticket_from_maxis(
                t_data["id"], result
            )
        resp = put_ticket_entry_for_announcement(
            t_data["folderId"],
            t_data["id"],
            thread_id,
            announcement_id,
            document_action,
            updated_count + 1,
            True,
        )
        print(f"ticket details added in ddb [{ticket_id}] : {resp}")
    return result


def execute_daily_ticket_summary(
    folder_ids,
    dry_run=False,
    shouldGroupByFolder=False,
):
    print(f"sending daily ticket summary for folders : {folder_ids}")
    response = []
    if shouldGroupByFolder:
        all_t_data = []
        for folder_id in folder_ids:
            t_data = get_all_open_tickets(folder_id)
            if t_data:
                all_t_data.extend(t_data)
        if all_t_data:
            print(f"[{folder_ids}] tickets length : [{len(all_t_data)}]")
            conf = get_daily_reminder_config(folder_ids[0])
            response.append(
                _execute_daily_summary_module(
                    all_t_data,
                    conf.get("folderName"),
                    folder_ids,
                    conf.get("webhook"),
                    dry_run,
                )
            )

        else:
            print("no tickets found for any folder")
    else:
        for folder_id in folder_ids:
            conf = get_daily_reminder_config(folder_id)
            t_data = get_all_open_tickets(folder_id)
            if t_data:
                print(f"[{folder_ids}] tickets length : [{len(t_data)}]")
                response.append(
                    _execute_daily_summary_module(
                        t_data,
                        conf.get("folderName"),
                        folder_id,
                        conf.get("webhook"),
                        dry_run,
                    )
                )
            else:
                print(f"no ticket found for folder : [{folder_id}] ")
    return response


def execute_calls(document_id, edit_id, document_action, dry_run=False):
    if document_action and document_action.lower() == "create":
        t_data = get_ticket_from_maxis(document_id)
        if t_data.get("current_status") == RESOLVED_STATUS:
            print(f"Ticket [{document_id}] is already resolved")
        elif t_data and is_tt_allowed(t_data):
            print(f"Processing ticket [{document_id}] for [{document_action}]")
            existing_ddb_entry = get_ticket_entry(document_id)
            if existing_ddb_entry and existing_ddb_entry.get("isSummaryDone"):
                print(f"Ticket [{document_id}] already summarized")
            else:
                if should_edit_details_from_maxis(document_id, edit_id, "create"):
                    return run_initial_summarizer(
                        document_id,
                        t_data,
                        document_action,
                        dry_run,
                        (
                            existing_ddb_entry.get("commentId")
                            if existing_ddb_entry
                            else None
                        ),
                    )
                else:
                    print(
                        f"Ticket [{document_id}] having edit id [{edit_id}] not allowed for processing due to non edit paths even though it's create action."
                    )

        else:
            print(f"Ticket [{document_id}] not in allowed folder")
    elif document_action and document_action.lower() == "modify":
        # invoked when a ticket is modified
        t_data = get_ticket_from_maxis(document_id)
        if t_data.get("current_status") == RESOLVED_STATUS:
            print(f"Ticket [{document_id}] is already resolved")
        if t_data and is_tt_allowed_for_edit(t_data):
            if should_edit_details_from_maxis(document_id, edit_id, "modify"):
                if not is_user_announcement_present(t_data.get("threads", [])):
                    print(f"Processing ticket [{document_id}] for [{document_action}]")
                    existing_ddb_entry = get_ticket_entry(document_id)
                    return run_edit_summarizer(
                        document_id,
                        t_data,
                        document_action,
                        dry_run,
                        (
                            existing_ddb_entry.get("threadId")
                            if existing_ddb_entry
                            else None
                        ),
                        (
                            existing_ddb_entry.get("announcementId")
                            if existing_ddb_entry
                            else None
                        ),
                        (
                            existing_ddb_entry.get("updatedCount", 0)
                            if existing_ddb_entry
                            else 0
                        ),
                    )
                else:
                    print(
                        f"Ticket [{document_id}] not allowed for processing due to existing user announcement."
                    )
            else:
                print(
                    f"Ticket [{document_id}] not allowed for processing due to non edit paths."
                )
        else:
            print(f"Ticket [{document_id}] not in allowed folder")
    else:
        print(f"Document [{document_id}] action [{document_action}] not enabled yet.")


def lambda_handler(event, context):

    if "Records" in event:
        # print("Receiving Message from myQueue SQS")
        for record in event["Records"]:
            body = json.loads(record["body"])
            message = json.loads(body["Message"])
            print(message)
            documentId = message["documentId"]["id"]
            documentAction = message["action"]
            execute_calls(documentId, message.get("editId", ""), documentAction)
    elif "folderIds" in event:
        execute_daily_ticket_summary(
            event["folderIds"], False, event.get("shouldGroupByFolder")
        )
    elif "leader" in event:
        execute_lt_summarizer(
            event["leader"],
            False,
        )
    elif "body" in event:
        t_id = json.loads(event.get("body", {}))
        t_id = t_id["ticketId"]
        t_data = get_ticket_from_maxis(t_id)
        return list_similar_ticket_from_maxis(
            t_data["id"], t_data["title"], t_data["folderId"], t_data
        )
    else:
        print("invalid input payload provided")


"""
for local invocations
"""
# print(
#     run_initial_summarizer(
#         "D161592422",
#         passed_t_data=None,
#         document_action="Create",
#         dry_run=False,
#         existing_comment_id="3c772c42-8556-4776-b702-8ac3ea34d718",
#     )
# )
# print(execute_calls("24cf0ae6-5c3b-4042-91aa-66cdfa05ca34", "", "Modify", False))
# print(
#     execute_daily_ticket_summary(
#         [
#             "894d636c-ba6d-4ddf-8db9-a0e551f6cdd2",
#         ],
#         False,
#     )
# )
# print(execute_lt_summarizer("srsudhir", False))
# print(
#     execute_daily_ticket_summary(
#         [
#             "db080ba5-b593-4942-87f6-bda10ef6e156",
#         ],
#         False,
#         False,
#     )
# )
