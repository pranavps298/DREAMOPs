import re
from config import MAX_TITLE_SIZE, MAX_SIM_TICKETS, BOT_SIM_COMMENT_AUTHORS, FOOTER


def escape_string(s):
    special_chars = [
        "\\",
        "+",
        "-",
        "!",
        "(",
        ")",
        ":",
        "^",
        "[",
        "]",
        '"',
        "{",
        "}",
        "~",
        "*",
        "?",
        "|",
        "&",
        ";",
        "/",
        "<",
        ">",
    ]
    sb = ""
    for c in s:
        if c in special_chars:
            sb += "\\"
        sb += c
    klm = re.sub(r"\b(and|or|not)\b", "", sb).replace("=", " ")
    return klm


def _get_requester(requester):
    try:
        if re.search("kerberos:.+@ANT.AMAZON.COM", requester, flags=re.I):
            return re.search(
                "kerberos:(.+)@ANT.AMAZON.COM", requester, flags=re.I
            ).group(1)
        elif re.search("SnowServiceRole-v3|SnowEngine-Service", requester, flags=re.I):
            return "system"
        elif re.search("arn:aws.*:user.*", requester, flags=re.I):
            return re.search("arn:(.+):user/(.+)", requester, flags=re.I).group(2)
        return requester
    except Exception as ex:
        print("error while getting requester identity", ex)
    return requester


def _format_comments(comments):
    all_comments = []
    for comment in comments:
        author = _get_requester(comment.get("authorIdentity", ""))
        if author not in BOT_SIM_COMMENT_AUTHORS:
            all_comments.append(
                {
                    "comment": comment.get("message", ""),
                    "author": author,
                    "createDate": comment.get("createDate", ""),
                    "lastUpdatedDate": comment.get("lastUpdatedDate", ""),
                    "commentType": comment.get("messageType", ""),
                }
            )
    return sorted(all_comments, key=lambda x: x["createDate"], reverse=True)


def format_ticket_data(ticket):
    return {
        "title": ticket.get("title", ""),
        "description": ticket.get("description", ""),
        "id": ticket.get("id", ""),
        "current_status": ticket.get("status", ""),
        "createDate": ticket.get("createDate", ""),
        "lastUpdatedDate": ticket.get("lastUpdatedDate", ""),
        "requester": _get_requester(ticket.get("requesterIdentity", "")),
        "lastResolvedBy": _get_requester(ticket.get("lastResolvedByIdentity", "")),
        "conversation": _format_comments(ticket.get("conversation", [])),
        "folderId": ticket.get("assignedFolder", ""),
        "threads": ticket.get("threads", []),
        "dedupeString": ticket.get("extensions", {})
        .get("tt", {})
        .get("dedupeString", "")
        or ticket.get("deduplicatorString", "")
        or ticket.get("title", ""),
        "rootCause": ticket.get("extensions", {}).get("tt", {}).get("rootCause", ""),
        "severity": ticket.get("extensions", {}).get("tt", {}).get("impact", 4),
        "closureCode": ticket.get("extensions", {})
        .get("tt", {})
        .get("closureCode", ""),
        "assignedGroup": ticket.get("extensions", {})
        .get("tt", {})
        .get("assignedGroup", ""),
        "cti": ticket.get("extensions", {}).get("tt", {}).get("category", "")
        + "|"
        + ticket.get("extensions", {}).get("tt", {}).get("type", ""),
    }


def get_similar_tickets_section(
    s_tickets, max_count=MAX_SIM_TICKETS, include_footer=True
):
    klm = ""
    if s_tickets:
        klm = "### Similar tickets in past:\n---\nTICKETS | LAST RESOLVED | CLOSURE CODE | ROOT CAUSE | LAST RESOLVED BY\n------------------- | ------------------- | ------------------- | ------------------- | -------------------\n"
        tickets = []
        for t in s_tickets:
            name = escape_string(
                t.get("title")
                if len(t.get("title")) <= MAX_TITLE_SIZE
                else t.get("title")[:MAX_TITLE_SIZE] + "..."
                # .replace("[", "\[")
                # .replace("]", "\]")
            )
            # replace multiple newline in name with blank space
            name = name.replace("\r", " ").replace("\n", " ")
            user = t.get("lastResolvedBy", "NaN")
            rootCause = t.get("rootCause")
            closureCode = t.get("closureCode")
            createDate = t.get("createDate")
            tickets.append(
                f"[{name}](https://t.corp.amazon.com/{t.get('id')}) | {createDate} | {closureCode} | {rootCause} | [{user}](https://phonetool.amazon.com/users/{user}) |"
            )
        klm += "\n".join(tickets[:max_count])
    if not include_footer:
        klm += "\n\n##### Powered by [TRIBot]"
    else:
        klm += f"\n\n{FOOTER}"
    return klm.strip()


# from pprint import pprint

# pprint(format_ticket_data(abc))
