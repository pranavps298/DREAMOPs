# Coral - Datapath Shadow Comparator

This tool extracts logs, uploads them to S3, constructs requests for both Datapath and Coral APIs, compares their responses, and produces a final report.

The HTML report is found in the `tmp/responses/shadow_comparison_report...` file. Check the terminal for the exact filename.

## Prerequisites

Ensure you have access to the AWS account: `339712754253`.

## Steps

### 1. Log Parsing

1. Modify `parse_logs.py` to set the time range and desired API:
   ```python
   directory_path: str = "/onlinelogs/ADGProductService/NA/Beta/2025/02/"
   file_pattern: str = "application.log"
   api_name: str = "GetProductRequest"
   max_request_length: int = 1000
   ```
2. SSH to the timber host and run the script. Data goes to `dc-vending-exp-shadow-tests` bucket.

### 2. Invocation

1. Clone `get_product.py`, rename it, and update the service config:
   ```python
   config = ServiceConfig(
       file_name="GetProductRequest_requests_1738913250.json",
       view_name="digital::catalog::adg::product::getProduct",
       service_name="getProductADGProductService",
   )
   ```
2. Adjust `DataTransformer` methods as needed.
3. Run the script. The final report is in `tmp/responses/shadow_comparison_report...`.

### 3. [ Individual ] Report Generation

1. Use the `generate_report.py` script to generate the HTML report:

   ```python
   from generate_report import generate

   generate("tmp/responses/shadow_response.json", "API_NAME")
   ```

### 4. [ Individual ] Running the Entire Process

1. To run the entire process, use the `make_calls.py` script:

   ```python
   from make_calls import run_execute

   run_execute(
       file_name="GetProductRequest_requests_1738913250.json",
       view_name="digital::catalog::adg::product::getProduct",
       request_transformer_dp=DataTransformer.transform_request_for_dp,
       request_transformer_coral=DataTransformer.transform_request_for_coral,
       response_transformer_dp=DataTransformer.transform_response_for_dp,
       response_transformer_coral=DataTransformer.transform_response_for_coral,
       api_name="getProductADGProductService",
   )
   ```

## Directory Structure

- `parse_logs.py`: Script to parse logs and upload to S3.
- `get_product.py`: Script to transform payloads and make API calls.
- `generate_report.py`: Script to generate HTML reports.
- `make_calls.py`: Script to run the entire process.

## Notes

- Ensure all necessary AWS credentials and permissions are in place.
- Modify the scripts as needed to fit your specific use case.
