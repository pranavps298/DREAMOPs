import requests
import aioboto3
import os
import json
import re
import asyncio
import aiohttp
from requests_aws4auth import AWS4Auth
from concurrent.futures import ThreadPoolExecutor
from generate_report import generate
from botocore.credentials import Credentials


class ShadowTestConfig:
    BUCKET_NAME = "dc-vending-exp-shadow-tests"
    S3_AWS_ACT = "600124756229"
    DATAPATH_TOKEN = "ADGDiscoveryService-Appstore-Datapath"
    DATAPATH_URL = "http://sable-responders-adhoc.integ.amazon.com:8080/datapath/query"
    API_REGION = "us-east-1"
    API_URL = "https://37ghybcqoh.execute-api.us-east-1.amazonaws.com/beta"
    RESOURCE_ID_MAP = {"getProductADGProductService": "ui8gg7"}
    API_ID = "37ghybcqoh"
    API_AWS_ACT = "339712754253"

    TEMP_DIR = "tmp"
    RESPONSE_DIR = f"{TEMP_DIR}/responses"


class S3Client:
    @staticmethod
    async def download_file(region, file_name, local_path):
        """Download file from S3 using aioboto3."""
        print(f"Getting {file_name} from S3...")
        try:
            session = aioboto3.Session()
            async with session.client("s3", region_name=region) as s3:
                await s3.download_file(
                    ShadowTestConfig.BUCKET_NAME, file_name, local_path
                )
            print(f"Downloaded {file_name} to {local_path}")
        except Exception as e:
            print(f"Error downloading from S3: {str(e)}")
            raise


class DataPathClient:
    @staticmethod
    async def make_call(session, view_name, input_data):
        try:
            payload = f"({view_name} {json.dumps(input_data)} payload)"
            async with session.post(
                ShadowTestConfig.DATAPATH_URL,
                headers={
                    "Authorization": f"SableBasic {ShadowTestConfig.DATAPATH_TOKEN}",
                    "Accept": "application/json",
                },
                data=payload,
            ) as response:
                text = await response.text()
                cleaned_response = re.sub(
                    '\{"type":"HostNameProvider.*', "", text, flags=re.I
                )
                return {
                    "response": cleaned_response.strip(),
                    "success": True,
                    "input": payload,
                }
        except Exception as e:
            return {
                "error": str(e),
                "success": False,
                "input": payload,
            }


class APIGatewayClient:
    @staticmethod
    async def make_call(session, region, payload):
        try:
            async with aioboto3.Session().client("sts") as client:
                credentials = await aioboto3.Session().get_credentials()
                credentials = await credentials.get_frozen_credentials()

                aws_auth = AWS4Auth(
                    credentials.access_key,
                    credentials.secret_key,
                    region,
                    "execute-api",
                    session_token=credentials.token,
                )

            api_url = f"{ShadowTestConfig.API_URL}/{payload['api']}"
            headers = {"Content-Type": "application/json"}
            request = requests.Request(
                "POST",
                api_url,
                json=payload["request"],
                headers=headers,
                auth=aws_auth,
            ).prepare()

            async with aiohttp.ClientSession() as session:
                async with session.post(
                    api_url,
                    data=request.body,
                    headers=request.headers,
                ) as response:
                    if response.status != 200:
                        raise Exception(await response.text())

                    resp_data = await response.json()
                    if resp_data and not resp_data.get("status"):
                        raise Exception(resp_data.get("response"))

                    return {
                        "response": resp_data.get("response"),
                        "success": True,
                        "input": payload,
                    }
        except Exception as ex:
            return {
                "error": str(ex),
                "success": False,
                "input": payload,
            }


class JSONComparator:
    @staticmethod
    def compare(json1, json2, ignore_null=False):
        if json1 == json2:
            return {}

        def compare_arrays(arr1, arr2, ignore_null):
            import json

            # Sort arrays using canonical string representation
            try:
                sorted_arr1 = sorted(arr1, key=lambda x: json.dumps(x, sort_keys=True))
                sorted_arr2 = sorted(arr2, key=lambda x: json.dumps(x, sort_keys=True))
            except Exception as ex:
                # Fallback to original order if sorting fails
                sorted_arr1, sorted_arr2 = arr1, arr2

            differences = {}
            if len(sorted_arr1) != len(sorted_arr2):
                differences["length"] = {
                    "datapath": len(sorted_arr1),
                    "coral": len(sorted_arr2),
                }
            for i, (v1, v2) in enumerate(zip(sorted_arr1, sorted_arr2)):
                nested_diff = diff(v1, v2)
                if nested_diff:
                    differences[i] = nested_diff
            return differences

        def diff(d1, d2):
            # Attempt to decode JSON if both are strings
            if isinstance(d1, str) and isinstance(d2, str):
                try:
                    decoded1 = json.loads(d1)
                    decoded2 = json.loads(d2)
                except Exception:
                    pass  # Not valid JSON; fallback to string comparison
                else:
                    return diff(decoded1, decoded2)
            # Handle lists
            if isinstance(d1, list) and isinstance(d2, list):
                return compare_arrays(d1, d2, ignore_null)
            # Handle dictionaries
            if isinstance(d1, dict) and isinstance(d2, dict):
                differences = {}
                all_keys = set(d1.keys()).union(d2.keys())
                for key in all_keys:
                    val1, val2 = d1.get(key), d2.get(key)
                    if ignore_null and val1 is None and val2 is None:
                        continue
                    nested_diff = diff(val1, val2)
                    if nested_diff:
                        differences[key] = nested_diff
                return differences
            # Handle type mismatches and primitives
            if type(d1) != type(d2):
                return {"datapath": d1, "coral": d2}
            return {} if d1 == d2 else {"datapath": d1, "coral": d2}

        return diff(json1, json2)


def setup_directories(api_name):
    os.makedirs(ShadowTestConfig.TEMP_DIR, exist_ok=True)
    os.makedirs(ShadowTestConfig.RESPONSE_DIR, exist_ok=True)
    os.makedirs(f"{ShadowTestConfig.RESPONSE_DIR}/{api_name}", exist_ok=True)


def generate_internal_report(output_file, api_name):
    """
    Simple report generation function. Replace with your actual report generation logic.
    """
    report_file = f"{output_file}_report.txt"
    with open(output_file, "r") as f:
        data = json.load(f)

    with open(report_file, "w") as f:
        f.write(f"Shadow Test Report for {api_name}\n")
        f.write("=" * 50 + "\n\n")

        total_tests = len(data)
        successful_tests = sum(1 for v in data.values() if not v.get("error"))
        failed_tests = total_tests - successful_tests

        f.write(f"Total tests: {total_tests}\n")
        f.write(f"Successful tests: {successful_tests}\n")
        f.write(f"Failed tests: {failed_tests}\n\n")

        for id, result in data.items():
            f.write(f"Test ID: {id}\n")
            if "error" in result:
                f.write(f"Error: {result['error']}\n")
            else:
                f.write(f"Differences found: {bool(result['differences'])}\n")
                if result["differences"]:
                    f.write(
                        f"Differences: {json.dumps(result['differences'], indent=2)}\n"
                    )
            f.write("-" * 30 + "\n")

    return report_file


async def process_entry(
    session,
    id,
    entry,
    view_name,
    request_transformer_dp,
    request_transformer_coral,
    api_name,
):
    try:
        print(f"\nProcessing entry: {id}")

        # Make API calls concurrently
        dp_task = DataPathClient.make_call(
            session, view_name, request_transformer_dp(entry)
        )

        lambda_task = APIGatewayClient.make_call(
            session,
            ShadowTestConfig.API_REGION,
            {"api": api_name, "request": request_transformer_coral(entry)},
        )

        dp_response, lambda_response = await asyncio.gather(dp_task, lambda_task)
        return id, dp_response, lambda_response
    except Exception as ex:
        print(f"--- Error processing entry {id}: {str(ex)} ---")
        raise ex


async def execute(
    file_name,
    view_name,
    request_transformer_dp,
    request_transformer_coral,
    response_transformer_dp,
    response_transformer_coral,
    api_name,
):
    setup_directories(api_name)
    input_file_path = os.path.join(
        f"{ShadowTestConfig.RESPONSE_DIR}/{api_name}", file_name
    )

    # Update credentials (using thread pool to not block)
    loop = asyncio.get_event_loop()
    with ThreadPoolExecutor() as pool:
        await loop.run_in_executor(
            pool,
            lambda: os.system(
                f"ada credentials update --account={ShadowTestConfig.API_AWS_ACT} "
                "--provider=conduit --role=IibsAdminAccess-DO-NOT-DELETE --once"
            ),
        )

    # Download input file from S3
    await S3Client.download_file(
        ShadowTestConfig.API_REGION, file_name, input_file_path
    )

    # Read input data
    with open(input_file_path, "r") as f:
        input_data = json.load(f)
    print(f"Read {len(input_data)} entries from {input_file_path}")

    # input_data = dict(list(input_data.items())[:100])

    # Process entries concurrently
    async with aiohttp.ClientSession() as session:
        results = []
        batch_size = 50
        items = list(input_data.items())
        for i in range(0, len(items), batch_size):
            batch = items[i : i + batch_size]
            tasks = [
                process_entry(
                    session,
                    id,
                    entry,
                    view_name,
                    request_transformer_dp,
                    request_transformer_coral,
                    api_name,
                )
                for id, entry in batch
            ]
            batch_results = await asyncio.gather(*tasks)
            results.extend(batch_results)

    # Process results
    shadow_response = {}
    print("Comparing responses...")
    for id, dp_resp, lambda_resp in results:
        try:
            differences = {}
            if (
                dp_resp
                and lambda_resp
                and dp_resp.get("success")
                and lambda_resp.get("success")
            ):
                dp_data = response_transformer_dp(json.loads(dp_resp["response"]))
                lambda_data = response_transformer_coral(
                    json.loads(lambda_resp["response"])
                )

                print(f"Comparing responses for entry: {id}")
                differences = JSONComparator.compare(dp_data, lambda_data, True)
                shadow_response[id] = {
                    "dp_response": dp_resp,
                    "lambda_response": lambda_resp,
                    "differences": differences,
                }
            else:
                shadow_response[id] = {
                    "dp_response": dp_resp,
                    "lambda_response": lambda_resp,
                    "error": lambda_resp.get("error")
                    or dp_resp.get("error")
                    or "one or both calls failed",
                    "differences": differences,
                }

        except Exception as ex:
            shadow_response[id] = {
                "error": str(ex),
                "dp_response": dp_resp,
                "lambda_response": lambda_resp,
                "differences": {},
            }

    # Save results
    output_file = os.path.join(
        f"{ShadowTestConfig.RESPONSE_DIR}/{api_name}", "shadow_response.json"
    )
    with open(output_file, "w") as f:
        json.dump(shadow_response, f, indent=4)
    print(f"\nShadow response written to {output_file}")

    # Generate report
    print("\nGenerating report...")
    generate_internal_report(output_file, api_name)
    final_report = generate(output_file, api_name)
    print(f"\nReport generated at {final_report}")


def run_execute(*args, **kwargs):
    asyncio.run(execute(*args, **kwargs))
