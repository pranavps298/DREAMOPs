import os
import re
import json
import zstandard as zstd
import time
import requests
import base64
import boto3
import uuid
from multiprocessing import Pool, cpu_count
from functools import partial
from typing import Dict, List, Any, Tuple
from dataclasses import dataclass


@dataclass
class Config:
    """Configuration settings for the application"""

    directory_path: str = "/onlinelogs/ADGProductService/NA/Beta/2025/02/"
    file_pattern: str = "application.log"
    api_name: str = "GetProductsInChannelRequest"
    max_request_length: int = 1000
    odin_credentials: str = (
        "com.amazon.credentials.isengard.600124756229.user/s3-uploader"
    )
    s3_bucket: str = "dc-vending-exp-shadow-tests"
    region: str = "us-east-1"

    def get_output_filename(self) -> str:
        return f"{self.api_name}_requests_{int(time.time())}.json"


class OdinCredentialManager:
    """Handles Odin credential retrieval and management"""

    @staticmethod
    def get_credentials(material_set_name: str) -> Tuple[str, str]:
        """Retrieve credentials from Odin service"""
        principal_data = requests.get(
            f"http://localhost:2009/query?Operation=retrieve&ContentType=JSON&"
            f"material.materialName={material_set_name}&material.materialType=Principal"
        )
        credential_data = requests.get(
            f"http://localhost:2009/query?Operation=retrieve&ContentType=JSON&"
            f"material.materialName={material_set_name}&material.materialType=Credential"
        )

        principal_json = principal_data.json()
        credential_json = credential_data.json()

        principal = base64.b64decode(principal_json["material"]["materialData"]).decode(
            "utf-8"
        )
        credential = ""

        if "Error" in credential_json:
            print(json.dumps(credential_json, indent=2))
        else:
            credential = base64.b64decode(
                credential_json["material"]["materialData"]
            ).decode("utf-8")

        return principal, credential


class S3Uploader:
    """Handles S3 upload operations"""

    def __init__(self, config: Config):
        self.config = config

    def upload_file(self, credentials: Tuple[str, str], file_name: str) -> Dict:
        """Upload a file to S3"""
        print(f"\nUploading {file_name} to S3...")

        s3_client = boto3.client(
            "s3",
            aws_access_key_id=credentials[0],
            aws_secret_access_key=credentials[1],
            region_name=self.config.region,
        )

        return s3_client.put_object(
            Body=open(file_name, "rb"),
            Bucket=self.config.s3_bucket,
            Key=file_name,
        )


class JsonProcessor:
    """Handles JSON processing and sanitization using type markers."""

    # When the marker is this, it signals that the inner element is an array.
    ARRAY_TYPE_MARKER = "class java.util.ArrayList"
    # For other type wrappers, if the simple class name is in this set,
    # then we wrap the inner value in a list.
    ARRAY_TYPES = {}

    @staticmethod
    def sanitize_json(raw_json: str) -> Any:
        try:
            data = json.loads(raw_json)
            return JsonProcessor._fix_structure(data)
        except json.JSONDecodeError:
            return None

    @staticmethod
    def _fix_structure(obj: Any, parent_key: str = None) -> Any:
        if isinstance(obj, list):
            # Detect a type wrapper: a 2-element list whose first element is a class marker.
            if len(obj) > 1 and isinstance(obj[0], str) and obj[0].startswith("class"):
                type_marker = obj[0]
                inner = JsonProcessor._fix_structure(obj[1], parent_key)
                if type_marker == JsonProcessor.ARRAY_TYPE_MARKER:
                    # Ensure the result is a list (wrap if not).
                    return inner if isinstance(inner, list) else [inner]
                else:
                    # For other type wrappers, extract the simple class name.
                    simple_name = type_marker.split()[-1].split(".")[-1]
                    if simple_name in JsonProcessor.ARRAY_TYPES:
                        # Wrap in a list if not already one.
                        return inner if isinstance(inner, list) else [inner]
                    else:
                        return inner
            else:
                # For a normal list, process each element.
                return [JsonProcessor._fix_structure(item, None) for item in obj]
        elif isinstance(obj, dict):
            new_dict = {}
            for key, value in obj.items():
                new_dict[key] = JsonProcessor._fix_structure(value, key)
            return new_dict
        else:
            return obj


class FileProcessor:
    """Handles file processing operations"""

    def __init__(self, config: Config):
        self.config = config
        self.json_pattern = re.compile(
            r"\{\[0\]=\[\s*\"class com\.amazon\.adg\.product\.service\.model\."
            + config.api_name
            + '",\s*(\{.*?\})\s*\]\}',
            re.DOTALL,
        )

    def find_matching_files(self) -> List[str]:
        """Find all matching files in the directory"""
        matching_files = []
        print(f"Searching for files in {self.config.directory_path}...")

        for root, _, files in os.walk(self.config.directory_path):
            matching_files.extend(
                os.path.join(root, file)
                for file in files
                if self.config.file_pattern in file
            )

        print(f"\nFound matching files: [{len(matching_files)}]")
        return matching_files

    def process_single_file(self, file_path: str) -> Dict:
        """Process a single file and return extracted entries"""
        entries = {}
        try:
            dctx = zstd.ZstdDecompressor()
            with open(file_path, "rb") as compressed_file:
                with dctx.stream_reader(compressed_file) as reader:
                    content = reader.read().decode("utf-8")
                    matches = self.json_pattern.findall(content)

                    for match in matches:
                        cleaned_json = JsonProcessor.sanitize_json(match)
                        if (
                            cleaned_json
                            and len(cleaned_json) < self.config.max_request_length
                        ):
                            entries[str(uuid.uuid4())] = cleaned_json

            print(f"Processed {file_path} - Found {len(entries)} entries")
            return entries

        except Exception as e:
            print(f"Error processing {file_path}: {str(e)}")
            return {}


def main():
    """Main execution function"""
    # Initialize configuration
    config = Config()
    output_file = config.get_output_filename()

    # Initialize processors
    file_processor = FileProcessor(config)
    s3_uploader = S3Uploader(config)

    # Find and process files
    matching_files = file_processor.find_matching_files()

    # Set up parallel processing
    num_processes = min(cpu_count(), len(matching_files))
    process_file_partial = partial(file_processor.process_single_file)

    # Process files in parallel
    sanitized_entries = {}
    with Pool(processes=num_processes) as pool:
        results = pool.map(process_file_partial, matching_files)

    # Combine results
    for result in results:
        sanitized_entries.update(result)
    # sanitized entries should have < max_request_length entries
    sanitized_entries = dict(
        list(sanitized_entries.items())[: config.max_request_length]
    )
    # Save results
    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(sanitized_entries, f, indent=4)

    print(
        f"\nExtracted and sanitized [{len(sanitized_entries)}] {config.api_name} entries. "
        f"Saved to [{output_file}]."
    )

    # Upload to S3 if entries exist
    if sanitized_entries:
        credentials = OdinCredentialManager.get_credentials(config.odin_credentials)
        s3_uploader.upload_file(credentials, output_file)

    print(f"\n------------------------------\n{output_file}")


if __name__ == "__main__":
    main()
