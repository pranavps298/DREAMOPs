import json
import datetime
from jinja2 import Environment
from pathlib import Path


class ReportGenerator:
    def __init__(self):
        self.env = Environment(autoescape=True)

    def _get_html_template(self):
        return """
        <!DOCTYPE html>
        <html>
        <head>
            <title>Shadow Comparison Report - {{ api_name }}</title>
            <style>
                body { 
                    font-family: Arial, sans-serif; 
                    margin: 20px;
                    line-height: 1.6;
                }
                .header { 
                    background-color: #f0f0f0; 
                    padding: 20px; 
                    margin-bottom: 20px;
                    border-radius: 5px;
                }
                .stats { 
                    display: flex; 
                    justify-content: space-around; 
                    margin: 20px 0; 
                }
                .stat-box { 
                    padding: 15px; 
                    border-radius: 5px; 
                    text-align: center; 
                    min-width: 150px;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                }
                .total { background-color: #e3f2fd; }
                .passed { background-color: #c8e6c9; }
                .failed { background-color: #ffcdd2; }
                .error { background-color: #ffebee; }
                .test-case { 
                    border: 1px solid #ddd; 
                    margin: 10px 0; 
                    padding: 15px;
                    border-radius: 5px;
                }
                .difference { 
                    background-color: #fff8dc; 
                    padding: 10px; 
                    margin: 5px 0;
                    border-radius: 3px;
                }
                .success { color: #2e7d32; }
                .failure { color: #c62828; }
                .response-block { 
                    background-color: #f8f9fa; 
                    padding: 10px; 
                    margin: 5px 0;
                    border-radius: 3px;
                }
                pre { 
                    white-space: pre-wrap; 
                    word-wrap: break-word;
                    background-color: #f5f5f5;
                    padding: 10px;
                    border-radius: 3px;
                }
                .collapsible { 
                    background-color: #666;
                    color: white;
                    cursor: pointer;
                    padding: 12px;
                    width: 100%;
                    border: none;
                    text-align: left;
                    outline: none;
                    font-size: 14px;
                    border-radius: 3px;
                    margin: 5px 0;
                }
                .active, .collapsible:hover { background-color: #555; }
                .content {
                    padding: 0 18px;
                    display: none;
                    overflow: hidden;
                    background-color: #f1f1f1;
                    border-radius: 0 0 3px 3px;
                }
                .summary-section {
                    margin: 20px 0;
                    padding: 15px;
                    background-color: #f8f9fa;
                    border-radius: 5px;
                }
                .category-box {
                    margin: 10px 0;
                    padding: 10px;
                    border: 1px solid #ddd;
                    border-radius: 3px;
                }
                .category-heading {
                    cursor: pointer;
                    user-select: none;
                    padding: 8px;
                    background-color: #eee;
                    border-radius: 3px;
                    margin: 5px 0;
                }
                .category-heading:hover {
                    background-color: #e0e0e0;
                }
                .category-content {
                    display: none;
                    padding: 10px;
                    margin-left: 20px;
                }
                .toggle-icon {
                    display: inline-block;
                    width: 20px;
                    font-size: 12px;
                }
                .category-title {
                    display: inline-block;
                    margin-left: 5px;
                }
                .diff-table {
                    width: 100%;
                    margin: 5px 0;
                    border-collapse: collapse;
                }
                .diff-table td {
                    padding: 8px;
                    border: 1px solid #ddd;
                }
                .diff-table td:first-child {
                    background-color: #f5f5f5;
                    width: 120px;
                    font-weight: bold;
                }
                .summary-link {
                    color: #1976d2;
                    text-decoration: none;
                }
                .summary-link:hover {
                    text-decoration: underline;
                }
            </style>
            <script>
                function toggleCollapsible(element) {
                    element.classList.toggle("active");
                    var content = element.nextElementSibling;
                    content.style.display = content.style.display === "block" ? "none" : "block";
                }

                function toggleCategory(element) {
                    var content = element.nextElementSibling;
                    var icon = element.querySelector('.toggle-icon');
                    if (content.style.display === "none" || content.style.display === "") {
                        content.style.display = "block";
                        icon.textContent = "▼";
                    } else {
                        content.style.display = "none";
                        icon.textContent = "▶";
                    }
                }
            </script>
        </head>
        <body>
            {# Define a recursive macro to render differences #}
            {% macro render_diff(key, diff) -%}
                {% if diff is mapping and diff.datapath is not defined and diff.coral is not defined %}
                    <div class="difference">
                        <strong>{{ key }}:</strong>
                        <ul>
                        {% for subkey, subdiff in diff.items() %}
                            <li>{{ subkey }}: {{ render_diff(subkey, subdiff) }}</li>
                        {% endfor %}
                        </ul>
                    </div>
                {% else %}
                    <div class="difference">
                        <strong>{{ key }}:</strong><br>
                        <table class="diff-table">
                            <tr>
                                <td><strong>Datapath:</strong></td>
                                <td>
                                    {% if diff.datapath is not none %}
                                        {% if diff.datapath == 0 %}0{% else %}{{ diff.datapath }}{% endif %}
                                    {% else %}
                                        null
                                    {% endif %}
                                </td>
                            </tr>
                            <tr>
                                <td><strong>Coral:</strong></td>
                                <td>
                                    {% if diff.coral is not none %}
                                        {% if diff.coral == 0 %}0{% else %}{{ diff.coral }}{% endif %}
                                    {% else %}
                                        null
                                    {% endif %}
                                </td>
                            </tr>
                        </table>
                    </div>
                {% endif %}
            {%- endmacro %}

            <div class="header">
                <h1>Shadow Comparison Report - {{ api_name }}</h1>
                <p>Generated on: {{ generation_time }}</p>
                
                <div class="stats">
                    <div class="stat-box total">
                        <h3>Total Cases</h3>
                        <p>{{ total_cases }}</p>
                    </div>
                    <div class="stat-box passed">
                        <h3>Passed</h3>
                        <p>{{ passed_cases }}</p>
                    </div>
                    <div class="stat-box failed">
                        <h3>Failed</h3>
                        <p>{{ failed_cases }}</p>
                    </div>
                    <div class="stat-box error">
                        <h3>Errors</h3>
                        <p>{{ error_cases }}</p>
                    </div>
                </div>
            </div>

            <button class="collapsible" onclick="toggleCollapsible(this)">Summary of Errors and Differences</button>
            <div class="content summary-section">
                {% if error_summary %}
                <div class="category-box">
                    <h3>Error Types</h3>
                    {% for error_type, cases in error_summary.items() %}
                    <div class="category-heading" onclick="toggleCategory(this)">
                        <span class="toggle-icon">▶</span>
                        <span class="category-title">{{ error_type }} ({{ cases|length }} cases)</span>
                    </div>
                    <div class="category-content">
                        <ul>
                            {% for case_id in cases %}
                            <li><a href="#test-{{ case_id }}" class="summary-link">Test Case {{ case_id }}</a></li>
                            {% endfor %}
                        </ul>
                    </div>
                    {% endfor %}
                </div>
                {% endif %}

                {% if difference_summary %}
                <div class="category-box">
                    <h3>Difference Types</h3>
                    {% for field, cases in difference_summary.items() %}
                    <div class="category-heading" onclick="toggleCategory(this)">
                        <span class="toggle-icon">▶</span>
                        <span class="category-title">Field: {{ field }} ({{ cases|length }} cases)</span>
                    </div>
                    <div class="category-content">
                        <ul>
                            {% for case_id in cases %}
                            <li><a href="#test-{{ case_id }}" class="summary-link">Test Case {{ case_id }}</a></li>
                            {% endfor %}
                        </ul>
                    </div>
                    {% endfor %}
                </div>
                {% endif %}
            </div>
            {% for test_id, test_data in data.items() %}
            <div class="test-case" id="test-{{ test_id }}">
                <h2>Test Case ID: {{ test_id }}</h2>
                
                {% if test_data.get('error') %}
                    <p>Status: <span class="failure">ERROR</span></p>
                    <div class="error">
                        <strong>Error Message:</strong>
                        <pre>{{ test_data.error }}</pre>
                    </div>
                {% else %}
                    <p>Status: 
                        <span class="{{ 'success' if not test_data.differences else 'failure' }}">
                            {{ 'PASSED' if not test_data.differences else 'FAILED' }}
                        </span>
                    </p>
                {% endif %}

                    <button class="collapsible" onclick="toggleCollapsible(this)">Show Input Details</button>
                    <div class="content">
                        <h4>DP Input:</h4>
                        <pre>{{ test_data.dp_response.input }}</pre>
                        <h4>Lambda Input:</h4>
                        <pre>{{ test_data.lambda_response.input | tojson(indent=2) }}</pre>
                    </div>

                    <h3>Differences Found:</h3>
                    {% if test_data.differences %}
                        {% for diff_key, diff_val in test_data.differences.items() %}
                            {{ render_diff(diff_key, diff_val) }}
                        {% endfor %}
                    {% else %}
                        <p>No differences found</p>
                    {% endif %}

                    <button class="collapsible" onclick="toggleCollapsible(this)">Show Response Details</button>
                    <div class="content">
                        <h3>DP Response:</h3>
                        <div class="response-block">
                            <strong>Success:</strong> 
                            <span class="{{ 'success' if test_data.dp_response.success else 'failure' }}">
                                {{ test_data.dp_response.success }}
                            </span>
                            <pre>{{ test_data.dp_response.response }}</pre>
                        </div>

                        <h3>Lambda Response:</h3>
                        <div class="response-block">
                            <strong>Success:</strong>
                            <span class="{{ 'success' if test_data.lambda_response.success else 'failure' }}">
                                {{ test_data.lambda_response.success }}
                            </span>
                            <pre>{{ test_data.lambda_response.response }}</pre>
                        </div>
                    </div>
            </div>
            {% endfor %}
        </body>
        </html>
        """

    def _categorize_errors_and_differences(self, json_data):
        error_summary = {}
        difference_summary = {}

        for test_id, test_data in json_data.items():
            # Categorize errors
            if "error" in test_data:
                error_message = str(test_data["error"])
                error_type = (
                    error_message.split(":")[0]
                    if ":" in error_message
                    else error_message
                )
                if error_type not in error_summary:
                    error_summary[error_type] = []
                error_summary[error_type].append(test_id)

            # Categorize differences
            if "differences" in test_data and test_data["differences"]:
                for field in test_data["differences"].keys():
                    if field not in difference_summary:
                        difference_summary[field] = []
                    difference_summary[field].append(test_id)

        return error_summary, difference_summary

    def _calculate_stats(self, json_data):
        total_cases = len(json_data)
        error_cases = sum(1 for test in json_data.values() if "error" in test)
        valid_cases = total_cases - error_cases
        failed_cases = sum(
            1
            for test in json_data.values()
            if "differences" in test and test.get("differences")
        )

        return {
            "total_cases": total_cases,
            "error_cases": error_cases,
            "failed_cases": failed_cases,
            "passed_cases": valid_cases - failed_cases,
        }

    def _ensure_output_directory(self):
        Path("tmp/responses").mkdir(parents=True, exist_ok=True)

    def generate_report(self, json_data, api_name):
        try:
            self._ensure_output_directory()
            stats = self._calculate_stats(json_data)
            error_summary, difference_summary = self._categorize_errors_and_differences(
                json_data
            )

            template = self.env.from_string(self._get_html_template())

            html_content = template.render(
                data=json_data,
                api_name=api_name,
                generation_time=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                error_summary=error_summary,
                difference_summary=difference_summary,
                **stats,
            )

            filename = f'shadow_comparison_report_{api_name.replace(" ", "_")}_{datetime.datetime.now().strftime("%Y%m%d_%H%M%S")}.html'
            output_path = Path("tmp/responses") / api_name / filename

            with open(output_path, "w", encoding="utf-8") as f:
                f.write(html_content)

            return filename

        except Exception as e:
            print(f"Error generating report: {str(e)}")
            raise


def generate(file_name, api_name):
    try:
        print(f"Generating report for {api_name} stored in file {file_name} ...")
        with open(file_name, "r", encoding="utf-8") as f:
            json_data = json.load(f)

        report_generator = ReportGenerator()
        return report_generator.generate_report(json_data, api_name)

    except Exception as e:
        print(f"Error processing file: {str(e)}")
        raise


# if __name__ == "__main__":
#     generate("tmp/responses/shadow_response.json", "API_NAME")
