import json
from dataclasses import dataclass
from make_calls import execute, run_execute

"""
how to use this script:
1. Create a ServiceConfig object with the file name, view name, and service name
2. Modify the DataTransformer class with the transformation functions for request and response
3. Call the main function to execute the service calls with transformations
"""


@dataclass
class ServiceConfig:
    """Configuration for service endpoints and transformations"""

    file_name: str
    view_name: str
    service_name: str

    def __post_init__(self):
        """Validate configuration parameters"""
        if not all([self.file_name, self.view_name, self.service_name]):
            raise ValueError("All configuration parameters must be non-empty")


class DataTransformer:
    """Handles data transformations for different service endpoints"""

    @staticmethod
    def transform_request_for_dp(input_data):
        return [input_data["product"]]

    @staticmethod
    def transform_request_for_coral(input_data):
        return {"product": json.dumps(input_data["product"])}

    @staticmethod
    def transform_response_for_dp(response_data):
        return response_data.get("products", [])[0]

    @staticmethod
    def transform_response_for_coral(response_data):
        return response_data.get("product")


def main():
    """Main execution function to process and transform data"""

    # Service configuration
    config = ServiceConfig(
        file_name="GetProductRequest_requests_1738913250.json",
        view_name="digital::catalog::adg::product::getProducts",
        service_name="getProductADGProductService",
    )

    # Create transformer instance
    transformer = DataTransformer()

    try:
        # Execute service calls with transformations
        run_execute(
            file_name=config.file_name,
            view_name=config.view_name,
            request_transformer_dp=transformer.transform_request_for_dp,
            request_transformer_coral=transformer.transform_request_for_coral,
            response_transformer_dp=transformer.transform_response_for_dp,
            response_transformer_coral=transformer.transform_response_for_coral,
            api_name=config.service_name,
        )

    except Exception as e:
        print(f"Error executing shadow comparator calls: {str(e)}")
        raise


if __name__ == "__main__":
    main()
