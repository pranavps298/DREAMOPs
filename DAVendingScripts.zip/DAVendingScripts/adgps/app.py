import os
import json
from modules.projections_views import get_projections_and_views
from modules.generate_ts import generate_ts_code

from time import time
from code_analysis.java.code_analysis import extract_java_dependencies
from modules.create_content import create_files_from_json
from config import *

TEMP_FOLDER_NAME = "output/tmp"
if not os.path.exists(TEMP_FOLDER_NAME):
    os.makedirs(TEMP_FOLDER_NAME)


CONTENT_FOLDER = "output/contents/"


# extract java dependencies
sample_java_code_as_text = ""
for sample_java_activity_name in sample_java_activity_names:
    sample_java_output_file = f"{TEMP_FOLDER_NAME}/{sample_java_activity_name}_extracted_activity_{int(time())}.java"
    extract_java_dependencies(
        sample_java_class_base_path, sample_java_activity_name, sample_java_output_file
    )
    sample_java_code_as_text += "\n\n" + open(sample_java_output_file).read()
print("\n//////////////////////")

# extract typescript dependencies
sample_ts_code_as_text = ""
for sample_ts_class_name in sample_ts_class_names:
    sample_ts_output_file = (
        f"{TEMP_FOLDER_NAME}/{sample_ts_class_name}_extracted_ts_{int(time())}.ts"
    )
    os.system(
        f"cd {node_root_folder} && node app.js -p {sample_ts_class_base_path} -c {sample_ts_class_name} -o ../../{sample_ts_output_file}"
    )
    sample_ts_code_as_text += "\n\n" + open(sample_ts_output_file).read()

# generates projections, view definitions and respective test files
print("\n//////////////////////")
ch = input("\n\nDo you want me to generate the projection and view files (y/N) ? ")
if ch.lower() == "y":
    print(f"generating projections and views in directory {CONTENT_FOLDER} ...")
    p_v = get_projections_and_views(RoleArn, new_table_details, use_latest_model=True)
    print(p_v)
    print(f"creating files for the projections and views ...")
    create_files_from_json(CONTENT_FOLDER, json.loads(p_v))
else:
    print("skipping the generation of projections and views ...")


# generates ts files for projections and views
print("\n//////////////////////")
ch = input("\n\nDo you want me to generate the typescript files (y/N) ? ")
if ch.lower() == "y":
    print(f"generating typescript files ...")

    if not sample_java_code_as_text or not sample_ts_code_as_text:
        print(
            "sample java or ts code is empty, skipping the generation of typescript files ..."
        )
    else:
        new_java_output_file = f"{TEMP_FOLDER_NAME}/{new_java_activity_name}_extracted_activity_{int(time())}.java"
        extract_java_dependencies(
            new_java_class_path, new_java_activity_name, new_java_output_file
        )
        new_java_output_file_as_text = open(new_java_output_file).read()
        if not new_java_output_file_as_text:
            print(
                "new java code is empty, skipping the generation of typescript files ..."
            )
        else:
            ts_contents = generate_ts_code(
                RoleArn,
                sample_java_code_as_text,
                sample_ts_code_as_text,
                new_java_output_file_as_text,
                use_latest_model=True,
            )
            print(ts_contents)
            create_files_from_json(CONTENT_FOLDER, json.loads(ts_contents))
else:
    print("skipping the generation of typescript files ...")
