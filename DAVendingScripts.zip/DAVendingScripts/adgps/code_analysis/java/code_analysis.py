import os
import re
import javalang
from typing import Set, Dict, List, Optional


class JavaDependencyExtractor:
    def __init__(self, base_path: str):
        self.base_path = base_path
        self.all_classes: Dict[str, str] = {}
        self.all_interfaces: Dict[str, str] = {}
        self.interface_implementations: Dict[str, Set[str]] = {}
        self.class_dependencies: Dict[str, Set[str]] = {}

    def load_java_files(self):
        for root, _, files in os.walk(self.base_path):
            for file in files:
                if file.endswith(".java"):
                    file_path = os.path.join(root, file)
                    with open(file_path, "r") as f:
                        content = f.read()
                        try:
                            tree = javalang.parse.parse(content)
                            for _, interface_declaration in tree.filter(
                                javalang.tree.InterfaceDeclaration
                            ):
                                self.all_interfaces[interface_declaration.name] = (
                                    content
                                )
                                self.interface_implementations[
                                    interface_declaration.name
                                ] = set()

                            for _, class_declaration in tree.filter(
                                javalang.tree.ClassDeclaration
                            ):
                                self.all_classes[class_declaration.name] = content

                                if class_declaration.implements:
                                    for interface_type in class_declaration.implements:
                                        interface_name = interface_type.name
                                        if interface_name in self.all_interfaces:
                                            if (
                                                interface_name
                                                not in self.interface_implementations
                                            ):
                                                self.interface_implementations[
                                                    interface_name
                                                ] = set()
                                            self.interface_implementations[
                                                interface_name
                                            ].add(class_declaration.name)

                        except Exception as e:
                            print(f"Failed to parse {file_path}: {str(e)}")

    def find_dependencies(self, activity_name: str) -> Set[str]:
        if activity_name not in self.all_classes:
            raise ValueError(f"Activity {activity_name} not found")

        dependencies = set()
        to_process = {activity_name}
        processed = set()

        while to_process:
            class_name = to_process.pop()
            if class_name in processed:
                continue

            processed.add(class_name)
            class_content = self.all_classes.get(class_name)

            if not class_content:
                continue

            tree = javalang.parse.parse(class_content)

            for _, node in tree.filter(javalang.tree.ReferenceType):
                if isinstance(node.name, str):
                    if node.name in self.all_classes:
                        dependencies.add(node.name)
                        to_process.add(node.name)
                    elif node.name in self.all_interfaces:
                        dependencies.add(node.name)
                        impl_classes = self.interface_implementations.get(
                            node.name, set()
                        )
                        dependencies.update(impl_classes)
                        to_process.update(impl_classes)

            for _, class_declaration in tree.filter(javalang.tree.ClassDeclaration):
                if class_declaration.implements:
                    for interface_type in class_declaration.implements:
                        interface_name = interface_type.name
                        if interface_name in self.all_interfaces:
                            dependencies.add(interface_name)

        return dependencies

    def extract_activity_code(self, activity_name: str) -> str:
        dependencies = self.find_dependencies(activity_name)
        dependencies.add(activity_name)

        extracted_code = []

        for dep in dependencies:
            if dep in self.all_interfaces:
                extracted_code.append(f"// Interface: {dep}.java")
                extracted_code.append(self.all_interfaces[dep])
                extracted_code.append("\n\n")

        for dep in dependencies:
            if dep in self.all_classes:
                extracted_code.append(f"// Class: {dep}.java")
                extracted_code.append(self.all_classes[dep])
                extracted_code.append("\n\n")

        return "\n".join(extracted_code)

    def save_extracted_code(self, activity_name: str, output_file: str):
        code = self.extract_activity_code(activity_name)
        with open(output_file, "w") as f:
            f.write(code)


def extract_java_dependencies(base_path, activity_name, output_file):
    print(f"Extracting Java dependencies for {activity_name}...")
    extractor = JavaDependencyExtractor(base_path)
    extractor.load_java_files()
    extractor.save_extracted_code(activity_name, output_file)
    print(f"Java dependencies extracted and saved to {output_file}")
