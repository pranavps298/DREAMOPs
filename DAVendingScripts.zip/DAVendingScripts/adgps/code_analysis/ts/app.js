const fs = require("fs");
const path = require("path");
const ts = require("typescript");
const { program } = require("commander");

class TypeScriptExtractor {
  constructor(projectPath) {
    this.projectPath = path.resolve(projectPath);
    this.program = this.createProgram();
    this.typeChecker = this.program.getTypeChecker();
    this.dependencies = new Map();
    this.fileContents = new Map();
    this.fileImports = new Map();
    this.componentFiles = new Map();
  }

  createProgram() {
    const configPath = ts.findConfigFile(
      this.projectPath,
      ts.sys.fileExists,
      "tsconfig.json"
    );

    let program;
    if (configPath) {
      const { config } = ts.readConfigFile(configPath, ts.sys.readFile);
      const { options, fileNames } = ts.parseJsonConfigFileContent(
        config,
        ts.sys,
        path.dirname(configPath)
      );
      program = ts.createProgram(fileNames, options);
    } else {
      const defaultOptions = {
        target: ts.ScriptTarget.ES2015,
        module: ts.ModuleKind.CommonJS,
        allowJs: true,
        checkJs: false,
      };
      const fileNames = this.findTypeScriptFiles(this.projectPath);
      program = ts.createProgram(fileNames, defaultOptions);
    }
    return program;
  }

  findTypeScriptFiles(dir) {
    let results = [];
    const items = fs.readdirSync(dir);
    for (const item of items) {
      const fullPath = path.join(dir, item);
      if (fullPath.includes("node_modules")) continue;

      const stat = fs.statSync(fullPath);
      if (stat.isDirectory()) {
        results = results.concat(this.findTypeScriptFiles(fullPath));
      } else if (fullPath.endsWith(".ts") || fullPath.endsWith(".tsx")) {
        results.push(fullPath);
      }
    }
    return results;
  }

  analyzeFiles() {
    for (const sourceFile of this.program.getSourceFiles()) {
      if (
        !sourceFile.isDeclarationFile &&
        sourceFile.fileName.startsWith(this.projectPath)
      ) {
        const relativePath = path.relative(
          this.projectPath,
          sourceFile.fileName
        );
        this.fileContents.set(relativePath, sourceFile.getFullText());

        const fileImports = [];
        const components = new Set();

        ts.forEachChild(sourceFile, (node) => {
          if (ts.isImportDeclaration(node)) {
            fileImports.push(this.getImportText(node));
          }

          let componentName;
          if (ts.isClassDeclaration(node) && node.name) {
            componentName = node.name.text;
          } else if (ts.isFunctionDeclaration(node) && node.name) {
            componentName = node.name.text;
          } else if (ts.isVariableStatement(node)) {
            const declarations = node.declarationList.declarations;
            if (
              declarations.length > 0 &&
              ts.isIdentifier(declarations[0].name)
            ) {
              componentName = declarations[0].name.text;
            }
          }

          if (componentName) {
            components.add(componentName);
            this.componentFiles.set(componentName, relativePath);
            this.dependencies.set(componentName, new Set(fileImports));
          }
        });

        this.fileImports.set(relativePath, fileImports);
      }
    }
  }

  getImportText(importNode) {
    return importNode.getText();
  }

  findComponentDependencies(componentName) {
    const result = new Map();
    const toProcess = [componentName];
    const processed = new Set();

    while (toProcess.length > 0) {
      const current = toProcess.pop();
      if (processed.has(current)) continue;

      processed.add(current);

      const filePath = this.componentFiles.get(current);
      if (filePath) {
        const fileImports = this.fileImports.get(filePath) || [];
        if (!result.has(filePath)) {
          result.set(filePath, new Set(fileImports));
        } else {
          fileImports.forEach((imp) => result.get(filePath).add(imp));
        }

        for (const [comp, compFile] of this.componentFiles) {
          if (
            !processed.has(comp) &&
            fileImports.some((imp) => imp.includes(comp))
          ) {
            toProcess.push(comp);
          }
        }
      }
    }

    return result;
  }

  extractComponentCode(componentName) {
    this.analyzeFiles();
    const dependencyFiles = this.findComponentDependencies(componentName);
    let extractedCode = "";

    for (const [filePath, imports] of dependencyFiles) {
      extractedCode += `// File: ${filePath}\n`;

      for (const importStatement of imports) {
        extractedCode += `${importStatement}\n`;
      }

      if (imports.size > 0) {
        extractedCode += "\n";
      }

      const content = this.fileContents.get(filePath);
      if (content) {
        const contentWithoutImports = content
          .replace(/import[^;]+;/g, "")
          .trim();
        extractedCode += `${contentWithoutImports}\n\n`;
      }
    }

    return extractedCode;
  }
}

function setupCommandLineInterface() {
  program
    .version("1.0.0")
    .requiredOption("-p, --project <path>", "Path to TypeScript project")
    .requiredOption("-c, --component <name>", "Component name to extract")
    .option("-o, --output <file>", "Output file (defaults to stdout)")
    .parse(process.argv);

  return program.opts();
}

function main() {
  const options = setupCommandLineInterface();

  try {
    console.log(`Analyzing project: ${options.project}`);
    console.log(`Extracting component: ${options.component}`);

    const extractor = new TypeScriptExtractor(options.project);
    const code = extractor.extractComponentCode(options.component);

    if (options.output) {
      fs.writeFileSync(options.output, code);
      console.log(
        `Successfully extracted ${options.component} to ${options.output}`
      );
    } else {
      console.log("\nExtracted code:");
      console.log(code);
    }
  } catch (error) {
    console.error("Error:", error.message);
    process.exit(1);
  }
}

if (require.main === module) {
  main();
}

module.exports = TypeScriptExtractor;
