import os
import json


def create_files_from_json(content_folder, json_array):
    for item in json_array:
        file_name = item.get("file_name")
        file_content = item.get("file_content")
        if not file_name:
            print("Error: Missing 'file_name'. Skipping item.")
            continue
        file_name = os.path.join(content_folder, file_name)

        file_path = os.path.dirname(file_name)
        if file_path and not os.path.exists(file_path):
            os.makedirs(file_path)

        try:
            with open(file_name, "w") as file:
                file.write(file_content)
            print(f"File '{file_name}' created successfully.")
        except Exception as e:
            print(f"Error creating file '{file_name}': {e}")
