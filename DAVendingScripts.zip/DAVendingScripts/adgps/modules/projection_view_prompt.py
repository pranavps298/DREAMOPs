def get_default_prompt_for_views_projections():
    return """
I am working on a datapath application (an internal application). what it does is basically provides easy way to connect to sources and query data for instance dynamodb etc, In this case we will solely focus on dynamodb.
The business logic resides in what is called as views in datapath. anyone can access or call any other view or call is via a rest endpoint.
The code follows a folder structure like below. I will provide details of each in later sections.

Directory structure
------
-bindings/
-projection/
-src/
-tst/
-typescript/

Details of each 
------
the main logic that is the view definition resides in src folder while the iam roles and table details, query pattern etc are in projection folder. the bindings folder contains simple details for exposing rest bindings for a given view. the tst folder contains the test cases for the view. because writing code in datapath language is complex it provides option to write code in typescript where we can import views created in datapath and test them. the typescript folder contains the typescript code for the views.

the src folder follows a file naming pattern which ultimately becomes the view name and same is the case with projection folder. 
- a file named src/digital/catalog/vendor/getVendorById.dp will have the view definition for "digital::catalog::vendor::getVendorById" view while the projection logic will be present in "projection/digital/catalog/vendor/getVendorById/getVendorById.dp" , note the naming structure in both cases, there is no such folder naming structure in typescript

the dynamdob tables have the below primary and gsi keys
--------------------------------
- ADGVendor table has VendorId as primary key
    - ADGVendorByMASVendorCode-index is a GSI with MASVendorCode as primary key
    - ADGVendorByMASVendorId-index is a GSI with MASVendorId as primary key
- ADGDomain table has DomainId as primary key
    - ADGDomainByOwnerId-DomainName-index is a GSI with OwnerId as primary key and DomainName as range key
    - ADGDomainByOwnerId-DomainType-index is a GSI with OwnerId as primary key and DomainType as range key
    - ADGDomainByOwnerId-index is a GSI with OwnerId as primary key and DomainId as range key
- ADGProduct table has ProductId as primary key
    - ADGProductByASIN-index is a GSI with ASIN as primary key
    - ADGProductByVendorIdVendorSku-index is a GSI with VendorId as primary key and VendorSku as range key
    - ADGProductByVendorIdExternalProductId-index is a GSI with VendorId as primary key and ExternalProductId as range key

below are details of code for some projections and view file
--------------------------------

projection/digital/catalog/vendor/getVendorById/getVendorById.dp
--------------
```
'dynamodb@1.0'::'query@1.0'::{
     dynamodb_table_name: "ADGVendor",
     key_schema: ((string VendorId)),
     partition_pattern: (field VendorId),
     partition_name: "VendorId",

     region_configs: {
         prod_iad: {
             role_arn: "arn:aws:iam::686590389163:role/DatapathDynamodbAccess",
             aws_region: us_east_1,
         },
         prod_dub: {
             role_arn: "arn:aws:iam::686590389163:role/DatapathDynamodbAccess",
             aws_region: eu_west_1,
         },
         prod_pdx: {
             role_arn: "arn:aws:iam::686590389163:role/DatapathDynamodbAccess",
             aws_region: us_west_2,
         },
         prod_pek: {
             role_arn: "arn:aws:iam::686590389163:role/DatapathDynamodbAccess",
             aws_region: cn_north_1,
         },
         integ: {
             role_arn: "arn:aws:iam::358650257226:role/DatapathDynamodbAccess",
             aws_region: us_east_1,
         }
     },
    query :(
            and
            (
                dynamodb::resource
                "ADGVendor"
                {
                    VendorId: id
                }
                output
            )
            (
                +
                output
                {
                    VendorId: id
                }
                payload
            )
    ),

     projection_type: DynamoDB,
     projection_attributes: {},
 }
 ```

 projection/digital/catalog/vendor/getVendorByVendorCode/getVendorByVendorCode.dp
 --------------
 ```
  'dynamodb@1.0'::'query@1.0'::{
     dynamodb_table_name: "ADGVendor",
     key_schema: ((string MASVendorCode)),
     partition_pattern: (field MASVendorCode),
     partition_name: "MASVendorCode",
     index_name: "ADGVendorByMASVendorCode-index",
     index_type: GLOBAL,
     region_configs: {
         prod_iad: {
             role_arn: "arn:aws:iam::686590389163:role/DatapathDynamodbAccess",
             aws_region: us_east_1,
         },
         prod_dub: {
             role_arn: "arn:aws:iam::686590389163:role/DatapathDynamodbAccess",
             aws_region: eu_west_1,
         },
         prod_pdx: {
             role_arn: "arn:aws:iam::686590389163:role/DatapathDynamodbAccess",
             aws_region: us_west_2,
         },
         prod_pek: {
             role_arn: "arn:aws:iam::686590389163:role/DatapathDynamodbAccess",
             aws_region: cn_north_1,
         },
         integ: {
             role_arn: "arn:aws:iam::358650257226:role/DatapathDynamodbAccess",
             aws_region: us_east_1,
         }
     },
    query :(
            and
            (
                dynamodb::resource
                "ADGVendor"
                {
                    MASVendorCode: vendorCode
                }
                output
            )
            (
                +
                output
                {
                    MASVendorCode: vendorCode
                }
                payload
            )
    ),

     projection_type: DynamoDB,
     projection_attributes: {},
 }

 ```

 projection/digital/catalog/domain/getDomainByOwnerIdDomainName/getDomainByOwnerIdDomainName.dp
 --------------
 ```
 'dynamodb@1.0'::'query@1.0'::{
        dynamodb_table_name: "ADGDomain",
     	key_schema: ((string OwnerId) (string DomainName) ),
     	partition_pattern: (field OwnerId),
     	partition_name: "OwnerId",

		range_name: "DomainName",
        range_pattern: (field DomainName),

    	index_name: "ADGDomainByOwnerId-DomainName-index",
        index_type: GLOBAL,

        region_configs: {
         prod_iad: {
             role_arn: "arn:aws:iam::686590389163:role/DatapathDynamodbAccess",
             aws_region: us_east_1,
         },
         prod_dub: {
             role_arn: "arn:aws:iam::686590389163:role/DatapathDynamodbAccess",
             aws_region: eu_west_1,
         },
         prod_pdx: {
             role_arn: "arn:aws:iam::686590389163:role/DatapathDynamodbAccess",
             aws_region: us_west_2,
         },
         prod_pek: {
             role_arn: "arn:aws:iam::686590389163:role/DatapathDynamodbAccess",
             aws_region: cn_north_1,
         },
         integ: {
             role_arn: "arn:aws:iam::358650257226:role/DatapathDynamodbAccess",
             aws_region: us_east_1,
         }
     		},

        query :(
                and
                (
                    dynamodb::resource
                    "ADGDomain"
                    {
                        OwnerId:ownerId, DomainName:domainName
                    }
                    output
                )
                (
                    +
                    output
                    {
                        OwnerId:ownerId, DomainName:domainName
                    }
                    payload
                )
        ),

        projection_type: DynamoDB,
        projection_attributes: {}
}
 ```

 src/digital/catalog/vendor/getVendorById.dp
 --------------
 ```
 (visible private)
	 (doc
	     (view '''View for fetching vendor data using id''')
	     (argument
	         (id '''String representing vendor id''')
	         (payload '''Output: vendor details in vendor table in ADG''')
	     )
	 )
	 (define (digital::catalog::vendor::getVendorById string::id struct::payload)
	     (diverge "Default projection invalid.")
	 )
```

src/digital/catalog/vendor/getVendorByVendorCode.dp
--------------
```
(visible private)
 (doc
     (view '''View for fetching vendor data using vendor code''')
     (argument
         (vendorCode '''String representing vendor code''')
         (payload '''Output: vendor details in vendor table in ADG''')
     )
 )
 (define (digital::catalog::vendor::getVendorByVendorCode string::vendorCode struct::payload)
     (diverge "Default projection invalid.")
 )
```

src/digital/catalog/domain/getDomainByOwnerIdDomainName.dp
--------------
```
(visible private)
	 (doc
	     (view '''View for fetching domain by ownerId and domainName''')
	     (argument
	         (ownerId '''String representing ownerId of Domain''')
	         (domainName '''String representing domainName of Domain''')
	         (payload '''Output: Domain details in ADGDomain Dynamo DB''')
	     )
	 )
	 (define (digital::catalog::domain::getDomainByOwnerIdDomainName String::ownerId String::domainName payload)
	     (diverge "Default projection invalid.")
	 )

```

below is some sample for the tests file for the above views
--------------------------------
first we have to create some sample test data

test-data/validVendor.dp
--------------
```
{
  "VendorId": "d97911a2-02b5-486e-a17d-0f49411cd5bf",
  "MASVendorCode": "00MASKMRKJWX",
  "MASVendorId": "M1UA6X5LPQ2SZ6",
  "ModifiedTimestamp": "20210810123426284Z",
  "serviceProvider": "amazonDivac",
  "serviceProviderVendorId": "M1UA6X5LPQ2SZ6",
  "State": "ACTIVE",
  "storeId": "2534f34d-d808-4256-a8f9-0d4f92a7f903",
  "VendorName": "ALEXA",
  "Version": "1"
}
```

test-data/validVendorResult.dp
--------------
```
{
    vendor: {
        masVendorId: "M1UA6X5LPQ2SZ6",
        masVendorCode: "00MASKMRKJWX",
        name: "ALEXA",
        serviceProvider: "amazonDivac",
        id: "d97911a2-02b5-486e-a17d-0f49411cd5bf",
        store: {
            name: "Alexa",
            id: "2534f34d-d808-4256-a8f9-0d4f92a7f903"
        },
        serviceProviderVendorId: "M1UA6X5LPQ2SZ6"
    }
}
```

test-data/validDomainsResult.dp
--------------
```
[{
    DomainType: "VENDOR",
    OwnerId: "6fd9be9e-2b96-4c3e-9ba0-da07e7b16b4d",
    DomainId: "cb779a3e-744e-4b4e-b627-4f03417dc09e",
    Version: 1,
    DomainName: "amzn1.ask.skill.899ee558-9896-4380-897d-d2a5872fe7db",
    ModifiedTimestamp: "20210429061121338Z",
    RootDomainPath: ["f0031dcb-e0b3-4043-bd34-0277de9724ef"],
    State: "ACTIVE"
}, {
    DomainType: "PRODUCT_DISCRIMINATOR_DOMAIN",
    OwnerId: "a12fd9f8-6ed1-4142-8d0e-23515adad24a",
    DomainId: "26b4af88-51cb-4cd9-91a5-fe42497dd359",
    Version: 1,
    DomainName: "amzn1.adg.product.a7619163-4bf9-4d09-b11d-85154a87af29-4e183527-8241-4e91-a194-bb05db4b11b4-pd-domain",
    ModifiedTimestamp: "20240106085140096Z",
    RootDomainPath: ["dfb375be-f089-4618-9fa8-15a1e3860605"],
    State: "ACTIVE"
}]
```

now the actual tests
---------------------

tst/digital/catalog/vendor/getVendor.dp.tests.dp
--------------
```
'GetVendorByIdDAOSuccessCase'
"Tests that view picks the entry from dynamodb"
(override (dynamodb::resource table key attributes)
     (or
         (=
             [table, key, attributes]
             [
                 "ADGVendor",
                 {VendorId: "d97911a2-02b5-486e-a17d-0f49411cd5bf"},
                 (quote 'import@1.0'::"test-data::validVendor.dp")
            ]
         )
     )
 )
(digital::catalog::vendor::getVendorById "d97911a2-02b5-486e-a17d-0f49411cd5bf" payload)
['import@1.0'::"test-data::validVendor.dp"]

'GetVendorByVendorCodeDAOSuccessCase'
"Tests that view picks the entry from dynamodb"
(override (dynamodb::resource table key attributes)
     (or
         (=
             [table, key, attributes]
             [
                 "ADGVendor",
                 { MASVendorCode: "00MASKMRKJWX" },
                 (quote 'import@1.0'::"test-data::validVendor.dp")
            ]
         )
     )
 )
(digital::catalog::vendor::getVendorByVendorCode "00MASKMRKJWX" payload)
['import@1.0'::"test-data::validVendor.dp"]

'GetVendorByMasVendorIdDAOSuccessCase'
"Tests that view picks the entry from dynamodb"
(override (dynamodb::resource table key attributes)
     (or
         (=
             [table, key, attributes]
             [
                 "ADGVendor",
                 {MASVendorId: "M1UA6X5LPQ2SZ6"},
                 (quote 'import@1.0'::"test-data::validVendor.dp")
            ]
         )
     )
 )
(digital::catalog::vendor::getVendorByMasVendorId "M1UA6X5LPQ2SZ6" payload)
['import@1.0'::"test-data::validVendor.dp"]


'GetVendorByIdDAOFailureCase'
"Tests incorrect vendor id"
(override (dynamodb::resource table key attributes)
     (or
         (=
             [table, key, attributes]
             [
                 "ADGVendor",
                 {VendorId: "d97911a2-02b5-486e-a17d-0f49411cd5bf"},
                 (quote 'import@1.0'::"test-data::validVendor.dp")
            ]
         )
     )
)
(digital::catalog::vendor::getVendorById "amzn1.adg.product.fc0dcb2" payload)
[]

'GetVendorByVendorCodeDAOFailureCase'
"Tests incorrect vendor code"
(override (dynamodb::resource table key attributes)
     (or
         (=
             [table, key, attributes]
             [
                 "ADGVendor",
                 { MASVendorCode: "00MASKMRKJWX" },
                 (quote 'import@1.0'::"test-data::validVendor.dp")
            ]
         )
     )
 )
(digital::catalog::vendor::getVendorByVendorCode "00MASKM" payload)
[]

'GetVendorByMasVendorIdDAOFailureCase'
"Tests incorrect vendor id"
(override (dynamodb::resource table key attributes)
     (or
         (=
             [table, key, attributes]
             [
                 "ADGVendor",
                 {MASVendorId: "M1UA6X5LPQ2SZ6"},
                 (quote 'import@1.0'::"test-data::validVendor.dp")
            ]
         )
     )
 )
(digital::catalog::vendor::getVendorByMasVendorId "M1UA6" payload)
[]
```

tst/digital/catalog/domain/getDomainByIdBatchDPTest.dp
--------------
```
'getDomainByIdBatchSuccessCase'
"Tests that view picks the entry from dynamodb"
(override (dynamodb::resource table key attributes)
     (or
         (=
             [table, key, attributes]
             [
                 "ADGDomain",
                 {DomainId: "cb779a3e-744e-4b4e-b627-4f03417dc09e"},
                 {
                     DomainType:"VENDOR",
                     OwnerId:"6fd9be9e-2b96-4c3e-9ba0-da07e7b16b4d",
                     DomainId: "cb779a3e-744e-4b4e-b627-4f03417dc09e",
                     Version:1,
                     DomainName:"amzn1.ask.skill.899ee558-9896-4380-897d-d2a5872fe7db",
                     ModifiedTimestamp:"20210429061121338Z",
                     RootDomainPath:[
                       "f0031dcb-e0b3-4043-bd34-0277de9724ef"
                     ],
                     State:"ACTIVE"
                 }
            ]
         )
         (=
                      [table, key, attributes]
                      [
                          "ADGDomain",
                          {DomainId: "26b4af88-51cb-4cd9-91a5-fe42497dd359"},
                          {
                              DomainType:"PRODUCT_DISCRIMINATOR_DOMAIN",
                              OwnerId:"a12fd9f8-6ed1-4142-8d0e-23515adad24a",
                              DomainId: "26b4af88-51cb-4cd9-91a5-fe42497dd359",
                              Version:1,
                              DomainName:"amzn1.adg.product.a7619163-4bf9-4d09-b11d-85154a87af29-4e183527-8241-4e91-a194-bb05db4b11b4-pd-domain",
                              ModifiedTimestamp:"20240106085140096Z",
                              RootDomainPath:[
                                "dfb375be-f089-4618-9fa8-15a1e3860605"
                              ],
                              State:"ACTIVE"
                            }
                     ]
                  )
     )
 )
(digital::catalog::domain::getDomainByIdBatch ["cb779a3e-744e-4b4e-b627-4f03417dc09e","26b4af88-51cb-4cd9-91a5-fe42497dd359"] result)
['import@1.0'::"test-data::validDomainsResult.dp"]

'getDomainByIdBatchInvalidDomainId'
"Tests the view for invalid DomainId"
(override (dynamodb::resource table key attributes)
     (or
         (=
             [table, key, attributes]
             [
                 "ADGDomain",
                 {DomainId: "cb779a3e-744e-4b4e-b627-4f03417dc09e"},
                 {
                     DomainType:"VENDOR",
                     OwnerId:"6fd9be9e-2b96-4c3e-9ba0-da07e7b16b4d",
                     DomainId: "cb779a3e-744e-4b4e-b627-4f03417dc09e",
                     Version:1,
                     DomainName:"amzn1.ask.skill.899ee558-9896-4380-897d-d2a5872fe7db",
                     ModifiedTimestamp:"20210429061121338Z",
                     RootDomainPath:[
                       "f0031dcb-e0b3-4043-bd34-0277de9724ef"
                     ],
                     State:"ACTIVE"
                 }
            ]
         )
     )
 )
(digital::catalog::domain::getDomainByIdBatch ["abc"] result)
[$dp_set::[]]
```

tst/digital/catalog/domain/getDomainByOwnerIdDPTest.dp
--------------
```
'getDomainByOwnerIdSuccess'
"Tests that view picks the entry from dynamodb by OwnerId and DomainID"
(override (dynamodb::resource table key attributes)
     (or
         (=
             [table, key, attributes]
             [
                 "ADGDomain",
                 {
                     OwnerId: "23b35ff0-5163-4f95-b593-525691b2a8ba"
                 },
                 {
                   DomainType:"VENDOR",
                   Version:1,
                   OwnerId: "23b35ff0-5163-4f95-b593-525691b2a8ba",
                   DomainName:"amzn1.ask.skill.6794d269-e9b1-4f43-bf1c-700724ecca20",
                   ModifiedTimestamp:"20210904204508116Z",
                   RootDomainPath:[
                     "4645a306-d71a-4fac-a318-c6286a4956fd"
                   ],
                   State:"ACTIVE"
                 }
            ]
         )
     )
 )
(digital::catalog::domain::getDomainByOwnerId "23b35ff0-5163-4f95-b593-525691b2a8ba" result)
[{ModifiedTimestamp:"20210904204508116Z",State:"ACTIVE",OwnerId:"23b35ff0-5163-4f95-b593-525691b2a8ba",DomainType:"VENDOR",DomainName:"amzn1.ask.skill.6794d269-e9b1-4f43-bf1c-700724ecca20",RootDomainPath:["4645a306-d71a-4fac-a318-c6286a4956fd"],Version:1}]

'getDomainByOwnerIdInvalidOwnerId'
"Tests that view picks 0 records from dynamodb for invalid OwnerId"
(override (dynamodb::resource table key attributes)
     (or
         (=
             [table, key, attributes]
             [
                 "ADGDomain",
                 {
                     DomainId: "7833b7b1-985e-4802-b38e-e5b0b5eaa3c5",
                     OwnerId: "23b35ff0-5163-4f95-b593-525691b2a8ba"
                 },
                 {
                   DomainType:"VENDOR",
                   Version:1,
                   DomainId: "7833b7b1-985e-4802-b38e-e5b0b5eaa3c5",
                   OwnerId: "23b35ff0-5163-4f95-b593-525691b2a8ba",
                   DomainName:"amzn1.ask.skill.6794d269-e9b1-4f43-bf1c-700724ecca20",
                   ModifiedTimestamp:"20210904204508116Z",
                   RootDomainPath:[
                     "4645a306-d71a-4fac-a318-c6286a4956fd"
                   ],
                   State:"ACTIVE"
                 }
            ]
         )
     )
 )
(digital::catalog::domain::getDomainByOwnerId "abc" result)
[]
```

tst/digital/catalog/domain/getDomainByOwnerIdDomainNameDPTest.dp
--------------
```
'getDomainByOwnerIdDomainNameSuccess'
"Tests that view picks the entry from dynamodb by OwnerId and DomainName"
(override (dynamodb::resource table key attributes)
     (or
         (=
             [table, key, attributes]
             [
                 "ADGDomain",
                 {
                     DomainName: "amzn1.adg.product.9b8e3e0b-030b-40e0-8c82-eeec046586d6-4e183527-8241-4e91-a194-bb05db4b11b4-pd-domain",
                     OwnerId: "f57e2d2d-7127-438c-8ba2-005f397b1076"
                 },
                 {
                   DomainId:"31d5a99d-213e-407b-b133-3836183e5998",
                   DomainName: "amzn1.adg.product.9b8e3e0b-030b-40e0-8c82-eeec046586d6-4e183527-8241-4e91-a194-bb05db4b11b4-pd-domain",
                   OwnerId: "f57e2d2d-7127-438c-8ba2-005f397b1076",
                   DomainType:"PRODUCT_DISCRIMINATOR_DOMAIN",
                   Version:1,
                   ModifiedTimestamp:"20230430042046962Z",
                   RootDomainPath:[
                     "5f79066c-d3ea-489b-9076-50d5c09560c7"
                   ],
                   State:"ACTIVE"
                 }
            ]
         )
     )
 )
(digital::catalog::domain::getDomainByOwnerIdDomainName "f57e2d2d-7127-438c-8ba2-005f397b1076" "amzn1.adg.product.9b8e3e0b-030b-40e0-8c82-eeec046586d6-4e183527-8241-4e91-a194-bb05db4b11b4-pd-domain" result)
[{ModifiedTimestamp:"20230430042046962Z",State:"ACTIVE",OwnerId:"f57e2d2d-7127-438c-8ba2-005f397b1076",DomainType:"PRODUCT_DISCRIMINATOR_DOMAIN",DomainName:"amzn1.adg.product.9b8e3e0b-030b-40e0-8c82-eeec046586d6-4e183527-8241-4e91-a194-bb05db4b11b4-pd-domain",DomainId:"31d5a99d-213e-407b-b133-3836183e5998",RootDomainPath:["5f79066c-d3ea-489b-9076-50d5c09560c7"],Version:1}]

'getDomainByOwnerIdDomainNameInvalidOwnerId'
"Tests that view picks the entry from dynamodb by OwnerId and DomainName"
(override (dynamodb::resource table key attributes)
     (or
         (=
             [table, key, attributes]
             [
                 "ADGDomain",
                 {
                     DomainName: "amzn1.adg.product.9b8e3e0b-030b-40e0-8c82-eeec046586d6-4e183527-8241-4e91-a194-bb05db4b11b4-pd-domain",
                     OwnerId: "f57e2d2d-7127-438c-8ba2-005f397b1076"
                 },
                 {
                   DomainId:"31d5a99d-213e-407b-b133-3836183e5998",
                   DomainType:"PRODUCT_DISCRIMINATOR_DOMAIN",
                   DomainName: "amzn1.adg.product.9b8e3e0b-030b-40e0-8c82-eeec046586d6-4e183527-8241-4e91-a194-bb05db4b11b4-pd-domain",
                   OwnerId: "f57e2d2d-7127-438c-8ba2-005f397b1076",
                   Version:1,
                   ModifiedTimestamp:"20230430042046962Z",
                   RootDomainPath:[
                     "5f79066c-d3ea-489b-9076-50d5c09560c7"
                   ],
                   State:"ACTIVE"
                 }
            ]
         )
     )
 )
(digital::catalog::domain::getDomainByOwnerIdDomainName "abc" "amzn1.adg.product.9b8e3e0b-030b-40e0-8c82-eeec046586d6-4e183527-8241-4e91-a194-bb05db4b11b4-pd-domain" result)
[]

'getDomainByOwnerIdDomainNameInvalidDomainName'
"Tests that view picks the entry from dynamodb by OwnerId and DomainName"
(override (dynamodb::resource table key attributes)
     (or
         (=
             [table, key, attributes]
             [
                 "ADGDomain",
                 {
                     DomainName: "amzn1.adg.product.9b8e3e0b-030b-40e0-8c82-eeec046586d6-4e183527-8241-4e91-a194-bb05db4b11b4-pd-domain",
                     OwnerId: "f57e2d2d-7127-438c-8ba2-005f397b1076"
                 },
                 {
                   DomainId:"31d5a99d-213e-407b-b133-3836183e5998",
                   DomainType:"PRODUCT_DISCRIMINATOR_DOMAIN",
                   DomainName: "amzn1.adg.product.9b8e3e0b-030b-40e0-8c82-eeec046586d6-4e183527-8241-4e91-a194-bb05db4b11b4-pd-domain",
                   OwnerId: "f57e2d2d-7127-438c-8ba2-005f397b1076",
                   Version:1,
                   ModifiedTimestamp:"20230430042046962Z",
                   RootDomainPath:[
                     "5f79066c-d3ea-489b-9076-50d5c09560c7"
                   ],
                   State:"ACTIVE"
                 }
            ]
         )
     )
 )
(digital::catalog::domain::getDomainByOwnerIdDomainName "f57e2d2d-7127-438c-8ba2-005f397b1076" "abc" result)
[]
```

"""
