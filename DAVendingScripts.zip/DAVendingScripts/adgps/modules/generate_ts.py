from modules.projection_view_prompt import get_default_prompt_for_views_projections
from modules.invoke_bedrock import invoke_bedrock


def get_ts_code_prompt(java_sample_code, ts_sample_code, new_java_code):
    return (
        get_default_prompt_for_views_projections()
        + f"""below is sample java code and it's corresponding typescript code that is being used currently for one of the apis.

java code
--------
```
"""
        + java_sample_code
        + """
```

typescript code
--------
```
"""
        + ts_sample_code
        + """
```

now I will provide you a sample java code which you have to convert to typescript code based on sample provided above.

java code
------
```
"""
        + new_java_code
        + """
```

----------------

Projections and views code you don't need to provide, that you already provided in earlier steps. For this use case I want you to solely focus on converting the java code to typescript based on the sample provided. Note that in typescript code (the sample provided)we don't emit metrics like in java and also there are not Activity classes like AbstractActivity etc. You can remove some redundant code as it doesn't have ot be 1:1 mapping but the logic should be same. Reiterating again to focus on sample java code and it's respective datapath typescript code. Also instead of dao layer you need to use the views and projections defined. Focus on existing typescript code provided to get some idea how it's working. And give the response for individual file as a json array having fields as file_name, file_content, file_description. don't provide any other details in response just the json array with above fields. Make sure file contents are json serializable strings. Also note that all files are inside folder named `typescript/` in the project.
"""
    )


def generate_ts_code(
    role_arn,
    java_sample_code,
    ts_sample_code,
    new_java_code,
    use_latest_model: bool = True,
):
    return invoke_bedrock(
        role_arn,
        get_ts_code_prompt(java_sample_code, ts_sample_code, new_java_code),
        use_latest_model,
    )
