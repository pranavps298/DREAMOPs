import boto3
from time import sleep
import json
import re

OLD_MODEL_ID = "anthropic.claude-3-sonnet-20240229-v1:0"
NEW_MODEL_ID = "anthropic.claude-3-5-sonnet-20240620-v1:0"


def invoke_bedrock(
    role_arn, prompt, use_newer_model=False, is_initial_call=True, is_retry=False
):
    try:
        boto_session = boto3.Session()
        sts = boto_session.client("sts")
        response = sts.assume_role(
            RoleArn=role_arn,
            RoleSessionName="bedrock-session",
        )
        new_session = boto3.Session(
            aws_access_key_id=response["Credentials"]["AccessKeyId"],
            aws_secret_access_key=response["Credentials"]["SecretAccessKey"],
            aws_session_token=response["Credentials"]["SessionToken"],
        )

        # bedrock = new_session.client(service_name="bedrock", region_name="us-east-1")
        bedrock_runtime = new_session.client(
            service_name="bedrock-runtime", region_name="us-east-1"
        )
        print(f"bedrock input size : {len(prompt)}")
        response = bedrock_runtime.invoke_model(
            body=json.dumps(
                {
                    "messages": [
                        {"role": "user", "content": [{"type": "text", "text": prompt}]}
                    ],
                    "max_tokens": 60480,
                    "temperature": 0.5,
                    "top_k": 250,
                    "top_p": 1,
                    "stop_sequences": ["\n\nHuman:"],
                    "anthropic_version": "bedrock-2023-05-31",
                }
            ),
            modelId=(NEW_MODEL_ID if use_newer_model else OLD_MODEL_ID),
            contentType="application/json",
            accept="application/json",
        )
        response_body = json.loads(response.get("body").read())
        output_list = response_body.get("content", [])
        answers = [output["text"] for output in output_list]

        return (
            answers[0] if answers else "some error occurred"
        )  # {"statusCode": 200, "body": json.dumps({"answers": answers})}
    except Exception as e:
        if is_initial_call and re.search(
            "ReadTimeoutError: Read timeout on endpoint URL|Input is too long for requested model",
            str(e),
            flags=re.IGNORECASE,
        ):
            return 400
        if not is_retry and re.search(
            "ThrottlingException",
            str(e),
            flags=re.IGNORECASE,
        ):
            print(f"retrying due to ThrottlingException error: {e}")
            sleep(10)
            return invoke_bedrock(
                role_arn, prompt, use_newer_model, is_initial_call, True
            )
        print(f"bedrock error: {e}")
        raise e
