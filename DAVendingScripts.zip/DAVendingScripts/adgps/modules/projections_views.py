from modules.projection_view_prompt import get_default_prompt_for_views_projections
from modules.invoke_bedrock import invoke_bedrock


def get_prompt_for_views_projections(table_details=""):
    return (
        get_default_prompt_for_views_projections()
        + """

----------------

now I will provide you a dynamodb table details and query pattern and you need to write a projection file and view file for the same. don't focus on typescript for this case.

"""
        + table_details
        + """

----------------

I want to write the respective projection, view file and the tests for the above table and query pattern. And give the response for individual file as a json array having fields as file_name, file_content, file_description. don't provide any other details in response just the json array with above fields. Make sure file contents are json serializable strings.
"""
    )


def get_projections_and_views(role_arn, table_details, use_latest_model: bool = True):
    return invoke_bedrock(
        role_arn,
        get_prompt_for_views_projections(table_details),
        use_latest_model,
    )
