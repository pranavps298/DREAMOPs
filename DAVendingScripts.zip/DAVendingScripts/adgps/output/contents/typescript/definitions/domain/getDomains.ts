import { CustomErrorMessage, getDomainModelObjectFromData, isEmpty } from "../../utils/utils";
import { ERROR_TYPES } from "../../constants/constants";
import { Domain } from "../../interfaces/Domain";
import { getDomainFromDDBUsingId, getDomainFromDDBUsingOwnerIdAndName } from "../../views/views";

/**
 * View for fetching domain data
 * @exportView digital::catalog::adg::domain::getDomains
 */
function getDomains(domains: Domain[]): any {
    if (!domains || domains.length === 0) {
        return CustomErrorMessage("Domains cannot be null or empty", ERROR_TYPES.InvalidRequestException);
    }

    const found: Domain[] = [];
    const missing: Domain[] = [];
    const domainIdMap: Map<string, Domain> = new Map();
    const domainNameMap: Map<string, Domain> = new Map();

    domains.forEach(domain => {
        if (isEmpty(domain.id) && (isEmpty(domain.name) || isEmpty(domain.owner?.id))) {
            throw new Error("Domain must have at least an id or ownerId + domainName");
        }

        if (!isEmpty(domain.id)) {
            domainIdMap.set(domain.id, domain);
        } else if (!isEmpty(domain.name) && !isEmpty(domain.owner?.id)) {
            domainNameMap.set(`${domain.owner.id}:${domain.name}`, domain);
        }
    });

    domainIdMap.forEach((domain, id) => {
        const result = getDomainModelObjectFromData(getDomainFromDDBUsingId(id));
        if (result) {
            found.push(result);
        } else {
            missing.push(domain);
        }
    });

    domainNameMap.forEach((domain, key) => {
        const [ownerId, name] = key.split(':');
        const result = getDomainModelObjectFromData(getDomainFromDDBUsingOwnerIdAndName(ownerId, name));
        if (result) {
            found.push(result);
        } else {
            missing.push(domain);
        }
    });

    return { domains: found, notFound: missing.length > 0 ? missing : undefined };
}
