import { Domain, Owner } from "../interfaces/Domain";

export class ADGDomain implements Domain {
    private id: string;
    private name: string;
    private owner: Owner;
    private type: string;
    private state: string;
    private childrenIds: string[];
    private rootDomainPath: string[];

    constructor() {}

    getId(): string {
        return this.id;
    }

    setId(value: string) {
        this.id = value;
    }

    getName(): string {
        return this.name;
    }

    setName(value: string) {
        this.name = value;
    }

    getOwner(): Owner {
        return this.owner;
    }

    setOwner(value: Owner) {
        this.owner = value;
    }

    getType(): string {
        return this.type;
    }

    setType(value: string) {
        this.type = value;
    }

    getState(): string {
        return this.state;
    }

    setState(value: string) {
        this.state = value;
    }

    getChildrenIds(): string[] {
        return this.childrenIds;
    }

    setChildrenIds(value: string[]) {
        this.childrenIds = value;
    }

    getRootDomainPath(): string[] {
        return this.rootDomainPath;
    }

    setRootDomainPath(value: string[]) {
        this.rootDomainPath = value;
    }
}
