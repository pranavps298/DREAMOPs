export const ERROR_TYPES = {
    InvalidRequestException: 'InvalidRequestException',
    DependencyException: 'DependencyException',
    InternalServiceException: 'InternalServiceException',
    UniqueConstraintException: 'UniqueConstraintException',
    DomainNotFoundException: 'DomainNotFoundException'
};
