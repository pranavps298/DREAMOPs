export interface Owner {
    id: string;
}

export interface Domain {
    id?: string;
    name?: string;
    owner?: Owner;
    type?: string;
    state?: string;
    childrenIds?: string[];
    rootDomainPath?: string[];
}
