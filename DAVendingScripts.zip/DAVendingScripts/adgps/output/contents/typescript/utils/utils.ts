import { ADGDomain } from "../models/ADGDomain";
import { Domain } from "../interfaces/Domain";

export function isEmpty(input: any): boolean {
    return input == null || input === '';
}

export function CustomErrorMessage(message: string, errorType: string): any {
    return { message, type: errorType, error: true };
}

export function getDomainModelObjectFromData(data: any): ADGDomain | null {
    if (!data) return null;

    const domain = new ADGDomain();
    domain.setId(data?.DomainId);
    domain.setName(data?.DomainName);
    domain.setOwner({ id: data?.OwnerId });
    domain.setType(data?.DomainType);
    domain.setState(data?.State);

    if (!isEmpty(data?.ChildrenIds)) {
        domain.setChildrenIds(data.ChildrenIds);
    }
    if (!isEmpty(data?.RootDomainPath)) {
        domain.setRootDomainPath(data.RootDomainPath);
    }

    return domain;
}

export function validateDomainConsistency(fieldName: string, lookupValue: string, result: string): void {
    if (!isEmpty(lookupValue) && !isEmpty(result) && lookupValue != result) {
        throw new Error(`Input ${fieldName} (${lookupValue}) does not match resulting ${fieldName} (${result})`);
    }
}
