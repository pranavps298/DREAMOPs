// DomainNotFoundException.java
package com.amazon.adg.product.dao;

public class DomainNotFoundException extends PersistenceException {

  public DomainNotFoundException() {}

  public DomainNotFoundException(String message) {
    super(message);
  }

  public DomainNotFoundException(String message, Throwable cause) {
    super(message, cause);
  }

  public DomainNotFoundException(Throwable cause) {
    super(cause);
  }

  public DomainNotFoundException(
      String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
    super(message, cause, enableSuppression, writableStackTrace);
  }
}




// PersistenceException.java
package com.amazon.adg.product.dao;

/** Base class for exceptions that occur in the DAO. */
public class PersistenceException extends RuntimeException {

  public PersistenceException() {}

  public PersistenceException(String message) {
    super(message);
  }

  public PersistenceException(String message, Throwable cause) {
    super(message, cause);
  }

  public PersistenceException(Throwable cause) {
    super(cause);
  }

  public PersistenceException(
      String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
    super(message, cause, enableSuppression, writableStackTrace);
  }
}




// GetDomainsActivity.java
package com.amazon.adg.product.service.activity;

import com.amazon.adg.common.model.Domain;
import com.amazon.adg.product.dao.DomainDao;
import com.amazon.adg.product.metric.LogConfig;
import com.amazon.adg.product.service.model.DomainModelUtil;
import com.amazon.adg.product.service.model.GetDomainsRequest;
import com.amazon.adg.product.service.model.GetDomainsResponse;
import com.amazon.adg.product.service.model.InvalidRequestException;
import com.amazon.coral.annotation.Operation;
import com.amazon.coral.annotation.Service;
import com.amazon.coral.support.metrics.UseActivityMetricsForThread;
import com.amazon.mas.commons.coral.support.interceptor.MASDependentServiceInterceptor;
import com.amazon.mas.commons.coral.support.interceptor.MASInterceptorConfiguration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Service("ADGProductService")
public class GetDomainsActivity extends AbstractActivity<GetDomainsRequest, GetDomainsResponse> {

  private static final Logger logger = LogManager.getLogger(GetDomainsActivity.class);
  private static final String COLON_SEPARATOR = ":";

  private DomainDao domainDao;

  public DomainDao getDomainDao() {
    return domainDao;
  }

  public void setDomainDao(final DomainDao domainDao) {
    this.domainDao = domainDao;
  }

  @Operation("getDomains")
  @UseActivityMetricsForThread
  @MASDependentServiceInterceptor
  @MASInterceptorConfiguration(
      samplingRate = LogConfig.EXTERNAL_SAMPLE_RATE,
      internalAccountSamplingRate = LogConfig.INTERNAL_SAMPLE_RATE)
  public GetDomainsResponse getDomains(final GetDomainsRequest request) {
    return execute(request);
  }

  @Override
  protected GetDomainsResponse invoke(final GetDomainsRequest request) {
    final List<Domain> input = request.getDomains();
    final GetDomainsResponse response = new GetDomainsResponse();
    final Map<String, Domain> domainIdMap = new TreeMap<>();
    final Map<String, Domain> domainNameMap = new TreeMap<>();
    input.forEach(
        item -> {
          validateDomain(item);
          if (StringUtils.isNotBlank(item.getId())) {
            domainIdMap.put(item.getId(), item);
          } else if (StringUtils.isNotBlank(item.getName())
              && item.getOwner() != null
              && StringUtils.isNotBlank(item.getOwner().getId())) {
            domainNameMap.put(item.getOwner().getId() + COLON_SEPARATOR + item.getName(), item);
          }
        });
    final List<com.amazon.adg.product.data.Domain> foundDataForDomainId =
        domainDao.getDomains(domainIdMap.keySet());
    final Map<String, com.amazon.adg.product.data.Domain> foundDataForDomainName =
        domainDao.getDomains(domainNameMap);
    final Map<String, com.amazon.adg.product.data.Domain> foundMap = new HashMap<>();
    foundDataForDomainId.forEach(data -> foundMap.put(data.getDomainId(), data));
    final List<Domain> found = new ArrayList<>();
    final List<Domain> missing = new ArrayList<>();
    domainIdMap.forEach(
        (id, model) -> {
          if (foundMap.containsKey(id)) {
            found.add(DomainModelUtil.getModelObjectFromData(foundMap.get(id)));
          } else {
            missing.add(model);
          }
        });
    domainNameMap.forEach(
        (key, domain) -> {
          if (foundDataForDomainName.containsKey(key)) {
            found.add(DomainModelUtil.getModelObjectFromData(foundDataForDomainName.get(key)));
          } else {
            missing.add(domain);
          }
        });
    response.setDomains(found);
    if (!missing.isEmpty()) {
      logger.debug(missing.size() + " domain(s) not found.");
      response.setNotFound(missing);
    }
    return response;
  }

  @Override
  protected void validateRequest(final GetDomainsRequest request) {
    if (request == null) {
      logger.error("Received null request");
      throw new InvalidRequestException("Received null request");
    }
    final List<Domain> input = request.getDomains();
    if (input == null) {
      logger.error("Domains cannot be null");
      throw new InvalidRequestException("Domains cannot be null");
    }
  }

  private void validateDomain(final Domain domain) {
    if ((domain == null)) {
      throw new IllegalArgumentException("domain objects in domains must be non-empty");
    }
    if (StringUtils.isBlank(domain.getId())
        && (StringUtils.isBlank(domain.getName())
            || domain.getOwner() == null
            || StringUtils.isBlank(domain.getOwner().getId()))) {
      throw new IllegalArgumentException("domain must atleast have an id or ownerId + domainName");
    }
  }

  @Override
  protected void validateResponse(
      final GetDomainsRequest request, final GetDomainsResponse response, final long totalTime) {}
}




// ADGProductContextThreadInstance.java
package com.amazon.adg.product.service.context;

import static com.amazon.adg.coral.tenant.metrics.Constants.UNKNOWN;

import com.amazon.adg.coral.model.ADGClientContext;
import com.amazon.adg.coral.tenant.metrics.ADGTenant;
import com.amazon.adg.coral.tenant.metrics.Constants;
import com.amazon.coral.service.Identity;
import coral.service.ADGClientContextThreadInstance;
import java.util.Objects;
import java.util.Optional;
import org.apache.commons.lang.StringUtils;

public final class ADGProductContextThreadInstance {

  private Identity identity = null;

  public ADGProductContextThreadInstance() {}

  private static final ThreadLocal<ADGProductContextThreadInstance> adgProductThreadInstance =
      ThreadLocal.withInitial(() -> new ADGProductContextThreadInstance());

  public static ADGProductContextThreadInstance get() {
    return adgProductThreadInstance.get();
  }

  public void setIdentity(final Identity identity) {
    this.identity = identity;
  }

  public Identity getIdentity() {
    return this.identity;
  }

  public String getADGTenant() {
    if (this.identity == null || this.identity.getAttribute(Constants.ADG_TENANT) == null) {
      return ADGTenant.UNKNOWN.toString();
    }

    return this.identity.getAttribute(Constants.ADG_TENANT);
  }

  public String getAAAClientName() {
    ADGClientContext clientContext = ADGClientContextThreadInstance.getInstance();
    if (Objects.isNull(clientContext)) {
      return UNKNOWN;
    }

    Optional<String> aaaClientNameOptional = clientContext.getAAAClientName();
    return aaaClientNameOptional.isPresent() ? aaaClientNameOptional.get() : UNKNOWN;
  }

  public String getUser() {
    if (this.identity == null
        || StringUtils.isBlank(this.identity.getAttribute(Constants.ADG_UPSTREAM_SERVICE))) {
      return Constants.UNKNOWN;
    }

    return this.identity.getAttribute(Constants.ADG_UPSTREAM_SERVICE);
  }

  public static void removeContextInstance() {
    adgProductThreadInstance.remove();
  }
}




// AbstractActivity.java
package com.amazon.adg.product.service.activity;

import com.amazon.adg.product.dao.UniqueConstraintException;
import com.amazon.adg.product.metric.MetricConstants;
import com.amazon.adg.product.service.context.ADGProductContextThreadInstance;
import com.amazon.adg.product.service.model.DependencyException;
import com.amazon.adg.product.service.model.InternalServiceException;
import com.amazon.adg.product.service.model.InvalidRequestException;
import com.amazon.adg.product.service.model.VendorDoesNotExistException;
import com.amazon.coral.service.Activity;
import com.amazonaws.AmazonServiceException;
import com.google.common.base.Joiner;
import javax.measure.unit.SI;
import javax.measure.unit.Unit;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public abstract class AbstractActivity<T_Request, T_Response> extends Activity {
  private static final Logger logger = LogManager.getLogger(AbstractActivity.class);

  protected T_Response execute(final T_Request request) {
    final long startTime = startAndValidateRequest(request);
    boolean isSuccess = false;
    try {
      final T_Response response = invoke(request);
      stopAndValidateResponse(request, response, startTime);
      isSuccess = true;
      return response;
    } catch (final InvalidRequestException
        | IllegalArgumentException
        | IllegalStateException
        | UniqueConstraintException e) {
      logger.error(String.format("Bad request: %s", e.getMessage()), e);
      getMetrics()
          .addCount(
              getCompoundMetricName(
                  MetricConstants.METRIC_INVALID_REQUEST_EXCEPTION, "ReceivedBadRequest"),
              1,
              Unit.ONE);
      throw new InvalidRequestException(e.getMessage(), e);
    } catch (final AmazonServiceException e) {
      logger.error(String.format("Exception while retrieving: %s", e.getMessage()), e);
      getMetrics().addCount(MetricConstants.METRIC_DEPENDENCY_EXCEPTION, 1, Unit.ONE);
      throw new DependencyException("Problem loading from dynamo: " + e.getMessage(), e);
    } catch (final VendorDoesNotExistException e) {
      logger.error(String.format("Exception while retrieving: %s", e.getMessage()), e);
      throw new VendorDoesNotExistException("Vendor does not exist: " + e.getMessage(), e);
    } catch (final Throwable e) {
      logger.error(String.format("Exception while retrieving: %s", e.getMessage()), e);
      getMetrics().addCount(MetricConstants.METRIC_ANY_GENERIC_EXCEPTION, 1, Unit.ONE);
      throw new InternalServiceException("Received unknown exception", e);
    } finally {
      getMetrics().addCount(MetricConstants.METRIC_TOTAL_REQUESTS, (isSuccess) ? 1 : 0, Unit.ONE);
    }
  }

  private long startAndValidateRequest(final T_Request request) {
    final ADGProductContextThreadInstance contextThreadInstance =
        ADGProductContextThreadInstance.get();
    contextThreadInstance.setIdentity(this.getIdentity());

    validateRequest(request);
    final long start = System.currentTimeMillis();
    return start;
  }

  private void stopAndValidateResponse(
      final T_Request request, final T_Response response, final long startTime) {
    if (response == null) {
      logger.error("Returning null response");
      throw new InternalServiceException("Returning null response");
    }
    final long totalTime = System.currentTimeMillis() - startTime;
    validateResponse(request, response, totalTime);

    getMetrics()
        .addTime(MetricConstants.METRIC_RESPONSE_SUCCESS_TIME, totalTime, SI.MILLI(SI.SECOND));
  }

  public static String getCompoundMetricName(final String... components) {
    return Joiner.on(":").skipNulls().join(components);
  }

  /**
   * Simply invokes the API. All exceptions and logging will be handled.
   *
   * @param request
   * @return
   * @throws Exception
   */
  protected abstract T_Response invoke(final T_Request request) throws Exception;

  /**
   * Validates the request. Should throw InvalidRequestException if not valid.
   *
   * @param request
   */
  protected abstract void validateRequest(final T_Request request);

  /**
   * Validates the response. Should throw InternalServiceException if something is wrong or
   * unexpected.
   *
   * @param response
   * @param totalTime
   * @throws InternalServiceException
   */
  protected abstract void validateResponse(
      final T_Request request, final T_Response response, final long totalTime);
}




// UniqueConstraintException.java
package com.amazon.adg.product.dao;

public class UniqueConstraintException extends PersistenceException {

  public UniqueConstraintException() {}

  public UniqueConstraintException(String message) {
    super(message);
  }

  public UniqueConstraintException(String message, Throwable cause) {
    super(message, cause);
  }

  public UniqueConstraintException(Throwable cause) {
    super(cause);
  }

  public UniqueConstraintException(
      String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
    super(message, cause, enableSuppression, writableStackTrace);
  }
}




// AbstractDao.java
package com.amazon.adg.product.dao;

import com.amazon.coral.metrics.Metrics;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;

public abstract class AbstractDao {

  protected DynamoDBMapper readDbMapper;
  protected DynamoDBMapper writeDbMapper;
  protected Metrics metrics;

  public AbstractDao(
      final DynamoDBMapper readDbMapper,
      final DynamoDBMapper writeDbMapper,
      final Metrics metrics) {
    this.readDbMapper = readDbMapper;
    this.writeDbMapper = writeDbMapper;
    this.metrics = metrics;
  }

  public void setReadDbMapper(final DynamoDBMapper readDbMapper) {
    this.readDbMapper = readDbMapper;
  }

  public DynamoDBMapper getReadDbMapper() {
    return readDbMapper;
  }

  public void setWriteDbMapper(final DynamoDBMapper writeDbMapper) {
    this.writeDbMapper = writeDbMapper;
  }

  public DynamoDBMapper getWriteDbMapper() {
    return writeDbMapper;
  }
}




// Domain.java
package com.amazon.adg.product.data;

import com.amazon.adg.common.dynamodb.marshaller.ScopeLocalDateTimeMarshaller;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBIgnore;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBIndexHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBIndexRangeKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMarshalling;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBVersionAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.encryption.DoNotEncrypt;
import com.amazonaws.services.dynamodbv2.datamodeling.encryption.DoNotTouch;
import java.time.LocalDateTime;
import java.util.List;

@DynamoDBTable(tableName = "ADGDomain")
@DoNotTouch
public class Domain {

  public static final String TABLE_NAME = "ADGDomain";

  public static final String DOMAIN_ID = "DomainId";
  public static final String DOMAIN_NAME = "DomainName";
  public static final String OWNER_ID = "OwnerId";
  public static final String DOMAIN_TYPE = "DomainType";
  public static final String CHILDREN_IDS = "ChildrenIds";
  public static final String ROOT_DOMAIN_PATH = "RootDomainPath";
  public static final String MODIFIED_TIMESTAMP = "ModifiedTimestamp";
  public static final String STATE = "State";
  public static final String VERSION = "Version";

  public static final String INDEX_BY_OWNER_ID = "ADGDomainByOwnerId-index";
  public static final String INDEX_BY_OWNER_ID_DOMAINTYPE = "ADGDomainByOwnerId-DomainType-index";
  public static final String INDEX_BY_OWNER_ID_DOMAINNAME = "ADGDomainByOwnerId-DomainName-index";

  private String domainId;
  private String name;
  private String ownerId;
  private List<String> rootDomainPath;
  private List<String> childrenIds;
  private List<Domain> children;
  private LocalDateTime modifiedTimestamp;
  private String type;
  private String state;
  private Long version;

  public Domain() {}

  public Domain(String domainId) {
    this.domainId = domainId;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = DOMAIN_ID)
  @DynamoDBHashKey(attributeName = DOMAIN_ID)
  @DynamoDBIndexRangeKey(attributeName = DOMAIN_ID, globalSecondaryIndexName = INDEX_BY_OWNER_ID)
  public String getDomainId() {
    return domainId;
  }

  public void setDomainId(String domainId) {
    this.domainId = domainId;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = DOMAIN_NAME)
  @DynamoDBIndexRangeKey(
      attributeName = DOMAIN_NAME,
      globalSecondaryIndexName = INDEX_BY_OWNER_ID_DOMAINNAME)
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = OWNER_ID)
  @DynamoDBIndexHashKey(
      attributeName = OWNER_ID,
      globalSecondaryIndexNames = {
        INDEX_BY_OWNER_ID,
        INDEX_BY_OWNER_ID_DOMAINTYPE,
        INDEX_BY_OWNER_ID_DOMAINNAME
      })
  public String getOwnerId() {
    return ownerId;
  }

  public void setOwnerId(String ownerId) {
    this.ownerId = ownerId;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = DOMAIN_TYPE)
  @DynamoDBIndexRangeKey(
      attributeName = DOMAIN_TYPE,
      globalSecondaryIndexName = INDEX_BY_OWNER_ID_DOMAINTYPE)
  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = CHILDREN_IDS)
  public List<String> getChildrenIds() {
    return childrenIds;
  }

  public void setChildrenIds(List<String> childrenIds) {
    this.childrenIds = childrenIds;
  }

  @DynamoDBIgnore
  public List<Domain> getChildren() {
    return children;
  }

  public void setChildren(List<Domain> children) {
    this.children = children;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = ROOT_DOMAIN_PATH)
  public List<String> getRootDomainPath() {
    return rootDomainPath;
  }

  public void setRootDomainPath(List<String> rootDomainPath) {
    this.rootDomainPath = rootDomainPath;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = MODIFIED_TIMESTAMP)
  @DynamoDBMarshalling(marshallerClass = ScopeLocalDateTimeMarshaller.class)
  public LocalDateTime getModifiedTimestamp() {
    return modifiedTimestamp;
  }

  public void setModifiedTimestamp(LocalDateTime modifiedTimestamp) {
    this.modifiedTimestamp = modifiedTimestamp;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = STATE)
  public String getState() {
    return state;
  }

  public void setState(String state) {
    this.state = state;
  }

  /**
   * Version optimistic locking.
   *
   * @return Long version
   */
  @DoNotEncrypt
  @DynamoDBVersionAttribute(attributeName = VERSION)
  public Long getVersion() {
    return version;
  }

  public void setVersion(Long version) {
    this.version = version;
  }

  public String debugString() {
    StringBuilder str = new StringBuilder(domainId).append(" (v").append(version).append(")");
    return str.toString();
  }

  @Override
  public String toString() {
    final StringBuilder str = new StringBuilder("Domain{");
    str.append("domainId='");
    str.append(domainId);
    str.append("', name='");
    str.append(name);
    str.append("', type='");
    str.append(type);
    str.append("', ownerId='");
    str.append(ownerId);
    str.append("'}");
    return str.toString();
  }
}




// DomainDao.java
package com.amazon.adg.product.dao;

import static com.amazon.adg.product.utils.LoggerUtils.getAmazonServiceExceptionMessage;
import static com.amazon.adg.product.utils.LoggerUtils.getConditionalCheckExceptionMessage;
import static com.amazon.adg.product.utils.LoggerUtils.getRetryLimitExceededMessage;
import static com.amazon.adg.product.utils.LoggerUtils.getThrottledRequestMessage;

import com.amazon.adg.common.product.ADGDomainTypeEnum;
import com.amazon.adg.common.util.LocalDateTimeUtil;
import com.amazon.adg.product.data.Domain;
import com.amazon.adg.product.data.DomainStateEnum;
import com.amazon.adg.product.metric.MetricConstants;
import com.amazon.adg.product.service.model.InternalServiceException;
import com.amazon.adg.product.service.model.InvalidRequestException;
import com.amazon.adg.product.utils.MetricUtils;
import com.amazon.coral.metrics.Metrics;
import com.amazon.mas.commons.coral.support.metrics.ProfilerTimer;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.SdkClientException;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBQueryExpression;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.ComparisonOperator;
import com.amazonaws.services.dynamodbv2.model.Condition;
import com.amazonaws.services.dynamodbv2.model.ConditionalCheckFailedException;
import com.amazonaws.services.dynamodbv2.model.ProvisionedThroughputExceededException;
import com.amazonaws.services.dynamodbv2.transactions.Transaction;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/** DAO for working with Domain objects and DynamoDB. */
public class DomainDao extends AbstractDao {

  private static final Logger logger = LogManager.getLogger(DomainDao.class);

  public DomainDao(
      final DynamoDBMapper readDbMapper,
      final DynamoDBMapper writeDbMapper,
      final Metrics metrics) {
    super(readDbMapper, writeDbMapper, metrics);
  }

  /**
   * Create a root domain with provided domain.
   *
   * @param domain domain to be created
   */
  public Domain createRootDomain(final Domain domain) {
    return createDomain(domain, null, null);
  }

  public void createRootDomain(final Domain domain, final Transaction transaction) {
    createDomain(domain, null, transaction);
  }

  public Domain createChildDomain(final Domain domain, final Domain parentDomain) {
    return createDomain(domain, parentDomain, null);
  }

  /**
   * Create a child domain with provided domain and parent domain.
   *
   * @param domain domain to be created
   * @param parentDomain Required if creating a child domain. Needs parent domain in order to
   *     maintain unique names across parent's children.
   * @return the created child domain
   */
  public Domain createDomain(
      final Domain domain, final Domain parentDomain, final Transaction transaction) {
    if (domain == null) {
      throw new IllegalArgumentException("domain cannot be empty; must have name");
    }
    if (StringUtils.isBlank(domain.getName())) {
      throw new IllegalArgumentException("domain name cannot be empty");
    }
    if (StringUtils.isBlank(domain.getOwnerId())) {
      throw new IllegalArgumentException("ownerId cannot be empty");
    }
    if (StringUtils.isBlank(domain.getType())) {
      domain.setType(ADGDomainTypeEnum.VENDOR.name());
    }
    if (!ADGDomainTypeEnum.isValidDomainType(domain.getType())) {
      throw new IllegalArgumentException(
          "domainType should contain one of the ADGDomainTypeEnum values");
    }

    if (parentDomain != null) {
      final Domain foundParentDomain = getParentDomain(parentDomain);
      enforceDomainNameUniqueness(domain);

      updateRootDomainPath(domain, foundParentDomain);
    }
    if (StringUtils.isBlank(domain.getDomainId())) {
      domain.setDomainId(UUID.randomUUID().toString());
    }

    domain.setModifiedTimestamp(LocalDateTimeUtil.nowUtc());
    domain.setState(DomainStateEnum.ACTIVE.name());

    logger.debug("Saving new " + domain.debugString());

    final boolean isTransaction = transaction != null;

    final ProfilerTimer timer =
        new ProfilerTimer(
            metrics,
            isTransaction
                ? MetricConstants.METRIC_DYNAMO_DB_CREATE_DOMAIN_TRANSACTION
                : MetricConstants.METRIC_DYNAMO_DB_CREATE_DOMAIN,
            false);

    try {
      timer.start();

      if (isTransaction) {
        transaction.save(domain);
      } else {
        writeDbMapper.save(domain);
      }
    } catch (final ConditionalCheckFailedException ex) {
      logger.error(
          getConditionalCheckExceptionMessage("createChildDomain", "domain", domain.toString()));
      MetricUtils.emitConditionalCheckFailedExceptionMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_CREATE_DOMAIN_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_CREATE_DOMAIN);
      throw ex;
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(getThrottledRequestMessage("createChildDomain", "domain", domain.toString()));
      MetricUtils.emitThrottledRequestMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_CREATE_DOMAIN_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_CREATE_DOMAIN);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(
          getAmazonServiceExceptionMessage("createChildDomain", "domain", domain.toString()));
      MetricUtils.emitAmazonServiceExceptionMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_CREATE_DOMAIN_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_CREATE_DOMAIN);
      throw ex;
    } finally {
      timer.stop();
    }

    return domain;
  }

  /**
   * Creating or updating root domain based on whether we get the domain.id back from the database
   *
   * @param root
   * @param transaction
   * @return
   */
  public Domain createOrUpdateRootDomain(final Domain root, final Transaction transaction) {
    final Domain foundRootDomain = getDomain(root);
    if (foundRootDomain == null || StringUtils.isBlank(foundRootDomain.getDomainId())) {
      createRootDomain(root, transaction);
    } else {
      root.setDomainId(foundRootDomain.getDomainId());
      update(root, transaction);
    }
    return getDomain(root);
  }

  /**
   * Update domain item for ADGDomain with provided domain.
   *
   * @param domain updated domain
   */
  public void update(final Domain domain) {
    update(domain, null, null);
  }

  /**
   * Update domain item for ADGDomain with provided domain as part of a transaction
   *
   * @param domain
   * @param transaction
   */
  public void update(final Domain domain, final Transaction transaction) {
    update(domain, null, transaction);
  }

  /**
   * Update domain item for ADGDomain with provided domain and a parentDomain
   *
   * @param domain
   * @param parentDomain
   */
  public void update(final Domain domain, final Domain parentDomain) {
    update(domain, parentDomain, null);
  }

  /**
   * Update domain item for ADGDomain with provided domain, parent domain as part of a transaction.
   *
   * @param domain
   * @param parentDomain Parent domain of domain.  Required only if domain that is being updated has
   *     a changed name and is a child domain.
   * @param transaction
   */
  public void update(
      final Domain domain, final Domain parentDomain, final Transaction transaction) {
    if (domain == null) {
      throw new IllegalArgumentException("domain cannot be empty");
    }
    if (StringUtils.isBlank(domain.getDomainId())) {
      throw new IllegalArgumentException("domainId cannot be empty");
    }
    if (StringUtils.isBlank(domain.getName())) {
      throw new IllegalArgumentException("domain name cannot be empty");
    }
    domain.setModifiedTimestamp(LocalDateTimeUtil.nowUtc());

    final Domain foundDomain = getDomain(domain);
    if (foundDomain == null) {
      throw new DomainNotFoundException(
          "Unable to find matching domain to update for domain " + domain.toString() + ".");
    }
    logger.debug("found matching domain: " + domain.toString());

    if (StringUtils.isNotBlank(foundDomain.getName())
        && !foundDomain.getName().equals(domain.getName())) {
      // If domain is a child, a parent domain is needed.
      if (CollectionUtils.isNotEmpty(foundDomain.getRootDomainPath())) {
        if (parentDomain == null) {
          throw new IllegalArgumentException(
              String.format(
                  "Cannot change a root domain's name: attempting to change from %s to %s.",
                  foundDomain.getName(), domain.getName()));
        }
        getParentDomain(parentDomain);
        enforceDomainNameUniqueness(domain);
      }
    }
    if (StringUtils.isNotBlank(domain.getState())) {
      // will validate and normalize the string
      domain.setState(DomainStateEnum.valueOf(domain.getState()).name());
    } else {
      // explicitly using the previous state
      domain.setState(foundDomain.getState());
    }

    if (ADGDomainTypeEnum.isValidDomainType(domain.getType())) {
      // will validate and normalize the string
      domain.setType(ADGDomainTypeEnum.fromString(domain.getType()).name());
    } else {
      // explicitly using the previous type
      domain.setType(foundDomain.getType());
    }

    // explicitly using the previous type
    if (CollectionUtils.isEmpty(domain.getRootDomainPath())
        && CollectionUtils.isNotEmpty(foundDomain.getRootDomainPath())) {
      domain.setRootDomainPath(foundDomain.getRootDomainPath());
    } else if (CollectionUtils.isNotEmpty(domain.getRootDomainPath())
        && CollectionUtils.isNotEmpty(foundDomain.getRootDomainPath())) {
      // combining both the rootDomainPaths
      final Set<String> combinedRootDomainPath = Sets.newHashSet(foundDomain.getRootDomainPath());
      combinedRootDomainPath.addAll(domain.getRootDomainPath());
      domain.setRootDomainPath(Lists.newArrayList(combinedRootDomainPath));
    }

    if (transaction != null && domain.getVersion() == null) {
      domain.setVersion(foundDomain.getVersion());
    }

    logger.debug("Saving updated domain: " + domain.toString());

    final boolean isTransaction = transaction != null;

    final ProfilerTimer timer =
        new ProfilerTimer(
            metrics,
            isTransaction
                ? MetricConstants.METRIC_DYNAMO_DB_UPDATE_DOMAIN_TRANSACTION
                : MetricConstants.METRIC_DYNAMO_DB_UPDATE_DOMAIN,
            false);

    try {
      timer.start();

      if (isTransaction) {
        transaction.save(domain);
      } else {
        writeDbMapper.save(domain);
      }
    } catch (final ConditionalCheckFailedException ex) {
      logger.error(
          getConditionalCheckExceptionMessage("updateDomain", "domain", domain.toString()));
      MetricUtils.emitConditionalCheckFailedExceptionMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_UPDATE_DOMAIN_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_UPDATE_DOMAIN);
      throw ex;
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(getThrottledRequestMessage("updateDomain", "domain", domain.toString()));
      MetricUtils.emitThrottledRequestMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_UPDATE_DOMAIN_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_UPDATE_DOMAIN);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(getAmazonServiceExceptionMessage("updateDomain", "domain", domain.toString()));
      MetricUtils.emitAmazonServiceExceptionMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_UPDATE_DOMAIN_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_UPDATE_DOMAIN);
      throw ex;
    } finally {
      timer.stop();
    }
  }

  /**
   * Gets parent domain after checking its existence.
   *
   * @param parentDomain a domain's parent that is being enforced.
   * @return the found parent domain
   */
  private Domain getParentDomain(final Domain parentDomain) {
    final Domain foundParentDomain = getDomain(parentDomain);

    if (foundParentDomain == null) {
      throw new DomainNotFoundException("parent domain could not be found");
    }

    return foundParentDomain;
  }

  /**
   * Enforces domain to have a unique name across its vendor's domains.
   *
   * @param domain the domain that is being enforced.
   */
  private void enforceDomainNameUniqueness(final Domain domain) {
    final List<Domain> matchingNameDomains =
        getDomainsByOwnerIdAndDomainName(domain.getOwnerId(), domain.getName());

    if (!CollectionUtils.isEmpty(matchingNameDomains)) {
      final String errorMessage =
          "Domain name ["
              + domain.getName()
              + "] already present under Vendor ["
              + domain.getOwnerId()
              + "]";

      logger.error("Unique constraint violated: " + errorMessage);
      throw new UniqueConstraintException(errorMessage);
    }
  }

  /**
   * Updates RootDomainPath of a domain
   *
   * @param domain the domain that is being updated.
   * @param parentDomain the parent domain of the domain that is being updated.
   */
  private void updateRootDomainPath(final Domain domain, final Domain parentDomain) {
    if (ADGDomainTypeEnum.VENDOR.name().equals(parentDomain.getType())
        && ADGDomainTypeEnum.VENDOR_ROOT.name().equals(domain.getType())) {
      throw new IllegalStateException(
          "Invalid parent domain " + parentDomain.toString() + " for domain " + domain.toString());
    }

    final List<String> rootPath = new ArrayList<>();
    rootPath.add(parentDomain.getDomainId());

    if (parentDomain.getRootDomainPath() != null) {
      rootPath.addAll(parentDomain.getRootDomainPath());
    }

    domain.setRootDomainPath(rootPath);
  }

  /**
   * Adds childDomain as child for parentDomain
   *
   * @return the found parent domain in dynamoDb
   */
  public Domain addChild(final Domain parentDomain, final Domain childDomain) {
    return addChild(parentDomain, childDomain, null);
  }

  /**
   * Adds childDomain as child for parentDomain
   *
   * @return the found parent domain in dynamoDb
   */
  public Domain addChild(
      final Domain parentDomain, final Domain childDomain, final Transaction transaction) {
    if (parentDomain == null) {
      throw new IllegalArgumentException("parent domain cannot be null");
    }
    if (childDomain == null) {
      throw new IllegalArgumentException("child domain cannot be null");
    }

    final Domain foundParentDomain = getDomain(parentDomain);
    if (foundParentDomain == null) {
      throw new DomainNotFoundException(
          "Unable to find matching parent domain to update for domain "
              + parentDomain.toString()
              + ".");
    }
    logger.debug("found matching parent domain: " + foundParentDomain.toString());
    final Domain foundChildDomain = getDomain(childDomain);
    if (foundChildDomain == null) {
      throw new DomainNotFoundException(
          "Unable to find matching child domain to update for domain "
              + childDomain.toString()
              + ".");
    }
    logger.debug("found matching child domain: " + foundChildDomain.toString());

    if (ADGDomainTypeEnum.VENDOR.name().equals(foundParentDomain.getType())
        && ADGDomainTypeEnum.VENDOR_ROOT.name().equals(foundChildDomain.getType())) {
      throw new IllegalStateException(
          "Cannot add child domain "
              + foundChildDomain.toString()
              + " to parent domain "
              + foundParentDomain.toString());
    }

    final List<String> rootPath = new ArrayList<>();
    rootPath.add(foundParentDomain.getDomainId());
    if (foundParentDomain.getRootDomainPath() != null) {
      rootPath.addAll(foundParentDomain.getRootDomainPath());
    }
    foundChildDomain.setRootDomainPath(rootPath);
    if (foundParentDomain.getChildrenIds() == null) {
      foundParentDomain.setChildrenIds(new ArrayList<>());
    }
    if (foundParentDomain.getChildren() == null) {
      foundParentDomain.setChildren(new ArrayList<>());
    }
    foundParentDomain.getChildrenIds().add(foundChildDomain.getDomainId());
    foundParentDomain.getChildren().add(foundChildDomain);

    logger.debug("Updating childDomain ...");
    update(foundChildDomain, transaction);
    logger.debug("Updating parentDomain ...");
    update(foundParentDomain, transaction);

    return foundParentDomain;
  }

  /**
   * Gets domain from ADGDomain. Determines how to get domain based on what fields are available.
   *
   * @param domain ADG-specific domain
   * @return If domain is not found, returns null if. If found, returns ADG-specific domain.
   */
  public Domain getDomain(final Domain domain) {
    if (domain == null) {
      throw new IllegalArgumentException("domain cannot be null");
    }

    if (StringUtils.isNotBlank(domain.getDomainId())) {
      return getDomainByDomainId(domain.getDomainId());
    }
    if (StringUtils.isNotBlank(domain.getOwnerId()) && StringUtils.isNotBlank(domain.getName())) {
      return getDomainByOwnerIdAndDomainName(domain.getOwnerId(), domain.getName());
    }
    throw new IllegalArgumentException(
        "domain cannot be empty; one of the identifier fields needs to be populated (e.g. domainId)");
  }

  /**
   * Gets domain from ADGDomain by domain id.
   *
   * @param domainId domainId from ADG-specific domain
   * @return If not found returns null, if found, returns domain.
   */
  public Domain getDomainByDomainId(final String domainId) {
    if (StringUtils.isBlank(domainId)) {
      throw new IllegalArgumentException("domainId cannot be empty");
    }

    logger.debug("Loading domain for domainId " + domainId + " ...");

    final ProfilerTimer timer =
        new ProfilerTimer(metrics, MetricConstants.METRIC_DYNAMO_DB_GET_DOMAIN_BY_DOMAIN_ID, false);
    Domain domain;

    try {
      timer.start();
      domain = readDbMapper.load(Domain.class, domainId);

    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(getThrottledRequestMessage("getDomainByDomainId", "domainId", domainId));
      MetricUtils.emitThrottledRequestMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_DOMAIN_BY_DOMAIN_ID);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(getAmazonServiceExceptionMessage("getDomainByDomainId", "domainId", domainId));
      MetricUtils.emitAmazonServiceExceptionMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_DOMAIN_BY_DOMAIN_ID);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(getRetryLimitExceededMessage("getDomainByDomainId", "domainId", domainId));
      MetricUtils.emitRetryLimitExceededMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_DOMAIN_BY_DOMAIN_ID);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }

    logger.debug("Found: " + domain);

    return domain;
  }

  /**
   * Gets domain from ADGDomain by ownerId and domain name
   *
   * @param ownerId ownerId from ADG-specific domain
   * @param domainName domain Name from ADG-specific domain
   * @return If domains are not found from ownerId, returns null. If found, then returns domain
   * @exception UniqueConstraintException Throws if multiple domains are found.
   */
  private Domain getDomainByOwnerIdAndDomainName(final String ownerId, final String domainName) {
    if (StringUtils.isBlank(ownerId) || StringUtils.isBlank(domainName)) {
      throw new IllegalArgumentException("ownerId and domainName cannot be empty");
    }

    logger.debug("Loading domain for domainName " + domainName + " ...");
    final List<Domain> matchingDomains = getDomainsByOwnerIdAndDomainName(ownerId, domainName);
    if (matchingDomains.size() == 1) {
      return getDomainByDomainId(matchingDomains.get(0).getDomainId());
    } else if (matchingDomains.size() > 1) {
      throw new UniqueConstraintException(
          "More than one match for domainName "
              + domainName
              + "? Matches: "
              + matchingDomains.size());
    } else {
      return null;
    }
  }

  public List<Domain> getDomains(final Collection<String> domainIds) {
    if (CollectionUtils.isEmpty(domainIds)) {
      return new ArrayList<>();
    }

    final List<Object> batchInput = new ArrayList<>();
    domainIds.forEach(domainId -> batchInput.add(new Domain(domainId)));

    final ProfilerTimer timer =
        new ProfilerTimer(metrics, MetricConstants.METRIC_DYNAMO_DB_GET_DOMAINS, false);
    Map<String, List<Object>> foundMap;

    try {
      timer.start();
      foundMap = readDbMapper.batchLoad(batchInput);

    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(getThrottledRequestMessage("getDomains", "domainIds", domainIds.toString()));
      MetricUtils.emitThrottledRequestMetric(MetricConstants.METRIC_DYNAMO_DB_GET_DOMAINS);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(
          getAmazonServiceExceptionMessage("getDomains", "domainIds", domainIds.toString()));
      MetricUtils.emitAmazonServiceExceptionMetric(MetricConstants.METRIC_DYNAMO_DB_GET_DOMAINS);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(getRetryLimitExceededMessage("getDomains", "domainIds", domainIds.toString()));
      MetricUtils.emitRetryLimitExceededMetric(MetricConstants.METRIC_DYNAMO_DB_GET_DOMAINS);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }

    if (!foundMap.containsKey(Domain.TABLE_NAME)) {
      throw new IllegalStateException(
          "Unable to find batchLoad results entry for primary table name "
              + Domain.TABLE_NAME
              + "?");
    }
    final List<Domain> found = (List<Domain>) (List<?>) foundMap.get(Domain.TABLE_NAME);
    logger.debug("Found " + found.size() + " of the original " + batchInput.size() + " item(s).");
    return found;
  }

  public List<Domain> getDomainsByOwnerId(final String ownerId) {
    return getDomainsByOwnerIdAndDomainName(ownerId, null);
  }

  /**
   * Get domains from ownerId or ownerId + domainName
   *
   * @param ownerId ownerId to search for.
   * @param domainName domainName to filter for.
   * @return If no domains are found, returns an empty list. If found, return list of domains.
   */
  private List<Domain> getDomainsByOwnerIdAndDomainName(
      final String ownerId, final String domainName) {
    if (StringUtils.isBlank(ownerId)) {
      throw new IllegalArgumentException("ownerId cannot be empty");
    }

    logger.debug("Loading domain for ownerId " + ownerId + " ...");

    final Domain domainKey = new Domain();
    domainKey.setOwnerId(ownerId);

    final DynamoDBQueryExpression<Domain> queryExpression =
        new DynamoDBQueryExpression<Domain>().withConsistentRead(false);

    if (StringUtils.isNotBlank(domainName)) {
      final Condition rangeKeyCondition =
          new Condition()
              .withComparisonOperator(ComparisonOperator.EQ)
              .withAttributeValueList(new AttributeValue().withS(domainName));

      domainKey.setName(domainName);
      queryExpression.withIndexName(Domain.INDEX_BY_OWNER_ID_DOMAINNAME);
      queryExpression.withRangeKeyCondition(Domain.DOMAIN_NAME, rangeKeyCondition);
    } else {
      queryExpression.withIndexName(Domain.INDEX_BY_OWNER_ID);
    }

    queryExpression.withHashKeyValues(domainKey);

    final ProfilerTimer timer =
        new ProfilerTimer(metrics, MetricConstants.METRIC_DYNAMO_DB_GET_DOMAINS_BY_OWNER_ID, false);
    List<Domain> matches;

    try {
      timer.start();
      matches = readDbMapper.query(Domain.class, queryExpression);
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(
          getThrottledRequestMessage(
              "getDomainsByOwnerIdAndDomainName", "ownerId", ownerId, "domainName", domainName));
      MetricUtils.emitThrottledRequestMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_DOMAINS_BY_OWNER_ID);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(
          getAmazonServiceExceptionMessage(
              "getDomainsByOwnerIdAndDomainName", "ownerId", ownerId, "domainName", domainName));
      MetricUtils.emitAmazonServiceExceptionMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_DOMAINS_BY_OWNER_ID);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(
          getRetryLimitExceededMessage(
              "getDomainsByOwnerIdAndDomainName", "ownerId", ownerId, "domainName", domainName));
      MetricUtils.emitRetryLimitExceededMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_DOMAINS_BY_OWNER_ID);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }

    logger.debug("Matches in " + queryExpression.getIndexName() + " found: " + matches.size());
    return matches;
  }

  public List<Domain> getDomainRootPath(final String domainId) {
    if (StringUtils.isBlank(domainId)) {
      throw new IllegalArgumentException("domainId cannot be empty");
    }

    logger.debug("Loading domain root path for domainId " + domainId + " ...");

    try {
      final Domain domain = getDomainByDomainId(domainId);
      if (domain == null) {
        throw new DomainNotFoundException("No matching domain found for domainId " + domainId);
      }
      logger.debug("Found: " + domain);
      final List<Domain> domainRootPath = new ArrayList<>();
      if (CollectionUtils.isEmpty(domain.getRootDomainPath())) {
        return domainRootPath;
      }

      // otherwise ...
      final List<Domain> found = getDomains(domain.getRootDomainPath());
      if (found.size() != domain.getRootDomainPath().size()) {
        throw new DomainNotFoundException(
            "Unable to find all domains specified in rootDomainPath id collection? Expected "
                + domain.getRootDomainPath().size()
                + " results but got "
                + found.size());
      }
      final Map<String, Domain> foundMap = new HashMap<>();
      found.forEach(item -> foundMap.put(item.getDomainId(), item));
      final List<Domain> rootDomainPath = new ArrayList<>();
      domain
          .getRootDomainPath()
          .forEach(
              id -> {
                if (!foundMap.containsKey(id)) {
                  throw new DomainNotFoundException("domainId " + id + " was not found.");
                }
                rootDomainPath.add(foundMap.get(id));
              });
      return rootDomainPath;
    } catch (final AmazonServiceException ex) {
      logger.error("Problem? " + ex, ex);
      throw ex;
    }
  }

  public List<Domain> getVendorDomains(final String vendorId, final String domainType) {
    if (StringUtils.isBlank(vendorId)) {
      throw new IllegalArgumentException("vendorId cannot be empty");
    }
    if (!StringUtils.isBlank(domainType) && !ADGDomainTypeEnum.isValidDomainType(domainType)) {
      throw new IllegalArgumentException(
          "domainType should contain one of the ADGDomainTypeEnum values");
    }
    logger.debug(
        "Querying for domains for vendorId " + vendorId + ", domainType " + domainType + " ...");

    final List<Domain> domains =
        getVendorDomainsByTypeFromDynamo(
            vendorId, domainType, MetricConstants.METRIC_DYNAMO_DB_GET_DOMAINS_BY_DOMAIN_TYPE);

    if (CollectionUtils.isEmpty(domains)) {
      logger.debug(
          "No matches found, no domain has domain type of "
              + domainType
              + "under vendor"
              + vendorId);
    }

    return domains;
  }

  public Domain getVendorDomainTree(final String vendorId) {
    return getVendorDomainTree(vendorId, null);
  }

  public Domain getVendorDomainTree(final String vendorId, final String domainId) {
    if (StringUtils.isBlank(vendorId)) {
      throw new IllegalArgumentException("vendorId cannot be empty");
    }
    logger.debug("Querying for domains for vendorId " + vendorId + " ...");

    Domain root = null;
    final Map<String, Condition> queryFilter = new HashMap<>();

    if (StringUtils.isNotBlank(domainId)) {
      root = getDomainByDomainId(domainId);
      if (root == null) {
        return null;
      }
      final Condition condition =
          new Condition()
              .withComparisonOperator(ComparisonOperator.CONTAINS)
              .withAttributeValueList(new AttributeValue().withS(domainId));
      queryFilter.put(Domain.ROOT_DOMAIN_PATH, condition);
    }

    final List<Domain> domains =
        getVendorDomainsFromDynamo(
            vendorId, queryFilter, MetricConstants.METRIC_DYNAMO_DB_GET_DOMAIN_TREE);

    if (root != null) {
      // add the root node to the results, as it won't be found with the filter
      logger.debug("Adding root node for subtree into matches ...");
      domains.add(0, root);
    }
    return constructVendorDomainTree(vendorId, root, domains);
  }

  private List<Domain> getVendorDomainsFromDynamo(
      final String vendorId, Map<String, Condition> queryFilter, String metricTimerName) {
    final Domain vendorKey = new Domain();
    vendorKey.setOwnerId(vendorId);

    final DynamoDBQueryExpression<Domain> queryExpression =
        new DynamoDBQueryExpression<Domain>()
            .withHashKeyValues(vendorKey)
            .withConsistentRead(false)
            .withIndexName(Domain.INDEX_BY_OWNER_ID);

    queryExpression.withQueryFilter(queryFilter);

    return getVendorDomainsFromDynamo(queryExpression, metricTimerName);
  }

  private List<Domain> getVendorDomainsByTypeFromDynamo(
      final String vendorId, final String domainType, final String metricTimerName) {
    final Domain vendorKey = new Domain();
    vendorKey.setOwnerId(vendorId);

    final DynamoDBQueryExpression<Domain> queryExpression =
        new DynamoDBQueryExpression<Domain>().withConsistentRead(false);

    if (StringUtils.isBlank(domainType)) {
      queryExpression.withIndexName(Domain.INDEX_BY_OWNER_ID);
    } else {
      final Condition rangeKeyCondition =
          new Condition()
              .withComparisonOperator(ComparisonOperator.EQ)
              .withAttributeValueList(new AttributeValue().withS(domainType));

      vendorKey.setType(domainType);
      queryExpression.withIndexName(Domain.INDEX_BY_OWNER_ID_DOMAINTYPE);
      queryExpression.withRangeKeyCondition(Domain.DOMAIN_TYPE, rangeKeyCondition);
    }
    queryExpression.withHashKeyValues(vendorKey);

    return getVendorDomainsFromDynamo(queryExpression, metricTimerName);
  }

  private List<Domain> getVendorDomainsFromDynamo(
      final DynamoDBQueryExpression<Domain> queryExpression, String metricTimerName) {
    final String vendorId = queryExpression.getHashKeyValues().getOwnerId();

    final ProfilerTimer timer = new ProfilerTimer(metrics, metricTimerName, false);
    List<Domain> domains = new ArrayList<>();

    try {
      timer.start();
      // slurp them all up
      // TODO not sure about how this works if we have incredibly large domain trees
      domains.addAll(readDbMapper.query(Domain.class, queryExpression));
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(getThrottledRequestMessage("getVendorDomainsFromDynamo", "vendorId", vendorId));
      MetricUtils.emitThrottledRequestMetric(metricTimerName);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(
          getAmazonServiceExceptionMessage("getVendorDomainsFromDynamo", "vendorId", vendorId));
      MetricUtils.emitAmazonServiceExceptionMetric(metricTimerName);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(
          getRetryLimitExceededMessage("getVendorDomainsFromDynamo", "vendorId", vendorId));
      MetricUtils.emitRetryLimitExceededMetric(metricTimerName);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }

    logger.debug("Matches in " + queryExpression.getIndexName() + " found: " + domains.size());

    return domains;
  }

  protected Domain constructVendorDomainTree(
      final String vendorId, Domain root, final List<Domain> domains) {
    if (CollectionUtils.isEmpty(domains)) {
      logger.debug("No matches found, nothing to make a domain tree from.");
      return null;
    }
    final Map<String, Domain> map = new HashMap<>();
    final List<Domain> rootContainer = new ArrayList<>();
    domains.forEach(
        domain -> {
          if (ADGDomainTypeEnum.VENDOR_ROOT.name().equals(domain.getType())) {
            if (!CollectionUtils.isEmpty(rootContainer)) {
              throw new IllegalStateException(
                  "Vendor " + vendorId + " has more than one domain root.  Should only be one.");
            }
            // otherwise ...
            rootContainer.add(domain);
          } else {
            logger.debug(domain);
            map.put(domain.getDomainId(), domain);
          }
        });

    if (root != null) {
      // a root was passed in, we need to do some validation of the root node
      if (!CollectionUtils.isEmpty(rootContainer)) {
        final Domain vendorRoot = rootContainer.get(0);
        if (!root.getDomainId().equals(vendorRoot.getDomainId())) {
          logger.error(
              "subtree root node "
                  + root.getDomainId()
                  + " contains a vendor root "
                  + vendorRoot.getDomainId()
                  + "?  This subtree is corrupt.");
          throw new IllegalStateException(
              "subtree root domain "
                  + root.getDomainId()
                  + " contains vendor root domain "
                  + vendorRoot.getDomainId());
        } else {
          logger.debug("Specified root node was the vendor root.");
        }
      }
    } else {
      if (rootContainer.isEmpty()) {
        logger.warn(
            "No vendor root domain found?  " + domains.size() + " total matching domain(s) found.");
        return null;
      }
      root = rootContainer.get(0);
    }

    // otherwise ...
    populateChildren(vendorId, root, map, new HashSet<>());
    return root;
  }

  protected void populateChildren(
      final String vendorId,
      final Domain domain,
      final Map<String, Domain> map,
      final Set<String> processed) {
    if (processed.contains(domain.getDomainId())) {
      logger.warn(domain.getDomainId() + " already processed");
      return;
    }
    processed.add(domain.getDomainId());
    if ((domain.getChildrenIds() == null) || (domain.getChildrenIds().isEmpty())) {
      return;
    }
    // otherwise ...
    domain.setChildren(new ArrayList<>());
    domain
        .getChildrenIds()
        .forEach(
            childId -> {
              if (processed.contains(childId)) {
                logger.error(childId + " already processed, cycle?");
                return;
              } else {
                Domain child = map.get(childId);
                if (child == null) {
                  logger.warn(
                      "Unable to find a matching child domain "
                          + childId
                          + " for domain "
                          + domain.getDomainId()
                          + " for vendor "
                          + vendorId);
                } else {
                  domain.getChildren().add(child);
                  populateChildren(vendorId, child, map, processed);
                }
              }
            });
  }

  /**
   * Get domain details for ownerId and domainName as an input
   *
   * @param domainMap
   * @return
   */
  public Map<String, Domain> getDomains(
      final Map<String, com.amazon.adg.common.model.Domain> domainMap) {
    final Map<String, Domain> responseMap = new HashMap<>();
    if (domainMap == null) {
      return responseMap;
    }
    domainMap.forEach(
        (key, domain) -> {
          if (domain.getOwner() == null
              || StringUtils.isBlank(domain.getOwner().getId())
              || StringUtils.isBlank(domain.getName())) {
            throw new InvalidRequestException(
                "Domain doesn't have a valid ownerId and domainName for input : " + key);
          }
          final Domain foundDomain =
              getDomainByOwnerIdAndDomainName(domain.getOwner().getId(), domain.getName());
          if (foundDomain != null && StringUtils.isNotBlank(foundDomain.getDomainId())) {
            responseMap.put(key, foundDomain);
          }
        });
    return responseMap;
  }
}



