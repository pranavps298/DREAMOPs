// VendorDao.java
package com.amazon.adg.product.dao;

import static com.amazon.adg.product.utils.LoggerUtils.getAmazonServiceExceptionMessage;
import static com.amazon.adg.product.utils.LoggerUtils.getConditionalCheckExceptionMessage;
import static com.amazon.adg.product.utils.LoggerUtils.getRetryLimitExceededMessage;
import static com.amazon.adg.product.utils.LoggerUtils.getThrottledRequestMessage;

import com.amazon.adg.common.util.LocalDateTimeUtil;
import com.amazon.adg.product.data.Vendor;
import com.amazon.adg.product.data.VendorStateEnum;
import com.amazon.adg.product.metric.MetricConstants;
import com.amazon.adg.product.service.model.InternalServiceException;
import com.amazon.adg.product.utils.MetricUtils;
import com.amazon.coral.metrics.Metrics;
import com.amazon.mas.commons.coral.support.metrics.ProfilerTimer;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.SdkClientException;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBQueryExpression;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.ComparisonOperator;
import com.amazonaws.services.dynamodbv2.model.Condition;
import com.amazonaws.services.dynamodbv2.model.ConditionalCheckFailedException;
import com.amazonaws.services.dynamodbv2.model.ProvisionedThroughputExceededException;
import com.amazonaws.services.dynamodbv2.transactions.Transaction;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;
import javax.measure.unit.Unit;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/** DAO for working with Vendor objects and DynamoDB. */
public class VendorDao extends AbstractDao {

  private static final Logger logger = LogManager.getLogger(VendorDao.class);

  public VendorDao(
      final DynamoDBMapper readDbMapper,
      final DynamoDBMapper writeDbMapper,
      final Metrics metrics) {
    super(readDbMapper, writeDbMapper, metrics);
  }

  public void create(final Vendor vendor) {
    create(vendor, null);
  }

  public void create(final Vendor vendor, final Transaction transaction) {
    if (vendor == null) {
      throw new IllegalArgumentException("vendor cannot be empty; must have name");
    }
    if (StringUtils.isEmpty(vendor.getName())) {
      throw new IllegalArgumentException("vendor name cannot be empty");
    }
    if (StringUtils.isEmpty(vendor.getVendorId())) {
      vendor.setVendorId(UUID.randomUUID().toString());
    }
    vendor.setModifiedTimestamp(LocalDateTimeUtil.nowUtc());
    vendor.setState(VendorStateEnum.ACTIVE.name());

    verifyIfParentVendorExists(vendor);
    verifyExternalVendorIdentifierValue(Vendor.MAS_VENDOR_ID, null, vendor.getMasVendorId());
    verifyExternalVendorIdentifierValue(Vendor.MAS_VENDOR_CODE, null, vendor.getMasVendorCode());

    logger.debug("Saving new " + vendor.debugString());

    final boolean isTransaction = transaction != null;

    final ProfilerTimer timer =
        new ProfilerTimer(
            metrics,
            isTransaction
                ? MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR_TRANSACTION
                : MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR,
            false);

    try {
      timer.start();

      if (isTransaction) {
        transaction.save(vendor);
      } else {
        writeDbMapper.save(vendor);
      }
    } catch (final ConditionalCheckFailedException ex) {
      logger.error(
          getConditionalCheckExceptionMessage("createVendor", "vendor", vendor.toString()));
      MetricUtils.emitConditionalCheckFailedExceptionMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR);
      throw ex;
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(getThrottledRequestMessage("createVendor", "vendor", vendor.toString()));
      MetricUtils.emitThrottledRequestMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(getAmazonServiceExceptionMessage("createVendor", "vendor", vendor.toString()));
      MetricUtils.emitAmazonServiceExceptionMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR);
      throw ex;
    } finally {
      timer.stop();
    }
  }

  /**
   * Enforces single parent vendor rule for the vendor hierarchy, only if the vendor being created
   * is a parent vendor
   *
   * @param vendor
   */
  private void verifyIfParentVendorExists(final Vendor vendor) {
    if (StringUtils.isBlank(vendor.getMasVendorCode())
        && StringUtils.isNotBlank(vendor.getMasVendorId())) {
      // the new vendor is a parent vendor
      // check if a parent entry already exists
      final Optional<Vendor> optionalVendor =
          Optional.ofNullable(getVendorByMasVendorId(vendor.getMasVendorId()));
      optionalVendor.ifPresent(
          existingVendor -> {
            // parent vendor is the one without the masVendorCode
            if (StringUtils.isBlank(existingVendor.getMasVendorCode())) {
              throw new VendorAlreadyExistsException(
                  String.format(
                      "Parent vendor %s already exists with masVendorId %s",
                      existingVendor.getVendorId(), vendor.getMasVendorId()));
            }
          });
    }
  }

  /**
   * Enforces "unique" on the secondary indexes.
   *
   * @param externalIdTypeField the identifier field name (e.g. constant from data class like
   *     "MASVendorId")
   * @param currentValue the current value
   * @param newValue the proposed new value
   */
  protected void verifyExternalVendorIdentifierValue(
      final String externalIdTypeField, final String currentValue, final String newValue) {
    verifyExternalVendorIdentifierValue(externalIdTypeField, currentValue, newValue, false);
  }

  protected void verifyExternalVendorIdentifierValue(
      final String externalIdTypeField,
      final String currentValue,
      final String newValue,
      final boolean overwriteOk) {
    if (currentValue == null && newValue == null) {
      // no value for BOTH is fine
      return;
    }

    if (!overwriteOk && !StringUtils.isEmpty(currentValue) && !currentValue.equals(newValue)) {
      throw new IllegalArgumentException(
          String.format("Cannot change %s once it has already been set.", externalIdTypeField));
    }

    if (StringUtils.isEmpty(currentValue)) {
      if (StringUtils.isBlank(newValue)) {
        throw new IllegalArgumentException(
            "Empty string is not a valid value; use null or a non-empty string.");
      }
      // setting to new valid, value, verify not present ...
      if (Vendor.MAS_VENDOR_ID.equals(externalIdTypeField)) {
        // no checks needed for uniquesness for masVendorId
        return;
      } else if (Vendor.MAS_VENDOR_CODE.equals(externalIdTypeField)) {
        final Optional<Vendor> optionalVendor =
            Optional.ofNullable(getVendorByMasVendorCode(newValue));
        optionalVendor.ifPresent(
            vendor -> {
              throw new VendorAlreadyExistsException(
                  String.format(
                      "Vendor %s already exists with masVendorCode %s",
                      vendor.getVendorId(), newValue));
            });
      } else {
        throw new IllegalArgumentException("Unrecognized MAS vendor field? " + externalIdTypeField);
      }
    }
  }

  public void update(final Vendor vendor) {
    update(vendor, null, false);
  }

  public void update(final Vendor vendor, final Transaction transaction) {
    update(vendor, transaction, false);
  }

  public void update(
      final Vendor vendor, final Transaction transaction, final boolean overwriteOk) {
    if (vendor == null) {
      throw new IllegalArgumentException("vendor cannot be empty");
    }
    if (StringUtils.isEmpty(vendor.getVendorId())) {
      throw new IllegalArgumentException("vendorId cannot be empty");
    }
    if (StringUtils.isEmpty(vendor.getName())) {
      throw new IllegalArgumentException("vendor name cannot be empty");
    }
    vendor.setModifiedTimestamp(LocalDateTimeUtil.nowUtc());

    final Vendor foundVendor = getVendor(vendor, false);
    if (foundVendor == null) {
      throw new VendorNotFoundException(
          "Unable to find matching vendor to update for vendor " + vendor.getVendorId() + ".");
    }
    logger.debug("found matching vendor: " + vendor);

    verifyExternalVendorIdentifierValue(
        Vendor.MAS_VENDOR_ID, foundVendor.getMasVendorId(), vendor.getMasVendorId(), overwriteOk);
    verifyExternalVendorIdentifierValue(
        Vendor.MAS_VENDOR_CODE,
        foundVendor.getMasVendorCode(),
        vendor.getMasVendorCode(),
        overwriteOk);

    if (!StringUtils.isEmpty(vendor.getState())) {
      // will validate and normalize the string
      vendor.setState(VendorStateEnum.valueOf(vendor.getState()).name());
    } else {
      // explicitly using the previous state
      vendor.setState(foundVendor.getState());
    }

    if (transaction != null && vendor.getVersion() == null) {
      vendor.setVersion(foundVendor.getVersion());
    }

    logger.debug("Saving updated vendor: " + vendor.debugString());

    final boolean isTransaction = transaction != null;

    final ProfilerTimer timer =
        new ProfilerTimer(
            metrics,
            isTransaction
                ? MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR_TRANSACTION
                : MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR,
            false);

    try {
      timer.start();

      if (isTransaction) {
        transaction.save(vendor);
      } else {
        writeDbMapper.save(vendor);
      }
    } catch (final ConditionalCheckFailedException ex) {
      logger.error(
          getConditionalCheckExceptionMessage("updateVendor", "vendor", vendor.toString()));
      MetricUtils.emitConditionalCheckFailedExceptionMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR);
      throw ex;
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(getThrottledRequestMessage("updateVendor", "vendor", vendor.toString()));
      MetricUtils.emitThrottledRequestMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(getAmazonServiceExceptionMessage("updateVendor", "vendor", vendor.toString()));
      MetricUtils.emitAmazonServiceExceptionMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR);
      throw ex;
    } finally {
      timer.stop();
    }
  }

  /**
   * Gets a vendor from any identifiers specified in the vendorLookupValues, validating that request
   * identifiers are consistent with the result.
   *
   * @param vendorLookupValues
   * @return
   * @throws IllegalArgumentException if the request vendor identifiers are inconsistent with the
   *     result.
   */
  public Vendor getVendor(final Vendor vendorLookupValues) {
    return getVendor(vendorLookupValues, true);
  }

  /**
   * Gets a vendor from any identifiers specified in the vendorLookupValues. When forceConsistency
   * is true, it validates that request identifiers are consistent with the result.
   *
   * @param vendorLookupValues
   * @param forceConsistency
   * @return
   * @throws IllegalArgumentException if forceConsistency is true and the request vendor identifiers
   *     are inconsistent with the result.
   */
  public Vendor getVendor(final Vendor vendorLookupValues, final boolean forceConsistency) {
    if (vendorLookupValues == null) {
      throw new IllegalArgumentException("vendor lookup values cannot be null");
    }

    final Vendor result;
    if (StringUtils.isNotBlank(vendorLookupValues.getVendorId())) {
      result = getVendorByVendorId(vendorLookupValues.getVendorId());
    } else if (StringUtils.isNotBlank(vendorLookupValues.getMasVendorCode())) {
      result = getVendorByMasVendorCode(vendorLookupValues.getMasVendorCode());
    } else if (StringUtils.isNotBlank(vendorLookupValues.getMasVendorId())) {
      result = getVendorByMasVendorId(vendorLookupValues.getMasVendorId());
    } else {
      throw new IllegalArgumentException(
          "vendor lookup values cannot be empty; one of the identifier fields needs to be populated (e.g. vendorId)");
    }

    if (forceConsistency) {
      validateVendorConsistency(vendorLookupValues, result);
    }
    return result;
  }

  /**
   * This validates that a request did not refer to multiple vendors using the different vendor
   * identifiers.
   *
   * @param vendorLookup
   * @param result
   */
  private void validateVendorConsistency(final Vendor vendorLookup, final Vendor result) {
    if (vendorLookup == null || result == null) {
      return;
    }
    validateConsistency(Vendor.VENDOR_ID, vendorLookup.getVendorId(), result.getVendorId());
    validateConsistency(
        Vendor.MAS_VENDOR_CODE, vendorLookup.getMasVendorCode(), result.getMasVendorCode());
    validateConsistency(
        Vendor.MAS_VENDOR_ID, vendorLookup.getMasVendorId(), result.getMasVendorId());
  }

  private void validateConsistency(
      final String fieldName, final String lookupValue, final String result) {
    if (StringUtils.isNotBlank(lookupValue)
        && StringUtils.isNotBlank(result)
        && !lookupValue.equals(result)) {
      throw new IllegalArgumentException(
          String.format(
              "Input %s (%s) does not match resulting %s (%s)",
              fieldName, lookupValue, fieldName, result));
    }
  }

  public Vendor getVendorByVendorId(String vendorId) {
    if (StringUtils.isEmpty(vendorId)) {
      throw new IllegalArgumentException("vendorId cannot be empty");
    }

    logger.debug("Loading vendor for vendorId " + vendorId + " ...");

    final ProfilerTimer timer =
        new ProfilerTimer(metrics, MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_VENDOR_ID, false);
    Vendor vendor;

    try {
      timer.start();
      vendor = readDbMapper.load(Vendor.class, vendorId);
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(getThrottledRequestMessage("getVendorByVendorId", "vendorId", vendorId));
      MetricUtils.emitThrottledRequestMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_VENDOR_ID);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(getAmazonServiceExceptionMessage("getVendorByVendorId", "vendorId", vendorId));
      MetricUtils.emitAmazonServiceExceptionMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_VENDOR_ID);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(getRetryLimitExceededMessage("getVendorByVendorId", "vendorId", vendorId));
      MetricUtils.emitRetryLimitExceededMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_VENDOR_ID);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }

    logger.debug("Found: " + vendor);
    return vendor;
  }

  /**
   * As multiple adg vendors will have the same masVendorId (one parent and multiple child vendors),
   * we will only return the parent adg vendor when querying with masVendorId.
   *
   * @param masVendorId
   * @return
   */
  public Vendor getVendorByMasVendorId(final String masVendorId) {
    if (StringUtils.isEmpty(masVendorId)) {
      throw new IllegalArgumentException("masVendorId cannot be empty");
    }

    logger.debug("Querying for vendor with masVendorId " + masVendorId + " ...");

    final Vendor vendorKey = new Vendor();
    vendorKey.setMasVendorId(masVendorId);

    final DynamoDBQueryExpression<Vendor> queryExpression =
        new DynamoDBQueryExpression<Vendor>()
            .withHashKeyValues(vendorKey)
            .withConsistentRead(false)
            .withIndexName(Vendor.INDEX_BY_MAS_VENDOR_ID);

    final ProfilerTimer timer =
        new ProfilerTimer(
            metrics, MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_ID, false);
    List<Vendor> vendors;

    try {
      timer.start();
      vendors = readDbMapper.query(Vendor.class, queryExpression);

    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(
          getThrottledRequestMessage("getVendorByMasVendorId", "masVendorId", masVendorId));
      MetricUtils.emitThrottledRequestMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_ID);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(
          getAmazonServiceExceptionMessage("getVendorByMasVendorId", "masVendorId", masVendorId));
      MetricUtils.emitAmazonServiceExceptionMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_ID);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(
          getRetryLimitExceededMessage("getVendorByMasVendorId", "masVendorId", masVendorId));
      MetricUtils.emitRetryLimitExceededMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_ID);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }

    logger.debug("Matches in " + queryExpression.getIndexName() + " found: " + vendors.size());
    if (vendors.size() == 1) {
      // If only one entry, then return that entry (backwards compatible)
      return getVendorByVendorId(vendors.get(0).getVendorId());
    } else if (vendors.size() > 1) {
      // Multiple entries mean one of them probably is a parent.
      // As parent adg vendor will not have a masVendorCode, we are filtering on masVendorCode
      final List<Vendor> parentVendors =
          vendors.stream()
              .filter(vendor -> StringUtils.isBlank(vendor.getMasVendorCode()))
              .collect(Collectors.toList());
      if (parentVendors.size() == 1) {
        return getVendorByVendorId(parentVendors.get(0).getVendorId());
      } else if (parentVendors.size() > 1) {
        metrics.addCount(MetricConstants.METRIC_MULTIPLE_PARENT_VENDORS_FOUND, 1, Unit.ONE);
        throw new UniqueConstraintException(
            String.format(
                "More than one match for parent masVendorId %s? Matches: %d",
                masVendorId, parentVendors.size()));
      } else {
        metrics.addCount(MetricConstants.METRIC_NO_PARENT_VENDOR_FOUND, 1, Unit.ONE);
        final Vendor newParentVendor = createParentVendor();
        final Vendor updateParentVendor = getVendor(newParentVendor);
        updateParentVendor.setMasVendorId(masVendorId);
        updateParentVendor.setVendorId(newParentVendor.getVendorId());
        updateParentVendor.setName("MASTER");
        update(updateParentVendor);
        logger.warn(
            String.format(
                "Found %d vendors with masVendorId %s and different masVendorCodes. But no parent vendor. New one was created: %s",
                vendors.size(), masVendorId, newParentVendor.getVendorId()));
        return updateParentVendor;
      }
    } else {
      return null;
    }
  }

  public Vendor getVendorByMasVendorCode(final String masVendorCode) {
    if (StringUtils.isEmpty(masVendorCode)) {
      throw new IllegalArgumentException("masVendorCode cannot be empty");
    }

    logger.debug("Querying for vendor with masVendorCode " + masVendorCode + " ...");

    final Vendor vendorKey = new Vendor();
    vendorKey.setMasVendorCode(masVendorCode);

    final DynamoDBQueryExpression<Vendor> queryExpression =
        new DynamoDBQueryExpression<Vendor>()
            .withHashKeyValues(vendorKey)
            .withConsistentRead(false)
            .withIndexName(Vendor.INDEX_BY_MAS_VENDOR_CODE);

    final ProfilerTimer timer =
        new ProfilerTimer(
            metrics, MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_CODE, false);
    List<Vendor> vendors;

    try {
      timer.start();
      vendors = readDbMapper.query(Vendor.class, queryExpression);
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(
          getThrottledRequestMessage("getVendorByMasVendorCode", "masVendorCode", masVendorCode));
      MetricUtils.emitThrottledRequestMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_CODE);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(
          getAmazonServiceExceptionMessage(
              "getVendorByMasVendorCode", "masVendorCode", masVendorCode));
      MetricUtils.emitAmazonServiceExceptionMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_CODE);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(
          getRetryLimitExceededMessage("getVendorByMasVendorCode", "masVendorCode", masVendorCode));
      MetricUtils.emitRetryLimitExceededMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_CODE);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }

    logger.debug("Matches in " + queryExpression.getIndexName() + " found: " + vendors.size());
    if (vendors.size() == 1) {
      return getVendorByVendorId(vendors.get(0).getVendorId());
    }
    if (vendors.size() > 1) {
      throw new UniqueConstraintException(
          "More than one match for masVendorId " + masVendorCode + "? Matches: " + vendors.size());
    } else {
      return null;
    }
  }

  public Vendor createParentVendor() {
    final Vendor vendor = new Vendor();
    vendor.setName("MASTER");
    create(vendor);
    return vendor;
  }

  /**
   * Update vendor if you find the id in the database, otherwise create. While updating, we do not
   * overwrite existing values, if you need to overwrite values then call update().
   *
   * @param vendor
   * @param transaction
   * @return
   */
  public Vendor createOrUpdateVendor(final Vendor vendor, final Transaction transaction) {
    final Vendor foundVendor = getVendor(vendor, false);
    if (foundVendor == null || StringUtils.isBlank(foundVendor.getVendorId())) {
      create(vendor, transaction);
    } else {
      vendor.setVendorId(foundVendor.getVendorId());
      update(vendor, transaction, false);
    }
    return getVendor(vendor, false);
  }

  public static class VendorSearchCriteria {
    private String name;

    public String getName() {
      return name;
    }

    public void setName(final String name) {
      this.name = name;
    }
  }

  public static class VendorFilter {
    private VendorStateEnum state;

    public VendorStateEnum getState() {
      return state;
    }

    public void setState(final VendorStateEnum state) {
      this.state = state;
    }
  }

  /**
   * Do NOT use lightly, as this is a full table scan.
   *
   * @param criteria
   * @param filter
   * @return
   */
  public List<Vendor> searchVendors(
      final VendorSearchCriteria criteria, final VendorFilter filter) {
    if (criteria == null) {
      throw new IllegalArgumentException("vendor search criteria cannot be null");
    }
    final String vendorName = criteria.getName();
    if (StringUtils.isEmpty(vendorName)) {
      throw new IllegalArgumentException(
          "vendor search criteria cannot be empty; one of the criteria needs to be populated (e.g. name)");
    }

    final Condition nameCondition =
        new Condition()
            .withComparisonOperator(ComparisonOperator.CONTAINS)
            .withAttributeValueList(new AttributeValue().withS(vendorName));
    final Map<String, Condition> scanFilter = new LinkedHashMap<>();
    scanFilter.put(Vendor.VENDOR_NAME, nameCondition);

    final DynamoDBScanExpression scanExpression =
        new DynamoDBScanExpression().withScanFilter(scanFilter).withConsistentRead(false);

    final ProfilerTimer timer =
        new ProfilerTimer(metrics, MetricConstants.METRIC_DYNAMO_DB_SEARCH_VENDORS, false);
    List<Vendor> vendors;

    try {
      timer.start();
      vendors = readDbMapper.scan(Vendor.class, scanExpression);
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(getThrottledRequestMessage("searchVendors", "vendorName", vendorName));
      MetricUtils.emitThrottledRequestMetric(MetricConstants.METRIC_DYNAMO_DB_SEARCH_VENDORS);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(getAmazonServiceExceptionMessage("searchVendors", "vendorName", vendorName));
      MetricUtils.emitAmazonServiceExceptionMetric(MetricConstants.METRIC_DYNAMO_DB_SEARCH_VENDORS);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(getRetryLimitExceededMessage("searchVendors", "vendorName", vendorName));
      MetricUtils.emitRetryLimitExceededMetric(MetricConstants.METRIC_DYNAMO_DB_SEARCH_VENDORS);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }

    logger.debug("Matches found: " + vendors.size());
    return vendors;
  }
}




// VendorNotFoundException.java
package com.amazon.adg.product.dao;

public class VendorNotFoundException extends PersistenceException {

  public VendorNotFoundException() {}

  public VendorNotFoundException(String message) {
    super(message);
  }

  public VendorNotFoundException(String message, Throwable cause) {
    super(message, cause);
  }

  public VendorNotFoundException(Throwable cause) {
    super(cause);
  }

  public VendorNotFoundException(
      String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
    super(message, cause, enableSuppression, writableStackTrace);
  }
}




// PersistenceException.java
package com.amazon.adg.product.dao;

/** Base class for exceptions that occur in the DAO. */
public class PersistenceException extends RuntimeException {

  public PersistenceException() {}

  public PersistenceException(String message) {
    super(message);
  }

  public PersistenceException(String message, Throwable cause) {
    super(message, cause);
  }

  public PersistenceException(Throwable cause) {
    super(cause);
  }

  public PersistenceException(
      String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
    super(message, cause, enableSuppression, writableStackTrace);
  }
}




// ADGProductContextThreadInstance.java
package com.amazon.adg.product.service.context;

import static com.amazon.adg.coral.tenant.metrics.Constants.UNKNOWN;

import com.amazon.adg.coral.model.ADGClientContext;
import com.amazon.adg.coral.tenant.metrics.ADGTenant;
import com.amazon.adg.coral.tenant.metrics.Constants;
import com.amazon.coral.service.Identity;
import coral.service.ADGClientContextThreadInstance;
import java.util.Objects;
import java.util.Optional;
import org.apache.commons.lang.StringUtils;

public final class ADGProductContextThreadInstance {

  private Identity identity = null;

  public ADGProductContextThreadInstance() {}

  private static final ThreadLocal<ADGProductContextThreadInstance> adgProductThreadInstance =
      ThreadLocal.withInitial(() -> new ADGProductContextThreadInstance());

  public static ADGProductContextThreadInstance get() {
    return adgProductThreadInstance.get();
  }

  public void setIdentity(final Identity identity) {
    this.identity = identity;
  }

  public Identity getIdentity() {
    return this.identity;
  }

  public String getADGTenant() {
    if (this.identity == null || this.identity.getAttribute(Constants.ADG_TENANT) == null) {
      return ADGTenant.UNKNOWN.toString();
    }

    return this.identity.getAttribute(Constants.ADG_TENANT);
  }

  public String getAAAClientName() {
    ADGClientContext clientContext = ADGClientContextThreadInstance.getInstance();
    if (Objects.isNull(clientContext)) {
      return UNKNOWN;
    }

    Optional<String> aaaClientNameOptional = clientContext.getAAAClientName();
    return aaaClientNameOptional.isPresent() ? aaaClientNameOptional.get() : UNKNOWN;
  }

  public String getUser() {
    if (this.identity == null
        || StringUtils.isBlank(this.identity.getAttribute(Constants.ADG_UPSTREAM_SERVICE))) {
      return Constants.UNKNOWN;
    }

    return this.identity.getAttribute(Constants.ADG_UPSTREAM_SERVICE);
  }

  public static void removeContextInstance() {
    adgProductThreadInstance.remove();
  }
}




// VendorFilter.java
package com.amazon.adg.product.dao;

import static com.amazon.adg.product.utils.LoggerUtils.getAmazonServiceExceptionMessage;
import static com.amazon.adg.product.utils.LoggerUtils.getConditionalCheckExceptionMessage;
import static com.amazon.adg.product.utils.LoggerUtils.getRetryLimitExceededMessage;
import static com.amazon.adg.product.utils.LoggerUtils.getThrottledRequestMessage;

import com.amazon.adg.common.util.LocalDateTimeUtil;
import com.amazon.adg.product.data.Vendor;
import com.amazon.adg.product.data.VendorStateEnum;
import com.amazon.adg.product.metric.MetricConstants;
import com.amazon.adg.product.service.model.InternalServiceException;
import com.amazon.adg.product.utils.MetricUtils;
import com.amazon.coral.metrics.Metrics;
import com.amazon.mas.commons.coral.support.metrics.ProfilerTimer;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.SdkClientException;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBQueryExpression;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.ComparisonOperator;
import com.amazonaws.services.dynamodbv2.model.Condition;
import com.amazonaws.services.dynamodbv2.model.ConditionalCheckFailedException;
import com.amazonaws.services.dynamodbv2.model.ProvisionedThroughputExceededException;
import com.amazonaws.services.dynamodbv2.transactions.Transaction;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;
import javax.measure.unit.Unit;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/** DAO for working with Vendor objects and DynamoDB. */
public class VendorDao extends AbstractDao {

  private static final Logger logger = LogManager.getLogger(VendorDao.class);

  public VendorDao(
      final DynamoDBMapper readDbMapper,
      final DynamoDBMapper writeDbMapper,
      final Metrics metrics) {
    super(readDbMapper, writeDbMapper, metrics);
  }

  public void create(final Vendor vendor) {
    create(vendor, null);
  }

  public void create(final Vendor vendor, final Transaction transaction) {
    if (vendor == null) {
      throw new IllegalArgumentException("vendor cannot be empty; must have name");
    }
    if (StringUtils.isEmpty(vendor.getName())) {
      throw new IllegalArgumentException("vendor name cannot be empty");
    }
    if (StringUtils.isEmpty(vendor.getVendorId())) {
      vendor.setVendorId(UUID.randomUUID().toString());
    }
    vendor.setModifiedTimestamp(LocalDateTimeUtil.nowUtc());
    vendor.setState(VendorStateEnum.ACTIVE.name());

    verifyIfParentVendorExists(vendor);
    verifyExternalVendorIdentifierValue(Vendor.MAS_VENDOR_ID, null, vendor.getMasVendorId());
    verifyExternalVendorIdentifierValue(Vendor.MAS_VENDOR_CODE, null, vendor.getMasVendorCode());

    logger.debug("Saving new " + vendor.debugString());

    final boolean isTransaction = transaction != null;

    final ProfilerTimer timer =
        new ProfilerTimer(
            metrics,
            isTransaction
                ? MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR_TRANSACTION
                : MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR,
            false);

    try {
      timer.start();

      if (isTransaction) {
        transaction.save(vendor);
      } else {
        writeDbMapper.save(vendor);
      }
    } catch (final ConditionalCheckFailedException ex) {
      logger.error(
          getConditionalCheckExceptionMessage("createVendor", "vendor", vendor.toString()));
      MetricUtils.emitConditionalCheckFailedExceptionMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR);
      throw ex;
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(getThrottledRequestMessage("createVendor", "vendor", vendor.toString()));
      MetricUtils.emitThrottledRequestMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(getAmazonServiceExceptionMessage("createVendor", "vendor", vendor.toString()));
      MetricUtils.emitAmazonServiceExceptionMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR);
      throw ex;
    } finally {
      timer.stop();
    }
  }

  /**
   * Enforces single parent vendor rule for the vendor hierarchy, only if the vendor being created
   * is a parent vendor
   *
   * @param vendor
   */
  private void verifyIfParentVendorExists(final Vendor vendor) {
    if (StringUtils.isBlank(vendor.getMasVendorCode())
        && StringUtils.isNotBlank(vendor.getMasVendorId())) {
      // the new vendor is a parent vendor
      // check if a parent entry already exists
      final Optional<Vendor> optionalVendor =
          Optional.ofNullable(getVendorByMasVendorId(vendor.getMasVendorId()));
      optionalVendor.ifPresent(
          existingVendor -> {
            // parent vendor is the one without the masVendorCode
            if (StringUtils.isBlank(existingVendor.getMasVendorCode())) {
              throw new VendorAlreadyExistsException(
                  String.format(
                      "Parent vendor %s already exists with masVendorId %s",
                      existingVendor.getVendorId(), vendor.getMasVendorId()));
            }
          });
    }
  }

  /**
   * Enforces "unique" on the secondary indexes.
   *
   * @param externalIdTypeField the identifier field name (e.g. constant from data class like
   *     "MASVendorId")
   * @param currentValue the current value
   * @param newValue the proposed new value
   */
  protected void verifyExternalVendorIdentifierValue(
      final String externalIdTypeField, final String currentValue, final String newValue) {
    verifyExternalVendorIdentifierValue(externalIdTypeField, currentValue, newValue, false);
  }

  protected void verifyExternalVendorIdentifierValue(
      final String externalIdTypeField,
      final String currentValue,
      final String newValue,
      final boolean overwriteOk) {
    if (currentValue == null && newValue == null) {
      // no value for BOTH is fine
      return;
    }

    if (!overwriteOk && !StringUtils.isEmpty(currentValue) && !currentValue.equals(newValue)) {
      throw new IllegalArgumentException(
          String.format("Cannot change %s once it has already been set.", externalIdTypeField));
    }

    if (StringUtils.isEmpty(currentValue)) {
      if (StringUtils.isBlank(newValue)) {
        throw new IllegalArgumentException(
            "Empty string is not a valid value; use null or a non-empty string.");
      }
      // setting to new valid, value, verify not present ...
      if (Vendor.MAS_VENDOR_ID.equals(externalIdTypeField)) {
        // no checks needed for uniquesness for masVendorId
        return;
      } else if (Vendor.MAS_VENDOR_CODE.equals(externalIdTypeField)) {
        final Optional<Vendor> optionalVendor =
            Optional.ofNullable(getVendorByMasVendorCode(newValue));
        optionalVendor.ifPresent(
            vendor -> {
              throw new VendorAlreadyExistsException(
                  String.format(
                      "Vendor %s already exists with masVendorCode %s",
                      vendor.getVendorId(), newValue));
            });
      } else {
        throw new IllegalArgumentException("Unrecognized MAS vendor field? " + externalIdTypeField);
      }
    }
  }

  public void update(final Vendor vendor) {
    update(vendor, null, false);
  }

  public void update(final Vendor vendor, final Transaction transaction) {
    update(vendor, transaction, false);
  }

  public void update(
      final Vendor vendor, final Transaction transaction, final boolean overwriteOk) {
    if (vendor == null) {
      throw new IllegalArgumentException("vendor cannot be empty");
    }
    if (StringUtils.isEmpty(vendor.getVendorId())) {
      throw new IllegalArgumentException("vendorId cannot be empty");
    }
    if (StringUtils.isEmpty(vendor.getName())) {
      throw new IllegalArgumentException("vendor name cannot be empty");
    }
    vendor.setModifiedTimestamp(LocalDateTimeUtil.nowUtc());

    final Vendor foundVendor = getVendor(vendor, false);
    if (foundVendor == null) {
      throw new VendorNotFoundException(
          "Unable to find matching vendor to update for vendor " + vendor.getVendorId() + ".");
    }
    logger.debug("found matching vendor: " + vendor);

    verifyExternalVendorIdentifierValue(
        Vendor.MAS_VENDOR_ID, foundVendor.getMasVendorId(), vendor.getMasVendorId(), overwriteOk);
    verifyExternalVendorIdentifierValue(
        Vendor.MAS_VENDOR_CODE,
        foundVendor.getMasVendorCode(),
        vendor.getMasVendorCode(),
        overwriteOk);

    if (!StringUtils.isEmpty(vendor.getState())) {
      // will validate and normalize the string
      vendor.setState(VendorStateEnum.valueOf(vendor.getState()).name());
    } else {
      // explicitly using the previous state
      vendor.setState(foundVendor.getState());
    }

    if (transaction != null && vendor.getVersion() == null) {
      vendor.setVersion(foundVendor.getVersion());
    }

    logger.debug("Saving updated vendor: " + vendor.debugString());

    final boolean isTransaction = transaction != null;

    final ProfilerTimer timer =
        new ProfilerTimer(
            metrics,
            isTransaction
                ? MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR_TRANSACTION
                : MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR,
            false);

    try {
      timer.start();

      if (isTransaction) {
        transaction.save(vendor);
      } else {
        writeDbMapper.save(vendor);
      }
    } catch (final ConditionalCheckFailedException ex) {
      logger.error(
          getConditionalCheckExceptionMessage("updateVendor", "vendor", vendor.toString()));
      MetricUtils.emitConditionalCheckFailedExceptionMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR);
      throw ex;
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(getThrottledRequestMessage("updateVendor", "vendor", vendor.toString()));
      MetricUtils.emitThrottledRequestMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(getAmazonServiceExceptionMessage("updateVendor", "vendor", vendor.toString()));
      MetricUtils.emitAmazonServiceExceptionMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR);
      throw ex;
    } finally {
      timer.stop();
    }
  }

  /**
   * Gets a vendor from any identifiers specified in the vendorLookupValues, validating that request
   * identifiers are consistent with the result.
   *
   * @param vendorLookupValues
   * @return
   * @throws IllegalArgumentException if the request vendor identifiers are inconsistent with the
   *     result.
   */
  public Vendor getVendor(final Vendor vendorLookupValues) {
    return getVendor(vendorLookupValues, true);
  }

  /**
   * Gets a vendor from any identifiers specified in the vendorLookupValues. When forceConsistency
   * is true, it validates that request identifiers are consistent with the result.
   *
   * @param vendorLookupValues
   * @param forceConsistency
   * @return
   * @throws IllegalArgumentException if forceConsistency is true and the request vendor identifiers
   *     are inconsistent with the result.
   */
  public Vendor getVendor(final Vendor vendorLookupValues, final boolean forceConsistency) {
    if (vendorLookupValues == null) {
      throw new IllegalArgumentException("vendor lookup values cannot be null");
    }

    final Vendor result;
    if (StringUtils.isNotBlank(vendorLookupValues.getVendorId())) {
      result = getVendorByVendorId(vendorLookupValues.getVendorId());
    } else if (StringUtils.isNotBlank(vendorLookupValues.getMasVendorCode())) {
      result = getVendorByMasVendorCode(vendorLookupValues.getMasVendorCode());
    } else if (StringUtils.isNotBlank(vendorLookupValues.getMasVendorId())) {
      result = getVendorByMasVendorId(vendorLookupValues.getMasVendorId());
    } else {
      throw new IllegalArgumentException(
          "vendor lookup values cannot be empty; one of the identifier fields needs to be populated (e.g. vendorId)");
    }

    if (forceConsistency) {
      validateVendorConsistency(vendorLookupValues, result);
    }
    return result;
  }

  /**
   * This validates that a request did not refer to multiple vendors using the different vendor
   * identifiers.
   *
   * @param vendorLookup
   * @param result
   */
  private void validateVendorConsistency(final Vendor vendorLookup, final Vendor result) {
    if (vendorLookup == null || result == null) {
      return;
    }
    validateConsistency(Vendor.VENDOR_ID, vendorLookup.getVendorId(), result.getVendorId());
    validateConsistency(
        Vendor.MAS_VENDOR_CODE, vendorLookup.getMasVendorCode(), result.getMasVendorCode());
    validateConsistency(
        Vendor.MAS_VENDOR_ID, vendorLookup.getMasVendorId(), result.getMasVendorId());
  }

  private void validateConsistency(
      final String fieldName, final String lookupValue, final String result) {
    if (StringUtils.isNotBlank(lookupValue)
        && StringUtils.isNotBlank(result)
        && !lookupValue.equals(result)) {
      throw new IllegalArgumentException(
          String.format(
              "Input %s (%s) does not match resulting %s (%s)",
              fieldName, lookupValue, fieldName, result));
    }
  }

  public Vendor getVendorByVendorId(String vendorId) {
    if (StringUtils.isEmpty(vendorId)) {
      throw new IllegalArgumentException("vendorId cannot be empty");
    }

    logger.debug("Loading vendor for vendorId " + vendorId + " ...");

    final ProfilerTimer timer =
        new ProfilerTimer(metrics, MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_VENDOR_ID, false);
    Vendor vendor;

    try {
      timer.start();
      vendor = readDbMapper.load(Vendor.class, vendorId);
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(getThrottledRequestMessage("getVendorByVendorId", "vendorId", vendorId));
      MetricUtils.emitThrottledRequestMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_VENDOR_ID);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(getAmazonServiceExceptionMessage("getVendorByVendorId", "vendorId", vendorId));
      MetricUtils.emitAmazonServiceExceptionMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_VENDOR_ID);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(getRetryLimitExceededMessage("getVendorByVendorId", "vendorId", vendorId));
      MetricUtils.emitRetryLimitExceededMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_VENDOR_ID);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }

    logger.debug("Found: " + vendor);
    return vendor;
  }

  /**
   * As multiple adg vendors will have the same masVendorId (one parent and multiple child vendors),
   * we will only return the parent adg vendor when querying with masVendorId.
   *
   * @param masVendorId
   * @return
   */
  public Vendor getVendorByMasVendorId(final String masVendorId) {
    if (StringUtils.isEmpty(masVendorId)) {
      throw new IllegalArgumentException("masVendorId cannot be empty");
    }

    logger.debug("Querying for vendor with masVendorId " + masVendorId + " ...");

    final Vendor vendorKey = new Vendor();
    vendorKey.setMasVendorId(masVendorId);

    final DynamoDBQueryExpression<Vendor> queryExpression =
        new DynamoDBQueryExpression<Vendor>()
            .withHashKeyValues(vendorKey)
            .withConsistentRead(false)
            .withIndexName(Vendor.INDEX_BY_MAS_VENDOR_ID);

    final ProfilerTimer timer =
        new ProfilerTimer(
            metrics, MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_ID, false);
    List<Vendor> vendors;

    try {
      timer.start();
      vendors = readDbMapper.query(Vendor.class, queryExpression);

    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(
          getThrottledRequestMessage("getVendorByMasVendorId", "masVendorId", masVendorId));
      MetricUtils.emitThrottledRequestMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_ID);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(
          getAmazonServiceExceptionMessage("getVendorByMasVendorId", "masVendorId", masVendorId));
      MetricUtils.emitAmazonServiceExceptionMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_ID);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(
          getRetryLimitExceededMessage("getVendorByMasVendorId", "masVendorId", masVendorId));
      MetricUtils.emitRetryLimitExceededMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_ID);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }

    logger.debug("Matches in " + queryExpression.getIndexName() + " found: " + vendors.size());
    if (vendors.size() == 1) {
      // If only one entry, then return that entry (backwards compatible)
      return getVendorByVendorId(vendors.get(0).getVendorId());
    } else if (vendors.size() > 1) {
      // Multiple entries mean one of them probably is a parent.
      // As parent adg vendor will not have a masVendorCode, we are filtering on masVendorCode
      final List<Vendor> parentVendors =
          vendors.stream()
              .filter(vendor -> StringUtils.isBlank(vendor.getMasVendorCode()))
              .collect(Collectors.toList());
      if (parentVendors.size() == 1) {
        return getVendorByVendorId(parentVendors.get(0).getVendorId());
      } else if (parentVendors.size() > 1) {
        metrics.addCount(MetricConstants.METRIC_MULTIPLE_PARENT_VENDORS_FOUND, 1, Unit.ONE);
        throw new UniqueConstraintException(
            String.format(
                "More than one match for parent masVendorId %s? Matches: %d",
                masVendorId, parentVendors.size()));
      } else {
        metrics.addCount(MetricConstants.METRIC_NO_PARENT_VENDOR_FOUND, 1, Unit.ONE);
        final Vendor newParentVendor = createParentVendor();
        final Vendor updateParentVendor = getVendor(newParentVendor);
        updateParentVendor.setMasVendorId(masVendorId);
        updateParentVendor.setVendorId(newParentVendor.getVendorId());
        updateParentVendor.setName("MASTER");
        update(updateParentVendor);
        logger.warn(
            String.format(
                "Found %d vendors with masVendorId %s and different masVendorCodes. But no parent vendor. New one was created: %s",
                vendors.size(), masVendorId, newParentVendor.getVendorId()));
        return updateParentVendor;
      }
    } else {
      return null;
    }
  }

  public Vendor getVendorByMasVendorCode(final String masVendorCode) {
    if (StringUtils.isEmpty(masVendorCode)) {
      throw new IllegalArgumentException("masVendorCode cannot be empty");
    }

    logger.debug("Querying for vendor with masVendorCode " + masVendorCode + " ...");

    final Vendor vendorKey = new Vendor();
    vendorKey.setMasVendorCode(masVendorCode);

    final DynamoDBQueryExpression<Vendor> queryExpression =
        new DynamoDBQueryExpression<Vendor>()
            .withHashKeyValues(vendorKey)
            .withConsistentRead(false)
            .withIndexName(Vendor.INDEX_BY_MAS_VENDOR_CODE);

    final ProfilerTimer timer =
        new ProfilerTimer(
            metrics, MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_CODE, false);
    List<Vendor> vendors;

    try {
      timer.start();
      vendors = readDbMapper.query(Vendor.class, queryExpression);
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(
          getThrottledRequestMessage("getVendorByMasVendorCode", "masVendorCode", masVendorCode));
      MetricUtils.emitThrottledRequestMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_CODE);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(
          getAmazonServiceExceptionMessage(
              "getVendorByMasVendorCode", "masVendorCode", masVendorCode));
      MetricUtils.emitAmazonServiceExceptionMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_CODE);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(
          getRetryLimitExceededMessage("getVendorByMasVendorCode", "masVendorCode", masVendorCode));
      MetricUtils.emitRetryLimitExceededMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_CODE);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }

    logger.debug("Matches in " + queryExpression.getIndexName() + " found: " + vendors.size());
    if (vendors.size() == 1) {
      return getVendorByVendorId(vendors.get(0).getVendorId());
    }
    if (vendors.size() > 1) {
      throw new UniqueConstraintException(
          "More than one match for masVendorId " + masVendorCode + "? Matches: " + vendors.size());
    } else {
      return null;
    }
  }

  public Vendor createParentVendor() {
    final Vendor vendor = new Vendor();
    vendor.setName("MASTER");
    create(vendor);
    return vendor;
  }

  /**
   * Update vendor if you find the id in the database, otherwise create. While updating, we do not
   * overwrite existing values, if you need to overwrite values then call update().
   *
   * @param vendor
   * @param transaction
   * @return
   */
  public Vendor createOrUpdateVendor(final Vendor vendor, final Transaction transaction) {
    final Vendor foundVendor = getVendor(vendor, false);
    if (foundVendor == null || StringUtils.isBlank(foundVendor.getVendorId())) {
      create(vendor, transaction);
    } else {
      vendor.setVendorId(foundVendor.getVendorId());
      update(vendor, transaction, false);
    }
    return getVendor(vendor, false);
  }

  public static class VendorSearchCriteria {
    private String name;

    public String getName() {
      return name;
    }

    public void setName(final String name) {
      this.name = name;
    }
  }

  public static class VendorFilter {
    private VendorStateEnum state;

    public VendorStateEnum getState() {
      return state;
    }

    public void setState(final VendorStateEnum state) {
      this.state = state;
    }
  }

  /**
   * Do NOT use lightly, as this is a full table scan.
   *
   * @param criteria
   * @param filter
   * @return
   */
  public List<Vendor> searchVendors(
      final VendorSearchCriteria criteria, final VendorFilter filter) {
    if (criteria == null) {
      throw new IllegalArgumentException("vendor search criteria cannot be null");
    }
    final String vendorName = criteria.getName();
    if (StringUtils.isEmpty(vendorName)) {
      throw new IllegalArgumentException(
          "vendor search criteria cannot be empty; one of the criteria needs to be populated (e.g. name)");
    }

    final Condition nameCondition =
        new Condition()
            .withComparisonOperator(ComparisonOperator.CONTAINS)
            .withAttributeValueList(new AttributeValue().withS(vendorName));
    final Map<String, Condition> scanFilter = new LinkedHashMap<>();
    scanFilter.put(Vendor.VENDOR_NAME, nameCondition);

    final DynamoDBScanExpression scanExpression =
        new DynamoDBScanExpression().withScanFilter(scanFilter).withConsistentRead(false);

    final ProfilerTimer timer =
        new ProfilerTimer(metrics, MetricConstants.METRIC_DYNAMO_DB_SEARCH_VENDORS, false);
    List<Vendor> vendors;

    try {
      timer.start();
      vendors = readDbMapper.scan(Vendor.class, scanExpression);
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(getThrottledRequestMessage("searchVendors", "vendorName", vendorName));
      MetricUtils.emitThrottledRequestMetric(MetricConstants.METRIC_DYNAMO_DB_SEARCH_VENDORS);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(getAmazonServiceExceptionMessage("searchVendors", "vendorName", vendorName));
      MetricUtils.emitAmazonServiceExceptionMetric(MetricConstants.METRIC_DYNAMO_DB_SEARCH_VENDORS);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(getRetryLimitExceededMessage("searchVendors", "vendorName", vendorName));
      MetricUtils.emitRetryLimitExceededMetric(MetricConstants.METRIC_DYNAMO_DB_SEARCH_VENDORS);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }

    logger.debug("Matches found: " + vendors.size());
    return vendors;
  }
}




// AbstractActivity.java
package com.amazon.adg.product.service.activity;

import com.amazon.adg.product.dao.UniqueConstraintException;
import com.amazon.adg.product.metric.MetricConstants;
import com.amazon.adg.product.service.context.ADGProductContextThreadInstance;
import com.amazon.adg.product.service.model.DependencyException;
import com.amazon.adg.product.service.model.InternalServiceException;
import com.amazon.adg.product.service.model.InvalidRequestException;
import com.amazon.adg.product.service.model.VendorDoesNotExistException;
import com.amazon.coral.service.Activity;
import com.amazonaws.AmazonServiceException;
import com.google.common.base.Joiner;
import javax.measure.unit.SI;
import javax.measure.unit.Unit;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public abstract class AbstractActivity<T_Request, T_Response> extends Activity {
  private static final Logger logger = LogManager.getLogger(AbstractActivity.class);

  protected T_Response execute(final T_Request request) {
    final long startTime = startAndValidateRequest(request);
    boolean isSuccess = false;
    try {
      final T_Response response = invoke(request);
      stopAndValidateResponse(request, response, startTime);
      isSuccess = true;
      return response;
    } catch (final InvalidRequestException
        | IllegalArgumentException
        | IllegalStateException
        | UniqueConstraintException e) {
      logger.error(String.format("Bad request: %s", e.getMessage()), e);
      getMetrics()
          .addCount(
              getCompoundMetricName(
                  MetricConstants.METRIC_INVALID_REQUEST_EXCEPTION, "ReceivedBadRequest"),
              1,
              Unit.ONE);
      throw new InvalidRequestException(e.getMessage(), e);
    } catch (final AmazonServiceException e) {
      logger.error(String.format("Exception while retrieving: %s", e.getMessage()), e);
      getMetrics().addCount(MetricConstants.METRIC_DEPENDENCY_EXCEPTION, 1, Unit.ONE);
      throw new DependencyException("Problem loading from dynamo: " + e.getMessage(), e);
    } catch (final VendorDoesNotExistException e) {
      logger.error(String.format("Exception while retrieving: %s", e.getMessage()), e);
      throw new VendorDoesNotExistException("Vendor does not exist: " + e.getMessage(), e);
    } catch (final Throwable e) {
      logger.error(String.format("Exception while retrieving: %s", e.getMessage()), e);
      getMetrics().addCount(MetricConstants.METRIC_ANY_GENERIC_EXCEPTION, 1, Unit.ONE);
      throw new InternalServiceException("Received unknown exception", e);
    } finally {
      getMetrics().addCount(MetricConstants.METRIC_TOTAL_REQUESTS, (isSuccess) ? 1 : 0, Unit.ONE);
    }
  }

  private long startAndValidateRequest(final T_Request request) {
    final ADGProductContextThreadInstance contextThreadInstance =
        ADGProductContextThreadInstance.get();
    contextThreadInstance.setIdentity(this.getIdentity());

    validateRequest(request);
    final long start = System.currentTimeMillis();
    return start;
  }

  private void stopAndValidateResponse(
      final T_Request request, final T_Response response, final long startTime) {
    if (response == null) {
      logger.error("Returning null response");
      throw new InternalServiceException("Returning null response");
    }
    final long totalTime = System.currentTimeMillis() - startTime;
    validateResponse(request, response, totalTime);

    getMetrics()
        .addTime(MetricConstants.METRIC_RESPONSE_SUCCESS_TIME, totalTime, SI.MILLI(SI.SECOND));
  }

  public static String getCompoundMetricName(final String... components) {
    return Joiner.on(":").skipNulls().join(components);
  }

  /**
   * Simply invokes the API. All exceptions and logging will be handled.
   *
   * @param request
   * @return
   * @throws Exception
   */
  protected abstract T_Response invoke(final T_Request request) throws Exception;

  /**
   * Validates the request. Should throw InvalidRequestException if not valid.
   *
   * @param request
   */
  protected abstract void validateRequest(final T_Request request);

  /**
   * Validates the response. Should throw InternalServiceException if something is wrong or
   * unexpected.
   *
   * @param response
   * @param totalTime
   * @throws InternalServiceException
   */
  protected abstract void validateResponse(
      final T_Request request, final T_Response response, final long totalTime);
}




// VendorAlreadyExistsException.java
package com.amazon.adg.product.dao;

public class VendorAlreadyExistsException extends PersistenceException {

  public VendorAlreadyExistsException() {}

  public VendorAlreadyExistsException(String message) {
    super(message);
  }

  public VendorAlreadyExistsException(String message, Throwable cause) {
    super(message, cause);
  }

  public VendorAlreadyExistsException(Throwable cause) {
    super(cause);
  }

  public VendorAlreadyExistsException(
      String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
    super(message, cause, enableSuppression, writableStackTrace);
  }
}




// GetVendorActivity.java
package com.amazon.adg.product.service.activity;

import com.amazon.adg.common.model.Vendor;
import com.amazon.adg.product.dao.VendorDao;
import com.amazon.adg.product.metric.LogConfig;
import com.amazon.adg.product.service.model.GetVendorRequest;
import com.amazon.adg.product.service.model.GetVendorResponse;
import com.amazon.adg.product.service.model.InvalidRequestException;
import com.amazon.adg.product.service.model.VendorDoesNotExistException;
import com.amazon.adg.product.service.model.VendorModelUtil;
import com.amazon.coral.annotation.Operation;
import com.amazon.coral.annotation.Service;
import com.amazon.coral.support.metrics.UseActivityMetricsForThread;
import com.amazon.mas.commons.coral.support.interceptor.MASDependentServiceInterceptor;
import com.amazon.mas.commons.coral.support.interceptor.MASInterceptorConfiguration;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Service("ADGProductService")
public class GetVendorActivity extends AbstractActivity<GetVendorRequest, GetVendorResponse> {

  private static final Logger logger = LogManager.getLogger(GetVendorActivity.class);

  private VendorDao vendorDao;

  public VendorDao getVendorDao() {
    return vendorDao;
  }

  public void setVendorDao(VendorDao vendorDao) {
    this.vendorDao = vendorDao;
  }

  @Operation("getVendor")
  @UseActivityMetricsForThread
  @MASDependentServiceInterceptor
  @MASInterceptorConfiguration(
      samplingRate = LogConfig.EXTERNAL_SAMPLE_RATE,
      internalAccountSamplingRate = LogConfig.INTERNAL_SAMPLE_RATE)
  public GetVendorResponse getVendor(final GetVendorRequest request) {
    return execute(request);
  }

  @Override
  protected GetVendorResponse invoke(final GetVendorRequest request) {
    final Vendor input = request.getVendor();
    com.amazon.adg.product.data.Vendor found =
        vendorDao.getVendor(VendorModelUtil.getDataObjectFromModel(input));
    final GetVendorResponse response = new GetVendorResponse();

    response.setVendor(VendorModelUtil.getModelObjectFromData(found));
    return response;
  }

  @Override
  protected void validateRequest(final GetVendorRequest request) {
    if (request == null) {
      logger.error("Received null request");
      throw new InvalidRequestException("Received null request");
    }
    final Vendor vendor = request.getVendor();
    if (vendor == null) {
      logger.error("Received null vendor");
      throw new InvalidRequestException("Received null vendor");
    }
  }

  @Override
  protected void validateResponse(
      final GetVendorRequest request, final GetVendorResponse response, final long totalTime) {
    if (response == null) {
      logger.error("Returning null response");
      throw new VendorDoesNotExistException("Returning null vendor");
    }
  }
}




// UniqueConstraintException.java
package com.amazon.adg.product.dao;

public class UniqueConstraintException extends PersistenceException {

  public UniqueConstraintException() {}

  public UniqueConstraintException(String message) {
    super(message);
  }

  public UniqueConstraintException(String message, Throwable cause) {
    super(message, cause);
  }

  public UniqueConstraintException(Throwable cause) {
    super(cause);
  }

  public UniqueConstraintException(
      String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
    super(message, cause, enableSuppression, writableStackTrace);
  }
}




// Vendor.java
package com.amazon.adg.product.data;

import com.amazon.adg.common.dynamodb.marshaller.ScopeLocalDateTimeMarshaller;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBIndexHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMarshalling;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBVersionAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.encryption.DoNotEncrypt;
import com.amazonaws.services.dynamodbv2.datamodeling.encryption.DoNotTouch;
import java.time.LocalDateTime;

@DynamoDBTable(tableName = "ADGVendor")
@DoNotTouch
public class Vendor {
  public static final String TABLE_NAME = "ADGVendor";

  public static final String VENDOR_ID = "VendorId";
  public static final String VENDOR_NAME = "VendorName";
  public static final String MAS_VENDOR_ID = "MASVendorId";
  public static final String MAS_VENDOR_CODE = "MASVendorCode";
  public static final String STATE = "State";
  public static final String VERSION = "Version";
  public static final String MODIFIED_TIMESTAMP = "ModifiedTimestamp";

  public static final String INDEX_BY_MAS_VENDOR_ID = "ADGVendorByMASVendorId-index";
  public static final String INDEX_BY_MAS_VENDOR_CODE = "ADGVendorByMASVendorCode-index";
  public static final String STORE_ID = "storeId";
  public static final String SERVICE_PROVIDER = "serviceProvider";
  public static final String SERVICE_PROVIDER_VENDOR_ID = "serviceProviderVendorId";

  private String vendorId;
  private String masVendorId;
  private String masVendorCode;
  private String name;
  private String state;
  private LocalDateTime modifiedTimestamp;
  private Long version;
  private String storeId;
  private String serviceProvider;
  private String serviceProviderVendorId;

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = VENDOR_ID)
  @DynamoDBHashKey(attributeName = VENDOR_ID)
  public String getVendorId() {
    return vendorId;
  }

  public void setVendorId(String vendorId) {
    this.vendorId = vendorId;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = STORE_ID)
  public String getStoreId() {
    return storeId;
  }

  public void setStoreId(String storeId) {
    this.storeId = storeId;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = SERVICE_PROVIDER)
  public String getServiceProvider() {
    return serviceProvider;
  }

  public void setServiceProvider(String serviceProvider) {
    this.serviceProvider = serviceProvider;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = SERVICE_PROVIDER_VENDOR_ID)
  public String getServiceProviderVendorId() {
    return serviceProviderVendorId;
  }

  public void setServiceProviderVendorId(String serviceProviderVendorId) {
    this.serviceProviderVendorId = serviceProviderVendorId;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = MAS_VENDOR_ID)
  @DynamoDBIndexHashKey(
      attributeName = MAS_VENDOR_ID,
      globalSecondaryIndexName = INDEX_BY_MAS_VENDOR_ID)
  public String getMasVendorId() {
    return masVendorId;
  }

  public void setMasVendorId(String masVendorId) {
    this.masVendorId = masVendorId;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = MAS_VENDOR_CODE)
  @DynamoDBIndexHashKey(
      attributeName = MAS_VENDOR_CODE,
      globalSecondaryIndexName = INDEX_BY_MAS_VENDOR_CODE)
  public String getMasVendorCode() {
    return masVendorCode;
  }

  public void setMasVendorCode(String masVendorCode) {
    this.masVendorCode = masVendorCode;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = VENDOR_NAME)
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = STATE)
  public String getState() {
    return state;
  }

  public void setState(String state) {
    this.state = state;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = MODIFIED_TIMESTAMP)
  @DynamoDBMarshalling(marshallerClass = ScopeLocalDateTimeMarshaller.class)
  public LocalDateTime getModifiedTimestamp() {
    return modifiedTimestamp;
  }

  public void setModifiedTimestamp(LocalDateTime modifiedTimestamp) {
    this.modifiedTimestamp = modifiedTimestamp;
  }

  /**
   * Version optimistic locking.
   *
   * @return Long version
   */
  @DoNotEncrypt
  @DynamoDBVersionAttribute(attributeName = VERSION)
  public Long getVersion() {
    return version;
  }

  public void setVersion(Long version) {
    this.version = version;
  }

  public String debugString() {
    StringBuilder str = new StringBuilder(vendorId).append(" (v").append(version).append(")");
    return str.toString();
  }

  @Override
  public String toString() {
    final StringBuilder str = new StringBuilder("Vendor{");
    str.append("vendorId='");
    str.append(vendorId);
    str.append("',masVendorId='");
    str.append(masVendorId);
    str.append("',masVendorCode='");
    str.append(masVendorCode);
    str.append("'}");
    return str.toString();
  }
}




// VendorSearchCriteria.java
package com.amazon.adg.product.dao;

import static com.amazon.adg.product.utils.LoggerUtils.getAmazonServiceExceptionMessage;
import static com.amazon.adg.product.utils.LoggerUtils.getConditionalCheckExceptionMessage;
import static com.amazon.adg.product.utils.LoggerUtils.getRetryLimitExceededMessage;
import static com.amazon.adg.product.utils.LoggerUtils.getThrottledRequestMessage;

import com.amazon.adg.common.util.LocalDateTimeUtil;
import com.amazon.adg.product.data.Vendor;
import com.amazon.adg.product.data.VendorStateEnum;
import com.amazon.adg.product.metric.MetricConstants;
import com.amazon.adg.product.service.model.InternalServiceException;
import com.amazon.adg.product.utils.MetricUtils;
import com.amazon.coral.metrics.Metrics;
import com.amazon.mas.commons.coral.support.metrics.ProfilerTimer;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.SdkClientException;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBQueryExpression;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.ComparisonOperator;
import com.amazonaws.services.dynamodbv2.model.Condition;
import com.amazonaws.services.dynamodbv2.model.ConditionalCheckFailedException;
import com.amazonaws.services.dynamodbv2.model.ProvisionedThroughputExceededException;
import com.amazonaws.services.dynamodbv2.transactions.Transaction;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;
import javax.measure.unit.Unit;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/** DAO for working with Vendor objects and DynamoDB. */
public class VendorDao extends AbstractDao {

  private static final Logger logger = LogManager.getLogger(VendorDao.class);

  public VendorDao(
      final DynamoDBMapper readDbMapper,
      final DynamoDBMapper writeDbMapper,
      final Metrics metrics) {
    super(readDbMapper, writeDbMapper, metrics);
  }

  public void create(final Vendor vendor) {
    create(vendor, null);
  }

  public void create(final Vendor vendor, final Transaction transaction) {
    if (vendor == null) {
      throw new IllegalArgumentException("vendor cannot be empty; must have name");
    }
    if (StringUtils.isEmpty(vendor.getName())) {
      throw new IllegalArgumentException("vendor name cannot be empty");
    }
    if (StringUtils.isEmpty(vendor.getVendorId())) {
      vendor.setVendorId(UUID.randomUUID().toString());
    }
    vendor.setModifiedTimestamp(LocalDateTimeUtil.nowUtc());
    vendor.setState(VendorStateEnum.ACTIVE.name());

    verifyIfParentVendorExists(vendor);
    verifyExternalVendorIdentifierValue(Vendor.MAS_VENDOR_ID, null, vendor.getMasVendorId());
    verifyExternalVendorIdentifierValue(Vendor.MAS_VENDOR_CODE, null, vendor.getMasVendorCode());

    logger.debug("Saving new " + vendor.debugString());

    final boolean isTransaction = transaction != null;

    final ProfilerTimer timer =
        new ProfilerTimer(
            metrics,
            isTransaction
                ? MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR_TRANSACTION
                : MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR,
            false);

    try {
      timer.start();

      if (isTransaction) {
        transaction.save(vendor);
      } else {
        writeDbMapper.save(vendor);
      }
    } catch (final ConditionalCheckFailedException ex) {
      logger.error(
          getConditionalCheckExceptionMessage("createVendor", "vendor", vendor.toString()));
      MetricUtils.emitConditionalCheckFailedExceptionMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR);
      throw ex;
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(getThrottledRequestMessage("createVendor", "vendor", vendor.toString()));
      MetricUtils.emitThrottledRequestMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(getAmazonServiceExceptionMessage("createVendor", "vendor", vendor.toString()));
      MetricUtils.emitAmazonServiceExceptionMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR);
      throw ex;
    } finally {
      timer.stop();
    }
  }

  /**
   * Enforces single parent vendor rule for the vendor hierarchy, only if the vendor being created
   * is a parent vendor
   *
   * @param vendor
   */
  private void verifyIfParentVendorExists(final Vendor vendor) {
    if (StringUtils.isBlank(vendor.getMasVendorCode())
        && StringUtils.isNotBlank(vendor.getMasVendorId())) {
      // the new vendor is a parent vendor
      // check if a parent entry already exists
      final Optional<Vendor> optionalVendor =
          Optional.ofNullable(getVendorByMasVendorId(vendor.getMasVendorId()));
      optionalVendor.ifPresent(
          existingVendor -> {
            // parent vendor is the one without the masVendorCode
            if (StringUtils.isBlank(existingVendor.getMasVendorCode())) {
              throw new VendorAlreadyExistsException(
                  String.format(
                      "Parent vendor %s already exists with masVendorId %s",
                      existingVendor.getVendorId(), vendor.getMasVendorId()));
            }
          });
    }
  }

  /**
   * Enforces "unique" on the secondary indexes.
   *
   * @param externalIdTypeField the identifier field name (e.g. constant from data class like
   *     "MASVendorId")
   * @param currentValue the current value
   * @param newValue the proposed new value
   */
  protected void verifyExternalVendorIdentifierValue(
      final String externalIdTypeField, final String currentValue, final String newValue) {
    verifyExternalVendorIdentifierValue(externalIdTypeField, currentValue, newValue, false);
  }

  protected void verifyExternalVendorIdentifierValue(
      final String externalIdTypeField,
      final String currentValue,
      final String newValue,
      final boolean overwriteOk) {
    if (currentValue == null && newValue == null) {
      // no value for BOTH is fine
      return;
    }

    if (!overwriteOk && !StringUtils.isEmpty(currentValue) && !currentValue.equals(newValue)) {
      throw new IllegalArgumentException(
          String.format("Cannot change %s once it has already been set.", externalIdTypeField));
    }

    if (StringUtils.isEmpty(currentValue)) {
      if (StringUtils.isBlank(newValue)) {
        throw new IllegalArgumentException(
            "Empty string is not a valid value; use null or a non-empty string.");
      }
      // setting to new valid, value, verify not present ...
      if (Vendor.MAS_VENDOR_ID.equals(externalIdTypeField)) {
        // no checks needed for uniquesness for masVendorId
        return;
      } else if (Vendor.MAS_VENDOR_CODE.equals(externalIdTypeField)) {
        final Optional<Vendor> optionalVendor =
            Optional.ofNullable(getVendorByMasVendorCode(newValue));
        optionalVendor.ifPresent(
            vendor -> {
              throw new VendorAlreadyExistsException(
                  String.format(
                      "Vendor %s already exists with masVendorCode %s",
                      vendor.getVendorId(), newValue));
            });
      } else {
        throw new IllegalArgumentException("Unrecognized MAS vendor field? " + externalIdTypeField);
      }
    }
  }

  public void update(final Vendor vendor) {
    update(vendor, null, false);
  }

  public void update(final Vendor vendor, final Transaction transaction) {
    update(vendor, transaction, false);
  }

  public void update(
      final Vendor vendor, final Transaction transaction, final boolean overwriteOk) {
    if (vendor == null) {
      throw new IllegalArgumentException("vendor cannot be empty");
    }
    if (StringUtils.isEmpty(vendor.getVendorId())) {
      throw new IllegalArgumentException("vendorId cannot be empty");
    }
    if (StringUtils.isEmpty(vendor.getName())) {
      throw new IllegalArgumentException("vendor name cannot be empty");
    }
    vendor.setModifiedTimestamp(LocalDateTimeUtil.nowUtc());

    final Vendor foundVendor = getVendor(vendor, false);
    if (foundVendor == null) {
      throw new VendorNotFoundException(
          "Unable to find matching vendor to update for vendor " + vendor.getVendorId() + ".");
    }
    logger.debug("found matching vendor: " + vendor);

    verifyExternalVendorIdentifierValue(
        Vendor.MAS_VENDOR_ID, foundVendor.getMasVendorId(), vendor.getMasVendorId(), overwriteOk);
    verifyExternalVendorIdentifierValue(
        Vendor.MAS_VENDOR_CODE,
        foundVendor.getMasVendorCode(),
        vendor.getMasVendorCode(),
        overwriteOk);

    if (!StringUtils.isEmpty(vendor.getState())) {
      // will validate and normalize the string
      vendor.setState(VendorStateEnum.valueOf(vendor.getState()).name());
    } else {
      // explicitly using the previous state
      vendor.setState(foundVendor.getState());
    }

    if (transaction != null && vendor.getVersion() == null) {
      vendor.setVersion(foundVendor.getVersion());
    }

    logger.debug("Saving updated vendor: " + vendor.debugString());

    final boolean isTransaction = transaction != null;

    final ProfilerTimer timer =
        new ProfilerTimer(
            metrics,
            isTransaction
                ? MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR_TRANSACTION
                : MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR,
            false);

    try {
      timer.start();

      if (isTransaction) {
        transaction.save(vendor);
      } else {
        writeDbMapper.save(vendor);
      }
    } catch (final ConditionalCheckFailedException ex) {
      logger.error(
          getConditionalCheckExceptionMessage("updateVendor", "vendor", vendor.toString()));
      MetricUtils.emitConditionalCheckFailedExceptionMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR);
      throw ex;
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(getThrottledRequestMessage("updateVendor", "vendor", vendor.toString()));
      MetricUtils.emitThrottledRequestMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(getAmazonServiceExceptionMessage("updateVendor", "vendor", vendor.toString()));
      MetricUtils.emitAmazonServiceExceptionMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR);
      throw ex;
    } finally {
      timer.stop();
    }
  }

  /**
   * Gets a vendor from any identifiers specified in the vendorLookupValues, validating that request
   * identifiers are consistent with the result.
   *
   * @param vendorLookupValues
   * @return
   * @throws IllegalArgumentException if the request vendor identifiers are inconsistent with the
   *     result.
   */
  public Vendor getVendor(final Vendor vendorLookupValues) {
    return getVendor(vendorLookupValues, true);
  }

  /**
   * Gets a vendor from any identifiers specified in the vendorLookupValues. When forceConsistency
   * is true, it validates that request identifiers are consistent with the result.
   *
   * @param vendorLookupValues
   * @param forceConsistency
   * @return
   * @throws IllegalArgumentException if forceConsistency is true and the request vendor identifiers
   *     are inconsistent with the result.
   */
  public Vendor getVendor(final Vendor vendorLookupValues, final boolean forceConsistency) {
    if (vendorLookupValues == null) {
      throw new IllegalArgumentException("vendor lookup values cannot be null");
    }

    final Vendor result;
    if (StringUtils.isNotBlank(vendorLookupValues.getVendorId())) {
      result = getVendorByVendorId(vendorLookupValues.getVendorId());
    } else if (StringUtils.isNotBlank(vendorLookupValues.getMasVendorCode())) {
      result = getVendorByMasVendorCode(vendorLookupValues.getMasVendorCode());
    } else if (StringUtils.isNotBlank(vendorLookupValues.getMasVendorId())) {
      result = getVendorByMasVendorId(vendorLookupValues.getMasVendorId());
    } else {
      throw new IllegalArgumentException(
          "vendor lookup values cannot be empty; one of the identifier fields needs to be populated (e.g. vendorId)");
    }

    if (forceConsistency) {
      validateVendorConsistency(vendorLookupValues, result);
    }
    return result;
  }

  /**
   * This validates that a request did not refer to multiple vendors using the different vendor
   * identifiers.
   *
   * @param vendorLookup
   * @param result
   */
  private void validateVendorConsistency(final Vendor vendorLookup, final Vendor result) {
    if (vendorLookup == null || result == null) {
      return;
    }
    validateConsistency(Vendor.VENDOR_ID, vendorLookup.getVendorId(), result.getVendorId());
    validateConsistency(
        Vendor.MAS_VENDOR_CODE, vendorLookup.getMasVendorCode(), result.getMasVendorCode());
    validateConsistency(
        Vendor.MAS_VENDOR_ID, vendorLookup.getMasVendorId(), result.getMasVendorId());
  }

  private void validateConsistency(
      final String fieldName, final String lookupValue, final String result) {
    if (StringUtils.isNotBlank(lookupValue)
        && StringUtils.isNotBlank(result)
        && !lookupValue.equals(result)) {
      throw new IllegalArgumentException(
          String.format(
              "Input %s (%s) does not match resulting %s (%s)",
              fieldName, lookupValue, fieldName, result));
    }
  }

  public Vendor getVendorByVendorId(String vendorId) {
    if (StringUtils.isEmpty(vendorId)) {
      throw new IllegalArgumentException("vendorId cannot be empty");
    }

    logger.debug("Loading vendor for vendorId " + vendorId + " ...");

    final ProfilerTimer timer =
        new ProfilerTimer(metrics, MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_VENDOR_ID, false);
    Vendor vendor;

    try {
      timer.start();
      vendor = readDbMapper.load(Vendor.class, vendorId);
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(getThrottledRequestMessage("getVendorByVendorId", "vendorId", vendorId));
      MetricUtils.emitThrottledRequestMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_VENDOR_ID);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(getAmazonServiceExceptionMessage("getVendorByVendorId", "vendorId", vendorId));
      MetricUtils.emitAmazonServiceExceptionMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_VENDOR_ID);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(getRetryLimitExceededMessage("getVendorByVendorId", "vendorId", vendorId));
      MetricUtils.emitRetryLimitExceededMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_VENDOR_ID);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }

    logger.debug("Found: " + vendor);
    return vendor;
  }

  /**
   * As multiple adg vendors will have the same masVendorId (one parent and multiple child vendors),
   * we will only return the parent adg vendor when querying with masVendorId.
   *
   * @param masVendorId
   * @return
   */
  public Vendor getVendorByMasVendorId(final String masVendorId) {
    if (StringUtils.isEmpty(masVendorId)) {
      throw new IllegalArgumentException("masVendorId cannot be empty");
    }

    logger.debug("Querying for vendor with masVendorId " + masVendorId + " ...");

    final Vendor vendorKey = new Vendor();
    vendorKey.setMasVendorId(masVendorId);

    final DynamoDBQueryExpression<Vendor> queryExpression =
        new DynamoDBQueryExpression<Vendor>()
            .withHashKeyValues(vendorKey)
            .withConsistentRead(false)
            .withIndexName(Vendor.INDEX_BY_MAS_VENDOR_ID);

    final ProfilerTimer timer =
        new ProfilerTimer(
            metrics, MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_ID, false);
    List<Vendor> vendors;

    try {
      timer.start();
      vendors = readDbMapper.query(Vendor.class, queryExpression);

    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(
          getThrottledRequestMessage("getVendorByMasVendorId", "masVendorId", masVendorId));
      MetricUtils.emitThrottledRequestMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_ID);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(
          getAmazonServiceExceptionMessage("getVendorByMasVendorId", "masVendorId", masVendorId));
      MetricUtils.emitAmazonServiceExceptionMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_ID);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(
          getRetryLimitExceededMessage("getVendorByMasVendorId", "masVendorId", masVendorId));
      MetricUtils.emitRetryLimitExceededMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_ID);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }

    logger.debug("Matches in " + queryExpression.getIndexName() + " found: " + vendors.size());
    if (vendors.size() == 1) {
      // If only one entry, then return that entry (backwards compatible)
      return getVendorByVendorId(vendors.get(0).getVendorId());
    } else if (vendors.size() > 1) {
      // Multiple entries mean one of them probably is a parent.
      // As parent adg vendor will not have a masVendorCode, we are filtering on masVendorCode
      final List<Vendor> parentVendors =
          vendors.stream()
              .filter(vendor -> StringUtils.isBlank(vendor.getMasVendorCode()))
              .collect(Collectors.toList());
      if (parentVendors.size() == 1) {
        return getVendorByVendorId(parentVendors.get(0).getVendorId());
      } else if (parentVendors.size() > 1) {
        metrics.addCount(MetricConstants.METRIC_MULTIPLE_PARENT_VENDORS_FOUND, 1, Unit.ONE);
        throw new UniqueConstraintException(
            String.format(
                "More than one match for parent masVendorId %s? Matches: %d",
                masVendorId, parentVendors.size()));
      } else {
        metrics.addCount(MetricConstants.METRIC_NO_PARENT_VENDOR_FOUND, 1, Unit.ONE);
        final Vendor newParentVendor = createParentVendor();
        final Vendor updateParentVendor = getVendor(newParentVendor);
        updateParentVendor.setMasVendorId(masVendorId);
        updateParentVendor.setVendorId(newParentVendor.getVendorId());
        updateParentVendor.setName("MASTER");
        update(updateParentVendor);
        logger.warn(
            String.format(
                "Found %d vendors with masVendorId %s and different masVendorCodes. But no parent vendor. New one was created: %s",
                vendors.size(), masVendorId, newParentVendor.getVendorId()));
        return updateParentVendor;
      }
    } else {
      return null;
    }
  }

  public Vendor getVendorByMasVendorCode(final String masVendorCode) {
    if (StringUtils.isEmpty(masVendorCode)) {
      throw new IllegalArgumentException("masVendorCode cannot be empty");
    }

    logger.debug("Querying for vendor with masVendorCode " + masVendorCode + " ...");

    final Vendor vendorKey = new Vendor();
    vendorKey.setMasVendorCode(masVendorCode);

    final DynamoDBQueryExpression<Vendor> queryExpression =
        new DynamoDBQueryExpression<Vendor>()
            .withHashKeyValues(vendorKey)
            .withConsistentRead(false)
            .withIndexName(Vendor.INDEX_BY_MAS_VENDOR_CODE);

    final ProfilerTimer timer =
        new ProfilerTimer(
            metrics, MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_CODE, false);
    List<Vendor> vendors;

    try {
      timer.start();
      vendors = readDbMapper.query(Vendor.class, queryExpression);
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(
          getThrottledRequestMessage("getVendorByMasVendorCode", "masVendorCode", masVendorCode));
      MetricUtils.emitThrottledRequestMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_CODE);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(
          getAmazonServiceExceptionMessage(
              "getVendorByMasVendorCode", "masVendorCode", masVendorCode));
      MetricUtils.emitAmazonServiceExceptionMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_CODE);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(
          getRetryLimitExceededMessage("getVendorByMasVendorCode", "masVendorCode", masVendorCode));
      MetricUtils.emitRetryLimitExceededMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_CODE);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }

    logger.debug("Matches in " + queryExpression.getIndexName() + " found: " + vendors.size());
    if (vendors.size() == 1) {
      return getVendorByVendorId(vendors.get(0).getVendorId());
    }
    if (vendors.size() > 1) {
      throw new UniqueConstraintException(
          "More than one match for masVendorId " + masVendorCode + "? Matches: " + vendors.size());
    } else {
      return null;
    }
  }

  public Vendor createParentVendor() {
    final Vendor vendor = new Vendor();
    vendor.setName("MASTER");
    create(vendor);
    return vendor;
  }

  /**
   * Update vendor if you find the id in the database, otherwise create. While updating, we do not
   * overwrite existing values, if you need to overwrite values then call update().
   *
   * @param vendor
   * @param transaction
   * @return
   */
  public Vendor createOrUpdateVendor(final Vendor vendor, final Transaction transaction) {
    final Vendor foundVendor = getVendor(vendor, false);
    if (foundVendor == null || StringUtils.isBlank(foundVendor.getVendorId())) {
      create(vendor, transaction);
    } else {
      vendor.setVendorId(foundVendor.getVendorId());
      update(vendor, transaction, false);
    }
    return getVendor(vendor, false);
  }

  public static class VendorSearchCriteria {
    private String name;

    public String getName() {
      return name;
    }

    public void setName(final String name) {
      this.name = name;
    }
  }

  public static class VendorFilter {
    private VendorStateEnum state;

    public VendorStateEnum getState() {
      return state;
    }

    public void setState(final VendorStateEnum state) {
      this.state = state;
    }
  }

  /**
   * Do NOT use lightly, as this is a full table scan.
   *
   * @param criteria
   * @param filter
   * @return
   */
  public List<Vendor> searchVendors(
      final VendorSearchCriteria criteria, final VendorFilter filter) {
    if (criteria == null) {
      throw new IllegalArgumentException("vendor search criteria cannot be null");
    }
    final String vendorName = criteria.getName();
    if (StringUtils.isEmpty(vendorName)) {
      throw new IllegalArgumentException(
          "vendor search criteria cannot be empty; one of the criteria needs to be populated (e.g. name)");
    }

    final Condition nameCondition =
        new Condition()
            .withComparisonOperator(ComparisonOperator.CONTAINS)
            .withAttributeValueList(new AttributeValue().withS(vendorName));
    final Map<String, Condition> scanFilter = new LinkedHashMap<>();
    scanFilter.put(Vendor.VENDOR_NAME, nameCondition);

    final DynamoDBScanExpression scanExpression =
        new DynamoDBScanExpression().withScanFilter(scanFilter).withConsistentRead(false);

    final ProfilerTimer timer =
        new ProfilerTimer(metrics, MetricConstants.METRIC_DYNAMO_DB_SEARCH_VENDORS, false);
    List<Vendor> vendors;

    try {
      timer.start();
      vendors = readDbMapper.scan(Vendor.class, scanExpression);
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(getThrottledRequestMessage("searchVendors", "vendorName", vendorName));
      MetricUtils.emitThrottledRequestMetric(MetricConstants.METRIC_DYNAMO_DB_SEARCH_VENDORS);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(getAmazonServiceExceptionMessage("searchVendors", "vendorName", vendorName));
      MetricUtils.emitAmazonServiceExceptionMetric(MetricConstants.METRIC_DYNAMO_DB_SEARCH_VENDORS);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(getRetryLimitExceededMessage("searchVendors", "vendorName", vendorName));
      MetricUtils.emitRetryLimitExceededMetric(MetricConstants.METRIC_DYNAMO_DB_SEARCH_VENDORS);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }

    logger.debug("Matches found: " + vendors.size());
    return vendors;
  }
}




// AbstractDao.java
package com.amazon.adg.product.dao;

import com.amazon.coral.metrics.Metrics;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;

public abstract class AbstractDao {

  protected DynamoDBMapper readDbMapper;
  protected DynamoDBMapper writeDbMapper;
  protected Metrics metrics;

  public AbstractDao(
      final DynamoDBMapper readDbMapper,
      final DynamoDBMapper writeDbMapper,
      final Metrics metrics) {
    this.readDbMapper = readDbMapper;
    this.writeDbMapper = writeDbMapper;
    this.metrics = metrics;
  }

  public void setReadDbMapper(final DynamoDBMapper readDbMapper) {
    this.readDbMapper = readDbMapper;
  }

  public DynamoDBMapper getReadDbMapper() {
    return readDbMapper;
  }

  public void setWriteDbMapper(final DynamoDBMapper writeDbMapper) {
    this.writeDbMapper = writeDbMapper;
  }

  public DynamoDBMapper getWriteDbMapper() {
    return writeDbMapper;
  }
}



