// ProductNotFoundException.java
package com.amazon.adg.product.dao;

public class ProductNotFoundException extends PersistenceException {

  public ProductNotFoundException() {}

  public ProductNotFoundException(String message) {
    super(message);
  }

  public ProductNotFoundException(String message, Throwable cause) {
    super(message, cause);
  }

  public ProductNotFoundException(Throwable cause) {
    super(cause);
  }

  public ProductNotFoundException(
      String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
    super(message, cause, enableSuppression, writableStackTrace);
  }
}




// DynamoCursorPager.java
package com.amazon.adg.product.cursor.paging;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBQueryExpression;
import com.amazonaws.services.dynamodbv2.datamodeling.PaginatedQueryList;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * A class used to paginate over results returned by Dynamo using a cursor based approach.
 *
 * @param <T> Type of the record to be returned
 */
public class DynamoCursorPager<T> {

  /** Our logger. */
  private static final Logger logger = LogManager.getLogger(DynamoCursorPager.class);

  private final Class<T> type;
  private final DynamoDBMapper readDbMapper;

  /**
   * @param type type the type of records to be returned by queries
   * @param readDbMapper the DynamoDBMapper to use when running queries.
   */
  public DynamoCursorPager(final Class<T> type, final DynamoDBMapper readDbMapper) {
    this.type = type;
    this.readDbMapper = readDbMapper;
  }
  /**
   * Queries for a page of data based on the queryExpression and pagination parameters. In order to
   * efficiently paginate, the queryExpression will be built using the "LastEvaluatedKey" of the
   * provided pagination parameters. If pagination parameters are not passed in we will query for
   * all results.
   *
   * <p>Note, Loading all results at once can be very expensive depending on the size of your data
   * set.
   *
   * @param queryExpression A DynamoDB Query
   * @param dynamoPagingQueryParameters the pagination parameters. If null we will retrieve all
   *     results.
   * @return a PagedResponse which will contain the lastEvaluatedResult from which you can build a
   *     "LastEvaluatedKey" for subsequent calls.
   */
  public PagedResponse retrievePage(
      final DynamoDBQueryExpression<T> queryExpression,
      final DynamoPagingQueryParameters dynamoPagingQueryParameters) {

    // a pointer to the last processed record.
    T lastEvaluatedResult = null;
    final List<T> resultList = new ArrayList<>();
    final PagedResponse<T> pagedResponse = new PagedResponse<T>();

    int itemCount = 0;

    if (dynamoPagingQueryParameters != null) {
      queryExpression.setExclusiveStartKey(dynamoPagingQueryParameters.getLastEvaluatedEntry());
      if (queryExpression.getLimit() == null) {
        queryExpression.setLimit(dynamoPagingQueryParameters.getPageSize());
      }
    }

    final PaginatedQueryList<T> results = readDbMapper.query(type, queryExpression);

    // Note: PaginatedQueryList.size() loads all query results under the hood, which is why its an
    // expensive operation.
    final int pageSize =
        dynamoPagingQueryParameters != null
            ? dynamoPagingQueryParameters.getPageSize()
            : results.size();
    // iterate over the results until we have filled up the page
    // or we have no more results
    final Iterator<T> it = results.iterator();
    while (it.hasNext() && itemCount < pageSize) {
      final T result = it.next();
      resultList.add(result);
      itemCount++;
      lastEvaluatedResult = result;
    }

    // We do not have more results, we set lastEvaluatedResult to indicate that
    // there are no more pages to query for.
    if (!it.hasNext()) {
      lastEvaluatedResult = null;
    }

    pagedResponse.setLastEvaluatedResult(lastEvaluatedResult);
    pagedResponse.setPageSize(itemCount);
    pagedResponse.setPagedResults(resultList);

    return pagedResponse;
  }
}




// Product.java
package com.amazon.adg.product.data;

import com.amazon.adg.common.dynamodb.marshaller.ScopeLocalDateTimeMarshaller;
import com.amazon.adg.common.product.ADGProductTypeEnum;
import com.amazon.adg.common.product.ProductLineEnum;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBIgnore;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBIndexHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBIndexRangeKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMarshalling;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBVersionAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.encryption.DoNotEncrypt;
import com.amazonaws.services.dynamodbv2.datamodeling.encryption.DoNotTouch;
import java.time.LocalDateTime;

@DynamoDBTable(tableName = "ADGProduct")
@DoNotTouch
public class Product {

  public static final String TABLE_NAME = "ADGProduct";

  public static final String PRODUCT_ID = "ProductId";
  public static final String VENDOR_ID = "VendorId";
  public static final String VENDOR_SKU = "VendorSku";
  public static final String ASIN = "ASIN";
  public static final String PRIMARY_DOMAIN_ID = "PrimaryDomainId";
  public static final String PRODUCT_TYPE = "ProductType";
  public static final String PRODUCT_LINE = "ProductLine";
  public static final String PRODUCT_TITLE = "ProductTitle";
  public static final String PRODUCT_DESCRIPTION = "ProductDescription";
  public static final String STATE = "State";
  public static final String PRODUCT_DETAILS = "ProductDetails";
  public static final String EXTERNAL_PRODUCT_ID = "ExternalProductId";
  public static final String PUBLISHED_REVISION_ID = "PublishedRevisionId";
  public static final String VERSION = "Version";
  public static final String MODIFIED_TIMESTAMP = "ModifiedTimestamp";

  public static final String INDEX_BY_ASIN = "ADGProductByASIN-index";
  public static final String INDEX_BY_VENDOR_ID_SKU = "ADGProductByVendorIdVendorSku-index";
  public static final String INDEX_BY_VENDOR_ID_PRODUCT_ID = "ADGProductByVendorIdProductId-index";
  public static final String INDEX_BY_PRIMARY_DOMAIN_ID = "ADGProductByPrimaryDomainId-index";
  public static final String INDEX_BY_VENDOR_ID_EXTERNAL_PRODUCT_ID =
      "ADGProductByVendorIdExternalProductId-index";

  private String productId;
  private String vendorId;
  private String vendorSku;
  private String asin;
  private String primaryDomainId;
  private String productType;
  private String productLine;
  private String title;
  private String description;
  private String state;
  private String productDetails;
  private String externalProductId;
  private String publishedRevisionId;
  private Long version;
  private LocalDateTime modifiedTimestamp;

  public Product() {}

  public Product(String productId) {
    this.productId = productId;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = PRODUCT_ID)
  @DynamoDBHashKey(attributeName = PRODUCT_ID)
  @DynamoDBIndexRangeKey(
      attributeName = VENDOR_SKU,
      globalSecondaryIndexNames = {INDEX_BY_VENDOR_ID_PRODUCT_ID, INDEX_BY_PRIMARY_DOMAIN_ID})
  public String getProductId() {
    return productId;
  }

  public void setProductId(String productId) {
    this.productId = productId;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = VENDOR_ID)
  @DynamoDBIndexHashKey(
      attributeName = VENDOR_ID,
      globalSecondaryIndexNames = {
        INDEX_BY_VENDOR_ID_SKU,
        INDEX_BY_VENDOR_ID_PRODUCT_ID,
        INDEX_BY_VENDOR_ID_EXTERNAL_PRODUCT_ID
      })
  public String getVendorId() {
    return vendorId;
  }

  public void setVendorId(String vendorId) {
    this.vendorId = vendorId;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = VENDOR_SKU)
  @DynamoDBIndexRangeKey(
      attributeName = VENDOR_SKU,
      globalSecondaryIndexName = INDEX_BY_VENDOR_ID_SKU)
  public String getVendorSku() {
    return vendorSku;
  }

  public void setVendorSku(String vendorSku) {
    this.vendorSku = vendorSku;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = ASIN)
  @DynamoDBIndexHashKey(attributeName = ASIN, globalSecondaryIndexName = INDEX_BY_ASIN)
  public String getAsin() {
    return asin;
  }

  public void setAsin(String asin) {
    this.asin = asin;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = PRIMARY_DOMAIN_ID)
  @DynamoDBIndexHashKey(
      attributeName = PRIMARY_DOMAIN_ID,
      globalSecondaryIndexNames = {INDEX_BY_PRIMARY_DOMAIN_ID})
  public String getPrimaryDomainId() {
    return primaryDomainId;
  }

  public void setPrimaryDomainId(String primaryDomainId) {
    this.primaryDomainId = primaryDomainId;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = PRODUCT_TYPE)
  public String getProductType() {
    return productType;
  }

  public void setProductType(String productType) {
    this.productType = productType;
  }

  public void setProductType(ADGProductTypeEnum productType) {
    this.productType = productType.toString();
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = PRODUCT_LINE)
  public String getProductLine() {
    return productLine;
  }

  public void setProductLine(String productLine) {
    this.productLine = productLine;
  }

  public void setProductLine(ProductLineEnum productLine) {
    this.productLine = productLine.toString();
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = PRODUCT_TITLE)
  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = PRODUCT_DESCRIPTION)
  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = MODIFIED_TIMESTAMP)
  @DynamoDBMarshalling(marshallerClass = ScopeLocalDateTimeMarshaller.class)
  public LocalDateTime getModifiedTimestamp() {
    return modifiedTimestamp;
  }

  public void setModifiedTimestamp(LocalDateTime modifiedTimestamp) {
    this.modifiedTimestamp = modifiedTimestamp;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = PRODUCT_DETAILS)
  public String getProductDetails() {
    return productDetails;
  }

  public void setProductDetails(final String productDetails) {
    this.productDetails = productDetails;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = STATE)
  public String getState() {
    return state;
  }

  public void setState(String state) {
    this.state = state;
  }

  public void setState(ProductStateEnum state) {
    this.state = state.name();
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = EXTERNAL_PRODUCT_ID)
  @DynamoDBIndexRangeKey(
      attributeName = EXTERNAL_PRODUCT_ID,
      globalSecondaryIndexName = INDEX_BY_VENDOR_ID_EXTERNAL_PRODUCT_ID)
  public String getExternalProductId() {
    return externalProductId;
  }

  public void setExternalProductId(final String externalProductId) {
    this.externalProductId = externalProductId;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = PUBLISHED_REVISION_ID)
  public String getPublishedRevisionId() {
    return publishedRevisionId;
  }

  public void setPublishedRevisionId(final String publishedRevisionId) {
    this.publishedRevisionId = publishedRevisionId;
  }

  @DynamoDBIgnore
  public boolean isLive() {
    if (ProductStateEnum.LIVE.name().equals(state)) {
      return true;
    }

    // othwerwise ...
    return false;
  }

  /**
   * Version optimistic locking.
   *
   * @return Long version
   */
  @DoNotEncrypt
  @DynamoDBVersionAttribute(attributeName = VERSION)
  public Long getVersion() {
    return version;
  }

  public void setVersion(Long version) {
    this.version = version;
  }

  public String debugString() {
    StringBuilder str =
        new StringBuilder()
            .append(productId)
            .append(" - ")
            .append(vendorId)
            .append(":")
            .append(vendorSku)
            .append("/")
            .append(asin)
            .append(" (v")
            .append(version)
            .append(")");
    return str.toString();
  }

  @Override
  public String toString() {
    final StringBuilder str = new StringBuilder("Product{");
    str.append("productId='");
    str.append(productId);
    str.append("',asin='");
    str.append(asin);
    str.append("',vendorId='");
    str.append(vendorId);
    str.append("',sku='");
    str.append(vendorSku);
    str.append("',domainId='");
    str.append(primaryDomainId);
    str.append("',externalProductId='");
    str.append(externalProductId);
    str.append("',publishedRevisionId='");
    str.append(publishedRevisionId);
    str.append("'}");
    return str.toString();
  }
}




// ADGProductContextThreadInstance.java
package com.amazon.adg.product.service.context;

import static com.amazon.adg.coral.tenant.metrics.Constants.UNKNOWN;

import com.amazon.adg.coral.model.ADGClientContext;
import com.amazon.adg.coral.tenant.metrics.ADGTenant;
import com.amazon.adg.coral.tenant.metrics.Constants;
import com.amazon.coral.service.Identity;
import coral.service.ADGClientContextThreadInstance;
import java.util.Objects;
import java.util.Optional;
import org.apache.commons.lang.StringUtils;

public final class ADGProductContextThreadInstance {

  private Identity identity = null;

  public ADGProductContextThreadInstance() {}

  private static final ThreadLocal<ADGProductContextThreadInstance> adgProductThreadInstance =
      ThreadLocal.withInitial(() -> new ADGProductContextThreadInstance());

  public static ADGProductContextThreadInstance get() {
    return adgProductThreadInstance.get();
  }

  public void setIdentity(final Identity identity) {
    this.identity = identity;
  }

  public Identity getIdentity() {
    return this.identity;
  }

  public String getADGTenant() {
    if (this.identity == null || this.identity.getAttribute(Constants.ADG_TENANT) == null) {
      return ADGTenant.UNKNOWN.toString();
    }

    return this.identity.getAttribute(Constants.ADG_TENANT);
  }

  public String getAAAClientName() {
    ADGClientContext clientContext = ADGClientContextThreadInstance.getInstance();
    if (Objects.isNull(clientContext)) {
      return UNKNOWN;
    }

    Optional<String> aaaClientNameOptional = clientContext.getAAAClientName();
    return aaaClientNameOptional.isPresent() ? aaaClientNameOptional.get() : UNKNOWN;
  }

  public String getUser() {
    if (this.identity == null
        || StringUtils.isBlank(this.identity.getAttribute(Constants.ADG_UPSTREAM_SERVICE))) {
      return Constants.UNKNOWN;
    }

    return this.identity.getAttribute(Constants.ADG_UPSTREAM_SERVICE);
  }

  public static void removeContextInstance() {
    adgProductThreadInstance.remove();
  }
}




// AbstractActivity.java
package com.amazon.adg.product.service.activity;

import com.amazon.adg.product.dao.UniqueConstraintException;
import com.amazon.adg.product.metric.MetricConstants;
import com.amazon.adg.product.service.context.ADGProductContextThreadInstance;
import com.amazon.adg.product.service.model.DependencyException;
import com.amazon.adg.product.service.model.InternalServiceException;
import com.amazon.adg.product.service.model.InvalidRequestException;
import com.amazon.adg.product.service.model.VendorDoesNotExistException;
import com.amazon.coral.service.Activity;
import com.amazonaws.AmazonServiceException;
import com.google.common.base.Joiner;
import javax.measure.unit.SI;
import javax.measure.unit.Unit;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public abstract class AbstractActivity<T_Request, T_Response> extends Activity {
  private static final Logger logger = LogManager.getLogger(AbstractActivity.class);

  protected T_Response execute(final T_Request request) {
    final long startTime = startAndValidateRequest(request);
    boolean isSuccess = false;
    try {
      final T_Response response = invoke(request);
      stopAndValidateResponse(request, response, startTime);
      isSuccess = true;
      return response;
    } catch (final InvalidRequestException
        | IllegalArgumentException
        | IllegalStateException
        | UniqueConstraintException e) {
      logger.error(String.format("Bad request: %s", e.getMessage()), e);
      getMetrics()
          .addCount(
              getCompoundMetricName(
                  MetricConstants.METRIC_INVALID_REQUEST_EXCEPTION, "ReceivedBadRequest"),
              1,
              Unit.ONE);
      throw new InvalidRequestException(e.getMessage(), e);
    } catch (final AmazonServiceException e) {
      logger.error(String.format("Exception while retrieving: %s", e.getMessage()), e);
      getMetrics().addCount(MetricConstants.METRIC_DEPENDENCY_EXCEPTION, 1, Unit.ONE);
      throw new DependencyException("Problem loading from dynamo: " + e.getMessage(), e);
    } catch (final VendorDoesNotExistException e) {
      logger.error(String.format("Exception while retrieving: %s", e.getMessage()), e);
      throw new VendorDoesNotExistException("Vendor does not exist: " + e.getMessage(), e);
    } catch (final Throwable e) {
      logger.error(String.format("Exception while retrieving: %s", e.getMessage()), e);
      getMetrics().addCount(MetricConstants.METRIC_ANY_GENERIC_EXCEPTION, 1, Unit.ONE);
      throw new InternalServiceException("Received unknown exception", e);
    } finally {
      getMetrics().addCount(MetricConstants.METRIC_TOTAL_REQUESTS, (isSuccess) ? 1 : 0, Unit.ONE);
    }
  }

  private long startAndValidateRequest(final T_Request request) {
    final ADGProductContextThreadInstance contextThreadInstance =
        ADGProductContextThreadInstance.get();
    contextThreadInstance.setIdentity(this.getIdentity());

    validateRequest(request);
    final long start = System.currentTimeMillis();
    return start;
  }

  private void stopAndValidateResponse(
      final T_Request request, final T_Response response, final long startTime) {
    if (response == null) {
      logger.error("Returning null response");
      throw new InternalServiceException("Returning null response");
    }
    final long totalTime = System.currentTimeMillis() - startTime;
    validateResponse(request, response, totalTime);

    getMetrics()
        .addTime(MetricConstants.METRIC_RESPONSE_SUCCESS_TIME, totalTime, SI.MILLI(SI.SECOND));
  }

  public static String getCompoundMetricName(final String... components) {
    return Joiner.on(":").skipNulls().join(components);
  }

  /**
   * Simply invokes the API. All exceptions and logging will be handled.
   *
   * @param request
   * @return
   * @throws Exception
   */
  protected abstract T_Response invoke(final T_Request request) throws Exception;

  /**
   * Validates the request. Should throw InvalidRequestException if not valid.
   *
   * @param request
   */
  protected abstract void validateRequest(final T_Request request);

  /**
   * Validates the response. Should throw InternalServiceException if something is wrong or
   * unexpected.
   *
   * @param response
   * @param totalTime
   * @throws InternalServiceException
   */
  protected abstract void validateResponse(
      final T_Request request, final T_Response response, final long totalTime);
}




// VendorAlreadyExistsException.java
package com.amazon.adg.product.dao;

public class VendorAlreadyExistsException extends PersistenceException {

  public VendorAlreadyExistsException() {}

  public VendorAlreadyExistsException(String message) {
    super(message);
  }

  public VendorAlreadyExistsException(String message, Throwable cause) {
    super(message, cause);
  }

  public VendorAlreadyExistsException(Throwable cause) {
    super(cause);
  }

  public VendorAlreadyExistsException(
      String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
    super(message, cause, enableSuppression, writableStackTrace);
  }
}




// VendorSearchCriteria.java
package com.amazon.adg.product.dao;

import static com.amazon.adg.product.utils.LoggerUtils.getAmazonServiceExceptionMessage;
import static com.amazon.adg.product.utils.LoggerUtils.getConditionalCheckExceptionMessage;
import static com.amazon.adg.product.utils.LoggerUtils.getRetryLimitExceededMessage;
import static com.amazon.adg.product.utils.LoggerUtils.getThrottledRequestMessage;

import com.amazon.adg.common.util.LocalDateTimeUtil;
import com.amazon.adg.product.data.Vendor;
import com.amazon.adg.product.data.VendorStateEnum;
import com.amazon.adg.product.metric.MetricConstants;
import com.amazon.adg.product.service.model.InternalServiceException;
import com.amazon.adg.product.utils.MetricUtils;
import com.amazon.coral.metrics.Metrics;
import com.amazon.mas.commons.coral.support.metrics.ProfilerTimer;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.SdkClientException;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBQueryExpression;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.ComparisonOperator;
import com.amazonaws.services.dynamodbv2.model.Condition;
import com.amazonaws.services.dynamodbv2.model.ConditionalCheckFailedException;
import com.amazonaws.services.dynamodbv2.model.ProvisionedThroughputExceededException;
import com.amazonaws.services.dynamodbv2.transactions.Transaction;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;
import javax.measure.unit.Unit;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/** DAO for working with Vendor objects and DynamoDB. */
public class VendorDao extends AbstractDao {

  private static final Logger logger = LogManager.getLogger(VendorDao.class);

  public VendorDao(
      final DynamoDBMapper readDbMapper,
      final DynamoDBMapper writeDbMapper,
      final Metrics metrics) {
    super(readDbMapper, writeDbMapper, metrics);
  }

  public void create(final Vendor vendor) {
    create(vendor, null);
  }

  public void create(final Vendor vendor, final Transaction transaction) {
    if (vendor == null) {
      throw new IllegalArgumentException("vendor cannot be empty; must have name");
    }
    if (StringUtils.isEmpty(vendor.getName())) {
      throw new IllegalArgumentException("vendor name cannot be empty");
    }
    if (StringUtils.isEmpty(vendor.getVendorId())) {
      vendor.setVendorId(UUID.randomUUID().toString());
    }
    vendor.setModifiedTimestamp(LocalDateTimeUtil.nowUtc());
    vendor.setState(VendorStateEnum.ACTIVE.name());

    verifyIfParentVendorExists(vendor);
    verifyExternalVendorIdentifierValue(Vendor.MAS_VENDOR_ID, null, vendor.getMasVendorId());
    verifyExternalVendorIdentifierValue(Vendor.MAS_VENDOR_CODE, null, vendor.getMasVendorCode());

    logger.debug("Saving new " + vendor.debugString());

    final boolean isTransaction = transaction != null;

    final ProfilerTimer timer =
        new ProfilerTimer(
            metrics,
            isTransaction
                ? MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR_TRANSACTION
                : MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR,
            false);

    try {
      timer.start();

      if (isTransaction) {
        transaction.save(vendor);
      } else {
        writeDbMapper.save(vendor);
      }
    } catch (final ConditionalCheckFailedException ex) {
      logger.error(
          getConditionalCheckExceptionMessage("createVendor", "vendor", vendor.toString()));
      MetricUtils.emitConditionalCheckFailedExceptionMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR);
      throw ex;
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(getThrottledRequestMessage("createVendor", "vendor", vendor.toString()));
      MetricUtils.emitThrottledRequestMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(getAmazonServiceExceptionMessage("createVendor", "vendor", vendor.toString()));
      MetricUtils.emitAmazonServiceExceptionMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR);
      throw ex;
    } finally {
      timer.stop();
    }
  }

  /**
   * Enforces single parent vendor rule for the vendor hierarchy, only if the vendor being created
   * is a parent vendor
   *
   * @param vendor
   */
  private void verifyIfParentVendorExists(final Vendor vendor) {
    if (StringUtils.isBlank(vendor.getMasVendorCode())
        && StringUtils.isNotBlank(vendor.getMasVendorId())) {
      // the new vendor is a parent vendor
      // check if a parent entry already exists
      final Optional<Vendor> optionalVendor =
          Optional.ofNullable(getVendorByMasVendorId(vendor.getMasVendorId()));
      optionalVendor.ifPresent(
          existingVendor -> {
            // parent vendor is the one without the masVendorCode
            if (StringUtils.isBlank(existingVendor.getMasVendorCode())) {
              throw new VendorAlreadyExistsException(
                  String.format(
                      "Parent vendor %s already exists with masVendorId %s",
                      existingVendor.getVendorId(), vendor.getMasVendorId()));
            }
          });
    }
  }

  /**
   * Enforces "unique" on the secondary indexes.
   *
   * @param externalIdTypeField the identifier field name (e.g. constant from data class like
   *     "MASVendorId")
   * @param currentValue the current value
   * @param newValue the proposed new value
   */
  protected void verifyExternalVendorIdentifierValue(
      final String externalIdTypeField, final String currentValue, final String newValue) {
    verifyExternalVendorIdentifierValue(externalIdTypeField, currentValue, newValue, false);
  }

  protected void verifyExternalVendorIdentifierValue(
      final String externalIdTypeField,
      final String currentValue,
      final String newValue,
      final boolean overwriteOk) {
    if (currentValue == null && newValue == null) {
      // no value for BOTH is fine
      return;
    }

    if (!overwriteOk && !StringUtils.isEmpty(currentValue) && !currentValue.equals(newValue)) {
      throw new IllegalArgumentException(
          String.format("Cannot change %s once it has already been set.", externalIdTypeField));
    }

    if (StringUtils.isEmpty(currentValue)) {
      if (StringUtils.isBlank(newValue)) {
        throw new IllegalArgumentException(
            "Empty string is not a valid value; use null or a non-empty string.");
      }
      // setting to new valid, value, verify not present ...
      if (Vendor.MAS_VENDOR_ID.equals(externalIdTypeField)) {
        // no checks needed for uniquesness for masVendorId
        return;
      } else if (Vendor.MAS_VENDOR_CODE.equals(externalIdTypeField)) {
        final Optional<Vendor> optionalVendor =
            Optional.ofNullable(getVendorByMasVendorCode(newValue));
        optionalVendor.ifPresent(
            vendor -> {
              throw new VendorAlreadyExistsException(
                  String.format(
                      "Vendor %s already exists with masVendorCode %s",
                      vendor.getVendorId(), newValue));
            });
      } else {
        throw new IllegalArgumentException("Unrecognized MAS vendor field? " + externalIdTypeField);
      }
    }
  }

  public void update(final Vendor vendor) {
    update(vendor, null, false);
  }

  public void update(final Vendor vendor, final Transaction transaction) {
    update(vendor, transaction, false);
  }

  public void update(
      final Vendor vendor, final Transaction transaction, final boolean overwriteOk) {
    if (vendor == null) {
      throw new IllegalArgumentException("vendor cannot be empty");
    }
    if (StringUtils.isEmpty(vendor.getVendorId())) {
      throw new IllegalArgumentException("vendorId cannot be empty");
    }
    if (StringUtils.isEmpty(vendor.getName())) {
      throw new IllegalArgumentException("vendor name cannot be empty");
    }
    vendor.setModifiedTimestamp(LocalDateTimeUtil.nowUtc());

    final Vendor foundVendor = getVendor(vendor, false);
    if (foundVendor == null) {
      throw new VendorNotFoundException(
          "Unable to find matching vendor to update for vendor " + vendor.getVendorId() + ".");
    }
    logger.debug("found matching vendor: " + vendor);

    verifyExternalVendorIdentifierValue(
        Vendor.MAS_VENDOR_ID, foundVendor.getMasVendorId(), vendor.getMasVendorId(), overwriteOk);
    verifyExternalVendorIdentifierValue(
        Vendor.MAS_VENDOR_CODE,
        foundVendor.getMasVendorCode(),
        vendor.getMasVendorCode(),
        overwriteOk);

    if (!StringUtils.isEmpty(vendor.getState())) {
      // will validate and normalize the string
      vendor.setState(VendorStateEnum.valueOf(vendor.getState()).name());
    } else {
      // explicitly using the previous state
      vendor.setState(foundVendor.getState());
    }

    if (transaction != null && vendor.getVersion() == null) {
      vendor.setVersion(foundVendor.getVersion());
    }

    logger.debug("Saving updated vendor: " + vendor.debugString());

    final boolean isTransaction = transaction != null;

    final ProfilerTimer timer =
        new ProfilerTimer(
            metrics,
            isTransaction
                ? MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR_TRANSACTION
                : MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR,
            false);

    try {
      timer.start();

      if (isTransaction) {
        transaction.save(vendor);
      } else {
        writeDbMapper.save(vendor);
      }
    } catch (final ConditionalCheckFailedException ex) {
      logger.error(
          getConditionalCheckExceptionMessage("updateVendor", "vendor", vendor.toString()));
      MetricUtils.emitConditionalCheckFailedExceptionMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR);
      throw ex;
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(getThrottledRequestMessage("updateVendor", "vendor", vendor.toString()));
      MetricUtils.emitThrottledRequestMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(getAmazonServiceExceptionMessage("updateVendor", "vendor", vendor.toString()));
      MetricUtils.emitAmazonServiceExceptionMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR);
      throw ex;
    } finally {
      timer.stop();
    }
  }

  /**
   * Gets a vendor from any identifiers specified in the vendorLookupValues, validating that request
   * identifiers are consistent with the result.
   *
   * @param vendorLookupValues
   * @return
   * @throws IllegalArgumentException if the request vendor identifiers are inconsistent with the
   *     result.
   */
  public Vendor getVendor(final Vendor vendorLookupValues) {
    return getVendor(vendorLookupValues, true);
  }

  /**
   * Gets a vendor from any identifiers specified in the vendorLookupValues. When forceConsistency
   * is true, it validates that request identifiers are consistent with the result.
   *
   * @param vendorLookupValues
   * @param forceConsistency
   * @return
   * @throws IllegalArgumentException if forceConsistency is true and the request vendor identifiers
   *     are inconsistent with the result.
   */
  public Vendor getVendor(final Vendor vendorLookupValues, final boolean forceConsistency) {
    if (vendorLookupValues == null) {
      throw new IllegalArgumentException("vendor lookup values cannot be null");
    }

    final Vendor result;
    if (StringUtils.isNotBlank(vendorLookupValues.getVendorId())) {
      result = getVendorByVendorId(vendorLookupValues.getVendorId());
    } else if (StringUtils.isNotBlank(vendorLookupValues.getMasVendorCode())) {
      result = getVendorByMasVendorCode(vendorLookupValues.getMasVendorCode());
    } else if (StringUtils.isNotBlank(vendorLookupValues.getMasVendorId())) {
      result = getVendorByMasVendorId(vendorLookupValues.getMasVendorId());
    } else {
      throw new IllegalArgumentException(
          "vendor lookup values cannot be empty; one of the identifier fields needs to be populated (e.g. vendorId)");
    }

    if (forceConsistency) {
      validateVendorConsistency(vendorLookupValues, result);
    }
    return result;
  }

  /**
   * This validates that a request did not refer to multiple vendors using the different vendor
   * identifiers.
   *
   * @param vendorLookup
   * @param result
   */
  private void validateVendorConsistency(final Vendor vendorLookup, final Vendor result) {
    if (vendorLookup == null || result == null) {
      return;
    }
    validateConsistency(Vendor.VENDOR_ID, vendorLookup.getVendorId(), result.getVendorId());
    validateConsistency(
        Vendor.MAS_VENDOR_CODE, vendorLookup.getMasVendorCode(), result.getMasVendorCode());
    validateConsistency(
        Vendor.MAS_VENDOR_ID, vendorLookup.getMasVendorId(), result.getMasVendorId());
  }

  private void validateConsistency(
      final String fieldName, final String lookupValue, final String result) {
    if (StringUtils.isNotBlank(lookupValue)
        && StringUtils.isNotBlank(result)
        && !lookupValue.equals(result)) {
      throw new IllegalArgumentException(
          String.format(
              "Input %s (%s) does not match resulting %s (%s)",
              fieldName, lookupValue, fieldName, result));
    }
  }

  public Vendor getVendorByVendorId(String vendorId) {
    if (StringUtils.isEmpty(vendorId)) {
      throw new IllegalArgumentException("vendorId cannot be empty");
    }

    logger.debug("Loading vendor for vendorId " + vendorId + " ...");

    final ProfilerTimer timer =
        new ProfilerTimer(metrics, MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_VENDOR_ID, false);
    Vendor vendor;

    try {
      timer.start();
      vendor = readDbMapper.load(Vendor.class, vendorId);
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(getThrottledRequestMessage("getVendorByVendorId", "vendorId", vendorId));
      MetricUtils.emitThrottledRequestMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_VENDOR_ID);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(getAmazonServiceExceptionMessage("getVendorByVendorId", "vendorId", vendorId));
      MetricUtils.emitAmazonServiceExceptionMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_VENDOR_ID);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(getRetryLimitExceededMessage("getVendorByVendorId", "vendorId", vendorId));
      MetricUtils.emitRetryLimitExceededMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_VENDOR_ID);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }

    logger.debug("Found: " + vendor);
    return vendor;
  }

  /**
   * As multiple adg vendors will have the same masVendorId (one parent and multiple child vendors),
   * we will only return the parent adg vendor when querying with masVendorId.
   *
   * @param masVendorId
   * @return
   */
  public Vendor getVendorByMasVendorId(final String masVendorId) {
    if (StringUtils.isEmpty(masVendorId)) {
      throw new IllegalArgumentException("masVendorId cannot be empty");
    }

    logger.debug("Querying for vendor with masVendorId " + masVendorId + " ...");

    final Vendor vendorKey = new Vendor();
    vendorKey.setMasVendorId(masVendorId);

    final DynamoDBQueryExpression<Vendor> queryExpression =
        new DynamoDBQueryExpression<Vendor>()
            .withHashKeyValues(vendorKey)
            .withConsistentRead(false)
            .withIndexName(Vendor.INDEX_BY_MAS_VENDOR_ID);

    final ProfilerTimer timer =
        new ProfilerTimer(
            metrics, MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_ID, false);
    List<Vendor> vendors;

    try {
      timer.start();
      vendors = readDbMapper.query(Vendor.class, queryExpression);

    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(
          getThrottledRequestMessage("getVendorByMasVendorId", "masVendorId", masVendorId));
      MetricUtils.emitThrottledRequestMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_ID);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(
          getAmazonServiceExceptionMessage("getVendorByMasVendorId", "masVendorId", masVendorId));
      MetricUtils.emitAmazonServiceExceptionMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_ID);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(
          getRetryLimitExceededMessage("getVendorByMasVendorId", "masVendorId", masVendorId));
      MetricUtils.emitRetryLimitExceededMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_ID);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }

    logger.debug("Matches in " + queryExpression.getIndexName() + " found: " + vendors.size());
    if (vendors.size() == 1) {
      // If only one entry, then return that entry (backwards compatible)
      return getVendorByVendorId(vendors.get(0).getVendorId());
    } else if (vendors.size() > 1) {
      // Multiple entries mean one of them probably is a parent.
      // As parent adg vendor will not have a masVendorCode, we are filtering on masVendorCode
      final List<Vendor> parentVendors =
          vendors.stream()
              .filter(vendor -> StringUtils.isBlank(vendor.getMasVendorCode()))
              .collect(Collectors.toList());
      if (parentVendors.size() == 1) {
        return getVendorByVendorId(parentVendors.get(0).getVendorId());
      } else if (parentVendors.size() > 1) {
        metrics.addCount(MetricConstants.METRIC_MULTIPLE_PARENT_VENDORS_FOUND, 1, Unit.ONE);
        throw new UniqueConstraintException(
            String.format(
                "More than one match for parent masVendorId %s? Matches: %d",
                masVendorId, parentVendors.size()));
      } else {
        metrics.addCount(MetricConstants.METRIC_NO_PARENT_VENDOR_FOUND, 1, Unit.ONE);
        final Vendor newParentVendor = createParentVendor();
        final Vendor updateParentVendor = getVendor(newParentVendor);
        updateParentVendor.setMasVendorId(masVendorId);
        updateParentVendor.setVendorId(newParentVendor.getVendorId());
        updateParentVendor.setName("MASTER");
        update(updateParentVendor);
        logger.warn(
            String.format(
                "Found %d vendors with masVendorId %s and different masVendorCodes. But no parent vendor. New one was created: %s",
                vendors.size(), masVendorId, newParentVendor.getVendorId()));
        return updateParentVendor;
      }
    } else {
      return null;
    }
  }

  public Vendor getVendorByMasVendorCode(final String masVendorCode) {
    if (StringUtils.isEmpty(masVendorCode)) {
      throw new IllegalArgumentException("masVendorCode cannot be empty");
    }

    logger.debug("Querying for vendor with masVendorCode " + masVendorCode + " ...");

    final Vendor vendorKey = new Vendor();
    vendorKey.setMasVendorCode(masVendorCode);

    final DynamoDBQueryExpression<Vendor> queryExpression =
        new DynamoDBQueryExpression<Vendor>()
            .withHashKeyValues(vendorKey)
            .withConsistentRead(false)
            .withIndexName(Vendor.INDEX_BY_MAS_VENDOR_CODE);

    final ProfilerTimer timer =
        new ProfilerTimer(
            metrics, MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_CODE, false);
    List<Vendor> vendors;

    try {
      timer.start();
      vendors = readDbMapper.query(Vendor.class, queryExpression);
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(
          getThrottledRequestMessage("getVendorByMasVendorCode", "masVendorCode", masVendorCode));
      MetricUtils.emitThrottledRequestMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_CODE);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(
          getAmazonServiceExceptionMessage(
              "getVendorByMasVendorCode", "masVendorCode", masVendorCode));
      MetricUtils.emitAmazonServiceExceptionMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_CODE);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(
          getRetryLimitExceededMessage("getVendorByMasVendorCode", "masVendorCode", masVendorCode));
      MetricUtils.emitRetryLimitExceededMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_CODE);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }

    logger.debug("Matches in " + queryExpression.getIndexName() + " found: " + vendors.size());
    if (vendors.size() == 1) {
      return getVendorByVendorId(vendors.get(0).getVendorId());
    }
    if (vendors.size() > 1) {
      throw new UniqueConstraintException(
          "More than one match for masVendorId " + masVendorCode + "? Matches: " + vendors.size());
    } else {
      return null;
    }
  }

  public Vendor createParentVendor() {
    final Vendor vendor = new Vendor();
    vendor.setName("MASTER");
    create(vendor);
    return vendor;
  }

  /**
   * Update vendor if you find the id in the database, otherwise create. While updating, we do not
   * overwrite existing values, if you need to overwrite values then call update().
   *
   * @param vendor
   * @param transaction
   * @return
   */
  public Vendor createOrUpdateVendor(final Vendor vendor, final Transaction transaction) {
    final Vendor foundVendor = getVendor(vendor, false);
    if (foundVendor == null || StringUtils.isBlank(foundVendor.getVendorId())) {
      create(vendor, transaction);
    } else {
      vendor.setVendorId(foundVendor.getVendorId());
      update(vendor, transaction, false);
    }
    return getVendor(vendor, false);
  }

  public static class VendorSearchCriteria {
    private String name;

    public String getName() {
      return name;
    }

    public void setName(final String name) {
      this.name = name;
    }
  }

  public static class VendorFilter {
    private VendorStateEnum state;

    public VendorStateEnum getState() {
      return state;
    }

    public void setState(final VendorStateEnum state) {
      this.state = state;
    }
  }

  /**
   * Do NOT use lightly, as this is a full table scan.
   *
   * @param criteria
   * @param filter
   * @return
   */
  public List<Vendor> searchVendors(
      final VendorSearchCriteria criteria, final VendorFilter filter) {
    if (criteria == null) {
      throw new IllegalArgumentException("vendor search criteria cannot be null");
    }
    final String vendorName = criteria.getName();
    if (StringUtils.isEmpty(vendorName)) {
      throw new IllegalArgumentException(
          "vendor search criteria cannot be empty; one of the criteria needs to be populated (e.g. name)");
    }

    final Condition nameCondition =
        new Condition()
            .withComparisonOperator(ComparisonOperator.CONTAINS)
            .withAttributeValueList(new AttributeValue().withS(vendorName));
    final Map<String, Condition> scanFilter = new LinkedHashMap<>();
    scanFilter.put(Vendor.VENDOR_NAME, nameCondition);

    final DynamoDBScanExpression scanExpression =
        new DynamoDBScanExpression().withScanFilter(scanFilter).withConsistentRead(false);

    final ProfilerTimer timer =
        new ProfilerTimer(metrics, MetricConstants.METRIC_DYNAMO_DB_SEARCH_VENDORS, false);
    List<Vendor> vendors;

    try {
      timer.start();
      vendors = readDbMapper.scan(Vendor.class, scanExpression);
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(getThrottledRequestMessage("searchVendors", "vendorName", vendorName));
      MetricUtils.emitThrottledRequestMetric(MetricConstants.METRIC_DYNAMO_DB_SEARCH_VENDORS);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(getAmazonServiceExceptionMessage("searchVendors", "vendorName", vendorName));
      MetricUtils.emitAmazonServiceExceptionMetric(MetricConstants.METRIC_DYNAMO_DB_SEARCH_VENDORS);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(getRetryLimitExceededMessage("searchVendors", "vendorName", vendorName));
      MetricUtils.emitRetryLimitExceededMetric(MetricConstants.METRIC_DYNAMO_DB_SEARCH_VENDORS);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }

    logger.debug("Matches found: " + vendors.size());
    return vendors;
  }
}




// Vendor.java
package com.amazon.adg.product.data;

import com.amazon.adg.common.dynamodb.marshaller.ScopeLocalDateTimeMarshaller;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBIndexHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMarshalling;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBVersionAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.encryption.DoNotEncrypt;
import com.amazonaws.services.dynamodbv2.datamodeling.encryption.DoNotTouch;
import java.time.LocalDateTime;

@DynamoDBTable(tableName = "ADGVendor")
@DoNotTouch
public class Vendor {
  public static final String TABLE_NAME = "ADGVendor";

  public static final String VENDOR_ID = "VendorId";
  public static final String VENDOR_NAME = "VendorName";
  public static final String MAS_VENDOR_ID = "MASVendorId";
  public static final String MAS_VENDOR_CODE = "MASVendorCode";
  public static final String STATE = "State";
  public static final String VERSION = "Version";
  public static final String MODIFIED_TIMESTAMP = "ModifiedTimestamp";

  public static final String INDEX_BY_MAS_VENDOR_ID = "ADGVendorByMASVendorId-index";
  public static final String INDEX_BY_MAS_VENDOR_CODE = "ADGVendorByMASVendorCode-index";
  public static final String STORE_ID = "storeId";
  public static final String SERVICE_PROVIDER = "serviceProvider";
  public static final String SERVICE_PROVIDER_VENDOR_ID = "serviceProviderVendorId";

  private String vendorId;
  private String masVendorId;
  private String masVendorCode;
  private String name;
  private String state;
  private LocalDateTime modifiedTimestamp;
  private Long version;
  private String storeId;
  private String serviceProvider;
  private String serviceProviderVendorId;

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = VENDOR_ID)
  @DynamoDBHashKey(attributeName = VENDOR_ID)
  public String getVendorId() {
    return vendorId;
  }

  public void setVendorId(String vendorId) {
    this.vendorId = vendorId;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = STORE_ID)
  public String getStoreId() {
    return storeId;
  }

  public void setStoreId(String storeId) {
    this.storeId = storeId;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = SERVICE_PROVIDER)
  public String getServiceProvider() {
    return serviceProvider;
  }

  public void setServiceProvider(String serviceProvider) {
    this.serviceProvider = serviceProvider;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = SERVICE_PROVIDER_VENDOR_ID)
  public String getServiceProviderVendorId() {
    return serviceProviderVendorId;
  }

  public void setServiceProviderVendorId(String serviceProviderVendorId) {
    this.serviceProviderVendorId = serviceProviderVendorId;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = MAS_VENDOR_ID)
  @DynamoDBIndexHashKey(
      attributeName = MAS_VENDOR_ID,
      globalSecondaryIndexName = INDEX_BY_MAS_VENDOR_ID)
  public String getMasVendorId() {
    return masVendorId;
  }

  public void setMasVendorId(String masVendorId) {
    this.masVendorId = masVendorId;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = MAS_VENDOR_CODE)
  @DynamoDBIndexHashKey(
      attributeName = MAS_VENDOR_CODE,
      globalSecondaryIndexName = INDEX_BY_MAS_VENDOR_CODE)
  public String getMasVendorCode() {
    return masVendorCode;
  }

  public void setMasVendorCode(String masVendorCode) {
    this.masVendorCode = masVendorCode;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = VENDOR_NAME)
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = STATE)
  public String getState() {
    return state;
  }

  public void setState(String state) {
    this.state = state;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = MODIFIED_TIMESTAMP)
  @DynamoDBMarshalling(marshallerClass = ScopeLocalDateTimeMarshaller.class)
  public LocalDateTime getModifiedTimestamp() {
    return modifiedTimestamp;
  }

  public void setModifiedTimestamp(LocalDateTime modifiedTimestamp) {
    this.modifiedTimestamp = modifiedTimestamp;
  }

  /**
   * Version optimistic locking.
   *
   * @return Long version
   */
  @DoNotEncrypt
  @DynamoDBVersionAttribute(attributeName = VERSION)
  public Long getVersion() {
    return version;
  }

  public void setVersion(Long version) {
    this.version = version;
  }

  public String debugString() {
    StringBuilder str = new StringBuilder(vendorId).append(" (v").append(version).append(")");
    return str.toString();
  }

  @Override
  public String toString() {
    final StringBuilder str = new StringBuilder("Vendor{");
    str.append("vendorId='");
    str.append(vendorId);
    str.append("',masVendorId='");
    str.append(masVendorId);
    str.append("',masVendorCode='");
    str.append(masVendorCode);
    str.append("'}");
    return str.toString();
  }
}




// PagedRequest.java
package com.amazon.adg.product.cursor.paging;

/** An object that holds the information needed for a paged DB query request. */
public class PagedRequest<T_Input, T_QueryParams> {

  private T_Input input;
  private T_QueryParams queryParameters;

  public T_Input getInput() {
    return input;
  }

  public void setInput(T_Input input) {
    this.input = input;
  }

  public T_QueryParams getQueryParameters() {
    return queryParameters;
  }

  public void setQueryParameters(final T_QueryParams queryParameters) {
    this.queryParameters = queryParameters;
  }
}




// GetProductsActivity.java
package com.amazon.adg.product.service.activity;

import com.amazon.adg.common.model.Product;
import com.amazon.adg.discovery.common.localization.LocalizationUtils;
import com.amazon.adg.product.metric.LogConfig;
import com.amazon.adg.product.service.model.GetProductsRequest;
import com.amazon.adg.product.service.model.GetProductsResponse;
import com.amazon.adg.product.service.model.InvalidRequestException;
import com.amazon.adg.product.service.orchestrators.GetProductsOrchestrator;
import com.amazon.adg.product.service.util.RequestValidationUtils;
import com.amazon.coral.annotation.Operation;
import com.amazon.coral.annotation.Service;
import com.amazon.coral.support.metrics.UseActivityMetricsForThread;
import com.amazon.mas.commons.coral.support.interceptor.MASDependentServiceInterceptor;
import com.amazon.mas.commons.coral.support.interceptor.MASInterceptorConfiguration;
import java.util.List;
import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

@Service("ADGProductService")
public class GetProductsActivity extends AbstractActivity<GetProductsRequest, GetProductsResponse> {
  private static final Logger logger = LogManager.getLogger(GetProductsActivity.class);

  @Autowired private GetProductsOrchestrator getProductsOrchestrator;

  @Operation("getProducts")
  @UseActivityMetricsForThread
  @MASDependentServiceInterceptor
  @MASInterceptorConfiguration(
      samplingRate = LogConfig.EXTERNAL_SAMPLE_RATE,
      internalAccountSamplingRate = LogConfig.INTERNAL_SAMPLE_RATE)
  public GetProductsResponse getProducts(final GetProductsRequest request) {
    return execute(request);
  }

  @Override
  protected GetProductsResponse invoke(final GetProductsRequest request) {
    final List<Product> products = getProductsOrchestrator.getProducts(request.getProducts());
    if (CollectionUtils.isNotEmpty(products)) {
      // Passing in null for language to keep it as a localized json.
      products.forEach(product -> LocalizationUtils.localizeStrings(product, null));
    }
    final GetProductsResponse response = new GetProductsResponse();
    response.setProducts(products);
    return response;
  }

  @Override
  protected void validateRequest(final GetProductsRequest request) {
    if (request == null) {
      logger.error("Received null request");
      throw new InvalidRequestException("Received null request");
    }

    RequestValidationUtils.validateProductRequest(request.getProducts());
  }

  @Override
  protected void validateResponse(
      final GetProductsRequest request, final GetProductsResponse response, final long totalTime) {}
}




// AbstractDao.java
package com.amazon.adg.product.dao;

import com.amazon.coral.metrics.Metrics;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;

public abstract class AbstractDao {

  protected DynamoDBMapper readDbMapper;
  protected DynamoDBMapper writeDbMapper;
  protected Metrics metrics;

  public AbstractDao(
      final DynamoDBMapper readDbMapper,
      final DynamoDBMapper writeDbMapper,
      final Metrics metrics) {
    this.readDbMapper = readDbMapper;
    this.writeDbMapper = writeDbMapper;
    this.metrics = metrics;
  }

  public void setReadDbMapper(final DynamoDBMapper readDbMapper) {
    this.readDbMapper = readDbMapper;
  }

  public DynamoDBMapper getReadDbMapper() {
    return readDbMapper;
  }

  public void setWriteDbMapper(final DynamoDBMapper writeDbMapper) {
    this.writeDbMapper = writeDbMapper;
  }

  public DynamoDBMapper getWriteDbMapper() {
    return writeDbMapper;
  }
}




// GetProductsOrchestrator.java
package com.amazon.adg.product.service.orchestrators;

import com.amazon.adg.common.model.Product;
import com.amazon.adg.discovery.common.util.ProductMappingUtils;
import com.amazon.adg.product.service.database.ADGProductDatabase;
import com.amazon.adg.product.service.model.ErrorCode;
import com.amazon.adg.product.service.model.ProductFailure;
import com.amazon.adg.product.service.model.ProductModelUtil;
import com.amazon.adg.product.service.model.ProductsByDomainRequest;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

public class GetProductsOrchestrator {

  private static final String SKU_AND_VENDOR_DELIMITER = ":";

  private boolean migrationOn = false;

  @Autowired private ADGProductDatabase adgProductDatabase;

  public void setMigrationOn(final boolean migrationOn) {
    this.migrationOn = migrationOn;
  }

  /**
   * Gets a populated product given a productRequest. ProductId, asin, or vendorId+sku must be
   * populated.
   *
   * @param productRequest the product that we are populating
   * @return a populated product
   */
  public Product getProduct(final Product productRequest) {
    Product product = adgProductDatabase.getProduct(productRequest);
    if (product == null && migrationOn) {
      product = populateAsinProductFromCatalogData(productRequest);
    }
    return product;
  }

  /**
   * Given a list of product requests, it returns a list of populated products. Each product must
   * have one of the following identifiers: productId, asin, vendorId+sku,
   * vendorId+externalProductId
   *
   * @param productRequests - product objects with identifiers populated.
   * @return a list of populated products
   */
  public List<Product> getProducts(final Collection<Product> productRequests) {
    if (CollectionUtils.isEmpty(productRequests)) {
      return new ArrayList<>();
    }

    List<Product> foundProducts = adgProductDatabase.getProducts(productRequests);

    if (CollectionUtils.isEmpty(foundProducts) && migrationOn) {
      // See if any had ASINs and then try to populate from Catalog data
      foundProducts = populateAsinProductsFromCatalogData(productRequests);
    }

    return foundProducts;
  }

  // TODO: [ADG-14961] we should support populating by externalProductId and vendorId+masVendorCode
  // here
  /**
   * Populating products that are not in a list format from the database can be tricky. This class
   * takes care of that by populating the products with any missing fields from the database result.
   * This is a bit less intuitive than it would seem, since the products are copied to a database
   * object, those are populated, and then they are returned a products. In addition, products do
   * not have one single identifier, they have 3 potential input identifiers (id, asin, sku+vendor
   * id/code). So, this class solves this by mapping the identifiers in 3 separate maps for the 3
   * different type of identifiers.
   *
   * @param requests list of ProductsByDomainRequests, used to put into the failuresMap if failures
   *     are found
   * @param productsToPopulate list of products we are populating
   * @param failuresMap sourceProducts that failed to populate
   */
  public void populateProducts(
      final Collection<ProductsByDomainRequest> requests,
      final Collection<Product> productsToPopulate,
      final Map<ProductsByDomainRequest, ProductFailure> failuresMap) {
    if (CollectionUtils.isEmpty(productsToPopulate)) {
      return;
    }

    final List<Product> populatedProducts = getProducts(productsToPopulate);

    final Map<String, Product> requestedIdProducts = new HashMap<>(populatedProducts.size());
    final Map<String, Product> requestedAsinProducts = new HashMap<>(populatedProducts.size());
    final Map<String, Product> requestedSkuAndVendorIdProducts =
        new HashMap<>(populatedProducts.size());
    final Map<String, Product> requestedSkuAndVendorCodeProducts =
        new HashMap<>(populatedProducts.size());

    for (final Product product : populatedProducts) {
      requestedIdProducts.put(product.getId(), product);
      requestedAsinProducts.put(product.getAsin(), product);
      final String skuAndVendorId = getSkuAndVendorId(product);
      requestedSkuAndVendorIdProducts.put(skuAndVendorId, product);
      final String skuAndVendorCode = getSkuAndVendorCode(product);
      requestedSkuAndVendorCodeProducts.put(skuAndVendorCode, product);
    }

    for (final Product product : productsToPopulate) {
      boolean found = false;
      if (StringUtils.isNotBlank(product.getId())
          && requestedIdProducts.containsKey(product.getId())) {
        ProductMappingUtils.mapMissingFields(product, requestedIdProducts.get(product.getId()));
        found = true;
      }
      if (StringUtils.isNotBlank(product.getAsin())
          && requestedAsinProducts.containsKey(product.getAsin())) {
        ProductMappingUtils.mapMissingFields(product, requestedAsinProducts.get(product.getAsin()));
        found = true;
      }
      final String skuAndVendorId = getSkuAndVendorId(product);
      if (StringUtils.isNotBlank(skuAndVendorId)
          && requestedSkuAndVendorIdProducts.containsKey(skuAndVendorId)) {
        ProductMappingUtils.mapMissingFields(
            product, requestedSkuAndVendorIdProducts.get(skuAndVendorId));
        found = true;
      }
      final String skuAndVendorCode = getSkuAndVendorCode(product);
      if (StringUtils.isNotBlank(skuAndVendorCode)
          && requestedSkuAndVendorCodeProducts.containsKey(skuAndVendorCode)) {
        ProductMappingUtils.mapMissingFields(
            product, requestedSkuAndVendorCodeProducts.get(skuAndVendorCode));
        found = true;
      }
      if (!found) {
        final ProductsByDomainRequest requestWithProduct = getRequestWithProduct(requests, product);
        if (requestWithProduct != null) {
          failuresMap.put(
              requestWithProduct,
              ProductFailure.builder()
                  .withProduct(product)
                  .withCode(ErrorCode.PRODUCT_NOT_FOUND)
                  .withMessage(
                      new StringBuilder()
                          .append("Unable to find product: id ")
                          .append(product.getId())
                          .append(", asin ")
                          .append(product.getAsin())
                          .append(", skuAndVendorId ")
                          .append(skuAndVendorId)
                          .append(", skuAndVendorCode ")
                          .append(skuAndVendorCode)
                          .toString())
                  .build());
        }
      }
    }
  }

  /**
   * Finds the request with the given product as its source.
   *
   * @param requests list of requests
   * @param product source product to look for
   * @return the request with the product if it is found, null otherwise
   */
  static ProductsByDomainRequest getRequestWithProduct(
      final Collection<ProductsByDomainRequest> requests, final Product product) {
    if (requests == null) {
      return null;
    }

    return requests.stream().filter(r -> r.getSource().equals(product)).findAny().orElse(null);
  }

  /**
   * Gets a unique identifier for a sku and a vendor id if they are both provided, otherwise returns
   * null.
   *
   * @param product product we are getting identifier for
   * @return an identifier unique to the sku and vendorId of the product
   */
  private String getSkuAndVendorId(final Product product) {
    final String vendorId = ProductModelUtil.extractVendorId(product);
    if (StringUtils.isBlank(vendorId) || StringUtils.isBlank(product.getSku())) {
      return null;
    }

    return vendorId + SKU_AND_VENDOR_DELIMITER + product.getSku();
  }

  private String getSkuAndVendorCode(final Product product) {
    final String masVendorCode = ProductModelUtil.extractMasVendorCode(product);
    if (StringUtils.isBlank(masVendorCode) || StringUtils.isBlank(product.getSku())) {
      return null;
    }

    return masVendorCode + SKU_AND_VENDOR_DELIMITER + product.getSku();
  }

  private Product populateAsinProductFromCatalogData(final Product product) {
    final List<Product> productList =
        populateAsinProductsFromCatalogData(Collections.singletonList(product));
    return CollectionUtils.isNotEmpty(productList) ? productList.get(0) : null;
  }

  /**
   * When products cannot be found, try populating the products from their asin data. TODO Not yet
   * implemented. Meant to populate products from a given asin from the catalog.
   *
   * @param products
   * @return
   */
  private List<Product> populateAsinProductsFromCatalogData(final Collection<Product> products) {
    return new ArrayList<>();
  }
}




// DynamoPagingQueryParameters.java
package com.amazon.adg.product.cursor.paging;

import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import java.util.Map;

/** Contains the details of a pagination request. Such as page size and a the lastEvaluatedKey. */
public class DynamoPagingQueryParameters {

  private int pageSize;
  private Map<String, AttributeValue> lastEvaluatedEntry;

  public int getPageSize() {
    return pageSize;
  }

  public void setPageSize(final int pageSize) {
    this.pageSize = pageSize;
  }

  public Map<String, AttributeValue> getLastEvaluatedEntry() {
    return lastEvaluatedEntry;
  }

  public void setLastEvaluatedEntry(final Map<String, AttributeValue> lastEvaluatedEntry) {
    this.lastEvaluatedEntry = lastEvaluatedEntry;
  }
}




// VendorFilter.java
package com.amazon.adg.product.dao;

import static com.amazon.adg.product.utils.LoggerUtils.getAmazonServiceExceptionMessage;
import static com.amazon.adg.product.utils.LoggerUtils.getConditionalCheckExceptionMessage;
import static com.amazon.adg.product.utils.LoggerUtils.getRetryLimitExceededMessage;
import static com.amazon.adg.product.utils.LoggerUtils.getThrottledRequestMessage;

import com.amazon.adg.common.util.LocalDateTimeUtil;
import com.amazon.adg.product.data.Vendor;
import com.amazon.adg.product.data.VendorStateEnum;
import com.amazon.adg.product.metric.MetricConstants;
import com.amazon.adg.product.service.model.InternalServiceException;
import com.amazon.adg.product.utils.MetricUtils;
import com.amazon.coral.metrics.Metrics;
import com.amazon.mas.commons.coral.support.metrics.ProfilerTimer;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.SdkClientException;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBQueryExpression;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.ComparisonOperator;
import com.amazonaws.services.dynamodbv2.model.Condition;
import com.amazonaws.services.dynamodbv2.model.ConditionalCheckFailedException;
import com.amazonaws.services.dynamodbv2.model.ProvisionedThroughputExceededException;
import com.amazonaws.services.dynamodbv2.transactions.Transaction;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;
import javax.measure.unit.Unit;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/** DAO for working with Vendor objects and DynamoDB. */
public class VendorDao extends AbstractDao {

  private static final Logger logger = LogManager.getLogger(VendorDao.class);

  public VendorDao(
      final DynamoDBMapper readDbMapper,
      final DynamoDBMapper writeDbMapper,
      final Metrics metrics) {
    super(readDbMapper, writeDbMapper, metrics);
  }

  public void create(final Vendor vendor) {
    create(vendor, null);
  }

  public void create(final Vendor vendor, final Transaction transaction) {
    if (vendor == null) {
      throw new IllegalArgumentException("vendor cannot be empty; must have name");
    }
    if (StringUtils.isEmpty(vendor.getName())) {
      throw new IllegalArgumentException("vendor name cannot be empty");
    }
    if (StringUtils.isEmpty(vendor.getVendorId())) {
      vendor.setVendorId(UUID.randomUUID().toString());
    }
    vendor.setModifiedTimestamp(LocalDateTimeUtil.nowUtc());
    vendor.setState(VendorStateEnum.ACTIVE.name());

    verifyIfParentVendorExists(vendor);
    verifyExternalVendorIdentifierValue(Vendor.MAS_VENDOR_ID, null, vendor.getMasVendorId());
    verifyExternalVendorIdentifierValue(Vendor.MAS_VENDOR_CODE, null, vendor.getMasVendorCode());

    logger.debug("Saving new " + vendor.debugString());

    final boolean isTransaction = transaction != null;

    final ProfilerTimer timer =
        new ProfilerTimer(
            metrics,
            isTransaction
                ? MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR_TRANSACTION
                : MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR,
            false);

    try {
      timer.start();

      if (isTransaction) {
        transaction.save(vendor);
      } else {
        writeDbMapper.save(vendor);
      }
    } catch (final ConditionalCheckFailedException ex) {
      logger.error(
          getConditionalCheckExceptionMessage("createVendor", "vendor", vendor.toString()));
      MetricUtils.emitConditionalCheckFailedExceptionMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR);
      throw ex;
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(getThrottledRequestMessage("createVendor", "vendor", vendor.toString()));
      MetricUtils.emitThrottledRequestMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(getAmazonServiceExceptionMessage("createVendor", "vendor", vendor.toString()));
      MetricUtils.emitAmazonServiceExceptionMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR);
      throw ex;
    } finally {
      timer.stop();
    }
  }

  /**
   * Enforces single parent vendor rule for the vendor hierarchy, only if the vendor being created
   * is a parent vendor
   *
   * @param vendor
   */
  private void verifyIfParentVendorExists(final Vendor vendor) {
    if (StringUtils.isBlank(vendor.getMasVendorCode())
        && StringUtils.isNotBlank(vendor.getMasVendorId())) {
      // the new vendor is a parent vendor
      // check if a parent entry already exists
      final Optional<Vendor> optionalVendor =
          Optional.ofNullable(getVendorByMasVendorId(vendor.getMasVendorId()));
      optionalVendor.ifPresent(
          existingVendor -> {
            // parent vendor is the one without the masVendorCode
            if (StringUtils.isBlank(existingVendor.getMasVendorCode())) {
              throw new VendorAlreadyExistsException(
                  String.format(
                      "Parent vendor %s already exists with masVendorId %s",
                      existingVendor.getVendorId(), vendor.getMasVendorId()));
            }
          });
    }
  }

  /**
   * Enforces "unique" on the secondary indexes.
   *
   * @param externalIdTypeField the identifier field name (e.g. constant from data class like
   *     "MASVendorId")
   * @param currentValue the current value
   * @param newValue the proposed new value
   */
  protected void verifyExternalVendorIdentifierValue(
      final String externalIdTypeField, final String currentValue, final String newValue) {
    verifyExternalVendorIdentifierValue(externalIdTypeField, currentValue, newValue, false);
  }

  protected void verifyExternalVendorIdentifierValue(
      final String externalIdTypeField,
      final String currentValue,
      final String newValue,
      final boolean overwriteOk) {
    if (currentValue == null && newValue == null) {
      // no value for BOTH is fine
      return;
    }

    if (!overwriteOk && !StringUtils.isEmpty(currentValue) && !currentValue.equals(newValue)) {
      throw new IllegalArgumentException(
          String.format("Cannot change %s once it has already been set.", externalIdTypeField));
    }

    if (StringUtils.isEmpty(currentValue)) {
      if (StringUtils.isBlank(newValue)) {
        throw new IllegalArgumentException(
            "Empty string is not a valid value; use null or a non-empty string.");
      }
      // setting to new valid, value, verify not present ...
      if (Vendor.MAS_VENDOR_ID.equals(externalIdTypeField)) {
        // no checks needed for uniquesness for masVendorId
        return;
      } else if (Vendor.MAS_VENDOR_CODE.equals(externalIdTypeField)) {
        final Optional<Vendor> optionalVendor =
            Optional.ofNullable(getVendorByMasVendorCode(newValue));
        optionalVendor.ifPresent(
            vendor -> {
              throw new VendorAlreadyExistsException(
                  String.format(
                      "Vendor %s already exists with masVendorCode %s",
                      vendor.getVendorId(), newValue));
            });
      } else {
        throw new IllegalArgumentException("Unrecognized MAS vendor field? " + externalIdTypeField);
      }
    }
  }

  public void update(final Vendor vendor) {
    update(vendor, null, false);
  }

  public void update(final Vendor vendor, final Transaction transaction) {
    update(vendor, transaction, false);
  }

  public void update(
      final Vendor vendor, final Transaction transaction, final boolean overwriteOk) {
    if (vendor == null) {
      throw new IllegalArgumentException("vendor cannot be empty");
    }
    if (StringUtils.isEmpty(vendor.getVendorId())) {
      throw new IllegalArgumentException("vendorId cannot be empty");
    }
    if (StringUtils.isEmpty(vendor.getName())) {
      throw new IllegalArgumentException("vendor name cannot be empty");
    }
    vendor.setModifiedTimestamp(LocalDateTimeUtil.nowUtc());

    final Vendor foundVendor = getVendor(vendor, false);
    if (foundVendor == null) {
      throw new VendorNotFoundException(
          "Unable to find matching vendor to update for vendor " + vendor.getVendorId() + ".");
    }
    logger.debug("found matching vendor: " + vendor);

    verifyExternalVendorIdentifierValue(
        Vendor.MAS_VENDOR_ID, foundVendor.getMasVendorId(), vendor.getMasVendorId(), overwriteOk);
    verifyExternalVendorIdentifierValue(
        Vendor.MAS_VENDOR_CODE,
        foundVendor.getMasVendorCode(),
        vendor.getMasVendorCode(),
        overwriteOk);

    if (!StringUtils.isEmpty(vendor.getState())) {
      // will validate and normalize the string
      vendor.setState(VendorStateEnum.valueOf(vendor.getState()).name());
    } else {
      // explicitly using the previous state
      vendor.setState(foundVendor.getState());
    }

    if (transaction != null && vendor.getVersion() == null) {
      vendor.setVersion(foundVendor.getVersion());
    }

    logger.debug("Saving updated vendor: " + vendor.debugString());

    final boolean isTransaction = transaction != null;

    final ProfilerTimer timer =
        new ProfilerTimer(
            metrics,
            isTransaction
                ? MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR_TRANSACTION
                : MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR,
            false);

    try {
      timer.start();

      if (isTransaction) {
        transaction.save(vendor);
      } else {
        writeDbMapper.save(vendor);
      }
    } catch (final ConditionalCheckFailedException ex) {
      logger.error(
          getConditionalCheckExceptionMessage("updateVendor", "vendor", vendor.toString()));
      MetricUtils.emitConditionalCheckFailedExceptionMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR);
      throw ex;
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(getThrottledRequestMessage("updateVendor", "vendor", vendor.toString()));
      MetricUtils.emitThrottledRequestMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(getAmazonServiceExceptionMessage("updateVendor", "vendor", vendor.toString()));
      MetricUtils.emitAmazonServiceExceptionMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR);
      throw ex;
    } finally {
      timer.stop();
    }
  }

  /**
   * Gets a vendor from any identifiers specified in the vendorLookupValues, validating that request
   * identifiers are consistent with the result.
   *
   * @param vendorLookupValues
   * @return
   * @throws IllegalArgumentException if the request vendor identifiers are inconsistent with the
   *     result.
   */
  public Vendor getVendor(final Vendor vendorLookupValues) {
    return getVendor(vendorLookupValues, true);
  }

  /**
   * Gets a vendor from any identifiers specified in the vendorLookupValues. When forceConsistency
   * is true, it validates that request identifiers are consistent with the result.
   *
   * @param vendorLookupValues
   * @param forceConsistency
   * @return
   * @throws IllegalArgumentException if forceConsistency is true and the request vendor identifiers
   *     are inconsistent with the result.
   */
  public Vendor getVendor(final Vendor vendorLookupValues, final boolean forceConsistency) {
    if (vendorLookupValues == null) {
      throw new IllegalArgumentException("vendor lookup values cannot be null");
    }

    final Vendor result;
    if (StringUtils.isNotBlank(vendorLookupValues.getVendorId())) {
      result = getVendorByVendorId(vendorLookupValues.getVendorId());
    } else if (StringUtils.isNotBlank(vendorLookupValues.getMasVendorCode())) {
      result = getVendorByMasVendorCode(vendorLookupValues.getMasVendorCode());
    } else if (StringUtils.isNotBlank(vendorLookupValues.getMasVendorId())) {
      result = getVendorByMasVendorId(vendorLookupValues.getMasVendorId());
    } else {
      throw new IllegalArgumentException(
          "vendor lookup values cannot be empty; one of the identifier fields needs to be populated (e.g. vendorId)");
    }

    if (forceConsistency) {
      validateVendorConsistency(vendorLookupValues, result);
    }
    return result;
  }

  /**
   * This validates that a request did not refer to multiple vendors using the different vendor
   * identifiers.
   *
   * @param vendorLookup
   * @param result
   */
  private void validateVendorConsistency(final Vendor vendorLookup, final Vendor result) {
    if (vendorLookup == null || result == null) {
      return;
    }
    validateConsistency(Vendor.VENDOR_ID, vendorLookup.getVendorId(), result.getVendorId());
    validateConsistency(
        Vendor.MAS_VENDOR_CODE, vendorLookup.getMasVendorCode(), result.getMasVendorCode());
    validateConsistency(
        Vendor.MAS_VENDOR_ID, vendorLookup.getMasVendorId(), result.getMasVendorId());
  }

  private void validateConsistency(
      final String fieldName, final String lookupValue, final String result) {
    if (StringUtils.isNotBlank(lookupValue)
        && StringUtils.isNotBlank(result)
        && !lookupValue.equals(result)) {
      throw new IllegalArgumentException(
          String.format(
              "Input %s (%s) does not match resulting %s (%s)",
              fieldName, lookupValue, fieldName, result));
    }
  }

  public Vendor getVendorByVendorId(String vendorId) {
    if (StringUtils.isEmpty(vendorId)) {
      throw new IllegalArgumentException("vendorId cannot be empty");
    }

    logger.debug("Loading vendor for vendorId " + vendorId + " ...");

    final ProfilerTimer timer =
        new ProfilerTimer(metrics, MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_VENDOR_ID, false);
    Vendor vendor;

    try {
      timer.start();
      vendor = readDbMapper.load(Vendor.class, vendorId);
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(getThrottledRequestMessage("getVendorByVendorId", "vendorId", vendorId));
      MetricUtils.emitThrottledRequestMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_VENDOR_ID);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(getAmazonServiceExceptionMessage("getVendorByVendorId", "vendorId", vendorId));
      MetricUtils.emitAmazonServiceExceptionMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_VENDOR_ID);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(getRetryLimitExceededMessage("getVendorByVendorId", "vendorId", vendorId));
      MetricUtils.emitRetryLimitExceededMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_VENDOR_ID);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }

    logger.debug("Found: " + vendor);
    return vendor;
  }

  /**
   * As multiple adg vendors will have the same masVendorId (one parent and multiple child vendors),
   * we will only return the parent adg vendor when querying with masVendorId.
   *
   * @param masVendorId
   * @return
   */
  public Vendor getVendorByMasVendorId(final String masVendorId) {
    if (StringUtils.isEmpty(masVendorId)) {
      throw new IllegalArgumentException("masVendorId cannot be empty");
    }

    logger.debug("Querying for vendor with masVendorId " + masVendorId + " ...");

    final Vendor vendorKey = new Vendor();
    vendorKey.setMasVendorId(masVendorId);

    final DynamoDBQueryExpression<Vendor> queryExpression =
        new DynamoDBQueryExpression<Vendor>()
            .withHashKeyValues(vendorKey)
            .withConsistentRead(false)
            .withIndexName(Vendor.INDEX_BY_MAS_VENDOR_ID);

    final ProfilerTimer timer =
        new ProfilerTimer(
            metrics, MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_ID, false);
    List<Vendor> vendors;

    try {
      timer.start();
      vendors = readDbMapper.query(Vendor.class, queryExpression);

    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(
          getThrottledRequestMessage("getVendorByMasVendorId", "masVendorId", masVendorId));
      MetricUtils.emitThrottledRequestMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_ID);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(
          getAmazonServiceExceptionMessage("getVendorByMasVendorId", "masVendorId", masVendorId));
      MetricUtils.emitAmazonServiceExceptionMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_ID);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(
          getRetryLimitExceededMessage("getVendorByMasVendorId", "masVendorId", masVendorId));
      MetricUtils.emitRetryLimitExceededMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_ID);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }

    logger.debug("Matches in " + queryExpression.getIndexName() + " found: " + vendors.size());
    if (vendors.size() == 1) {
      // If only one entry, then return that entry (backwards compatible)
      return getVendorByVendorId(vendors.get(0).getVendorId());
    } else if (vendors.size() > 1) {
      // Multiple entries mean one of them probably is a parent.
      // As parent adg vendor will not have a masVendorCode, we are filtering on masVendorCode
      final List<Vendor> parentVendors =
          vendors.stream()
              .filter(vendor -> StringUtils.isBlank(vendor.getMasVendorCode()))
              .collect(Collectors.toList());
      if (parentVendors.size() == 1) {
        return getVendorByVendorId(parentVendors.get(0).getVendorId());
      } else if (parentVendors.size() > 1) {
        metrics.addCount(MetricConstants.METRIC_MULTIPLE_PARENT_VENDORS_FOUND, 1, Unit.ONE);
        throw new UniqueConstraintException(
            String.format(
                "More than one match for parent masVendorId %s? Matches: %d",
                masVendorId, parentVendors.size()));
      } else {
        metrics.addCount(MetricConstants.METRIC_NO_PARENT_VENDOR_FOUND, 1, Unit.ONE);
        final Vendor newParentVendor = createParentVendor();
        final Vendor updateParentVendor = getVendor(newParentVendor);
        updateParentVendor.setMasVendorId(masVendorId);
        updateParentVendor.setVendorId(newParentVendor.getVendorId());
        updateParentVendor.setName("MASTER");
        update(updateParentVendor);
        logger.warn(
            String.format(
                "Found %d vendors with masVendorId %s and different masVendorCodes. But no parent vendor. New one was created: %s",
                vendors.size(), masVendorId, newParentVendor.getVendorId()));
        return updateParentVendor;
      }
    } else {
      return null;
    }
  }

  public Vendor getVendorByMasVendorCode(final String masVendorCode) {
    if (StringUtils.isEmpty(masVendorCode)) {
      throw new IllegalArgumentException("masVendorCode cannot be empty");
    }

    logger.debug("Querying for vendor with masVendorCode " + masVendorCode + " ...");

    final Vendor vendorKey = new Vendor();
    vendorKey.setMasVendorCode(masVendorCode);

    final DynamoDBQueryExpression<Vendor> queryExpression =
        new DynamoDBQueryExpression<Vendor>()
            .withHashKeyValues(vendorKey)
            .withConsistentRead(false)
            .withIndexName(Vendor.INDEX_BY_MAS_VENDOR_CODE);

    final ProfilerTimer timer =
        new ProfilerTimer(
            metrics, MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_CODE, false);
    List<Vendor> vendors;

    try {
      timer.start();
      vendors = readDbMapper.query(Vendor.class, queryExpression);
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(
          getThrottledRequestMessage("getVendorByMasVendorCode", "masVendorCode", masVendorCode));
      MetricUtils.emitThrottledRequestMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_CODE);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(
          getAmazonServiceExceptionMessage(
              "getVendorByMasVendorCode", "masVendorCode", masVendorCode));
      MetricUtils.emitAmazonServiceExceptionMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_CODE);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(
          getRetryLimitExceededMessage("getVendorByMasVendorCode", "masVendorCode", masVendorCode));
      MetricUtils.emitRetryLimitExceededMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_CODE);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }

    logger.debug("Matches in " + queryExpression.getIndexName() + " found: " + vendors.size());
    if (vendors.size() == 1) {
      return getVendorByVendorId(vendors.get(0).getVendorId());
    }
    if (vendors.size() > 1) {
      throw new UniqueConstraintException(
          "More than one match for masVendorId " + masVendorCode + "? Matches: " + vendors.size());
    } else {
      return null;
    }
  }

  public Vendor createParentVendor() {
    final Vendor vendor = new Vendor();
    vendor.setName("MASTER");
    create(vendor);
    return vendor;
  }

  /**
   * Update vendor if you find the id in the database, otherwise create. While updating, we do not
   * overwrite existing values, if you need to overwrite values then call update().
   *
   * @param vendor
   * @param transaction
   * @return
   */
  public Vendor createOrUpdateVendor(final Vendor vendor, final Transaction transaction) {
    final Vendor foundVendor = getVendor(vendor, false);
    if (foundVendor == null || StringUtils.isBlank(foundVendor.getVendorId())) {
      create(vendor, transaction);
    } else {
      vendor.setVendorId(foundVendor.getVendorId());
      update(vendor, transaction, false);
    }
    return getVendor(vendor, false);
  }

  public static class VendorSearchCriteria {
    private String name;

    public String getName() {
      return name;
    }

    public void setName(final String name) {
      this.name = name;
    }
  }

  public static class VendorFilter {
    private VendorStateEnum state;

    public VendorStateEnum getState() {
      return state;
    }

    public void setState(final VendorStateEnum state) {
      this.state = state;
    }
  }

  /**
   * Do NOT use lightly, as this is a full table scan.
   *
   * @param criteria
   * @param filter
   * @return
   */
  public List<Vendor> searchVendors(
      final VendorSearchCriteria criteria, final VendorFilter filter) {
    if (criteria == null) {
      throw new IllegalArgumentException("vendor search criteria cannot be null");
    }
    final String vendorName = criteria.getName();
    if (StringUtils.isEmpty(vendorName)) {
      throw new IllegalArgumentException(
          "vendor search criteria cannot be empty; one of the criteria needs to be populated (e.g. name)");
    }

    final Condition nameCondition =
        new Condition()
            .withComparisonOperator(ComparisonOperator.CONTAINS)
            .withAttributeValueList(new AttributeValue().withS(vendorName));
    final Map<String, Condition> scanFilter = new LinkedHashMap<>();
    scanFilter.put(Vendor.VENDOR_NAME, nameCondition);

    final DynamoDBScanExpression scanExpression =
        new DynamoDBScanExpression().withScanFilter(scanFilter).withConsistentRead(false);

    final ProfilerTimer timer =
        new ProfilerTimer(metrics, MetricConstants.METRIC_DYNAMO_DB_SEARCH_VENDORS, false);
    List<Vendor> vendors;

    try {
      timer.start();
      vendors = readDbMapper.scan(Vendor.class, scanExpression);
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(getThrottledRequestMessage("searchVendors", "vendorName", vendorName));
      MetricUtils.emitThrottledRequestMetric(MetricConstants.METRIC_DYNAMO_DB_SEARCH_VENDORS);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(getAmazonServiceExceptionMessage("searchVendors", "vendorName", vendorName));
      MetricUtils.emitAmazonServiceExceptionMetric(MetricConstants.METRIC_DYNAMO_DB_SEARCH_VENDORS);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(getRetryLimitExceededMessage("searchVendors", "vendorName", vendorName));
      MetricUtils.emitRetryLimitExceededMetric(MetricConstants.METRIC_DYNAMO_DB_SEARCH_VENDORS);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }

    logger.debug("Matches found: " + vendors.size());
    return vendors;
  }
}




// ProductRevisionDao.java
package com.amazon.adg.product.dao;

import static com.amazon.adg.product.utils.LoggerUtils.getAmazonServiceExceptionMessage;
import static com.amazon.adg.product.utils.LoggerUtils.getConditionalCheckExceptionMessage;
import static com.amazon.adg.product.utils.LoggerUtils.getRetryLimitExceededMessage;
import static com.amazon.adg.product.utils.LoggerUtils.getThrottledRequestMessage;

import com.amazon.adg.common.util.LocalDateTimeUtil;
import com.amazon.adg.product.cursor.paging.DynamoCursorPager;
import com.amazon.adg.product.cursor.paging.DynamoPagingQueryParameters;
import com.amazon.adg.product.cursor.paging.PagedResponse;
import com.amazon.adg.product.data.ProductRevisionData;
import com.amazon.adg.product.metric.MetricConstants;
import com.amazon.adg.product.service.model.InternalServiceException;
import com.amazon.adg.product.utils.MetricUtils;
import com.amazon.coral.support.metrics.CoralMetricsThreadInstance;
import com.amazon.mas.commons.coral.support.metrics.ProfilerTimer;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.SdkClientException;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBQueryExpression;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.ComparisonOperator;
import com.amazonaws.services.dynamodbv2.model.Condition;
import com.amazonaws.services.dynamodbv2.model.ConditionalCheckFailedException;
import com.amazonaws.services.dynamodbv2.model.ProvisionedThroughputExceededException;
import com.amazonaws.services.dynamodbv2.model.Select;
import com.amazonaws.services.dynamodbv2.transactions.Transaction;
import java.util.List;
import java.util.Map;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/** DAO for working with ProductRevision objects and DynamoDB. */
public class ProductRevisionDao extends AbstractDao {
  private static final Logger logger = LogManager.getLogger(ProductRevisionDao.class);

  private static final int GET_REVISIONS_BY_PRODUCT_ID_QUERY_DEFAULT_PAGE_SIZE = 20;

  private final DynamoCursorPager<ProductRevisionData> paginator;

  public ProductRevisionDao(final DynamoDBMapper readDbMapper, final DynamoDBMapper writeDbMapper) {
    super(readDbMapper, writeDbMapper, CoralMetricsThreadInstance.getMetricsInstance());
    this.paginator = new DynamoCursorPager<>(ProductRevisionData.class, readDbMapper);
  }

  /**
   * Creates a product revision in DynamoDB
   *
   * @param productRevision the product revision to be created
   */
  public void create(final ProductRevisionData productRevision) {
    create(productRevision, null);
  }

  /**
   * Creates a product revision as part of a transaction in DynamoDB
   *
   * @param productRevision the product revision to be created
   * @param transaction the transaction to perform database actions
   */
  public void create(final ProductRevisionData productRevision, final Transaction transaction) {
    productRevision.setCreatedTimestamp(LocalDateTimeUtil.nowUtc());
    productRevision.setModifiedTimestamp(LocalDateTimeUtil.nowUtc());

    logger.debug("Saving new productRevision" + productRevision);

    final boolean isTransaction = transaction != null;

    final ProfilerTimer timer =
        new ProfilerTimer(
            metrics,
            isTransaction
                ? MetricConstants.METRIC_DYNAMO_DB_CREATE_PRODUCT_REVISION_TRANSACTION
                : MetricConstants.METRIC_DYNAMO_DB_CREATE_PRODUCT_REVISION,
            false);

    try {
      timer.start();

      if (isTransaction) {
        transaction.save(productRevision);
      } else {
        writeDbMapper.save(productRevision);
      }

    } catch (final ConditionalCheckFailedException ex) {
      logger.error(
          getConditionalCheckExceptionMessage(
              "createProductRevision", "productRevision", productRevision.toString()));
      MetricUtils.emitConditionalCheckFailedExceptionMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_CREATE_PRODUCT_REVISION_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_CREATE_PRODUCT_REVISION);
      throw ex;
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(
          getThrottledRequestMessage(
              "createProductRevision", "productRevision", productRevision.toString()));
      MetricUtils.emitThrottledRequestMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_CREATE_PRODUCT_REVISION_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_CREATE_PRODUCT_REVISION);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(
          getAmazonServiceExceptionMessage(
              "createProductRevision", "productRevision", productRevision.toString()));
      MetricUtils.emitAmazonServiceExceptionMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_CREATE_PRODUCT_REVISION_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_CREATE_PRODUCT_REVISION);
      throw ex;
    } finally {
      timer.stop();
    }
  }

  /**
   * Updates a product revision as part of a transaction in DynamoDB
   *
   * @param productRevision the product revision to be created
   * @param transaction the transaction to perform database actions
   */
  public void update(final ProductRevisionData productRevision, final Transaction transaction) {
    productRevision.setModifiedTimestamp(LocalDateTimeUtil.nowUtc());

    if (productRevision.getVersion() == null) {
      final ProductRevisionData foundProductRevision = getProductRevision(productRevision);
      productRevision.setVersion(foundProductRevision.getVersion());
      productRevision.setCreatedTimestamp(foundProductRevision.getCreatedTimestamp());
    }

    logger.debug("Saving updated productRevision: " + productRevision);

    final boolean isTransaction = transaction != null;

    final ProfilerTimer timer =
        new ProfilerTimer(
            metrics,
            isTransaction
                ? MetricConstants.METRIC_DYNAMO_DB_CREATE_PRODUCT_REVISION_TRANSACTION
                : MetricConstants.METRIC_DYNAMO_DB_CREATE_PRODUCT_REVISION,
            false);

    try {
      timer.start();

      if (isTransaction) {
        transaction.save(productRevision);
      } else {
        writeDbMapper.save(productRevision);
      }

    } catch (final ConditionalCheckFailedException ex) {
      logger.error(
          getConditionalCheckExceptionMessage(
              "updateProductRevision", "productRevision", productRevision.toString()));
      MetricUtils.emitConditionalCheckFailedExceptionMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_UPDATE_PRODUCT_REVISION_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_UPDATE_PRODUCT_REVISION);
      throw ex;
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(
          getThrottledRequestMessage(
              "updateProductRevision", "productRevision", productRevision.toString()));
      MetricUtils.emitThrottledRequestMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_UPDATE_PRODUCT_REVISION_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_UPDATE_PRODUCT_REVISION);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(
          getAmazonServiceExceptionMessage(
              "updateProductRevision", "productRevision", productRevision.toString()));
      MetricUtils.emitAmazonServiceExceptionMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_UPDATE_PRODUCT_REVISION_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_UPDATE_PRODUCT_REVISION);
      throw ex;
    } finally {
      timer.stop();
    }
  }

  /**
   * Gets a single product revision from DynamoDB using its productId+revisionId or
   * productId+externalRevisionId.
   *
   * @param productRevision the product revision populated with lookup values
   * @return if found, a product corresponding to populated lookup values. otherwise, null.
   */
  public ProductRevisionData getProductRevision(final ProductRevisionData productRevision) {
    if (productRevision == null) {
      return null;
    }

    if (StringUtils.isNotBlank(productRevision.getRevisionId())) {
      if (StringUtils.isNotBlank(productRevision.getProductId())) {
        return getProductRevisionByProductIdAndRevisionId(productRevision);
      } else {
        return getProductRevisionByRevisionId(productRevision);
      }
    }

    if (StringUtils.isNotBlank(productRevision.getProductId())
        && StringUtils.isNotBlank(productRevision.getExternalRevisionId())) {
      return getProductRevisionByProductIdAndExternalRevisionId(productRevision);
    }

    final String errorMessage =
        "Received a request for product revision with insufficient data."
            + " A revisionId or productId+revision is required.";
    throw new IllegalArgumentException(errorMessage);
  }

  /**
   * Gets a single product revision from DynamoDB using productId+revisionId.
   *
   * @param productRevision the product revision populated with productId+revisionId
   * @return if found, the product revision corresponding to populated revisionId. otherwise, null.
   */
  public ProductRevisionData getProductRevisionByProductIdAndRevisionId(
      final ProductRevisionData productRevision) {
    final String productId = productRevision.getProductId();
    final String revisionId = productRevision.getRevisionId();
    logger.debug(
        String.format(
            "Querying for productRevision with productId %s and revisionId %s.",
            productId, revisionId));

    final ProfilerTimer timer =
        new ProfilerTimer(
            metrics,
            MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCT_REVISION_BY_PRODUCT_ID_REVISION_ID,
            false);

    try {
      timer.start();
      final ProductRevisionData foundProductRevision =
          readDbMapper.load(ProductRevisionData.class, productId, revisionId);
      return foundProductRevision;
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(
          getThrottledRequestMessage(
              "getProductRevisionByProductIdAndRevisionId",
              "productId",
              productId,
              "revisionId",
              revisionId));
      MetricUtils.emitThrottledRequestMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCT_REVISION_BY_PRODUCT_ID_REVISION_ID);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(
          getAmazonServiceExceptionMessage(
              "getProductRevisionByProductIdAndRevisionId",
              "productId",
              productId,
              "revisionId",
              revisionId));
      MetricUtils.emitAmazonServiceExceptionMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCT_REVISION_BY_PRODUCT_ID_REVISION_ID);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(
          getRetryLimitExceededMessage(
              "getProductRevisionByProductIdAndRevisionId",
              "productId",
              productId,
              "revisionId",
              revisionId));
      MetricUtils.emitRetryLimitExceededMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCT_REVISION_BY_PRODUCT_ID_REVISION_ID);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }
  }

  /**
   * Gets a single product revision from DynamoDB using revisionId
   *
   * @param productRevision the product revision populated with revisionId
   * @return if found, the product revision corresponding to populated revisionId. otherwise, null.
   */
  public ProductRevisionData getProductRevisionByRevisionId(
      final ProductRevisionData productRevision) {
    final String revisionId = productRevision.getRevisionId();
    logger.debug("Querying for productRevision with revisionId " + revisionId);

    final ProductRevisionData key = new ProductRevisionData();
    key.setRevisionId(revisionId);

    final DynamoDBQueryExpression<ProductRevisionData> queryExpression =
        new DynamoDBQueryExpression<ProductRevisionData>()
            .withHashKeyValues(key)
            .withConsistentRead(false)
            .withSelect(Select.ALL_ATTRIBUTES)
            .withIndexName(ProductRevisionData.INDEX_BY_REVISION_ID);

    final ProfilerTimer timer =
        new ProfilerTimer(
            metrics, MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCT_REVISION_BY_REVISION_ID, false);
    List<ProductRevisionData> matches;

    try {
      timer.start();
      matches = readDbMapper.query(ProductRevisionData.class, queryExpression);
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(
          getThrottledRequestMessage("getProductRevisionByRevisionId", "revisionId", revisionId));
      MetricUtils.emitThrottledRequestMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCT_REVISION_BY_REVISION_ID);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(
          getAmazonServiceExceptionMessage(
              "getProductRevisionByRevisionId", "revisionId", revisionId));
      MetricUtils.emitAmazonServiceExceptionMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCT_REVISION_BY_REVISION_ID);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(
          getRetryLimitExceededMessage("getProductRevisionByRevisionId", "revisionId", revisionId));
      MetricUtils.emitRetryLimitExceededMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCT_REVISION_BY_REVISION_ID);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }

    logger.debug(
        String.format("Matches in %s found: %d", queryExpression.getIndexName(), matches.size()));
    if (matches.size() > 1) {
      throw new UniqueConstraintException(
          String.format(
              "More than one match for revisionId %s. Matches %d", revisionId, matches.size()));
    }
    return CollectionUtils.isEmpty(matches) ? null : matches.get(0);
  }

  /**
   * Gets a single product revision from DynamoDB using productId+externalRevisionId.
   *
   * @param productRevision the product revision populated with productId+externalRevisionId
   * @return if found, the product revision corresponding to populated productId+externalRevisionId.
   *     otherwise, null.
   */
  public ProductRevisionData getProductRevisionByProductIdAndExternalRevisionId(
      final ProductRevisionData productRevision) {
    final String productId = productRevision.getProductId();
    final String externalRevisionId = productRevision.getExternalRevisionId();
    logger.debug(
        String.format(
            "Querying for productRevision with productId %s and externalRevisionId %s.",
            productId, externalRevisionId));

    final ProfilerTimer timer =
        new ProfilerTimer(
            metrics,
            MetricConstants
                .METRIC_DYNAMO_DB_GET_PRODUCT_REVISION_BY_PRODUCT_ID_EXTERNAL_REVISION_ID,
            false);
    List<ProductRevisionData> matches;

    final Condition rangeKeyCondition =
        new Condition()
            .withComparisonOperator(ComparisonOperator.EQ)
            .withAttributeValueList(new AttributeValue().withS(externalRevisionId));

    final ProductRevisionData key = new ProductRevisionData();
    key.setProductId(productId);
    key.setExternalRevisionId(externalRevisionId);

    final DynamoDBQueryExpression<ProductRevisionData> queryExpression =
        new DynamoDBQueryExpression<ProductRevisionData>()
            .withHashKeyValues(key)
            .withRangeKeyCondition(ProductRevisionData.EXTERNAL_REVISION_ID, rangeKeyCondition)
            .withConsistentRead(false)
            .withSelect(Select.ALL_ATTRIBUTES)
            .withIndexName(ProductRevisionData.INDEX_BY_PRODUCT_ID_AND_EXTERNAL_REVISION_ID);

    try {
      timer.start();
      matches = readDbMapper.query(ProductRevisionData.class, queryExpression);

    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(
          getThrottledRequestMessage(
              "getProductRevisionByProductIdAndExternalRevisionId",
              "productId",
              productId,
              "externalRevisionId",
              externalRevisionId));
      MetricUtils.emitThrottledRequestMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCT_REVISION_BY_PRODUCT_ID_EXTERNAL_REVISION_ID);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(
          getAmazonServiceExceptionMessage(
              "getProductRevisionByProductIdAndExternalRevisionId",
              "productId",
              productId,
              "externalRevisionId",
              externalRevisionId));
      MetricUtils.emitAmazonServiceExceptionMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCT_REVISION_BY_PRODUCT_ID_EXTERNAL_REVISION_ID);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(
          getRetryLimitExceededMessage(
              "getProductRevisionByProductIdAndExternalRevisionId",
              "productId",
              productId,
              "externalRevisionId",
              externalRevisionId));
      MetricUtils.emitRetryLimitExceededMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCT_REVISION_BY_PRODUCT_ID_EXTERNAL_REVISION_ID);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }

    logger.debug(
        String.format("Matches in %s found: %d", queryExpression.getIndexName(), matches.size()));
    if (matches.size() > 1) {
      throw new UniqueConstraintException(
          String.format(
              "More than one match for productId %s and externalRevisionId %s. Matches %d",
              productId, externalRevisionId, matches.size()));
    }

    return CollectionUtils.isEmpty(matches) ? null : matches.get(0);
  }

  /**
   * Gets a list of product revisions from DynamoDB using productId. The product revisions are
   * sorted by revision. and filtered based on conditions and query filters.
   *
   * @param productId the productId to search on
   * @param keyConditionMap the rangeKeyConditions for the DynamoDB query
   * @param queryFilterMap the queryFilter for the DynamoDB query
   * @param paginationParameters the optional pagination query parameters. if null, simply retrieve
   *     all results
   * @return paginated response of product revisions
   */
  public PagedResponse<ProductRevisionData> getProductRevisionsByProductId(
      final String productId,
      final Map<String, Condition> keyConditionMap,
      final Map<String, Condition> queryFilterMap,
      final DynamoPagingQueryParameters paginationParameters) {
    if (StringUtils.isEmpty(productId)) {
      throw new IllegalArgumentException("productId cannot be empty");
    }
    logger.debug("Querying for productRevisions with productId " + productId);

    final ProductRevisionData key = new ProductRevisionData();
    key.setProductId(productId);

    final DynamoDBQueryExpression<ProductRevisionData> queryExpression =
        new DynamoDBQueryExpression<ProductRevisionData>()
            .withHashKeyValues(key)
            .withConsistentRead(false)
            .withSelect(Select.ALL_ATTRIBUTES)
            .withRangeKeyConditions(keyConditionMap)
            .withQueryFilter(queryFilterMap)
            .withScanIndexForward(false)
            .withIndexName(ProductRevisionData.INDEX_BY_PRODUCT_ID_AND_CREATED_TIMESTAMP);

    // To optimize record retrieval - Updates the number of records scanned per query before
    // applying filters
    // if requested size is lower than default. This reduces the number of database queries needed
    // to fill a page.
    // If limit is not set here then it will be set to paginationParameters.pageSize in
    // DynamoCursorPager.retrievePage
    if (paginationParameters != null
        && paginationParameters.getPageSize()
            < GET_REVISIONS_BY_PRODUCT_ID_QUERY_DEFAULT_PAGE_SIZE) {
      queryExpression.withLimit(GET_REVISIONS_BY_PRODUCT_ID_QUERY_DEFAULT_PAGE_SIZE);
    }

    final ProfilerTimer timer =
        new ProfilerTimer(
            metrics, MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCT_REVISIONS_BY_PRODUCT_ID, false);
    PagedResponse<ProductRevisionData> response;

    try {
      timer.start();
      response = paginator.retrievePage(queryExpression, paginationParameters);

    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(
          getThrottledRequestMessage("getProductRevisionsByProductId", "productId", productId));
      MetricUtils.emitThrottledRequestMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCT_REVISIONS_BY_PRODUCT_ID);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(
          getAmazonServiceExceptionMessage(
              "getProductRevisionsByProductId", "productId", productId));
      MetricUtils.emitAmazonServiceExceptionMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCT_REVISIONS_BY_PRODUCT_ID);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(
          getRetryLimitExceededMessage("getProductRevisionsByProductId", "productId", productId));
      MetricUtils.emitRetryLimitExceededMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCT_REVISIONS_BY_PRODUCT_ID);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }

    logger.debug(
        String.format(
            "Matches in %s found: %d", queryExpression.getIndexName(), response.getPageSize()));
    return response;
  }
}




// PagedResponse.java
package com.amazon.adg.product.cursor.paging;

import java.util.List;

/**
 * Contains the details of the paged response such as page size and lastEvaluatedResult.
 * LastEvaluatedResult is essentially the pointer to the last record we put in the page. It allows
 * us to resume paging.
 */
public class PagedResponse<T> {

  private List<T> pagedResults;
  private int pageSize;
  private T lastEvaluatedResult;

  public List<T> getPagedResults() {
    return pagedResults;
  }

  public void setPagedResults(final List<T> pagedResults) {
    this.pagedResults = pagedResults;
  }

  public T getLastEvaluatedResult() {
    return lastEvaluatedResult;
  }

  public void setLastEvaluatedResult(final T lastEvaluatedResult) {
    this.lastEvaluatedResult = lastEvaluatedResult;
  }

  public int getPageSize() {
    return pageSize;
  }

  public void setPageSize(final int pageSize) {
    this.pageSize = pageSize;
  }

  public boolean hasMoreResults() {
    return lastEvaluatedResult != null;
  }
}




// Builder.java
package com.amazon.adg.product.service.error;

/**
 * A generic class that's used to indicate a failure of processing an objectValue, e.g. a failure to
 * update a product.
 */
public class Failure<T> {
  // objectValue that we failed to process
  private T object;
  private String code;
  private String message;

  public T getObject() {
    return object;
  }

  public void setObject(T object) {
    this.object = object;
  }

  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  /** Statically creates a builder instance for Failure. */
  public static <E> Builder<E> builder(E object) {
    return new Builder<>();
  }

  /** Builder for instances of Failure. */
  public static class Builder<T> {
    private T objectValue;
    private String codeValue;
    private String messageValue;

    public Builder<T> withObject(T object) {
      this.objectValue = object;
      return this;
    }

    public Builder<T> withCode(String code) {
      this.codeValue = code;
      return this;
    }

    public Builder<T> withMessage(String message) {
      this.messageValue = message;
      return this;
    }

    /**
     * Sets the fields of the given instances to the corresponding values recorded when calling the
     * "with*" methods.
     *
     * @param instance The instance to be populated.
     */
    protected void populate(Failure<T> instance) {
      instance.setObject(this.objectValue);
      instance.setCode(this.codeValue);
      instance.setMessage(this.messageValue);
    }

    /**
     * Builds an instance of Failure.
     *
     * <p>The built objectValue has its fields set to the values given when calling the "with*"
     * methods of this builder.
     */
    public Failure<T> build() {
      Failure<T> instance = new Failure<>();
      populate(instance);
      return instance;
    }
  }
}




// VendorDao.java
package com.amazon.adg.product.dao;

import static com.amazon.adg.product.utils.LoggerUtils.getAmazonServiceExceptionMessage;
import static com.amazon.adg.product.utils.LoggerUtils.getConditionalCheckExceptionMessage;
import static com.amazon.adg.product.utils.LoggerUtils.getRetryLimitExceededMessage;
import static com.amazon.adg.product.utils.LoggerUtils.getThrottledRequestMessage;

import com.amazon.adg.common.util.LocalDateTimeUtil;
import com.amazon.adg.product.data.Vendor;
import com.amazon.adg.product.data.VendorStateEnum;
import com.amazon.adg.product.metric.MetricConstants;
import com.amazon.adg.product.service.model.InternalServiceException;
import com.amazon.adg.product.utils.MetricUtils;
import com.amazon.coral.metrics.Metrics;
import com.amazon.mas.commons.coral.support.metrics.ProfilerTimer;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.SdkClientException;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBQueryExpression;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.ComparisonOperator;
import com.amazonaws.services.dynamodbv2.model.Condition;
import com.amazonaws.services.dynamodbv2.model.ConditionalCheckFailedException;
import com.amazonaws.services.dynamodbv2.model.ProvisionedThroughputExceededException;
import com.amazonaws.services.dynamodbv2.transactions.Transaction;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;
import javax.measure.unit.Unit;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/** DAO for working with Vendor objects and DynamoDB. */
public class VendorDao extends AbstractDao {

  private static final Logger logger = LogManager.getLogger(VendorDao.class);

  public VendorDao(
      final DynamoDBMapper readDbMapper,
      final DynamoDBMapper writeDbMapper,
      final Metrics metrics) {
    super(readDbMapper, writeDbMapper, metrics);
  }

  public void create(final Vendor vendor) {
    create(vendor, null);
  }

  public void create(final Vendor vendor, final Transaction transaction) {
    if (vendor == null) {
      throw new IllegalArgumentException("vendor cannot be empty; must have name");
    }
    if (StringUtils.isEmpty(vendor.getName())) {
      throw new IllegalArgumentException("vendor name cannot be empty");
    }
    if (StringUtils.isEmpty(vendor.getVendorId())) {
      vendor.setVendorId(UUID.randomUUID().toString());
    }
    vendor.setModifiedTimestamp(LocalDateTimeUtil.nowUtc());
    vendor.setState(VendorStateEnum.ACTIVE.name());

    verifyIfParentVendorExists(vendor);
    verifyExternalVendorIdentifierValue(Vendor.MAS_VENDOR_ID, null, vendor.getMasVendorId());
    verifyExternalVendorIdentifierValue(Vendor.MAS_VENDOR_CODE, null, vendor.getMasVendorCode());

    logger.debug("Saving new " + vendor.debugString());

    final boolean isTransaction = transaction != null;

    final ProfilerTimer timer =
        new ProfilerTimer(
            metrics,
            isTransaction
                ? MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR_TRANSACTION
                : MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR,
            false);

    try {
      timer.start();

      if (isTransaction) {
        transaction.save(vendor);
      } else {
        writeDbMapper.save(vendor);
      }
    } catch (final ConditionalCheckFailedException ex) {
      logger.error(
          getConditionalCheckExceptionMessage("createVendor", "vendor", vendor.toString()));
      MetricUtils.emitConditionalCheckFailedExceptionMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR);
      throw ex;
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(getThrottledRequestMessage("createVendor", "vendor", vendor.toString()));
      MetricUtils.emitThrottledRequestMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(getAmazonServiceExceptionMessage("createVendor", "vendor", vendor.toString()));
      MetricUtils.emitAmazonServiceExceptionMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_CREATE_VENDOR);
      throw ex;
    } finally {
      timer.stop();
    }
  }

  /**
   * Enforces single parent vendor rule for the vendor hierarchy, only if the vendor being created
   * is a parent vendor
   *
   * @param vendor
   */
  private void verifyIfParentVendorExists(final Vendor vendor) {
    if (StringUtils.isBlank(vendor.getMasVendorCode())
        && StringUtils.isNotBlank(vendor.getMasVendorId())) {
      // the new vendor is a parent vendor
      // check if a parent entry already exists
      final Optional<Vendor> optionalVendor =
          Optional.ofNullable(getVendorByMasVendorId(vendor.getMasVendorId()));
      optionalVendor.ifPresent(
          existingVendor -> {
            // parent vendor is the one without the masVendorCode
            if (StringUtils.isBlank(existingVendor.getMasVendorCode())) {
              throw new VendorAlreadyExistsException(
                  String.format(
                      "Parent vendor %s already exists with masVendorId %s",
                      existingVendor.getVendorId(), vendor.getMasVendorId()));
            }
          });
    }
  }

  /**
   * Enforces "unique" on the secondary indexes.
   *
   * @param externalIdTypeField the identifier field name (e.g. constant from data class like
   *     "MASVendorId")
   * @param currentValue the current value
   * @param newValue the proposed new value
   */
  protected void verifyExternalVendorIdentifierValue(
      final String externalIdTypeField, final String currentValue, final String newValue) {
    verifyExternalVendorIdentifierValue(externalIdTypeField, currentValue, newValue, false);
  }

  protected void verifyExternalVendorIdentifierValue(
      final String externalIdTypeField,
      final String currentValue,
      final String newValue,
      final boolean overwriteOk) {
    if (currentValue == null && newValue == null) {
      // no value for BOTH is fine
      return;
    }

    if (!overwriteOk && !StringUtils.isEmpty(currentValue) && !currentValue.equals(newValue)) {
      throw new IllegalArgumentException(
          String.format("Cannot change %s once it has already been set.", externalIdTypeField));
    }

    if (StringUtils.isEmpty(currentValue)) {
      if (StringUtils.isBlank(newValue)) {
        throw new IllegalArgumentException(
            "Empty string is not a valid value; use null or a non-empty string.");
      }
      // setting to new valid, value, verify not present ...
      if (Vendor.MAS_VENDOR_ID.equals(externalIdTypeField)) {
        // no checks needed for uniquesness for masVendorId
        return;
      } else if (Vendor.MAS_VENDOR_CODE.equals(externalIdTypeField)) {
        final Optional<Vendor> optionalVendor =
            Optional.ofNullable(getVendorByMasVendorCode(newValue));
        optionalVendor.ifPresent(
            vendor -> {
              throw new VendorAlreadyExistsException(
                  String.format(
                      "Vendor %s already exists with masVendorCode %s",
                      vendor.getVendorId(), newValue));
            });
      } else {
        throw new IllegalArgumentException("Unrecognized MAS vendor field? " + externalIdTypeField);
      }
    }
  }

  public void update(final Vendor vendor) {
    update(vendor, null, false);
  }

  public void update(final Vendor vendor, final Transaction transaction) {
    update(vendor, transaction, false);
  }

  public void update(
      final Vendor vendor, final Transaction transaction, final boolean overwriteOk) {
    if (vendor == null) {
      throw new IllegalArgumentException("vendor cannot be empty");
    }
    if (StringUtils.isEmpty(vendor.getVendorId())) {
      throw new IllegalArgumentException("vendorId cannot be empty");
    }
    if (StringUtils.isEmpty(vendor.getName())) {
      throw new IllegalArgumentException("vendor name cannot be empty");
    }
    vendor.setModifiedTimestamp(LocalDateTimeUtil.nowUtc());

    final Vendor foundVendor = getVendor(vendor, false);
    if (foundVendor == null) {
      throw new VendorNotFoundException(
          "Unable to find matching vendor to update for vendor " + vendor.getVendorId() + ".");
    }
    logger.debug("found matching vendor: " + vendor);

    verifyExternalVendorIdentifierValue(
        Vendor.MAS_VENDOR_ID, foundVendor.getMasVendorId(), vendor.getMasVendorId(), overwriteOk);
    verifyExternalVendorIdentifierValue(
        Vendor.MAS_VENDOR_CODE,
        foundVendor.getMasVendorCode(),
        vendor.getMasVendorCode(),
        overwriteOk);

    if (!StringUtils.isEmpty(vendor.getState())) {
      // will validate and normalize the string
      vendor.setState(VendorStateEnum.valueOf(vendor.getState()).name());
    } else {
      // explicitly using the previous state
      vendor.setState(foundVendor.getState());
    }

    if (transaction != null && vendor.getVersion() == null) {
      vendor.setVersion(foundVendor.getVersion());
    }

    logger.debug("Saving updated vendor: " + vendor.debugString());

    final boolean isTransaction = transaction != null;

    final ProfilerTimer timer =
        new ProfilerTimer(
            metrics,
            isTransaction
                ? MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR_TRANSACTION
                : MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR,
            false);

    try {
      timer.start();

      if (isTransaction) {
        transaction.save(vendor);
      } else {
        writeDbMapper.save(vendor);
      }
    } catch (final ConditionalCheckFailedException ex) {
      logger.error(
          getConditionalCheckExceptionMessage("updateVendor", "vendor", vendor.toString()));
      MetricUtils.emitConditionalCheckFailedExceptionMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR);
      throw ex;
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(getThrottledRequestMessage("updateVendor", "vendor", vendor.toString()));
      MetricUtils.emitThrottledRequestMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(getAmazonServiceExceptionMessage("updateVendor", "vendor", vendor.toString()));
      MetricUtils.emitAmazonServiceExceptionMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_UPDATE_VENDOR);
      throw ex;
    } finally {
      timer.stop();
    }
  }

  /**
   * Gets a vendor from any identifiers specified in the vendorLookupValues, validating that request
   * identifiers are consistent with the result.
   *
   * @param vendorLookupValues
   * @return
   * @throws IllegalArgumentException if the request vendor identifiers are inconsistent with the
   *     result.
   */
  public Vendor getVendor(final Vendor vendorLookupValues) {
    return getVendor(vendorLookupValues, true);
  }

  /**
   * Gets a vendor from any identifiers specified in the vendorLookupValues. When forceConsistency
   * is true, it validates that request identifiers are consistent with the result.
   *
   * @param vendorLookupValues
   * @param forceConsistency
   * @return
   * @throws IllegalArgumentException if forceConsistency is true and the request vendor identifiers
   *     are inconsistent with the result.
   */
  public Vendor getVendor(final Vendor vendorLookupValues, final boolean forceConsistency) {
    if (vendorLookupValues == null) {
      throw new IllegalArgumentException("vendor lookup values cannot be null");
    }

    final Vendor result;
    if (StringUtils.isNotBlank(vendorLookupValues.getVendorId())) {
      result = getVendorByVendorId(vendorLookupValues.getVendorId());
    } else if (StringUtils.isNotBlank(vendorLookupValues.getMasVendorCode())) {
      result = getVendorByMasVendorCode(vendorLookupValues.getMasVendorCode());
    } else if (StringUtils.isNotBlank(vendorLookupValues.getMasVendorId())) {
      result = getVendorByMasVendorId(vendorLookupValues.getMasVendorId());
    } else {
      throw new IllegalArgumentException(
          "vendor lookup values cannot be empty; one of the identifier fields needs to be populated (e.g. vendorId)");
    }

    if (forceConsistency) {
      validateVendorConsistency(vendorLookupValues, result);
    }
    return result;
  }

  /**
   * This validates that a request did not refer to multiple vendors using the different vendor
   * identifiers.
   *
   * @param vendorLookup
   * @param result
   */
  private void validateVendorConsistency(final Vendor vendorLookup, final Vendor result) {
    if (vendorLookup == null || result == null) {
      return;
    }
    validateConsistency(Vendor.VENDOR_ID, vendorLookup.getVendorId(), result.getVendorId());
    validateConsistency(
        Vendor.MAS_VENDOR_CODE, vendorLookup.getMasVendorCode(), result.getMasVendorCode());
    validateConsistency(
        Vendor.MAS_VENDOR_ID, vendorLookup.getMasVendorId(), result.getMasVendorId());
  }

  private void validateConsistency(
      final String fieldName, final String lookupValue, final String result) {
    if (StringUtils.isNotBlank(lookupValue)
        && StringUtils.isNotBlank(result)
        && !lookupValue.equals(result)) {
      throw new IllegalArgumentException(
          String.format(
              "Input %s (%s) does not match resulting %s (%s)",
              fieldName, lookupValue, fieldName, result));
    }
  }

  public Vendor getVendorByVendorId(String vendorId) {
    if (StringUtils.isEmpty(vendorId)) {
      throw new IllegalArgumentException("vendorId cannot be empty");
    }

    logger.debug("Loading vendor for vendorId " + vendorId + " ...");

    final ProfilerTimer timer =
        new ProfilerTimer(metrics, MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_VENDOR_ID, false);
    Vendor vendor;

    try {
      timer.start();
      vendor = readDbMapper.load(Vendor.class, vendorId);
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(getThrottledRequestMessage("getVendorByVendorId", "vendorId", vendorId));
      MetricUtils.emitThrottledRequestMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_VENDOR_ID);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(getAmazonServiceExceptionMessage("getVendorByVendorId", "vendorId", vendorId));
      MetricUtils.emitAmazonServiceExceptionMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_VENDOR_ID);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(getRetryLimitExceededMessage("getVendorByVendorId", "vendorId", vendorId));
      MetricUtils.emitRetryLimitExceededMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_VENDOR_ID);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }

    logger.debug("Found: " + vendor);
    return vendor;
  }

  /**
   * As multiple adg vendors will have the same masVendorId (one parent and multiple child vendors),
   * we will only return the parent adg vendor when querying with masVendorId.
   *
   * @param masVendorId
   * @return
   */
  public Vendor getVendorByMasVendorId(final String masVendorId) {
    if (StringUtils.isEmpty(masVendorId)) {
      throw new IllegalArgumentException("masVendorId cannot be empty");
    }

    logger.debug("Querying for vendor with masVendorId " + masVendorId + " ...");

    final Vendor vendorKey = new Vendor();
    vendorKey.setMasVendorId(masVendorId);

    final DynamoDBQueryExpression<Vendor> queryExpression =
        new DynamoDBQueryExpression<Vendor>()
            .withHashKeyValues(vendorKey)
            .withConsistentRead(false)
            .withIndexName(Vendor.INDEX_BY_MAS_VENDOR_ID);

    final ProfilerTimer timer =
        new ProfilerTimer(
            metrics, MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_ID, false);
    List<Vendor> vendors;

    try {
      timer.start();
      vendors = readDbMapper.query(Vendor.class, queryExpression);

    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(
          getThrottledRequestMessage("getVendorByMasVendorId", "masVendorId", masVendorId));
      MetricUtils.emitThrottledRequestMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_ID);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(
          getAmazonServiceExceptionMessage("getVendorByMasVendorId", "masVendorId", masVendorId));
      MetricUtils.emitAmazonServiceExceptionMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_ID);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(
          getRetryLimitExceededMessage("getVendorByMasVendorId", "masVendorId", masVendorId));
      MetricUtils.emitRetryLimitExceededMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_ID);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }

    logger.debug("Matches in " + queryExpression.getIndexName() + " found: " + vendors.size());
    if (vendors.size() == 1) {
      // If only one entry, then return that entry (backwards compatible)
      return getVendorByVendorId(vendors.get(0).getVendorId());
    } else if (vendors.size() > 1) {
      // Multiple entries mean one of them probably is a parent.
      // As parent adg vendor will not have a masVendorCode, we are filtering on masVendorCode
      final List<Vendor> parentVendors =
          vendors.stream()
              .filter(vendor -> StringUtils.isBlank(vendor.getMasVendorCode()))
              .collect(Collectors.toList());
      if (parentVendors.size() == 1) {
        return getVendorByVendorId(parentVendors.get(0).getVendorId());
      } else if (parentVendors.size() > 1) {
        metrics.addCount(MetricConstants.METRIC_MULTIPLE_PARENT_VENDORS_FOUND, 1, Unit.ONE);
        throw new UniqueConstraintException(
            String.format(
                "More than one match for parent masVendorId %s? Matches: %d",
                masVendorId, parentVendors.size()));
      } else {
        metrics.addCount(MetricConstants.METRIC_NO_PARENT_VENDOR_FOUND, 1, Unit.ONE);
        final Vendor newParentVendor = createParentVendor();
        final Vendor updateParentVendor = getVendor(newParentVendor);
        updateParentVendor.setMasVendorId(masVendorId);
        updateParentVendor.setVendorId(newParentVendor.getVendorId());
        updateParentVendor.setName("MASTER");
        update(updateParentVendor);
        logger.warn(
            String.format(
                "Found %d vendors with masVendorId %s and different masVendorCodes. But no parent vendor. New one was created: %s",
                vendors.size(), masVendorId, newParentVendor.getVendorId()));
        return updateParentVendor;
      }
    } else {
      return null;
    }
  }

  public Vendor getVendorByMasVendorCode(final String masVendorCode) {
    if (StringUtils.isEmpty(masVendorCode)) {
      throw new IllegalArgumentException("masVendorCode cannot be empty");
    }

    logger.debug("Querying for vendor with masVendorCode " + masVendorCode + " ...");

    final Vendor vendorKey = new Vendor();
    vendorKey.setMasVendorCode(masVendorCode);

    final DynamoDBQueryExpression<Vendor> queryExpression =
        new DynamoDBQueryExpression<Vendor>()
            .withHashKeyValues(vendorKey)
            .withConsistentRead(false)
            .withIndexName(Vendor.INDEX_BY_MAS_VENDOR_CODE);

    final ProfilerTimer timer =
        new ProfilerTimer(
            metrics, MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_CODE, false);
    List<Vendor> vendors;

    try {
      timer.start();
      vendors = readDbMapper.query(Vendor.class, queryExpression);
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(
          getThrottledRequestMessage("getVendorByMasVendorCode", "masVendorCode", masVendorCode));
      MetricUtils.emitThrottledRequestMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_CODE);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(
          getAmazonServiceExceptionMessage(
              "getVendorByMasVendorCode", "masVendorCode", masVendorCode));
      MetricUtils.emitAmazonServiceExceptionMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_CODE);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(
          getRetryLimitExceededMessage("getVendorByMasVendorCode", "masVendorCode", masVendorCode));
      MetricUtils.emitRetryLimitExceededMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_VENDOR_BY_MAS_VENDOR_CODE);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }

    logger.debug("Matches in " + queryExpression.getIndexName() + " found: " + vendors.size());
    if (vendors.size() == 1) {
      return getVendorByVendorId(vendors.get(0).getVendorId());
    }
    if (vendors.size() > 1) {
      throw new UniqueConstraintException(
          "More than one match for masVendorId " + masVendorCode + "? Matches: " + vendors.size());
    } else {
      return null;
    }
  }

  public Vendor createParentVendor() {
    final Vendor vendor = new Vendor();
    vendor.setName("MASTER");
    create(vendor);
    return vendor;
  }

  /**
   * Update vendor if you find the id in the database, otherwise create. While updating, we do not
   * overwrite existing values, if you need to overwrite values then call update().
   *
   * @param vendor
   * @param transaction
   * @return
   */
  public Vendor createOrUpdateVendor(final Vendor vendor, final Transaction transaction) {
    final Vendor foundVendor = getVendor(vendor, false);
    if (foundVendor == null || StringUtils.isBlank(foundVendor.getVendorId())) {
      create(vendor, transaction);
    } else {
      vendor.setVendorId(foundVendor.getVendorId());
      update(vendor, transaction, false);
    }
    return getVendor(vendor, false);
  }

  public static class VendorSearchCriteria {
    private String name;

    public String getName() {
      return name;
    }

    public void setName(final String name) {
      this.name = name;
    }
  }

  public static class VendorFilter {
    private VendorStateEnum state;

    public VendorStateEnum getState() {
      return state;
    }

    public void setState(final VendorStateEnum state) {
      this.state = state;
    }
  }

  /**
   * Do NOT use lightly, as this is a full table scan.
   *
   * @param criteria
   * @param filter
   * @return
   */
  public List<Vendor> searchVendors(
      final VendorSearchCriteria criteria, final VendorFilter filter) {
    if (criteria == null) {
      throw new IllegalArgumentException("vendor search criteria cannot be null");
    }
    final String vendorName = criteria.getName();
    if (StringUtils.isEmpty(vendorName)) {
      throw new IllegalArgumentException(
          "vendor search criteria cannot be empty; one of the criteria needs to be populated (e.g. name)");
    }

    final Condition nameCondition =
        new Condition()
            .withComparisonOperator(ComparisonOperator.CONTAINS)
            .withAttributeValueList(new AttributeValue().withS(vendorName));
    final Map<String, Condition> scanFilter = new LinkedHashMap<>();
    scanFilter.put(Vendor.VENDOR_NAME, nameCondition);

    final DynamoDBScanExpression scanExpression =
        new DynamoDBScanExpression().withScanFilter(scanFilter).withConsistentRead(false);

    final ProfilerTimer timer =
        new ProfilerTimer(metrics, MetricConstants.METRIC_DYNAMO_DB_SEARCH_VENDORS, false);
    List<Vendor> vendors;

    try {
      timer.start();
      vendors = readDbMapper.scan(Vendor.class, scanExpression);
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(getThrottledRequestMessage("searchVendors", "vendorName", vendorName));
      MetricUtils.emitThrottledRequestMetric(MetricConstants.METRIC_DYNAMO_DB_SEARCH_VENDORS);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(getAmazonServiceExceptionMessage("searchVendors", "vendorName", vendorName));
      MetricUtils.emitAmazonServiceExceptionMetric(MetricConstants.METRIC_DYNAMO_DB_SEARCH_VENDORS);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(getRetryLimitExceededMessage("searchVendors", "vendorName", vendorName));
      MetricUtils.emitRetryLimitExceededMetric(MetricConstants.METRIC_DYNAMO_DB_SEARCH_VENDORS);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }

    logger.debug("Matches found: " + vendors.size());
    return vendors;
  }
}




// PersistenceException.java
package com.amazon.adg.product.dao;

/** Base class for exceptions that occur in the DAO. */
public class PersistenceException extends RuntimeException {

  public PersistenceException() {}

  public PersistenceException(String message) {
    super(message);
  }

  public PersistenceException(String message, Throwable cause) {
    super(message, cause);
  }

  public PersistenceException(Throwable cause) {
    super(cause);
  }

  public PersistenceException(
      String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
    super(message, cause, enableSuppression, writableStackTrace);
  }
}




// DomainNotFoundException.java
package com.amazon.adg.product.dao;

public class DomainNotFoundException extends PersistenceException {

  public DomainNotFoundException() {}

  public DomainNotFoundException(String message) {
    super(message);
  }

  public DomainNotFoundException(String message, Throwable cause) {
    super(message, cause);
  }

  public DomainNotFoundException(Throwable cause) {
    super(cause);
  }

  public DomainNotFoundException(
      String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
    super(message, cause, enableSuppression, writableStackTrace);
  }
}




// Failure.java
package com.amazon.adg.product.service.error;

/**
 * A generic class that's used to indicate a failure of processing an objectValue, e.g. a failure to
 * update a product.
 */
public class Failure<T> {
  // objectValue that we failed to process
  private T object;
  private String code;
  private String message;

  public T getObject() {
    return object;
  }

  public void setObject(T object) {
    this.object = object;
  }

  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  /** Statically creates a builder instance for Failure. */
  public static <E> Builder<E> builder(E object) {
    return new Builder<>();
  }

  /** Builder for instances of Failure. */
  public static class Builder<T> {
    private T objectValue;
    private String codeValue;
    private String messageValue;

    public Builder<T> withObject(T object) {
      this.objectValue = object;
      return this;
    }

    public Builder<T> withCode(String code) {
      this.codeValue = code;
      return this;
    }

    public Builder<T> withMessage(String message) {
      this.messageValue = message;
      return this;
    }

    /**
     * Sets the fields of the given instances to the corresponding values recorded when calling the
     * "with*" methods.
     *
     * @param instance The instance to be populated.
     */
    protected void populate(Failure<T> instance) {
      instance.setObject(this.objectValue);
      instance.setCode(this.codeValue);
      instance.setMessage(this.messageValue);
    }

    /**
     * Builds an instance of Failure.
     *
     * <p>The built objectValue has its fields set to the values given when calling the "with*"
     * methods of this builder.
     */
    public Failure<T> build() {
      Failure<T> instance = new Failure<>();
      populate(instance);
      return instance;
    }
  }
}




// ProductDao.java
package com.amazon.adg.product.dao;

import static com.amazon.adg.coral.tenant.metrics.Constants.ADG_TENANT;
import static com.amazon.adg.coral.tenant.metrics.Constants.ADG_UPSTREAM_SERVICE;
import static com.amazon.adg.product.utils.LoggerUtils.getAmazonServiceExceptionMessage;
import static com.amazon.adg.product.utils.LoggerUtils.getConditionalCheckExceptionMessage;
import static com.amazon.adg.product.utils.LoggerUtils.getRetryLimitExceededMessage;
import static com.amazon.adg.product.utils.LoggerUtils.getThrottledRequestMessage;

import com.amazon.adg.common.util.LocalDateTimeUtil;
import com.amazon.adg.product.cursor.paging.DynamoCursorPager;
import com.amazon.adg.product.cursor.paging.DynamoPagingQueryParameters;
import com.amazon.adg.product.cursor.paging.PagedRequest;
import com.amazon.adg.product.cursor.paging.PagedResponse;
import com.amazon.adg.product.data.Product;
import com.amazon.adg.product.metric.MetricConstants;
import com.amazon.adg.product.service.context.ADGProductContextThreadInstance;
import com.amazon.adg.product.service.model.InternalServiceException;
import com.amazon.adg.product.utils.MetricUtils;
import com.amazon.coral.metrics.Metrics;
import com.amazon.coral.metrics.helper.Dimension;
import com.amazon.mas.commons.coral.support.metrics.Profiler;
import com.amazon.mas.commons.coral.support.metrics.ProfilerTimer;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.SdkClientException;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBQueryExpression;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.ComparisonOperator;
import com.amazonaws.services.dynamodbv2.model.Condition;
import com.amazonaws.services.dynamodbv2.model.ConditionalCheckFailedException;
import com.amazonaws.services.dynamodbv2.model.ProvisionedThroughputExceededException;
import com.amazonaws.services.dynamodbv2.model.Select;
import com.amazonaws.services.dynamodbv2.transactions.Transaction;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.stream.Collectors;
import javax.measure.unit.Unit;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/** DAO for working with Product objects and DynamoDB. */
public class ProductDao extends AbstractDao {

  private static final Logger logger = LogManager.getLogger(ProductDao.class);

  private final DynamoCursorPager paginator;

  public ProductDao(
      final DynamoDBMapper readDbMapper,
      final DynamoDBMapper writeDbMapper,
      final Metrics metrics) {
    super(readDbMapper, writeDbMapper, metrics);
    this.paginator = new DynamoCursorPager(Product.class, readDbMapper);
  }

  public void create(final Product product, final Transaction transaction) {
    product.setModifiedTimestamp(LocalDateTimeUtil.nowUtc());
    logger.debug("Saving new " + product.debugString());

    final boolean isTransaction = transaction != null;

    final ProfilerTimer timer =
        new ProfilerTimer(
            metrics,
            isTransaction
                ? MetricConstants.METRIC_DYNAMO_DB_CREATE_PRODUCT_TRANSACTION
                : MetricConstants.METRIC_DYNAMO_DB_CREATE_PRODUCT,
            false);

    try {
      timer.start();

      if (isTransaction) {
        transaction.save(product);
      } else {
        writeDbMapper.save(product);
      }
    } catch (final ConditionalCheckFailedException ex) {
      logger.error(
          getConditionalCheckExceptionMessage("createProduct", "product", product.toString()));
      MetricUtils.emitConditionalCheckFailedExceptionMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_CREATE_PRODUCT_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_CREATE_PRODUCT);
      throw ex;
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(getThrottledRequestMessage("createProduct", "product", product.toString()));
      MetricUtils.emitThrottledRequestMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_CREATE_PRODUCT_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_CREATE_PRODUCT);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(
          getAmazonServiceExceptionMessage("createProduct", "product", product.toString()));
      MetricUtils.emitAmazonServiceExceptionMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_CREATE_PRODUCT_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_CREATE_PRODUCT);
      throw ex;
    } finally {
      timer.stop();
    }
  }

  public void update(final Product product, final Transaction transaction) {
    product.setModifiedTimestamp(LocalDateTimeUtil.nowUtc());

    if (product.getVersion() == null) {
      final Product foundProduct = getProduct(product);
      product.setVersion(foundProduct.getVersion());
    }

    logger.debug("Saving updated product: " + product.debugString());

    final boolean isTransaction = transaction != null;

    final ProfilerTimer timer =
        new ProfilerTimer(
            metrics,
            isTransaction
                ? MetricConstants.METRIC_DYNAMO_DB_UPDATE_PRODUCT_TRANSACTION
                : MetricConstants.METRIC_DYNAMO_DB_UPDATE_PRODUCT,
            false);

    try {
      timer.start();

      if (isTransaction) {
        transaction.save(product);
      } else {
        writeDbMapper.save(product);
      }
    } catch (final ConditionalCheckFailedException ex) {
      logger.error(
          getConditionalCheckExceptionMessage("updateProduct", "product", product.toString()));
      MetricUtils.emitConditionalCheckFailedExceptionMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_UPDATE_PRODUCT_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_UPDATE_PRODUCT);
      throw ex;
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(getThrottledRequestMessage("updateProduct", "product", product.toString()));
      MetricUtils.emitThrottledRequestMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_UPDATE_PRODUCT_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_UPDATE_PRODUCT);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(
          getAmazonServiceExceptionMessage("updateProduct", "product", product.toString()));
      MetricUtils.emitAmazonServiceExceptionMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_UPDATE_PRODUCT_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_UPDATE_PRODUCT);
      throw ex;
    } finally {
      timer.stop();
    }
  }

  /**
   * Gets a single product from the DB using its productId, asin, vendorId+sku or
   * vendorId+externalProductId.
   *
   * @param product - product with productId, asin, vendorId+sku or vendorId+externalProductId
   *     populated.
   * @return - returns null if product is not found, otherwise returns a populated product from db
   */
  public Product getProduct(final Product product) {
    if (product == null) {
      return null;
    }

    if (StringUtils.isNotBlank(product.getProductId())) {
      return getProductByProductId(product);
    }
    if (StringUtils.isNotBlank(product.getAsin())) {
      return getProductByAsin(product);
    }
    if (StringUtils.isNotBlank(product.getVendorId())
        && StringUtils.isNotBlank(product.getVendorSku())) {
      return getProductBySkuAndVendor(product);
    }
    if (StringUtils.isNotBlank(product.getVendorId())
        && StringUtils.isNotBlank(product.getExternalProductId())) {
      return getProductByExternalIdAndVendor(product);
    }

    throw new IllegalArgumentException(
        "Received a product with insufficient data. A productId, asin, vendor+vendorSku or vendor+externalProductId is required.");
  }

  /**
   * Gets products from either productId, asin, sku + vendorId or externalProductId + vendorId
   *
   * @param products - products with productId, asin, vendorId + sku or vendorId + externalProductId
   *     populated.
   * @return - returns an empty list if products are not found (or there are none), otherwise
   *     returns a list of populated products from the db
   */
  public List<Product> getProducts(final List<Product> products) {
    final List<Product> productsFromProductId = new ArrayList<>(products.size());
    final List<Product> productsFromAsin = new ArrayList<>(products.size());
    final List<Product> productsFromSkuAndVendor = new ArrayList<>(products.size());
    final List<Product> productsFromExternalIdAndVendor = new ArrayList<>(products.size());

    for (final Product product : products) {
      if (StringUtils.isNotBlank(product.getProductId())) {
        productsFromProductId.add(product);
        continue;
      }
      if (StringUtils.isNotBlank(product.getAsin())) {
        productsFromAsin.add(product);
        continue;
      }
      if (StringUtils.isNotBlank(product.getVendorId())
          && StringUtils.isNotBlank(product.getVendorSku())) {
        productsFromSkuAndVendor.add(product);
        continue;
      }
      if (StringUtils.isNotBlank(product.getVendorId())
          && StringUtils.isNotBlank(product.getExternalProductId())) {
        productsFromExternalIdAndVendor.add(product);
        continue;
      }

      throw new IllegalArgumentException(
          "Received a product with insufficient data. A productId, asin, vendor and vendorSku or vendor and externalProductId is required.");
    }

    final List<Product> compiledProducts = new ArrayList<>(products.size());

    // We don't need to do these in parallel since it is unlikely we'd get inconsistent data
    // population.
    compiledProducts.addAll(
        getProductsByProductId(
            productsFromProductId.stream()
                .collect(
                    Collectors.toMap(
                        existingProduct -> existingProduct.getProductId(),
                        existingProduct -> existingProduct,
                        (first, second) -> first))
                .values()));
    compiledProducts.addAll(getProductsByAsin(productsFromAsin));
    compiledProducts.addAll(getProductsBySkuAndVendor(productsFromSkuAndVendor));
    compiledProducts.addAll(getProductsByExternalIdAndVendor(productsFromExternalIdAndVendor));

    return compiledProducts;
  }

  /**
   * Get products by their productIds. This is the fastest way to get a product. It uses a
   * batchLoad, which is only supported for primary keys.
   *
   * @param products - products with their productId populated.
   * @return - returns an empty list if products are not found (or there are none), otherwise
   *     returns a list of populated products from the db
   */
  private List<Product> getProductsByProductId(final Collection<Product> products) {
    if (CollectionUtils.isEmpty(products)) {
      return new ArrayList<>();
    }

    if (products.size() == 1) {
      final Product product = getProduct(products.iterator().next());
      return product != null ? Collections.singletonList(product) : new ArrayList<>();
    }

    logger.debug("Loading product for " + products.size() + " productId(s) ...");

    final ProfilerTimer timer =
        new ProfilerTimer(metrics, MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCTS, false);
    Map<String, List<Object>> foundMap;

    try {
      timer.start();
      foundMap = readDbMapper.batchLoad((Collection<Object>) (Collection<?>) products);

    } catch (final ProvisionedThroughputExceededException ex) {
      final List<String> productIds =
          products.stream().map(Product::getProductId).collect(Collectors.toList());
      logger.error(
          getThrottledRequestMessage(
              "getProductsByProductId", "productIds", productIds.toString()));
      MetricUtils.emitThrottledRequestMetric(MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCTS);
      throw ex;
    } catch (final AmazonServiceException ex) {
      final List<String> productIds =
          products.stream().map(Product::getProductId).collect(Collectors.toList());
      logger.error(
          getAmazonServiceExceptionMessage(
              "getProductsByProductId", "productIds", productIds.toString()));
      MetricUtils.emitAmazonServiceExceptionMetric(MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCTS);
      throw ex;
    } catch (final SdkClientException ex) {
      final List<String> productIds =
          products.stream().map(Product::getProductId).collect(Collectors.toList());
      logger.error(
          getRetryLimitExceededMessage(
              "getProductsByProductId", "productIds", productIds.toString()));
      MetricUtils.emitRetryLimitExceededMetric(MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCTS);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }

    if (!foundMap.containsKey(Product.TABLE_NAME)) {
      throw new IllegalStateException(
          "Unable to find batchLoad results entry for primary table name "
              + Product.TABLE_NAME
              + "?");
    }
    final List<Product> found = new ArrayList<>(foundMap.get(Product.TABLE_NAME).size());
    foundMap
        .get(Product.TABLE_NAME)
        .forEach(
            item -> {
              if (item != null) {
                found.add((Product) item);
              }
            });
    logger.debug("Found: " + found.size());
    return found;
  }

  /**
   * Gets a product by a given a product with a productId.
   *
   * @param productRequest
   * @return - returns a product from the db if it is found, null otherwise.
   */
  private Product getProductByProductId(final Product productRequest) {
    final String productId = productRequest.getProductId();
    logger.debug("Loading product for productId " + productId + " ...");

    final ProfilerTimer timer =
        new ProfilerTimer(metrics, MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCT, false);

    try {
      timer.start();
      final Product product = readDbMapper.load(Product.class, productId);
      logger.debug("Found: " + product);
      return product;
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(getThrottledRequestMessage("getProductByProductId", "productId", productId));
      MetricUtils.emitThrottledRequestMetric(MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCT);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(
          getAmazonServiceExceptionMessage("getProductByProductId", "productId", productId));
      MetricUtils.emitAmazonServiceExceptionMetric(MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCT);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(getRetryLimitExceededMessage("getProductByProductId", "productId", productId));
      MetricUtils.emitRetryLimitExceededMetric(MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCT);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }
  }

  /**
   * Gets a product given a list of asins. Uses a parallel stream to call multiple queries.
   *
   * @param products - products with their asin populated.
   * @return - returns an empty list if products are not found (or there are none), otherwise
   *     returns a collection of populated products from the db
   */
  private Collection<Product> getProductsByAsin(final Collection<Product> products) {
    if (CollectionUtils.isEmpty(products)) {
      return new ArrayList<>();
    }

    final ProfilerTimer timer =
        Profiler.startTimer(metrics, MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCTS_BY_ASIN, true);
    final Queue<Product> matches =
        products
            .parallelStream()
            .map(
                product -> {
                  final String asin = product.getAsin();
                  logger.debug("Querying for product with asin " + asin + " ...");

                  final Product productKey = new Product();
                  productKey.setAsin(asin);

                  final DynamoDBQueryExpression<Product> queryExpression =
                      new DynamoDBQueryExpression<Product>()
                          .withHashKeyValues(productKey)
                          .withConsistentRead(false)
                          .withSelect(Select.ALL_ATTRIBUTES)
                          .withIndexName(Product.INDEX_BY_ASIN);

                  try {
                    final List<Product> results =
                        readDbMapper.query(Product.class, queryExpression);
                    logger.debug(
                        "Matches in "
                            + queryExpression.getIndexName()
                            + " found: "
                            + results.size());

                    if (results.size() > 1) {
                      throw new UniqueConstraintException(
                          String.format(
                              "More than one match for asin %s. Matches: %d",
                              asin, results.size()));
                    }
                    return CollectionUtils.isNotEmpty(results) ? results.get(0) : null;

                  } catch (final ProvisionedThroughputExceededException ex) {
                    logger.error(getThrottledRequestMessage("getProductByAsin", "asin", asin));
                    MetricUtils.emitThrottledRequestMetric(
                        MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCT_BY_ASIN);
                    throw ex;
                  } catch (final AmazonServiceException ex) {
                    logger.error(
                        getAmazonServiceExceptionMessage("getProductByAsin", "asin", asin));
                    MetricUtils.emitAmazonServiceExceptionMetric(
                        MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCT_BY_ASIN);
                    throw ex;
                  } catch (final SdkClientException ex) {
                    logger.error(getRetryLimitExceededMessage("getProductByAsin", "asin", asin));
                    MetricUtils.emitRetryLimitExceededMetric(
                        MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCT_BY_ASIN);
                    throw new InternalServiceException(ex.getMessage(), ex);
                  }
                })
            .filter(Objects::nonNull)
            .collect(Collectors.toCollection(ConcurrentLinkedQueue::new));

    timer.stop();
    logger.debug(
        "Matches in getProductsByAsin found: "
            + matches.size()
            + " of originally request: "
            + products.size());
    return matches;
  }

  /**
   * Retrieves a product by a particular asin using a query.
   *
   * @param product - product with asin populated.
   * @return
   */
  private Product getProductByAsin(final Product product) {
    final String asin = product.getAsin();
    logger.debug("Querying for product with asin " + asin + " ...");

    final Product productKey = new Product();
    productKey.setAsin(asin);

    final DynamoDBQueryExpression<Product> queryExpression =
        new DynamoDBQueryExpression<Product>()
            .withHashKeyValues(productKey)
            .withConsistentRead(false)
            .withSelect(Select.ALL_ATTRIBUTES)
            .withIndexName(Product.INDEX_BY_ASIN);

    final ProfilerTimer timer =
        new ProfilerTimer(metrics, MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCT_BY_ASIN, false);

    try {
      timer.start();
      final List<Product> matches = readDbMapper.query(Product.class, queryExpression);
      logger.debug("Matches in " + queryExpression.getIndexName() + " found: " + matches.size());

      if (matches.size() > 1) {
        throw new UniqueConstraintException(
            String.format("More than one match for asin %s. Matches: %d", asin, matches.size()));
      }

      return CollectionUtils.isNotEmpty(matches) ? matches.get(0) : null;

    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(getThrottledRequestMessage("getProductByAsin", "asin", asin));
      MetricUtils.emitThrottledRequestMetric(MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCT_BY_ASIN);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(getAmazonServiceExceptionMessage("getProductByAsin", "asin", asin));
      MetricUtils.emitAmazonServiceExceptionMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCT_BY_ASIN);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(getRetryLimitExceededMessage("getProductByAsin", "asin", asin));
      MetricUtils.emitRetryLimitExceededMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCT_BY_ASIN);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }
  }

  /**
   * Queries for products given their sku and vendorId. Uses a parallel stream to call multiple
   * queries.
   *
   * @param products
   * @return - returns an empty list if products are not found (or there are none), otherwise
   *     returns a collection of populated products from the db
   */
  private Collection<Product> getProductsBySkuAndVendor(final List<Product> products) {
    if (CollectionUtils.isEmpty(products)) {
      return new ArrayList<>();
    }

    final ProfilerTimer timer =
        Profiler.startTimer(
            metrics, MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCTS_BY_VENDOR_ID_AND_SKU, true);

    final Queue<Product> matches = new ConcurrentLinkedQueue<>();
    // TODO Look into running this in parallel.  ParallelStream (java 8) causes issues with Coral
    // metrics and needs more investigation.
    // Though we could fix the issue with coral metrics in ParallelStreams, it uses a common thread
    // pool for all parallel streams,
    // and we are unsure if we want to proceed.
    products.forEach(
        product -> {
          final Product match = getProductBySkuAndVendor(product);
          if (match != null) {
            matches.add(match);
          }
        });
    timer.stop();
    logger.debug(
        "Matches in getProductsBySkuAndVendor found: "
            + matches.size()
            + " of originally request: "
            + products.size());
    return matches;
  }

  /**
   * Fetches a product using a query by vendorId and vendorSku.
   *
   * @param product
   * @return
   */
  private Product getProductBySkuAndVendor(final Product product) {
    final String sku = product.getVendorSku();
    final String vendorId = product.getVendorId();
    logger.debug(
        "Querying for product with vendorId " + vendorId + " and vendorSku " + sku + "...");

    final Condition rangeKeyCondition =
        new Condition()
            .withComparisonOperator(ComparisonOperator.EQ)
            .withAttributeValueList(new AttributeValue().withS(sku));

    final Product productKey = new Product();
    productKey.setVendorId(vendorId);
    productKey.setVendorSku(sku);

    final DynamoDBQueryExpression<Product> queryExpression =
        new DynamoDBQueryExpression<Product>()
            .withHashKeyValues(productKey)
            .withRangeKeyCondition(Product.VENDOR_SKU, rangeKeyCondition)
            .withConsistentRead(false)
            .withSelect(Select.ALL_ATTRIBUTES)
            .withIndexName(Product.INDEX_BY_VENDOR_ID_SKU);

    final ProfilerTimer timer =
        new ProfilerTimer(
            metrics, MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCT_BY_VENDOR_ID_AND_SKU, false);

    try {
      timer.start();
      final List<Product> matches = readDbMapper.query(Product.class, queryExpression);
      logger.debug("Matches in " + queryExpression.getIndexName() + " found: " + matches.size());

      if (matches.size() > 1) {
        throw new UniqueConstraintException(
            String.format(
                "More than one match for vendorId %s and sku %s. Matches: %d",
                vendorId, sku, matches.size()));
      }
      return CollectionUtils.isNotEmpty(matches) ? matches.get(0) : null;

    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(
          getThrottledRequestMessage("getProductBySkuAndVendor", "sku", sku, "vendorId", vendorId));
      MetricUtils.emitThrottledRequestMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCT_BY_VENDOR_ID_AND_SKU);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(
          getAmazonServiceExceptionMessage(
              "getProductBySkuAndVendor", "sku", sku, "vendorId", vendorId));
      MetricUtils.emitAmazonServiceExceptionMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCT_BY_VENDOR_ID_AND_SKU);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(
          getRetryLimitExceededMessage(
              "getProductBySkuAndVendor", "sku", sku, "vendorId", vendorId));
      MetricUtils.emitRetryLimitExceededMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCT_BY_VENDOR_ID_AND_SKU);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }
  }

  /**
   * Queries for products given their externalProductId and vendorId.
   *
   * @param products
   * @return - returns an empty list if products are not found (or there are none), otherwise
   *     returns a collection of populated products from the db
   */
  private Collection<Product> getProductsByExternalIdAndVendor(final List<Product> products) {
    if (CollectionUtils.isEmpty(products)) {
      return new ArrayList<>();
    }

    final ProfilerTimer timer =
        Profiler.startTimer(
            metrics,
            MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCTS_BY_VENDOR_ID_AND_EXTERNAL_ID,
            true);

    final List<Product> matches = new ArrayList<>();
    products.forEach(
        product -> {
          final Product match = getProductByExternalIdAndVendor(product);
          if (match != null) {
            matches.add(match);
          }
        });
    timer.stop();
    logger.debug(
        "Matches in getProductsByExternalIdAndVendor found: "
            + matches.size()
            + " of originally request: "
            + products.size());
    return matches;
  }

  /**
   * Fetches a product using a query by vendorId and externalProductId.
   *
   * @param product
   * @return
   */
  private Product getProductByExternalIdAndVendor(final Product product) {
    final String externalProductId = product.getExternalProductId();
    final String vendorId = product.getVendorId();
    logger.debug(
        "Querying for product with vendorId "
            + vendorId
            + " and externalProductId "
            + externalProductId
            + "...");

    // TODO remove when externalProductId+vendorId product identifier is no longer in use.
    // Emit a metric that would tell us who is calling this method.
    // Because we're deprecating this method, we want to know who to reach out to.
    String tenant = ADGProductContextThreadInstance.get().getADGTenant();
    String aaaClientName = ADGProductContextThreadInstance.get().getAAAClientName();
    metrics.addMetric(
        "getProductByVendorIdAndExternalProductIdInvoked",
        1,
        Unit.ONE,
        new Dimension(ADG_TENANT, tenant),
        new Dimension(ADG_UPSTREAM_SERVICE, aaaClientName));

    final Condition rangeKeyCondition =
        new Condition()
            .withComparisonOperator(ComparisonOperator.EQ)
            .withAttributeValueList(new AttributeValue().withS(externalProductId));

    final Product productKey = new Product();
    productKey.setVendorId(vendorId);
    productKey.setExternalProductId(externalProductId);

    final DynamoDBQueryExpression<Product> queryExpression =
        new DynamoDBQueryExpression<Product>()
            .withHashKeyValues(productKey)
            .withRangeKeyCondition(Product.EXTERNAL_PRODUCT_ID, rangeKeyCondition)
            .withConsistentRead(false)
            .withSelect(Select.ALL_ATTRIBUTES)
            .withIndexName(Product.INDEX_BY_VENDOR_ID_EXTERNAL_PRODUCT_ID);

    final ProfilerTimer timer =
        new ProfilerTimer(
            metrics,
            MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCT_BY_VENDOR_ID_AND_EXTERNAL_ID,
            false);

    try {
      timer.start();
      final List<Product> matches = readDbMapper.query(Product.class, queryExpression);
      logger.debug("Matches in " + queryExpression.getIndexName() + " found: " + matches.size());

      if (matches.size() > 1) {
        throw new UniqueConstraintException(
            String.format(
                "More than one match for vendorId %s and externalProductId %s. Matches: %d",
                vendorId, externalProductId, matches.size()));
      }
      return CollectionUtils.isNotEmpty(matches) ? matches.get(0) : null;

    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(
          getThrottledRequestMessage(
              "getProductByExternalIdAndVendor",
              "externalId",
              externalProductId,
              "vendorId",
              vendorId));
      MetricUtils.emitThrottledRequestMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCT_BY_VENDOR_ID_AND_EXTERNAL_ID);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(
          getAmazonServiceExceptionMessage(
              "getProductByExternalIdAndVendor",
              "externalId",
              externalProductId,
              "vendorId",
              vendorId));
      MetricUtils.emitAmazonServiceExceptionMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCT_BY_VENDOR_ID_AND_EXTERNAL_ID);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(
          getRetryLimitExceededMessage(
              "getProductByExternalIdAndVendor",
              "externalId",
              externalProductId,
              "vendorId",
              vendorId));
      MetricUtils.emitRetryLimitExceededMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCT_BY_VENDOR_ID_AND_EXTERNAL_ID);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }
  }

  /**
   * Gets a list of products for each given vendorId. Uses a parallel stream of queries to fetch the
   * results.
   *
   * @param vendorIds - the vendorIds of products to search on
   * @param keyConditionMap - the rangeKeyConditions for the dynamo query.
   * @param queryFilterMap - the queryFilter for the dynamoQuery.
   * @return
   */
  public Map<String, PagedResponse<Product>> getProductsByVendorIds(
      final List<PagedRequest<String, DynamoPagingQueryParameters>> vendorIds,
      final Map<String, Condition> keyConditionMap,
      final Map<String, Condition> queryFilterMap) {
    if (CollectionUtils.isEmpty(vendorIds)) {
      return new HashMap<>();
    }

    final ProfilerTimer timer =
        Profiler.startTimer(
            metrics, MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCTS_BY_VENDOR_IDS, true);

    final Map<String, PagedResponse<Product>> response = new ConcurrentHashMap<>(vendorIds.size());
    // TODO Look into running this in parallel.  ParallelStream (java 8) causes issues with Coral
    // metrics and needs more investigation.
    // Though we could fix the issue with coral metrics in ParallelStreams, it uses a common thread
    // pool for all parallel streams,
    // and we are unsure if we want to proceed.
    vendorIds.forEach(
        pagedRequest -> {
          final PagedResponse<Product> pagedResponse =
              getProductsByVendorId(
                  pagedRequest.getInput(),
                  keyConditionMap,
                  queryFilterMap,
                  pagedRequest.getQueryParameters());
          response.put(pagedRequest.getInput(), pagedResponse);
        });
    timer.stop();
    return response;
  }

  /**
   * Gets a list of products under a given vendor, filtering products on filterToState.
   *
   * @param vendorId - the vendorId to search on
   * @param keyConditionMap - the rangeKeyConditions for the dynamo query.
   * @param queryFilterMap - the queryFilter for the dynamoQuery.
   * @param paginationParameters - the (optional) pagination query parameters
   * @return
   */
  public PagedResponse<Product> getProductsByVendorId(
      final String vendorId,
      final Map<String, Condition> keyConditionMap,
      final Map<String, Condition> queryFilterMap,
      final DynamoPagingQueryParameters paginationParameters) {
    if (StringUtils.isEmpty(vendorId)) {
      throw new IllegalArgumentException("vendorId cannot be empty");
    }
    logger.debug("Querying for product with vendorId " + vendorId + "...");

    final Product productKey = new Product();
    productKey.setVendorId(vendorId);

    final DynamoDBQueryExpression<Product> queryExpression =
        new DynamoDBQueryExpression<Product>()
            .withHashKeyValues(productKey)
            .withConsistentRead(false)
            .withSelect(Select.ALL_ATTRIBUTES)
            .withIndexName(Product.INDEX_BY_VENDOR_ID_PRODUCT_ID)
            .withRangeKeyConditions(keyConditionMap)
            .withQueryFilter(queryFilterMap);

    final ProfilerTimer timer =
        new ProfilerTimer(
            metrics, MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCTS_BY_VENDOR_ID, false);

    try {
      timer.start();
      final PagedResponse response = paginator.retrievePage(queryExpression, paginationParameters);
      logger.debug(
          "Matches in " + queryExpression.getIndexName() + " found: " + response.getPageSize());
      return response;
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(getThrottledRequestMessage("getProductsByVendorId", "vendorId", vendorId));
      MetricUtils.emitThrottledRequestMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCTS_BY_VENDOR_ID);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(getAmazonServiceExceptionMessage("getProductsByVendorId", "vendorId", vendorId));
      MetricUtils.emitAmazonServiceExceptionMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCTS_BY_VENDOR_ID);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(getRetryLimitExceededMessage("getProductsByVendorId", "vendorId", vendorId));
      MetricUtils.emitRetryLimitExceededMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCTS_BY_VENDOR_ID);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }
  }

  /**
   * Gets a list of products by the primary domain ids. Uses a parallel stream of queries to fetch
   * the results.
   *
   * @param primaryDomainIds - the primary domain id of products to search on
   * @param keyConditionMap - the rangeKeyConditions for the dynamo query.
   * @param queryFilterMap - the queryFilter for the dynamoQuery.
   * @return a map of domainId to pagedResponse.
   */
  public Map<String, PagedResponse<Product>> getProductsByDomainIds(
      final List<PagedRequest<String, DynamoPagingQueryParameters>> primaryDomainIds,
      final Map<String, Condition> keyConditionMap,
      final Map<String, Condition> queryFilterMap) {
    if (CollectionUtils.isEmpty(primaryDomainIds)) {
      return new HashMap<>();
    }

    final ProfilerTimer timer =
        Profiler.startTimer(
            metrics, MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCTS_BY_DOMAIN_IDS, true);

    final Map<String, PagedResponse<Product>> response =
        new ConcurrentHashMap<>(primaryDomainIds.size());
    // TODO Look into running this in parallel.  ParallelStream (java 8) causes issues with Coral
    // metrics and needs more investigation.
    // Though we could fix the issue with coral metrics in ParallelStreams, it uses a common thread
    // pool for all parallel streams,
    // and we are unsure if we want to proceed.
    primaryDomainIds.forEach(
        pagedRequest -> {
          final PagedResponse<Product> pagedResponse =
              getProductsByDomainId(
                  pagedRequest.getInput(),
                  keyConditionMap,
                  queryFilterMap,
                  pagedRequest.getQueryParameters());
          response.put(pagedRequest.getInput(), pagedResponse);
        });
    timer.stop();
    return response;
  }

  /**
   * Gets a list of products by the primary domain id using a query.
   *
   * @param primaryDomainId - the domain id to search on
   * @return
   */
  public PagedResponse<Product> getProductsByDomainId(final String primaryDomainId) {
    return getProductsByDomainId(primaryDomainId, null, null, null);
  }

  /**
   * Gets a list of products by the primary domain id using a query.
   *
   * @param primaryDomainId - the domain id to search on
   * @param keyConditionMap - the rangeKeyConditions for the dynamo query.
   * @param queryFilterMap - the queryFilter for the dynamoQuery.
   * @param paginationParameters - the pagination parameters. Can be null if you do not wish to
   *     paginate.
   * @return
   */
  public PagedResponse<Product> getProductsByDomainId(
      final String primaryDomainId,
      final Map<String, Condition> keyConditionMap,
      final Map<String, Condition> queryFilterMap,
      final DynamoPagingQueryParameters paginationParameters) {
    if (StringUtils.isEmpty(primaryDomainId)) {
      throw new IllegalArgumentException("primaryDomainId cannot be empty");
    }
    logger.debug("Querying for product with primaryDomainId " + primaryDomainId + "...");

    final Product productKey = new Product();
    productKey.setPrimaryDomainId(primaryDomainId);

    final DynamoDBQueryExpression<Product> queryExpression =
        new DynamoDBQueryExpression<Product>()
            .withHashKeyValues(productKey)
            .withConsistentRead(false)
            .withSelect(Select.ALL_ATTRIBUTES)
            .withIndexName(Product.INDEX_BY_PRIMARY_DOMAIN_ID)
            .withRangeKeyConditions(keyConditionMap)
            .withQueryFilter(queryFilterMap);

    final ProfilerTimer timer =
        new ProfilerTimer(
            metrics, MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCTS_BY_DOMAIN_ID, false);

    try {
      timer.start();
      final PagedResponse response = paginator.retrievePage(queryExpression, paginationParameters);
      logger.debug(
          "Matches in " + queryExpression.getIndexName() + " found: " + response.getPageSize());
      return response;
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(
          getThrottledRequestMessage("getProductsByDomainId", "domainId", primaryDomainId));
      MetricUtils.emitThrottledRequestMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCTS_BY_DOMAIN_ID);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(
          getAmazonServiceExceptionMessage("getProductsByDomainId", "domainId", primaryDomainId));
      MetricUtils.emitAmazonServiceExceptionMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCTS_BY_DOMAIN_ID);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(
          getRetryLimitExceededMessage("getProductsByDomainId", "domainId", primaryDomainId));
      MetricUtils.emitRetryLimitExceededMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_PRODUCTS_BY_DOMAIN_ID);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }
  }
}




// UniqueConstraintException.java
package com.amazon.adg.product.dao;

public class UniqueConstraintException extends PersistenceException {

  public UniqueConstraintException() {}

  public UniqueConstraintException(String message) {
    super(message);
  }

  public UniqueConstraintException(String message, Throwable cause) {
    super(message, cause);
  }

  public UniqueConstraintException(Throwable cause) {
    super(cause);
  }

  public UniqueConstraintException(
      String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
    super(message, cause, enableSuppression, writableStackTrace);
  }
}




// VendorNotFoundException.java
package com.amazon.adg.product.dao;

public class VendorNotFoundException extends PersistenceException {

  public VendorNotFoundException() {}

  public VendorNotFoundException(String message) {
    super(message);
  }

  public VendorNotFoundException(String message, Throwable cause) {
    super(message, cause);
  }

  public VendorNotFoundException(Throwable cause) {
    super(cause);
  }

  public VendorNotFoundException(
      String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
    super(message, cause, enableSuppression, writableStackTrace);
  }
}




// ADGProductDatabase.java
package com.amazon.adg.product.service.database;

import static com.amazon.adg.product.service.model.ProductModelUtil.extractVendorId;

import com.amazon.adg.common.model.Domain;
import com.amazon.adg.common.model.Product;
import com.amazon.adg.common.model.ProductFilter;
import com.amazon.adg.common.model.ProductRevision;
import com.amazon.adg.common.model.Vendor;
import com.amazon.adg.common.product.ADGProductTypeEnum;
import com.amazon.adg.common.product.ProductLineEnum;
import com.amazon.adg.discovery.common.localization.LocalizationUtils;
import com.amazon.adg.product.cursor.paging.DynamoPagingQueryParameters;
import com.amazon.adg.product.cursor.paging.PagedRequest;
import com.amazon.adg.product.cursor.paging.PagedResponse;
import com.amazon.adg.product.dao.DomainDao;
import com.amazon.adg.product.dao.ProductDao;
import com.amazon.adg.product.dao.ProductNotFoundException;
import com.amazon.adg.product.dao.ProductRevisionDao;
import com.amazon.adg.product.dao.UniqueConstraintException;
import com.amazon.adg.product.dao.VendorDao;
import com.amazon.adg.product.data.ProductStateEnum;
import com.amazon.adg.product.service.model.DomainModelUtil;
import com.amazon.adg.product.service.model.InvalidRequestException;
import com.amazon.adg.product.service.model.ProductModelUtil;
import com.amazon.adg.product.service.model.ProductRevisionModelUtil;
import com.amazon.adg.product.service.model.VendorModelUtil;
import com.amazon.adg.product.service.util.LegacyStore;
import com.amazon.adg.product.service.util.ProductFilterUtils;
import com.amazon.adg.product.utils.ACIHelper;
import com.amazon.mas.commons.type.Asin;
import com.amazonaws.services.dynamodbv2.model.Condition;
import com.amazonaws.services.dynamodbv2.transactions.Transaction;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

public class ADGProductDatabase {
  private static final Logger logger = LogManager.getLogger(ADGProductDatabase.class);
  @Autowired private ProductDao productDao;
  @Autowired private VendorDao vendorDao;
  @Autowired private DomainDao domainDao;
  @Autowired private ProductRevisionDao productRevisionDao;

  /**
   * Creates a product in the database as part of a transaction and validates its fields.
   *
   * @param product
   */
  public Product createProduct(final Product product, final Transaction transaction) {
    verifySaveProductInputs(product, false);
    LocalizationUtils.validateLocaleStringsForStorage(product);

    if (StringUtils.isEmpty(product.getId())) {
      if (LegacyStore.isLegacyStoreForProductLine(product.getProductLine())) {
        product.setId(UUID.randomUUID().toString());
      } else {
        product.setId(ACIHelper.PRODUCT_ID_ACI_PREFIX + UUID.randomUUID().toString());
      }
    }
    if (StringUtils.isBlank(product.getState())) {
      product.setState(ProductStateEnum.LIVE.name());
    }
    enforceUniqueConstraints(product);
    createValidated(product, transaction);

    return product;
  }

  /**
   * Creates a product in the database and validates its fields.
   *
   * @param product
   */
  public Product createProduct(final Product product) {
    return createProduct(product, null);
  }

  /**
   * Updating a product will overwrite all product fields. If a field is not provided in the
   * overwriting product, this method will attempt to overwrite with a null value.
   *
   * @param product
   * @param transaction
   */
  public void updateProduct(final Product product, final Transaction transaction) {
    verifySaveProductInputs(product, true);
    LocalizationUtils.validateLocaleStringsForStorage(product);
    final Product foundProduct = getProduct(product);
    validateReceivedProductBeforeUpdate(product, foundProduct);
    updateValidated(product, transaction);
  }

  /**
   * Updates a product in the database and validates its fields.
   *
   * @param product
   */
  public void updateProduct(final Product product) {
    updateProduct(product, null);
  }

  /**
   * Creates a product in the database. The product has already been validated.
   *
   * @param product
   */
  private void createValidated(final Product product, final Transaction transaction) {
    productDao.create(ProductModelUtil.getDataObjectFromModel(product), transaction);
  }

  /**
   * Updates a product in the database. The update has already been validated.
   *
   * @param product
   */
  private void updateValidated(final Product product, final Transaction transaction) {
    productDao.update(ProductModelUtil.getDataObjectFromModel(product), transaction);
  }

  /**
   * Gets a single product from the DB using its productId, asin, or vendorId+sku. Verifies that a
   * product has all required fields populated before creating it.
   *
   * @param product - product with productId, asin, or vendorId + sku populated.
   * @param product
   * @return
   */
  public Product getProduct(final Product product) {
    if (product == null) {
      return null;
    }

    // populate vendor information for the input product if needed
    final Collection<Product> productToFilter = new ArrayList<>();
    productToFilter.add(product);

    final Map<String, Vendor> fetchedVendors = populateVendorOrFilterInputs(productToFilter);

    if (productToFilter.size() < 1) {
      return null;
    }

    final Product result =
        ProductModelUtil.getModelObjectFromData(
            productDao.getProduct(ProductModelUtil.getDataObjectFromModel(product)));

    // if we've already fetched the vendor info, put it in the results
    populateVendorForResults(fetchedVendors, Collections.singletonList(result));

    return result;
  }

  /**
   * Gets products from either productId, asin, or sku + vendorId.
   *
   * @param products - products with productId, asin, or vendorId + sku populated.
   * @return
   */
  public List<Product> getProducts(final Collection<Product> products) {

    // populate vendor information for the input products that require it.
    final Map<String, Vendor> fetchedVendors = populateVendorOrFilterInputs(products);

    final List<Product> results =
        ProductModelUtil.getModelObjectsFromData(
            productDao.getProducts(ProductModelUtil.getDataObjectsFromModel(products)));

    // if we've already fetched the vendor info, put it in the results
    populateVendorForResults(fetchedVendors, results);

    return results;
  }

  /**
   * Gets the product revision from either revisionId or productId + revisionId
   *
   * @param productRevision - input product revision
   */
  private ProductRevision getProductRevision(final ProductRevision productRevision) {
    return ProductRevisionModelUtil.getModelObjectFromData(
        productRevisionDao.getProductRevision(
            ProductRevisionModelUtil.getDataObjectFromModel(productRevision)));
  }

  /**
   * Queries for a list of products given a domainId and a product filter. Filters out products
   * according to keyed database fields in productFilter. It will not apply all fields of the
   * product filter, since we do not have all of the data on the product yet (productDetailMap for
   * instance). That is fetched from Disco.
   *
   * @param domainId - the domain id to query for products
   * @param productFilter
   * @param dynamoPagingQueryParameters - the (optional) pagination query parameters
   * @return
   */
  public PagedResponse<Product> getProductsByDomainId(
      final String domainId,
      final ProductFilter productFilter,
      final DynamoPagingQueryParameters dynamoPagingQueryParameters) {
    final PagedResponse<Product> response =
        ProductModelUtil.getModelObjectsPagedData(
            productDao.getProductsByDomainId(
                domainId,
                ProductFilterUtils.getKeyConditions(productFilter),
                ProductFilterUtils.getFilterConditions(productFilter),
                dynamoPagingQueryParameters));

    return response;
  }
  /**
   * Queries for a list of products given a domainId and a product filter. Filters out products
   * according to keyed database fields in productFilter. It will not apply all fields of the
   * product filter, since we do not have all of the data on the product yet (productDetailMap for
   * instance). That is fetched from Disco.
   *
   * @param domainIds - the list of paged requests of domain ids to query for products
   * @param productFilter
   * @return a mapping of domain id to paged response
   */
  public Map<String, PagedResponse<Product>> getProductsByDomainIds(
      final List<PagedRequest<String, DynamoPagingQueryParameters>> domainIds,
      final ProductFilter productFilter) {
    final Map<String, Condition> keyConditions = ProductFilterUtils.getKeyConditions(productFilter);
    final Map<String, Condition> filterConditions =
        ProductFilterUtils.getFilterConditions(productFilter);

    final Map<String, PagedResponse<Product>> response =
        ProductModelUtil.getModelObjectsForMappedPagedData(
            productDao.getProductsByDomainIds(domainIds, keyConditions, filterConditions));

    return response;
  }

  /**
   * Queries for a list of products given a vendorId and a product filter. Filters out products
   * according to keyed database fields in productFilter. It will not apply all fields of the
   * product filter, since we do not have all of the data on the product yet (productDetailMap for
   * instance). That is fetched from Disco.
   *
   * @param vendorId - the vendorId id to query for products
   * @param productFilter
   * @param dynamoPagingQueryParameters - the (optional) pagination query parameters
   * @return
   */
  public PagedResponse<Product> getProductsByVendorId(
      final String vendorId,
      final ProductFilter productFilter,
      final DynamoPagingQueryParameters dynamoPagingQueryParameters) {
    final PagedResponse<Product> response =
        ProductModelUtil.getModelObjectsPagedData(
            productDao.getProductsByVendorId(
                vendorId,
                ProductFilterUtils.getKeyConditions(productFilter),
                ProductFilterUtils.getFilterConditions(productFilter),
                dynamoPagingQueryParameters));

    return response;
  }

  /**
   * Queries for a list of products given a domainId and a product filter. Filters out products
   * according to keyed database fields in productFilter. It will not apply all fields of the
   * product filter, since we do not have all of the data on the product yet (productDetailMap for
   * instance). That is fetched from Disco.
   *
   * @param vendorIds - the vendor id based paged query requests
   * @param productFilter
   * @return
   */
  public Map<String, PagedResponse<Product>> getProductsByVendorIds(
      final List<PagedRequest<String, DynamoPagingQueryParameters>> vendorIds,
      final ProductFilter productFilter) {
    final Map<String, PagedResponse<Product>> response =
        ProductModelUtil.getModelObjectsForMappedPagedData(
            productDao.getProductsByVendorIds(
                vendorIds,
                ProductFilterUtils.getKeyConditions(productFilter),
                ProductFilterUtils.getFilterConditions(productFilter)));

    return response;
  }

  /**
   * Verifies that a product has all required fields populated before creating it.
   *
   * @param product
   * @param requireProductId
   */
  private void verifySaveProductInputs(final Product product, final boolean requireProductId) {
    if (product == null) {
      throw new IllegalArgumentException("product cannot be empty; must have name");
    }
    if (requireProductId && StringUtils.isEmpty(product.getId())) {
      throw new IllegalArgumentException("productId cannot be empty");
    }
    if (StringUtils.isNotEmpty(product.getAsin()) && !Asin.isWellFormed(product.getAsin())) {
      throw new IllegalArgumentException("asin is malformed");
    }
    if (StringUtils.isEmpty(product.getProductTitle())) {
      throw new IllegalArgumentException("product title cannot be empty");
    }
    if (product.getVendor() == null || StringUtils.isEmpty(product.getVendor().getId())) {
      throw new IllegalArgumentException("vendorId cannot be empty");
    }
    if (StringUtils.isEmpty(product.getSku())) {
      throw new IllegalArgumentException("vendorSku cannot be empty");
    }
    if (StringUtils.isEmpty(product.getProductLine())) {
      throw new IllegalArgumentException("productLine cannot be empty");
    }

    // Validates or sets the product type from the product line.
    final ProductLineEnum productLine = ProductLineEnum.fromString(product.getProductLine());
    if (StringUtils.isNotBlank(product.getType())) {
      if (productLine.type() != ADGProductTypeEnum.fromString(product.getType())) {
        throw new IllegalArgumentException(
            String.format(
                "Product type %s cannot change and does not match product line %s",
                product.getType(), productLine));
      }
    }
    // Resolves any potentially all caps input, to the ADG-usage of First-capital (IE:
    // "Entitlement").
    product.setType(productLine.type().toString());

    if (StringUtils.isEmpty(product.getType())) {
      throw new IllegalArgumentException("productType cannot be empty");
    } else {
      // will throw an error if not recognized
      ADGProductTypeEnum.fromString(product.getType());
    }
  }

  /**
   * Validates an update (product) on an existing product (foundProduct) is valid.
   *
   * @param product
   * @param foundProduct
   */
  private void validateReceivedProductBeforeUpdate(
      final Product product, final Product foundProduct) {
    if (foundProduct == null) {
      throw new ProductNotFoundException(
          "Unable to find matching product to update for product " + product.getId() + ".");
    }
    logger.debug("found matching product: " + product);

    // TODO Look into a safe way to change a vendor for a product.
    if (!Objects.equals(extractVendorId(foundProduct), extractVendorId(product))) {
      throw new IllegalStateException("VendorId cannot be changed for a product once it is set.");
    }

    // will validate and normalize the string if it is present,
    // or it will explicitly reuse the previous state from the found product
    if (!StringUtils.isEmpty(product.getState())) {
      product.setState(ProductStateEnum.valueOf(product.getState()).name());
    } else {
      product.setState(foundProduct.getState());
    }

    // Allowing ProductType change
    logger.info(
        String.format(
            "Product type changed from %s to %s.", foundProduct.getType(), product.getType()));

    // TODO: Implement validation to check for RELEASE channel before allowing productLine change
    // Currently this validation is happening is ADGProductProcessService
    final String foundProductLine = foundProduct.getProductLine();
    final String productLine = product.getProductLine();
    logger.info(
        String.format("Product line changed from %s to %s.", foundProductLine, productLine));

    if (StringUtils.isNotBlank(foundProduct.getAsin())
        && !Objects.equals(foundProduct.getAsin(), product.getAsin())) {
      // does not consider what happens if foundProduct's asin is null
      throw new IllegalStateException("ASIN cannot be changed for a product once it is set.");
    }
    if (!StringUtils.equals(product.getAsin(), foundProduct.getAsin())) {
      // covers the case where foundProduct's asin is null and is not equal to new asin
      enforceUniqueConstraints(Product.builder().withAsin(product.getAsin()).build());
    }

    if (!Objects.equals(foundProduct.getSku(), product.getSku())) {
      // Changed Sku
      enforceSkuAndVendorUniqueConstraints(product.getSku(), extractVendorId(product));
    }

    if (StringUtils.isNotBlank(foundProduct.getExternalProductId())
        && !foundProduct.getExternalProductId().equals(product.getExternalProductId())) {
      // Changed externalProductId
      enforceExternalProductIdAndVendorUniqueConstraints(
          product.getExternalProductId(), extractVendorId(product));
    }

    if (isDomainChange(foundProduct, product)) {
      verifyDomain(product.getProductDomain(), product.getVendor());
    }

    validatePublishedRevisionId(product, foundProduct);
  }

  private void validatePublishedRevisionId(final Product product, final Product foundProduct) {
    if (product.getProductRevision() != null
        && StringUtils.isNotBlank(product.getProductRevision().getRevisionId())) {
      // changing to a non-null value is allowed as long as the revision exists
      final ProductRevision foundRevision =
          getProductRevision(
              new ProductRevision.Builder()
                  .withProductId(product.getId())
                  .withRevisionId(product.getProductRevision().getRevisionId())
                  .build());
      if (foundRevision == null) {
        throw new IllegalStateException(
            String.format(
                "Published revision Id %s does not exist for product Id %s.",
                product.getProductRevision().getRevisionId(), product.getId()));
      }
      if (!ProductStateEnum.isLive(foundRevision.getState())
          && ProductStateEnum.isLive(product.getState())) {
        throw new IllegalStateException(
            String.format(
                "Cannot assign a %s revision %s to the product %s. Revision should be in LIVE state.",
                foundRevision.getState(),
                product.getProductRevision().getRevisionId(),
                product.getId()));
      }
    } else {
      // changing non-null value to null is only allowed for non-LIVE products as the LIVE product
      // should always have a publishedRevisionId
      if (foundProduct.getProductRevision() != null
          && StringUtils.isNotBlank(foundProduct.getProductRevision().getRevisionId())
          && (ProductStateEnum.isLive(product.getState())
              || ProductStateEnum.isLive(foundProduct.getState()))) {
        throw new IllegalStateException(
            String.format(
                "Published revision Id cannot be changed from %s to null as the product is still LIVE or the new state is LIVE",
                foundProduct.getProductRevision().getRevisionId()));
      }
    }
  }

  /**
   * Checks whether the user is attempting to update the domain between two products.
   *
   * @param foundProduct the product that already exists in Dynamo
   * @param updateProduct the product with update data from the request
   * @return true if domain is attempting to be changed. otherwise false.
   */
  boolean isDomainChange(final Product foundProduct, final Product updateProduct) {
    if (foundProduct.getProductDomain() == null
        || StringUtils.isBlank(foundProduct.getProductDomain().getId())) {
      if (updateProduct.getProductDomain() != null
          && StringUtils.isNotBlank(updateProduct.getProductDomain().getId())) {
        return true;
      }
    } else {
      if (updateProduct.getProductDomain() == null) {
        return true;
      }
      if (StringUtils.isBlank(updateProduct.getProductDomain().getId())) {
        return true;
      }

      if (!foundProduct
          .getProductDomain()
          .getId()
          .equals(updateProduct.getProductDomain().getId())) {
        return true;
      }
    }

    return false;
  }

  public void verifyDomain(Domain domain, Vendor vendor) {
    if (domain == null || StringUtils.isBlank(domain.getId())) {
      logger.debug("Verify domain for vendor: Domain is blank");
      return;
    }

    final com.amazon.adg.product.data.Domain foundDomain =
        domainDao.getDomain(DomainModelUtil.getDataObjectFromModel(domain));
    if (foundDomain == null || StringUtils.isBlank(foundDomain.getDomainId())) {
      logger.error(
          "Domain cannot be found in ADGDomain datastore. Please create a domain by calling createDomains api.");
      throw new InvalidRequestException(
          "Domain cannot be found in ADGDomain datastore. Please create a domain by calling createDomains api.");
    }

    if (foundDomain.getOwnerId() == null || !foundDomain.getOwnerId().equals(vendor.getId())) {
      logger.error(
          "Domain and Vendor are not related. Please use a domain which is in the domain tree for that vendor.");
      throw new InvalidRequestException(
          "Domain and Vendor are not related. Please use a domain which is in the domain tree for that vendor.");
    }
  }

  /**
   * Enforces that a vendor and sku doesn't already exist.
   *
   * @param sku
   * @param vendorId
   */
  private void enforceSkuAndVendorUniqueConstraints(final String sku, final String vendorId) {
    final Product skuAndVendorProduct = new Product();
    skuAndVendorProduct.setSku(sku);
    skuAndVendorProduct.setVendor(new Vendor());
    skuAndVendorProduct.getVendor().setId(vendorId);
    enforceUniqueConstraints(skuAndVendorProduct);
  }

  /**
   * Enforces that a vendor and externalProductId doesn't already exist.
   *
   * @param externalProductId
   * @param vendorId
   */
  private void enforceExternalProductIdAndVendorUniqueConstraints(
      final String externalProductId, final String vendorId) {
    final Product externalIdAndVendorProduct = new Product();
    externalIdAndVendorProduct.setExternalProductId(externalProductId);
    externalIdAndVendorProduct.setVendor(new Vendor());
    externalIdAndVendorProduct.getVendor().setId(vendorId);
    enforceUniqueConstraints(externalIdAndVendorProduct);
  }

  /**
   * Enforces that a productId, an asin, vendor + sku or vendor + externalProductId doesn't already
   * exist. Make sure that you call verifySaveProductInputs first to make sure validations are done
   * against the required fields.
   *
   * @param product
   */
  private void enforceUniqueConstraints(final Product product) {
    // Check for existing productId
    Product existingProduct;
    if (StringUtils.isNotBlank(product.getId())) {
      final Product idProduct = Product.builder().withId(product.getId()).build();
      existingProduct = getProduct(idProduct);
      if (existingProduct != null) {
        // ProductIds match.
        final String message =
            String.format(
                "Unique constraint violated: ProductId %s already present.", product.getId());
        logger.error(message);
        throw new UniqueConstraintException(message);
      }
    }

    // Checks for existing product asin if the asin is not blank.
    if (StringUtils.isNotBlank(product.getAsin())) {
      final Product asinProduct = Product.builder().withAsin(product.getAsin()).build();
      existingProduct = getProduct(asinProduct);
      if (existingProduct != null) {
        // ProductIds match.
        final String message =
            String.format(
                "Unique constraint violated: ASIN %s already present for productId %s",
                product.getAsin(), existingProduct.getId());
        logger.error(message);
        throw new UniqueConstraintException(message);
      }
    }

    // Check for existing vendor + sku
    if (StringUtils.isNotBlank(product.getSku())
        && product.getVendor() != null
        && StringUtils.isNotBlank(product.getVendor().getId())) {
      final Product skuAndVendorProduct =
          Product.builder().withSku(product.getSku()).withVendor(product.getVendor()).build();
      existingProduct = getProduct(skuAndVendorProduct);
      if (existingProduct != null) {
        // Sku and vendorId match.
        final String message =
            String.format(
                "Unique constraint violated: Sku %s and VendorId %s already present for productId %s",
                product.getSku(), extractVendorId(product), existingProduct.getId());
        logger.error(message);
        throw new UniqueConstraintException(message);
      }
    }

    // Check for existing vendor + externalProductId
    if (StringUtils.isNotBlank(product.getExternalProductId())
        && product.getVendor() != null
        && StringUtils.isNotBlank(product.getVendor().getId())) {
      final Product externalIdAndVendorProduct =
          Product.builder()
              .withExternalProductId(product.getExternalProductId())
              .withVendor(product.getVendor())
              .build();
      existingProduct = getProduct(externalIdAndVendorProduct);
      if (existingProduct != null) {
        // externalProductId and vendorId match.
        final String message =
            String.format(
                "Unique constraint violated: ExternalProductId %s and VendorId %s already present for ProductId %s",
                product.getExternalProductId(), extractVendorId(product), existingProduct.getId());
        logger.error(message);
        throw new UniqueConstraintException(message);
      }
    }
  }

  /**
   * This method checks if the supplied products are only populated with masVendorCode and sku. If
   * there are such products we query the vendor table for vendor information and populate the
   * vendor information. If the vendor information is not available we filter out the product from
   * the input list returns all the Vendors that were fetched in a vendorId to Vendor map.
   *
   * @param products
   * @return all the Vendors that were fetched in a vendorId to Vendor map. returns an empty map if
   *     no vendors are fetched.
   */
  private Map<String, Vendor> populateVendorOrFilterInputs(final Collection<Product> products) {

    final Map<String, Vendor> codeToVendorMap = new HashMap<>();
    final Map<String, Vendor> vendorIdToVendorMap = new HashMap<>();

    if (products == null) {
      return vendorIdToVendorMap;
    }
    final Iterator<Product> iterator = products.iterator();
    while (iterator.hasNext()) {
      final Product product = iterator.next();
      if (isProductBySkuAndVendorCodeRequest(product)) {
        final String masVendorCode = product.getVendor().getMasVendorCode();
        Vendor vendor = codeToVendorMap.get(masVendorCode);
        if (vendor == null) {
          // we haven't fetched this vendor yet.
          // query the vendorDao
          vendor =
              VendorModelUtil.getModelObjectFromData(
                  vendorDao.getVendor(VendorModelUtil.getDataObjectFromModel(product.getVendor())));

          if (vendor != null) {
            codeToVendorMap.put(masVendorCode, vendor);
            vendorIdToVendorMap.put(vendor.getId(), vendor);
          } else {
            // we didn't find a vendor based on the provided info
            // filter out the product so we don't send an invalid product to the dao
            logger.warn(
                "filtered product with vendor sku "
                    + product.getSku()
                    + " and masVendorCode "
                    + masVendorCode);
            iterator.remove();
          }
        }
        product.setVendor(vendor);
      }
    }

    return vendorIdToVendorMap;
  }

  /**
   * A convenience method for evaluating if the input product has only the sku and masVendorCode
   * populated.
   *
   * @param product
   * @return
   */
  private boolean isProductBySkuAndVendorCodeRequest(final Product product) {

    if (!StringUtils.isBlank(product.getId()) || !StringUtils.isBlank(product.getAsin())) {
      return false;
    }

    if (product.getVendor() == null) {
      return false;
    }

    if (!StringUtils.isBlank(product.getVendor().getId())) {
      return false;
    }

    if (!StringUtils.isBlank(product.getSku())
        && !StringUtils.isBlank(product.getVendor().getMasVendorCode())) {
      return true;
    }

    return false;
  }

  /**
   * Populates vendor information for products when we have already fetched the vendor info by
   * necessity. This happens when we are given only the sku and masVendorCode in the request. Does
   * not call the vendor table again.
   *
   * @param fetchedVendors
   * @param resultProducts
   */
  private void populateVendorForResults(
      final Map<String, Vendor> fetchedVendors, final Collection<Product> resultProducts) {

    if (resultProducts == null || MapUtils.isEmpty(fetchedVendors)) {
      return;
    }

    for (final Product product : resultProducts) {

      if (product == null || product.getVendor() == null) {
        continue;
      }

      if (fetchedVendors.get(product.getVendor().getId()) != null) {
        product.setVendor(fetchedVendors.get(product.getVendor().getId()));
      }
    }
  }
}




// Domain.java
package com.amazon.adg.product.data;

import com.amazon.adg.common.dynamodb.marshaller.ScopeLocalDateTimeMarshaller;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBIgnore;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBIndexHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBIndexRangeKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMarshalling;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBVersionAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.encryption.DoNotEncrypt;
import com.amazonaws.services.dynamodbv2.datamodeling.encryption.DoNotTouch;
import java.time.LocalDateTime;
import java.util.List;

@DynamoDBTable(tableName = "ADGDomain")
@DoNotTouch
public class Domain {

  public static final String TABLE_NAME = "ADGDomain";

  public static final String DOMAIN_ID = "DomainId";
  public static final String DOMAIN_NAME = "DomainName";
  public static final String OWNER_ID = "OwnerId";
  public static final String DOMAIN_TYPE = "DomainType";
  public static final String CHILDREN_IDS = "ChildrenIds";
  public static final String ROOT_DOMAIN_PATH = "RootDomainPath";
  public static final String MODIFIED_TIMESTAMP = "ModifiedTimestamp";
  public static final String STATE = "State";
  public static final String VERSION = "Version";

  public static final String INDEX_BY_OWNER_ID = "ADGDomainByOwnerId-index";
  public static final String INDEX_BY_OWNER_ID_DOMAINTYPE = "ADGDomainByOwnerId-DomainType-index";
  public static final String INDEX_BY_OWNER_ID_DOMAINNAME = "ADGDomainByOwnerId-DomainName-index";

  private String domainId;
  private String name;
  private String ownerId;
  private List<String> rootDomainPath;
  private List<String> childrenIds;
  private List<Domain> children;
  private LocalDateTime modifiedTimestamp;
  private String type;
  private String state;
  private Long version;

  public Domain() {}

  public Domain(String domainId) {
    this.domainId = domainId;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = DOMAIN_ID)
  @DynamoDBHashKey(attributeName = DOMAIN_ID)
  @DynamoDBIndexRangeKey(attributeName = DOMAIN_ID, globalSecondaryIndexName = INDEX_BY_OWNER_ID)
  public String getDomainId() {
    return domainId;
  }

  public void setDomainId(String domainId) {
    this.domainId = domainId;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = DOMAIN_NAME)
  @DynamoDBIndexRangeKey(
      attributeName = DOMAIN_NAME,
      globalSecondaryIndexName = INDEX_BY_OWNER_ID_DOMAINNAME)
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = OWNER_ID)
  @DynamoDBIndexHashKey(
      attributeName = OWNER_ID,
      globalSecondaryIndexNames = {
        INDEX_BY_OWNER_ID,
        INDEX_BY_OWNER_ID_DOMAINTYPE,
        INDEX_BY_OWNER_ID_DOMAINNAME
      })
  public String getOwnerId() {
    return ownerId;
  }

  public void setOwnerId(String ownerId) {
    this.ownerId = ownerId;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = DOMAIN_TYPE)
  @DynamoDBIndexRangeKey(
      attributeName = DOMAIN_TYPE,
      globalSecondaryIndexName = INDEX_BY_OWNER_ID_DOMAINTYPE)
  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = CHILDREN_IDS)
  public List<String> getChildrenIds() {
    return childrenIds;
  }

  public void setChildrenIds(List<String> childrenIds) {
    this.childrenIds = childrenIds;
  }

  @DynamoDBIgnore
  public List<Domain> getChildren() {
    return children;
  }

  public void setChildren(List<Domain> children) {
    this.children = children;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = ROOT_DOMAIN_PATH)
  public List<String> getRootDomainPath() {
    return rootDomainPath;
  }

  public void setRootDomainPath(List<String> rootDomainPath) {
    this.rootDomainPath = rootDomainPath;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = MODIFIED_TIMESTAMP)
  @DynamoDBMarshalling(marshallerClass = ScopeLocalDateTimeMarshaller.class)
  public LocalDateTime getModifiedTimestamp() {
    return modifiedTimestamp;
  }

  public void setModifiedTimestamp(LocalDateTime modifiedTimestamp) {
    this.modifiedTimestamp = modifiedTimestamp;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = STATE)
  public String getState() {
    return state;
  }

  public void setState(String state) {
    this.state = state;
  }

  /**
   * Version optimistic locking.
   *
   * @return Long version
   */
  @DoNotEncrypt
  @DynamoDBVersionAttribute(attributeName = VERSION)
  public Long getVersion() {
    return version;
  }

  public void setVersion(Long version) {
    this.version = version;
  }

  public String debugString() {
    StringBuilder str = new StringBuilder(domainId).append(" (v").append(version).append(")");
    return str.toString();
  }

  @Override
  public String toString() {
    final StringBuilder str = new StringBuilder("Domain{");
    str.append("domainId='");
    str.append(domainId);
    str.append("', name='");
    str.append(name);
    str.append("', type='");
    str.append(type);
    str.append("', ownerId='");
    str.append(ownerId);
    str.append("'}");
    return str.toString();
  }
}




// ProductRevisionData.java
package com.amazon.adg.product.data;

import com.amazon.adg.common.dynamodb.marshaller.ScopeLocalDateTimeMarshaller;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBIndexHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBIndexRangeKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMarshalling;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBRangeKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBVersionAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.encryption.DoNotEncrypt;
import com.amazonaws.services.dynamodbv2.datamodeling.encryption.DoNotTouch;
import java.time.LocalDateTime;

@DynamoDBTable(tableName = "ADGProductRevision")
@DoNotTouch
public class ProductRevisionData {

  public static final String TABLE_NAME = "ADGProductRevision";

  public static final String PRODUCT_ID = "ProductId";
  public static final String REVISION_ID = "RevisionId";
  public static final String EXTERNAL_REVISION_ID = "ExternalRevisionId";
  public static final String REVISION_STATE = "RevisionState";
  public static final String VENDOR_SKU = "VendorSku";
  public static final String CREATED_TIMESTAMP = "CreatedTimestamp";
  public static final String MODIFIED_TIMESTAMP = "ModifiedTimestamp";
  public static final String VERSION = "Version";

  public static final String INDEX_BY_PRODUCT_ID_AND_EXTERNAL_REVISION_ID =
      "ADGProductRevisionByProductIdAndExternalRevisionId-index";
  public static final String INDEX_BY_PRODUCT_ID_AND_CREATED_TIMESTAMP =
      "ADGProductRevisionByProductIdAndCreatedTimestamp-index";
  public static final String INDEX_BY_REVISION_ID = "ADGProductRevisionByRevisionId-index";

  private String productId;
  private String revisionId;
  private String externalRevisionId;
  private String revisionState;
  // The following fields are in revision because they can change for a Product over time
  private String vendorSku;
  private LocalDateTime createdTimestamp;
  private LocalDateTime modifiedTimestamp;
  private Long version;

  public ProductRevisionData() {}

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = PRODUCT_ID)
  @DynamoDBHashKey(attributeName = PRODUCT_ID)
  @DynamoDBIndexHashKey(
      attributeName = PRODUCT_ID,
      globalSecondaryIndexNames = {
        INDEX_BY_PRODUCT_ID_AND_EXTERNAL_REVISION_ID,
        INDEX_BY_PRODUCT_ID_AND_CREATED_TIMESTAMP
      })
  public String getProductId() {
    return productId;
  }

  public void setProductId(final String productId) {
    this.productId = productId;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = REVISION_ID)
  @DynamoDBRangeKey(attributeName = REVISION_ID)
  @DynamoDBIndexHashKey(
      attributeName = REVISION_ID,
      globalSecondaryIndexNames = INDEX_BY_REVISION_ID)
  public String getRevisionId() {
    return revisionId;
  }

  public void setRevisionId(final String revisionId) {
    this.revisionId = revisionId;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = EXTERNAL_REVISION_ID)
  @DynamoDBIndexRangeKey(
      attributeName = EXTERNAL_REVISION_ID,
      globalSecondaryIndexName = INDEX_BY_PRODUCT_ID_AND_EXTERNAL_REVISION_ID)
  public String getExternalRevisionId() {
    return externalRevisionId;
  }

  public void setExternalRevisionId(final String externalRevisionId) {
    this.externalRevisionId = externalRevisionId;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = REVISION_STATE)
  public String getRevisionState() {
    return revisionState;
  }

  public void setRevisionState(final String revisionState) {
    this.revisionState = revisionState;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = VENDOR_SKU)
  public String getVendorSku() {
    return vendorSku;
  }

  public void setVendorSku(final String vendorSku) {
    this.vendorSku = vendorSku;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = CREATED_TIMESTAMP)
  @DynamoDBIndexRangeKey(
      attributeName = CREATED_TIMESTAMP,
      globalSecondaryIndexName = INDEX_BY_PRODUCT_ID_AND_CREATED_TIMESTAMP)
  @DynamoDBMarshalling(marshallerClass = ScopeLocalDateTimeMarshaller.class)
  public LocalDateTime getCreatedTimestamp() {
    return createdTimestamp;
  }

  public void setCreatedTimestamp(final LocalDateTime createdTimestamp) {
    this.createdTimestamp = createdTimestamp;
  }

  @DoNotEncrypt
  @DynamoDBAttribute(attributeName = MODIFIED_TIMESTAMP)
  @DynamoDBMarshalling(marshallerClass = ScopeLocalDateTimeMarshaller.class)
  public LocalDateTime getModifiedTimestamp() {
    return modifiedTimestamp;
  }

  public void setModifiedTimestamp(final LocalDateTime modifiedTimestamp) {
    this.modifiedTimestamp = modifiedTimestamp;
  }

  @DoNotEncrypt
  @DynamoDBVersionAttribute(attributeName = VERSION)
  public Long getVersion() {
    return version;
  }

  public void setVersion(final Long version) {
    this.version = version;
  }

  @Override
  public String toString() {
    final StringBuilder str = new StringBuilder("ProductRevisionData{");
    str.append("productId='");
    str.append(productId);
    str.append("',revisionId='");
    str.append(revisionId);
    str.append("',externalRevisionId='");
    str.append(externalRevisionId);
    str.append("',sku='");
    str.append(vendorSku);
    str.append("'}");
    return str.toString();
  }
}




// DomainDao.java
package com.amazon.adg.product.dao;

import static com.amazon.adg.product.utils.LoggerUtils.getAmazonServiceExceptionMessage;
import static com.amazon.adg.product.utils.LoggerUtils.getConditionalCheckExceptionMessage;
import static com.amazon.adg.product.utils.LoggerUtils.getRetryLimitExceededMessage;
import static com.amazon.adg.product.utils.LoggerUtils.getThrottledRequestMessage;

import com.amazon.adg.common.product.ADGDomainTypeEnum;
import com.amazon.adg.common.util.LocalDateTimeUtil;
import com.amazon.adg.product.data.Domain;
import com.amazon.adg.product.data.DomainStateEnum;
import com.amazon.adg.product.metric.MetricConstants;
import com.amazon.adg.product.service.model.InternalServiceException;
import com.amazon.adg.product.service.model.InvalidRequestException;
import com.amazon.adg.product.utils.MetricUtils;
import com.amazon.coral.metrics.Metrics;
import com.amazon.mas.commons.coral.support.metrics.ProfilerTimer;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.SdkClientException;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBQueryExpression;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.ComparisonOperator;
import com.amazonaws.services.dynamodbv2.model.Condition;
import com.amazonaws.services.dynamodbv2.model.ConditionalCheckFailedException;
import com.amazonaws.services.dynamodbv2.model.ProvisionedThroughputExceededException;
import com.amazonaws.services.dynamodbv2.transactions.Transaction;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/** DAO for working with Domain objects and DynamoDB. */
public class DomainDao extends AbstractDao {

  private static final Logger logger = LogManager.getLogger(DomainDao.class);

  public DomainDao(
      final DynamoDBMapper readDbMapper,
      final DynamoDBMapper writeDbMapper,
      final Metrics metrics) {
    super(readDbMapper, writeDbMapper, metrics);
  }

  /**
   * Create a root domain with provided domain.
   *
   * @param domain domain to be created
   */
  public Domain createRootDomain(final Domain domain) {
    return createDomain(domain, null, null);
  }

  public void createRootDomain(final Domain domain, final Transaction transaction) {
    createDomain(domain, null, transaction);
  }

  public Domain createChildDomain(final Domain domain, final Domain parentDomain) {
    return createDomain(domain, parentDomain, null);
  }

  /**
   * Create a child domain with provided domain and parent domain.
   *
   * @param domain domain to be created
   * @param parentDomain Required if creating a child domain. Needs parent domain in order to
   *     maintain unique names across parent's children.
   * @return the created child domain
   */
  public Domain createDomain(
      final Domain domain, final Domain parentDomain, final Transaction transaction) {
    if (domain == null) {
      throw new IllegalArgumentException("domain cannot be empty; must have name");
    }
    if (StringUtils.isBlank(domain.getName())) {
      throw new IllegalArgumentException("domain name cannot be empty");
    }
    if (StringUtils.isBlank(domain.getOwnerId())) {
      throw new IllegalArgumentException("ownerId cannot be empty");
    }
    if (StringUtils.isBlank(domain.getType())) {
      domain.setType(ADGDomainTypeEnum.VENDOR.name());
    }
    if (!ADGDomainTypeEnum.isValidDomainType(domain.getType())) {
      throw new IllegalArgumentException(
          "domainType should contain one of the ADGDomainTypeEnum values");
    }

    if (parentDomain != null) {
      final Domain foundParentDomain = getParentDomain(parentDomain);
      enforceDomainNameUniqueness(domain);

      updateRootDomainPath(domain, foundParentDomain);
    }
    if (StringUtils.isBlank(domain.getDomainId())) {
      domain.setDomainId(UUID.randomUUID().toString());
    }

    domain.setModifiedTimestamp(LocalDateTimeUtil.nowUtc());
    domain.setState(DomainStateEnum.ACTIVE.name());

    logger.debug("Saving new " + domain.debugString());

    final boolean isTransaction = transaction != null;

    final ProfilerTimer timer =
        new ProfilerTimer(
            metrics,
            isTransaction
                ? MetricConstants.METRIC_DYNAMO_DB_CREATE_DOMAIN_TRANSACTION
                : MetricConstants.METRIC_DYNAMO_DB_CREATE_DOMAIN,
            false);

    try {
      timer.start();

      if (isTransaction) {
        transaction.save(domain);
      } else {
        writeDbMapper.save(domain);
      }
    } catch (final ConditionalCheckFailedException ex) {
      logger.error(
          getConditionalCheckExceptionMessage("createChildDomain", "domain", domain.toString()));
      MetricUtils.emitConditionalCheckFailedExceptionMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_CREATE_DOMAIN_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_CREATE_DOMAIN);
      throw ex;
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(getThrottledRequestMessage("createChildDomain", "domain", domain.toString()));
      MetricUtils.emitThrottledRequestMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_CREATE_DOMAIN_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_CREATE_DOMAIN);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(
          getAmazonServiceExceptionMessage("createChildDomain", "domain", domain.toString()));
      MetricUtils.emitAmazonServiceExceptionMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_CREATE_DOMAIN_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_CREATE_DOMAIN);
      throw ex;
    } finally {
      timer.stop();
    }

    return domain;
  }

  /**
   * Creating or updating root domain based on whether we get the domain.id back from the database
   *
   * @param root
   * @param transaction
   * @return
   */
  public Domain createOrUpdateRootDomain(final Domain root, final Transaction transaction) {
    final Domain foundRootDomain = getDomain(root);
    if (foundRootDomain == null || StringUtils.isBlank(foundRootDomain.getDomainId())) {
      createRootDomain(root, transaction);
    } else {
      root.setDomainId(foundRootDomain.getDomainId());
      update(root, transaction);
    }
    return getDomain(root);
  }

  /**
   * Update domain item for ADGDomain with provided domain.
   *
   * @param domain updated domain
   */
  public void update(final Domain domain) {
    update(domain, null, null);
  }

  /**
   * Update domain item for ADGDomain with provided domain as part of a transaction
   *
   * @param domain
   * @param transaction
   */
  public void update(final Domain domain, final Transaction transaction) {
    update(domain, null, transaction);
  }

  /**
   * Update domain item for ADGDomain with provided domain and a parentDomain
   *
   * @param domain
   * @param parentDomain
   */
  public void update(final Domain domain, final Domain parentDomain) {
    update(domain, parentDomain, null);
  }

  /**
   * Update domain item for ADGDomain with provided domain, parent domain as part of a transaction.
   *
   * @param domain
   * @param parentDomain Parent domain of domain.  Required only if domain that is being updated has
   *     a changed name and is a child domain.
   * @param transaction
   */
  public void update(
      final Domain domain, final Domain parentDomain, final Transaction transaction) {
    if (domain == null) {
      throw new IllegalArgumentException("domain cannot be empty");
    }
    if (StringUtils.isBlank(domain.getDomainId())) {
      throw new IllegalArgumentException("domainId cannot be empty");
    }
    if (StringUtils.isBlank(domain.getName())) {
      throw new IllegalArgumentException("domain name cannot be empty");
    }
    domain.setModifiedTimestamp(LocalDateTimeUtil.nowUtc());

    final Domain foundDomain = getDomain(domain);
    if (foundDomain == null) {
      throw new DomainNotFoundException(
          "Unable to find matching domain to update for domain " + domain.toString() + ".");
    }
    logger.debug("found matching domain: " + domain.toString());

    if (StringUtils.isNotBlank(foundDomain.getName())
        && !foundDomain.getName().equals(domain.getName())) {
      // If domain is a child, a parent domain is needed.
      if (CollectionUtils.isNotEmpty(foundDomain.getRootDomainPath())) {
        if (parentDomain == null) {
          throw new IllegalArgumentException(
              String.format(
                  "Cannot change a root domain's name: attempting to change from %s to %s.",
                  foundDomain.getName(), domain.getName()));
        }
        getParentDomain(parentDomain);
        enforceDomainNameUniqueness(domain);
      }
    }
    if (StringUtils.isNotBlank(domain.getState())) {
      // will validate and normalize the string
      domain.setState(DomainStateEnum.valueOf(domain.getState()).name());
    } else {
      // explicitly using the previous state
      domain.setState(foundDomain.getState());
    }

    if (ADGDomainTypeEnum.isValidDomainType(domain.getType())) {
      // will validate and normalize the string
      domain.setType(ADGDomainTypeEnum.fromString(domain.getType()).name());
    } else {
      // explicitly using the previous type
      domain.setType(foundDomain.getType());
    }

    // explicitly using the previous type
    if (CollectionUtils.isEmpty(domain.getRootDomainPath())
        && CollectionUtils.isNotEmpty(foundDomain.getRootDomainPath())) {
      domain.setRootDomainPath(foundDomain.getRootDomainPath());
    } else if (CollectionUtils.isNotEmpty(domain.getRootDomainPath())
        && CollectionUtils.isNotEmpty(foundDomain.getRootDomainPath())) {
      // combining both the rootDomainPaths
      final Set<String> combinedRootDomainPath = Sets.newHashSet(foundDomain.getRootDomainPath());
      combinedRootDomainPath.addAll(domain.getRootDomainPath());
      domain.setRootDomainPath(Lists.newArrayList(combinedRootDomainPath));
    }

    if (transaction != null && domain.getVersion() == null) {
      domain.setVersion(foundDomain.getVersion());
    }

    logger.debug("Saving updated domain: " + domain.toString());

    final boolean isTransaction = transaction != null;

    final ProfilerTimer timer =
        new ProfilerTimer(
            metrics,
            isTransaction
                ? MetricConstants.METRIC_DYNAMO_DB_UPDATE_DOMAIN_TRANSACTION
                : MetricConstants.METRIC_DYNAMO_DB_UPDATE_DOMAIN,
            false);

    try {
      timer.start();

      if (isTransaction) {
        transaction.save(domain);
      } else {
        writeDbMapper.save(domain);
      }
    } catch (final ConditionalCheckFailedException ex) {
      logger.error(
          getConditionalCheckExceptionMessage("updateDomain", "domain", domain.toString()));
      MetricUtils.emitConditionalCheckFailedExceptionMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_UPDATE_DOMAIN_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_UPDATE_DOMAIN);
      throw ex;
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(getThrottledRequestMessage("updateDomain", "domain", domain.toString()));
      MetricUtils.emitThrottledRequestMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_UPDATE_DOMAIN_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_UPDATE_DOMAIN);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(getAmazonServiceExceptionMessage("updateDomain", "domain", domain.toString()));
      MetricUtils.emitAmazonServiceExceptionMetric(
          isTransaction
              ? MetricConstants.METRIC_DYNAMO_DB_UPDATE_DOMAIN_TRANSACTION
              : MetricConstants.METRIC_DYNAMO_DB_UPDATE_DOMAIN);
      throw ex;
    } finally {
      timer.stop();
    }
  }

  /**
   * Gets parent domain after checking its existence.
   *
   * @param parentDomain a domain's parent that is being enforced.
   * @return the found parent domain
   */
  private Domain getParentDomain(final Domain parentDomain) {
    final Domain foundParentDomain = getDomain(parentDomain);

    if (foundParentDomain == null) {
      throw new DomainNotFoundException("parent domain could not be found");
    }

    return foundParentDomain;
  }

  /**
   * Enforces domain to have a unique name across its vendor's domains.
   *
   * @param domain the domain that is being enforced.
   */
  private void enforceDomainNameUniqueness(final Domain domain) {
    final List<Domain> matchingNameDomains =
        getDomainsByOwnerIdAndDomainName(domain.getOwnerId(), domain.getName());

    if (!CollectionUtils.isEmpty(matchingNameDomains)) {
      final String errorMessage =
          "Domain name ["
              + domain.getName()
              + "] already present under Vendor ["
              + domain.getOwnerId()
              + "]";

      logger.error("Unique constraint violated: " + errorMessage);
      throw new UniqueConstraintException(errorMessage);
    }
  }

  /**
   * Updates RootDomainPath of a domain
   *
   * @param domain the domain that is being updated.
   * @param parentDomain the parent domain of the domain that is being updated.
   */
  private void updateRootDomainPath(final Domain domain, final Domain parentDomain) {
    if (ADGDomainTypeEnum.VENDOR.name().equals(parentDomain.getType())
        && ADGDomainTypeEnum.VENDOR_ROOT.name().equals(domain.getType())) {
      throw new IllegalStateException(
          "Invalid parent domain " + parentDomain.toString() + " for domain " + domain.toString());
    }

    final List<String> rootPath = new ArrayList<>();
    rootPath.add(parentDomain.getDomainId());

    if (parentDomain.getRootDomainPath() != null) {
      rootPath.addAll(parentDomain.getRootDomainPath());
    }

    domain.setRootDomainPath(rootPath);
  }

  /**
   * Adds childDomain as child for parentDomain
   *
   * @return the found parent domain in dynamoDb
   */
  public Domain addChild(final Domain parentDomain, final Domain childDomain) {
    return addChild(parentDomain, childDomain, null);
  }

  /**
   * Adds childDomain as child for parentDomain
   *
   * @return the found parent domain in dynamoDb
   */
  public Domain addChild(
      final Domain parentDomain, final Domain childDomain, final Transaction transaction) {
    if (parentDomain == null) {
      throw new IllegalArgumentException("parent domain cannot be null");
    }
    if (childDomain == null) {
      throw new IllegalArgumentException("child domain cannot be null");
    }

    final Domain foundParentDomain = getDomain(parentDomain);
    if (foundParentDomain == null) {
      throw new DomainNotFoundException(
          "Unable to find matching parent domain to update for domain "
              + parentDomain.toString()
              + ".");
    }
    logger.debug("found matching parent domain: " + foundParentDomain.toString());
    final Domain foundChildDomain = getDomain(childDomain);
    if (foundChildDomain == null) {
      throw new DomainNotFoundException(
          "Unable to find matching child domain to update for domain "
              + childDomain.toString()
              + ".");
    }
    logger.debug("found matching child domain: " + foundChildDomain.toString());

    if (ADGDomainTypeEnum.VENDOR.name().equals(foundParentDomain.getType())
        && ADGDomainTypeEnum.VENDOR_ROOT.name().equals(foundChildDomain.getType())) {
      throw new IllegalStateException(
          "Cannot add child domain "
              + foundChildDomain.toString()
              + " to parent domain "
              + foundParentDomain.toString());
    }

    final List<String> rootPath = new ArrayList<>();
    rootPath.add(foundParentDomain.getDomainId());
    if (foundParentDomain.getRootDomainPath() != null) {
      rootPath.addAll(foundParentDomain.getRootDomainPath());
    }
    foundChildDomain.setRootDomainPath(rootPath);
    if (foundParentDomain.getChildrenIds() == null) {
      foundParentDomain.setChildrenIds(new ArrayList<>());
    }
    if (foundParentDomain.getChildren() == null) {
      foundParentDomain.setChildren(new ArrayList<>());
    }
    foundParentDomain.getChildrenIds().add(foundChildDomain.getDomainId());
    foundParentDomain.getChildren().add(foundChildDomain);

    logger.debug("Updating childDomain ...");
    update(foundChildDomain, transaction);
    logger.debug("Updating parentDomain ...");
    update(foundParentDomain, transaction);

    return foundParentDomain;
  }

  /**
   * Gets domain from ADGDomain. Determines how to get domain based on what fields are available.
   *
   * @param domain ADG-specific domain
   * @return If domain is not found, returns null if. If found, returns ADG-specific domain.
   */
  public Domain getDomain(final Domain domain) {
    if (domain == null) {
      throw new IllegalArgumentException("domain cannot be null");
    }

    if (StringUtils.isNotBlank(domain.getDomainId())) {
      return getDomainByDomainId(domain.getDomainId());
    }
    if (StringUtils.isNotBlank(domain.getOwnerId()) && StringUtils.isNotBlank(domain.getName())) {
      return getDomainByOwnerIdAndDomainName(domain.getOwnerId(), domain.getName());
    }
    throw new IllegalArgumentException(
        "domain cannot be empty; one of the identifier fields needs to be populated (e.g. domainId)");
  }

  /**
   * Gets domain from ADGDomain by domain id.
   *
   * @param domainId domainId from ADG-specific domain
   * @return If not found returns null, if found, returns domain.
   */
  public Domain getDomainByDomainId(final String domainId) {
    if (StringUtils.isBlank(domainId)) {
      throw new IllegalArgumentException("domainId cannot be empty");
    }

    logger.debug("Loading domain for domainId " + domainId + " ...");

    final ProfilerTimer timer =
        new ProfilerTimer(metrics, MetricConstants.METRIC_DYNAMO_DB_GET_DOMAIN_BY_DOMAIN_ID, false);
    Domain domain;

    try {
      timer.start();
      domain = readDbMapper.load(Domain.class, domainId);

    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(getThrottledRequestMessage("getDomainByDomainId", "domainId", domainId));
      MetricUtils.emitThrottledRequestMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_DOMAIN_BY_DOMAIN_ID);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(getAmazonServiceExceptionMessage("getDomainByDomainId", "domainId", domainId));
      MetricUtils.emitAmazonServiceExceptionMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_DOMAIN_BY_DOMAIN_ID);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(getRetryLimitExceededMessage("getDomainByDomainId", "domainId", domainId));
      MetricUtils.emitRetryLimitExceededMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_DOMAIN_BY_DOMAIN_ID);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }

    logger.debug("Found: " + domain);

    return domain;
  }

  /**
   * Gets domain from ADGDomain by ownerId and domain name
   *
   * @param ownerId ownerId from ADG-specific domain
   * @param domainName domain Name from ADG-specific domain
   * @return If domains are not found from ownerId, returns null. If found, then returns domain
   * @exception UniqueConstraintException Throws if multiple domains are found.
   */
  private Domain getDomainByOwnerIdAndDomainName(final String ownerId, final String domainName) {
    if (StringUtils.isBlank(ownerId) || StringUtils.isBlank(domainName)) {
      throw new IllegalArgumentException("ownerId and domainName cannot be empty");
    }

    logger.debug("Loading domain for domainName " + domainName + " ...");
    final List<Domain> matchingDomains = getDomainsByOwnerIdAndDomainName(ownerId, domainName);
    if (matchingDomains.size() == 1) {
      return getDomainByDomainId(matchingDomains.get(0).getDomainId());
    } else if (matchingDomains.size() > 1) {
      throw new UniqueConstraintException(
          "More than one match for domainName "
              + domainName
              + "? Matches: "
              + matchingDomains.size());
    } else {
      return null;
    }
  }

  public List<Domain> getDomains(final Collection<String> domainIds) {
    if (CollectionUtils.isEmpty(domainIds)) {
      return new ArrayList<>();
    }

    final List<Object> batchInput = new ArrayList<>();
    domainIds.forEach(domainId -> batchInput.add(new Domain(domainId)));

    final ProfilerTimer timer =
        new ProfilerTimer(metrics, MetricConstants.METRIC_DYNAMO_DB_GET_DOMAINS, false);
    Map<String, List<Object>> foundMap;

    try {
      timer.start();
      foundMap = readDbMapper.batchLoad(batchInput);

    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(getThrottledRequestMessage("getDomains", "domainIds", domainIds.toString()));
      MetricUtils.emitThrottledRequestMetric(MetricConstants.METRIC_DYNAMO_DB_GET_DOMAINS);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(
          getAmazonServiceExceptionMessage("getDomains", "domainIds", domainIds.toString()));
      MetricUtils.emitAmazonServiceExceptionMetric(MetricConstants.METRIC_DYNAMO_DB_GET_DOMAINS);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(getRetryLimitExceededMessage("getDomains", "domainIds", domainIds.toString()));
      MetricUtils.emitRetryLimitExceededMetric(MetricConstants.METRIC_DYNAMO_DB_GET_DOMAINS);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }

    if (!foundMap.containsKey(Domain.TABLE_NAME)) {
      throw new IllegalStateException(
          "Unable to find batchLoad results entry for primary table name "
              + Domain.TABLE_NAME
              + "?");
    }
    final List<Domain> found = (List<Domain>) (List<?>) foundMap.get(Domain.TABLE_NAME);
    logger.debug("Found " + found.size() + " of the original " + batchInput.size() + " item(s).");
    return found;
  }

  public List<Domain> getDomainsByOwnerId(final String ownerId) {
    return getDomainsByOwnerIdAndDomainName(ownerId, null);
  }

  /**
   * Get domains from ownerId or ownerId + domainName
   *
   * @param ownerId ownerId to search for.
   * @param domainName domainName to filter for.
   * @return If no domains are found, returns an empty list. If found, return list of domains.
   */
  private List<Domain> getDomainsByOwnerIdAndDomainName(
      final String ownerId, final String domainName) {
    if (StringUtils.isBlank(ownerId)) {
      throw new IllegalArgumentException("ownerId cannot be empty");
    }

    logger.debug("Loading domain for ownerId " + ownerId + " ...");

    final Domain domainKey = new Domain();
    domainKey.setOwnerId(ownerId);

    final DynamoDBQueryExpression<Domain> queryExpression =
        new DynamoDBQueryExpression<Domain>().withConsistentRead(false);

    if (StringUtils.isNotBlank(domainName)) {
      final Condition rangeKeyCondition =
          new Condition()
              .withComparisonOperator(ComparisonOperator.EQ)
              .withAttributeValueList(new AttributeValue().withS(domainName));

      domainKey.setName(domainName);
      queryExpression.withIndexName(Domain.INDEX_BY_OWNER_ID_DOMAINNAME);
      queryExpression.withRangeKeyCondition(Domain.DOMAIN_NAME, rangeKeyCondition);
    } else {
      queryExpression.withIndexName(Domain.INDEX_BY_OWNER_ID);
    }

    queryExpression.withHashKeyValues(domainKey);

    final ProfilerTimer timer =
        new ProfilerTimer(metrics, MetricConstants.METRIC_DYNAMO_DB_GET_DOMAINS_BY_OWNER_ID, false);
    List<Domain> matches;

    try {
      timer.start();
      matches = readDbMapper.query(Domain.class, queryExpression);
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(
          getThrottledRequestMessage(
              "getDomainsByOwnerIdAndDomainName", "ownerId", ownerId, "domainName", domainName));
      MetricUtils.emitThrottledRequestMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_DOMAINS_BY_OWNER_ID);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(
          getAmazonServiceExceptionMessage(
              "getDomainsByOwnerIdAndDomainName", "ownerId", ownerId, "domainName", domainName));
      MetricUtils.emitAmazonServiceExceptionMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_DOMAINS_BY_OWNER_ID);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(
          getRetryLimitExceededMessage(
              "getDomainsByOwnerIdAndDomainName", "ownerId", ownerId, "domainName", domainName));
      MetricUtils.emitRetryLimitExceededMetric(
          MetricConstants.METRIC_DYNAMO_DB_GET_DOMAINS_BY_OWNER_ID);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }

    logger.debug("Matches in " + queryExpression.getIndexName() + " found: " + matches.size());
    return matches;
  }

  public List<Domain> getDomainRootPath(final String domainId) {
    if (StringUtils.isBlank(domainId)) {
      throw new IllegalArgumentException("domainId cannot be empty");
    }

    logger.debug("Loading domain root path for domainId " + domainId + " ...");

    try {
      final Domain domain = getDomainByDomainId(domainId);
      if (domain == null) {
        throw new DomainNotFoundException("No matching domain found for domainId " + domainId);
      }
      logger.debug("Found: " + domain);
      final List<Domain> domainRootPath = new ArrayList<>();
      if (CollectionUtils.isEmpty(domain.getRootDomainPath())) {
        return domainRootPath;
      }

      // otherwise ...
      final List<Domain> found = getDomains(domain.getRootDomainPath());
      if (found.size() != domain.getRootDomainPath().size()) {
        throw new DomainNotFoundException(
            "Unable to find all domains specified in rootDomainPath id collection? Expected "
                + domain.getRootDomainPath().size()
                + " results but got "
                + found.size());
      }
      final Map<String, Domain> foundMap = new HashMap<>();
      found.forEach(item -> foundMap.put(item.getDomainId(), item));
      final List<Domain> rootDomainPath = new ArrayList<>();
      domain
          .getRootDomainPath()
          .forEach(
              id -> {
                if (!foundMap.containsKey(id)) {
                  throw new DomainNotFoundException("domainId " + id + " was not found.");
                }
                rootDomainPath.add(foundMap.get(id));
              });
      return rootDomainPath;
    } catch (final AmazonServiceException ex) {
      logger.error("Problem? " + ex, ex);
      throw ex;
    }
  }

  public List<Domain> getVendorDomains(final String vendorId, final String domainType) {
    if (StringUtils.isBlank(vendorId)) {
      throw new IllegalArgumentException("vendorId cannot be empty");
    }
    if (!StringUtils.isBlank(domainType) && !ADGDomainTypeEnum.isValidDomainType(domainType)) {
      throw new IllegalArgumentException(
          "domainType should contain one of the ADGDomainTypeEnum values");
    }
    logger.debug(
        "Querying for domains for vendorId " + vendorId + ", domainType " + domainType + " ...");

    final List<Domain> domains =
        getVendorDomainsByTypeFromDynamo(
            vendorId, domainType, MetricConstants.METRIC_DYNAMO_DB_GET_DOMAINS_BY_DOMAIN_TYPE);

    if (CollectionUtils.isEmpty(domains)) {
      logger.debug(
          "No matches found, no domain has domain type of "
              + domainType
              + "under vendor"
              + vendorId);
    }

    return domains;
  }

  public Domain getVendorDomainTree(final String vendorId) {
    return getVendorDomainTree(vendorId, null);
  }

  public Domain getVendorDomainTree(final String vendorId, final String domainId) {
    if (StringUtils.isBlank(vendorId)) {
      throw new IllegalArgumentException("vendorId cannot be empty");
    }
    logger.debug("Querying for domains for vendorId " + vendorId + " ...");

    Domain root = null;
    final Map<String, Condition> queryFilter = new HashMap<>();

    if (StringUtils.isNotBlank(domainId)) {
      root = getDomainByDomainId(domainId);
      if (root == null) {
        return null;
      }
      final Condition condition =
          new Condition()
              .withComparisonOperator(ComparisonOperator.CONTAINS)
              .withAttributeValueList(new AttributeValue().withS(domainId));
      queryFilter.put(Domain.ROOT_DOMAIN_PATH, condition);
    }

    final List<Domain> domains =
        getVendorDomainsFromDynamo(
            vendorId, queryFilter, MetricConstants.METRIC_DYNAMO_DB_GET_DOMAIN_TREE);

    if (root != null) {
      // add the root node to the results, as it won't be found with the filter
      logger.debug("Adding root node for subtree into matches ...");
      domains.add(0, root);
    }
    return constructVendorDomainTree(vendorId, root, domains);
  }

  private List<Domain> getVendorDomainsFromDynamo(
      final String vendorId, Map<String, Condition> queryFilter, String metricTimerName) {
    final Domain vendorKey = new Domain();
    vendorKey.setOwnerId(vendorId);

    final DynamoDBQueryExpression<Domain> queryExpression =
        new DynamoDBQueryExpression<Domain>()
            .withHashKeyValues(vendorKey)
            .withConsistentRead(false)
            .withIndexName(Domain.INDEX_BY_OWNER_ID);

    queryExpression.withQueryFilter(queryFilter);

    return getVendorDomainsFromDynamo(queryExpression, metricTimerName);
  }

  private List<Domain> getVendorDomainsByTypeFromDynamo(
      final String vendorId, final String domainType, final String metricTimerName) {
    final Domain vendorKey = new Domain();
    vendorKey.setOwnerId(vendorId);

    final DynamoDBQueryExpression<Domain> queryExpression =
        new DynamoDBQueryExpression<Domain>().withConsistentRead(false);

    if (StringUtils.isBlank(domainType)) {
      queryExpression.withIndexName(Domain.INDEX_BY_OWNER_ID);
    } else {
      final Condition rangeKeyCondition =
          new Condition()
              .withComparisonOperator(ComparisonOperator.EQ)
              .withAttributeValueList(new AttributeValue().withS(domainType));

      vendorKey.setType(domainType);
      queryExpression.withIndexName(Domain.INDEX_BY_OWNER_ID_DOMAINTYPE);
      queryExpression.withRangeKeyCondition(Domain.DOMAIN_TYPE, rangeKeyCondition);
    }
    queryExpression.withHashKeyValues(vendorKey);

    return getVendorDomainsFromDynamo(queryExpression, metricTimerName);
  }

  private List<Domain> getVendorDomainsFromDynamo(
      final DynamoDBQueryExpression<Domain> queryExpression, String metricTimerName) {
    final String vendorId = queryExpression.getHashKeyValues().getOwnerId();

    final ProfilerTimer timer = new ProfilerTimer(metrics, metricTimerName, false);
    List<Domain> domains = new ArrayList<>();

    try {
      timer.start();
      // slurp them all up
      // TODO not sure about how this works if we have incredibly large domain trees
      domains.addAll(readDbMapper.query(Domain.class, queryExpression));
    } catch (final ProvisionedThroughputExceededException ex) {
      logger.error(getThrottledRequestMessage("getVendorDomainsFromDynamo", "vendorId", vendorId));
      MetricUtils.emitThrottledRequestMetric(metricTimerName);
      throw ex;
    } catch (final AmazonServiceException ex) {
      logger.error(
          getAmazonServiceExceptionMessage("getVendorDomainsFromDynamo", "vendorId", vendorId));
      MetricUtils.emitAmazonServiceExceptionMetric(metricTimerName);
      throw ex;
    } catch (final SdkClientException ex) {
      logger.error(
          getRetryLimitExceededMessage("getVendorDomainsFromDynamo", "vendorId", vendorId));
      MetricUtils.emitRetryLimitExceededMetric(metricTimerName);
      throw new InternalServiceException(ex.getMessage(), ex);
    } finally {
      timer.stop();
    }

    logger.debug("Matches in " + queryExpression.getIndexName() + " found: " + domains.size());

    return domains;
  }

  protected Domain constructVendorDomainTree(
      final String vendorId, Domain root, final List<Domain> domains) {
    if (CollectionUtils.isEmpty(domains)) {
      logger.debug("No matches found, nothing to make a domain tree from.");
      return null;
    }
    final Map<String, Domain> map = new HashMap<>();
    final List<Domain> rootContainer = new ArrayList<>();
    domains.forEach(
        domain -> {
          if (ADGDomainTypeEnum.VENDOR_ROOT.name().equals(domain.getType())) {
            if (!CollectionUtils.isEmpty(rootContainer)) {
              throw new IllegalStateException(
                  "Vendor " + vendorId + " has more than one domain root.  Should only be one.");
            }
            // otherwise ...
            rootContainer.add(domain);
          } else {
            logger.debug(domain);
            map.put(domain.getDomainId(), domain);
          }
        });

    if (root != null) {
      // a root was passed in, we need to do some validation of the root node
      if (!CollectionUtils.isEmpty(rootContainer)) {
        final Domain vendorRoot = rootContainer.get(0);
        if (!root.getDomainId().equals(vendorRoot.getDomainId())) {
          logger.error(
              "subtree root node "
                  + root.getDomainId()
                  + " contains a vendor root "
                  + vendorRoot.getDomainId()
                  + "?  This subtree is corrupt.");
          throw new IllegalStateException(
              "subtree root domain "
                  + root.getDomainId()
                  + " contains vendor root domain "
                  + vendorRoot.getDomainId());
        } else {
          logger.debug("Specified root node was the vendor root.");
        }
      }
    } else {
      if (rootContainer.isEmpty()) {
        logger.warn(
            "No vendor root domain found?  " + domains.size() + " total matching domain(s) found.");
        return null;
      }
      root = rootContainer.get(0);
    }

    // otherwise ...
    populateChildren(vendorId, root, map, new HashSet<>());
    return root;
  }

  protected void populateChildren(
      final String vendorId,
      final Domain domain,
      final Map<String, Domain> map,
      final Set<String> processed) {
    if (processed.contains(domain.getDomainId())) {
      logger.warn(domain.getDomainId() + " already processed");
      return;
    }
    processed.add(domain.getDomainId());
    if ((domain.getChildrenIds() == null) || (domain.getChildrenIds().isEmpty())) {
      return;
    }
    // otherwise ...
    domain.setChildren(new ArrayList<>());
    domain
        .getChildrenIds()
        .forEach(
            childId -> {
              if (processed.contains(childId)) {
                logger.error(childId + " already processed, cycle?");
                return;
              } else {
                Domain child = map.get(childId);
                if (child == null) {
                  logger.warn(
                      "Unable to find a matching child domain "
                          + childId
                          + " for domain "
                          + domain.getDomainId()
                          + " for vendor "
                          + vendorId);
                } else {
                  domain.getChildren().add(child);
                  populateChildren(vendorId, child, map, processed);
                }
              }
            });
  }

  /**
   * Get domain details for ownerId and domainName as an input
   *
   * @param domainMap
   * @return
   */
  public Map<String, Domain> getDomains(
      final Map<String, com.amazon.adg.common.model.Domain> domainMap) {
    final Map<String, Domain> responseMap = new HashMap<>();
    if (domainMap == null) {
      return responseMap;
    }
    domainMap.forEach(
        (key, domain) -> {
          if (domain.getOwner() == null
              || StringUtils.isBlank(domain.getOwner().getId())
              || StringUtils.isBlank(domain.getName())) {
            throw new InvalidRequestException(
                "Domain doesn't have a valid ownerId and domainName for input : " + key);
          }
          final Domain foundDomain =
              getDomainByOwnerIdAndDomainName(domain.getOwner().getId(), domain.getName());
          if (foundDomain != null && StringUtils.isNotBlank(foundDomain.getDomainId())) {
            responseMap.put(key, foundDomain);
          }
        });
    return responseMap;
  }
}



