// File: definitions/vendor/getVendor.ts
import {
    CustomErrorMessage,
    getVendorModelObjectFromData,
    isEmpty, validateVendorConsistency, convertSolutionSetToList
} from "../../utils/utils";
import {ERROR_TYPES} from "../../constants/constants";
import {Vendor} from "../../interfaces/Product";
import {
    getVendorFromDDBUsingId,
    getVendorFromDDBUsingMasVendorId,
    getVendorFromDDBUsingVendorCode
} from "../../views/views";
import {ADGVendor} from "../../models/ADGVendor";

/**
 * View for fetching vendor data using vendor code
 * @exportView digital::catalog::adg::vendor::getVendor
 */
function getVendor(vendor: Vendor): any {
    const {id, masVendorCode, masVendorId} = vendor || {};
    try {
        let result: ADGVendor | null = null;
        if (!isEmpty(id)) {
            result = getVendorModelObjectFromData(getVendorFromDDBUsingId(id));
        } else if (!isEmpty(masVendorCode)) {
            const vendorData: any[] = convertSolutionSetToList(getVendorFromDDBUsingVendorCode(masVendorCode));
            if (vendorData?.length == 1) {
                result = getVendorModelObjectFromData(getVendorFromDDBUsingId(vendorData[0]?.VendorId));
            } else if (vendorData?.length > 1) {
                return CustomErrorMessage(`More than one match for masVendorCode ${masVendorCode}, Matches: ${vendorData.length}`, ERROR_TYPES.UniqueConstraintException);
            }
        } else if (!isEmpty(masVendorId)) {
            const vendorData: any[] = convertSolutionSetToList(getVendorFromDDBUsingMasVendorId(masVendorId));
            if (vendorData?.length == 1) {
                result = getVendorModelObjectFromData(getVendorFromDDBUsingId(vendorData[0]?.VendorId));
            } else if (vendorData?.length > 1) {
                const parentVendors: any[] = vendorData.filter(v => isEmpty((v?.MASVendorCode)))
                if (parentVendors && parentVendors.length == 1) {
                    result = getVendorModelObjectFromData(getVendorFromDDBUsingId(parentVendors[0]?.VendorId));
                } else if (parentVendors.length > 1) {
                    return CustomErrorMessage(`More than one match for masVendorId ${masVendorId}, Matches: ${parentVendors.length}`, ERROR_TYPES.UniqueConstraintException);
                }
            }
        } else {
            return CustomErrorMessage('Received a vendor input with insufficient data. An id or vendor code is' +
                ' required.', ERROR_TYPES.IllegalArgumentException);
        }
        validateVendorConsistency('id', id, result?.getVendor()?.getId());
        validateVendorConsistency('masVendorCode', masVendorCode, result?.getVendor()?.getMasVendorCode());
        validateVendorConsistency('masVendorId', masVendorId, result?.getVendor()?.getMasVendorId());
        return result;
    } catch (e) {
        return CustomErrorMessage(`Error in fetching vendor data : ${e?.message}`, ERROR_TYPES.IllegalArgumentException);
    }
}

// File: views/views.ts
/**
 * Fetches product from ddb using product id
 * @onMultipleResults {first}
 * @

/**
 * Fetches product from ddb using asin
 * @onMultipleResults {first}
 * @


/**
 * Fetches product from ddb using sku and vendor id
 * @onMultipleResults {first}
 * @


/**
 * Fetches product from ddb using external product id and vendor id
 * @onMultipleResults {first}
 * @


/**
 * Fetches vendor data from ddb using vendor id
 * @onMultipleResults {first}
 * @

/**
 * Fetches vendor data from ddb using mas vendor id
 * @

/**
 * Fetches vendor data from ddb using vendor code
 * @

// File: utils/utils.ts
import {ADGProduct} from "../models/ADGProduct";
import {ProductTypeEnumUtils} from "../enums/ProductTypeEnum";
import {Vendor} from "../models/Vendor";
import {getStoreFromUUID} from "../enums/StoreEnum";
import {ADGVendor} from "../models/ADGVendor";

export function isEmpty(input: any): boolean {
    return input == null || input === '';
}

export function CustomErrorMessage(message: string, errorType: string): any {
    return {message, type: errorType, error: true};
}

export function getProductModelObjectFromData(data: any): ADGProduct | null {
    if (!data) return null;

    const product = new ADGProduct();
    product.setId(data?.ProductId);
    product.setVendor({id: data?.VendorId});
    product.setSku(data?.VendorSku);
    product.setAsin(data?.ASIN);
    product.setProductDomain({id: data?.PrimaryDomainId});
    product.setProductTitle(data?.Title);
    product.setProductDescription(data?.Description);

    if (!isEmpty(data?.ProductType)) {
        product.setType(ProductTypeEnumUtils.fromString(data?.ProductType).toString());
    }
    if (!isEmpty(data?.ProductLine)) {
        product.setProductLine(data?.ProductLine);
    }
    if (!isEmpty(data?.ProductDetails)) {
        product.setProductDetails(JSON.parse(data?.ProductDetails));
    }
    if (!isEmpty(data?.ExternalProductId)) {
        product.setExternalProductId(data?.ExternalProductId);
    }
    if (!isEmpty(data?.PublishedRevisionId)) {
        product.setProductRevision({revisionId: data?.PublishedRevisionId});
    }

    return product;
}


export function getVendorModelObjectFromData(data: any): ADGVendor | null {
    if (!data) return null;

    const vendor: Vendor = new Vendor();
    vendor.setId(data?.VendorId);
    vendor.setName(data?.VendorName);
    vendor.setMasVendorId(data?.MASVendorId);
    vendor.setMasVendorCode(data?.MASVendorCode);
    vendor.setServiceProvider(data?.serviceProvider);
    vendor.setServiceProviderVendorId(data?.serviceProviderVendorId);
    if (!isEmpty(data?.storeId)) {
        vendor.setStore({id: data?.storeId, name: getStoreFromUUID(data?.storeId).toString()});
    }
    return new ADGVendor(vendor);
}

export function validateVendorConsistency(fieldName: string, lookupValue: string, result: string): void {
    if (!isEmpty(lookupValue) && !isEmpty(result) && lookupValue != result) {
        throw new Error(`Input ${fieldName} (${lookupValue}) does not match resulting ${fieldName} (${result})`);
    }
}

export function convertSolutionSetToList(solutions: SolutionSet<any>): any[] {
    const result: any[] = [];
    if (!solutions) return result;
    for (const solution of solutions) {
        result.push(solution);
    }
    return result;
}

// File: models/ADGVendor.ts
import {Vendor} from "./Vendor";

export class ADGVendor {
    constructor(vendor: Vendor) {
        this.vendor = vendor;
    }

    private readonly vendor: Vendor;

    getVendor(): Vendor {
        return this.vendor;
    }
}

// File: models/Vendor.ts
import {Store} from "../interfaces/Product";

export class Vendor {
    private id: string;
    private name: string;
    private externalVendorId: string;
    private parentVendorId: string;
    private store: Store;
    private masVendorCode: string;
    private masVendorId: string;
    private serviceProvider: string;
    private serviceProviderVendorId: string;

    constructor() {
    }

    getId(): string {
        return this.id;
    }

    setId(value: string) {
        this.id = value;
    }

    getName(): string {
        return this.name;
    }

    setName(value: string) {
        this.name = value;
    }

    getExternalVendorId(): string {
        return this.externalVendorId;
    }

    setExternalVendorId(value: string) {
        this.externalVendorId = value;
    }

    getParentVendorId(): string {
        return this.parentVendorId;
    }

    setParentVendorId(value: string) {
        this.parentVendorId = value;
    }

    getStore(): Store {
        return this.store;
    }

    setStore(value: Store) {
        this.store = value;
    }

    getMasVendorCode(): string {
        return this.masVendorCode;
    }

    setMasVendorCode(value: string) {
        this.masVendorCode = value;
    }

    getMasVendorId(): string {
        return this.masVendorId;
    }

    setMasVendorId(value: string) {
        this.masVendorId = value;
    }

    getServiceProvider(): string {
        return this.serviceProvider;
    }

    setServiceProvider(value: string) {
        this.serviceProvider = value;
    }

    getServiceProviderVendorId(): string {
        return this.serviceProviderVendorId;
    }

    setServiceProviderVendorId(value: string) {
        this.serviceProviderVendorId = value;
    }
}

// File: enums/StoreEnum.ts
enum StoreEnum {
    ADG = "de8c201f-36ea-4839-9a92-1247dc860154",
    ADGTEST = "00000000-0000-beef-0000-00000000feed",
    ADGQA = "30e743f5-8d93-472f-a453-54094477f087",
    ADGSandbox = "5db0932a-f23a-4b3b-a117-c4d2b39b5c71",
    AGSLive = "14a5d9ac-1f03-11e7-93ae-92361f002671",
    Appstore = "cb8566b9-0add-4d30-8af2-94f0bb50dfb3",
    Alexa = "2534f34d-d808-4256-a8f9-0d4f92a7f903",
    BusinessWebServices = "dc59a1d5-1382-4384-a87b-00ccb021bbbf",
    DSB = "80a47707-6cde-4078-ac7d-e14b32a1d25b",
    Lumberyard = "cc35ef96-0e8a-11e7-93ae-92361f002671",
    Santos = "d53ca636-b1d1-11eb-8529-0242ac130003",
    Sonic = "f906bb90-73f2-48a0-84e6-3f08c0064591",
    Tempo = "b3a1544c-f5ea-4e69-a1f3-e41f0f92ce07",
    Twitch = "5bd4863c-8083-453e-b832-e01b902d970f",
    HealthTech = "664ee4ff-0dcd-4860-bfca-cc819735a54e",
    AmazonRegistryServices = "b530cf56-54f1-4694-ab4d-d5991f3fc3ed",
    AmazonKidsPlus = "e4e4c04d-9ddd-4a44-b697-f182a8afff9d",
    Grocery = "0c96eaff-8fcf-4282-95e6-ddb7079d9da9"
}

export function getStoreFromUUID(uuid: string): StoreEnum {
    if (!uuid) {
        throw new Error("Empty string is not a valid enum value.");
    }
    for (const [enumKey, enumValue] of Object.entries(StoreEnum)) {
        if (enumValue == uuid) {
            return enumKey as StoreEnum;
        }
    }
    throw new Error(`${uuid} does not match any known enums.`);
}

// File: enums/ProductTypeEnum.ts
export enum ProductTypeEnum {
    ENTITLEMENT = "Entitlement",
    CONSUMABLE = "Consumable",
    SUBSCRIPTION = "Subscription",
    STORED_VALUE = "StoredValue",
    BUNDLE = "Bundle"
}

export class ProductTypeEnumUtils {
    static fromString(val: string): ProductTypeEnum {
        if (!val) {
            throw new Error("Empty string is not a valid enum value.");
        }
        for (const [enumKey, enumValue] of Object.entries(ProductTypeEnum)) {
            if (enumKey == val || enumValue == val) {
                return ProductTypeEnum[enumKey as keyof typeof ProductTypeEnum];
            }
        }
        throw new Error(`${val} does not match any known enums.`);
    }

    static value(productType: ProductTypeEnum): string {
        return productType;
    }

    static toString(productType: ProductTypeEnum): string {
        return productType;
    }
}

// File: models/ADGProduct.ts
import {
    Collection,
    ContentChannel,
    Domain,
    ProductDetail,
    ProductRevision,
    SellerInfo, Vendor
} from "../interfaces/Product";

export class ADGProduct {
    private asin: string;
    private asinVersion: number;
    private collections: Collection[];
    private contentChannel: ContentChannel;
    private discriminators: string[];
    private domains: Domain[];
    private externalProductId: string;
    private id: string;
    private offers: any;
    private productDescription: string;
    private productDetails: ProductDetail;
    private productDomain: Domain;
    private productLine: string;
    private productRevision: ProductRevision;
    private productTitle: string;
    private seller: SellerInfo;
    private sku: string;
    private source: string;
    private state: string;
    private type: string;
    private vendor: Vendor;

    constructor() {}

    getAsin(): string {
        return this.asin;
    }

    setAsin(value: string) {
        this.asin = value;
    }

    getAsinVersion(): number {
        return this.asinVersion;
    }

    setAsinVersion(value: number) {
        this.asinVersion = value;
    }

    getCollections(): Collection[] {
        return this.collections;
    }

    setCollections(value: Collection[]) {
        this.collections = value;
    }

    getContentChannel(): ContentChannel {
        return this.contentChannel;
    }

    setContentChannel(value: ContentChannel) {
        this.contentChannel = value;
    }

    getDiscriminators(): string[] {
        return this.discriminators;
    }

    setDiscriminators(value: string[]) {
        this.discriminators = value;
    }

    getDomains(): Domain[] {
        return this.domains;
    }

    setDomains(value: Domain[]) {
        this.domains = value;
    }

    getExternalProductId(): string {
        return this.externalProductId;
    }

    setExternalProductId(value: string) {
        this.externalProductId = value;
    }

    getId(): string {
        return this.id;
    }

    setId(value: string) {
        this.id = value;
    }

    getOffers(): any {
        return this.offers;
    }

    setOffers(value: any) {
        this.offers = value;
    }

    getProductDescription(): string {
        return this.productDescription;
    }

    setProductDescription(value: string) {
        this.productDescription = value;
    }

    getProductDetails(): ProductDetail {
        return this.productDetails;
    }

    setProductDetails(value: ProductDetail) {
        this.productDetails = value;
    }

    getProductDomain(): Domain {
        return this.productDomain;
    }

    setProductDomain(value: Domain) {
        this.productDomain = value;
    }

    getProductLine(): string {
        return this.productLine;
    }

    setProductLine(value: string) {
        this.productLine = value;
    }

    getProductRevision(): ProductRevision {
        return this.productRevision;
    }

    setProductRevision(value: ProductRevision) {
        this.productRevision = value;
    }

    getProductTitle(): string {
        return this.productTitle;
    }

    setProductTitle(value: string) {
        this.productTitle = value;
    }

    getSeller(): SellerInfo {
        return this.seller;
    }

    setSeller(value: SellerInfo) {
        this.seller = value;
    }

    getSku(): string {
        return this.sku;
    }

    setSku(value: string) {
        this.sku = value;
    }

    getSource(): string {
        return this.source;
    }

    setSource(value: string) {
        this.source = value;
    }

    getState(): string {
        return this.state;
    }

    setState(value: string) {
        this.state = value;
    }

    getType(): string {
        return this.type;
    }

    setType(value: string) {
        this.type = value;
    }

    getVendor(): Vendor {
        return this.vendor;
    }

    setVendor(value: Vendor) {
        this.vendor = value;
    }
}

