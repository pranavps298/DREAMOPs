# details of existing datapath and java classes
# don not change these as these are used as context
node_root_folder = "code_analysis/ts"
sample_java_activity_names = ["GetVendorActivity", "GetProductsActivity"]

sample_ts_class_names = ["getVendor", "getProduct"]


################
# modify the below details
################

# locally check out ADGPS and ADGProductDatapathViewsApp service codebase to get the below details
sample_java_class_base_path = (
    "/Volumes/workplace/DAVendingScripts/src/ADGProductService/src"
)
sample_ts_class_base_path = "/Volumes/workplace/DAVendingScripts/src/ADGProductDatapathViewsApp/typescript/digital/catalog"


# new java class details that you are trying to migrate , can be from any service like CRS

# new_java_class_path = "/Volumes/workplace/DAVendingScripts/src/ADGProductService/src"
# new_java_activity_name = "GetDomainsActivity"
new_java_class_path = "/Volumes/workplace/DAVendingScripts/src/CRSCatalogStorageService"
new_java_activity_name = "GetProductsBatchActivity"


# table details and the query pattern, if there are multiple tables or query patterns for a single api then provide all of them

# new_table_details = """table name: ExternalVendorIdInfo
# primary key: externalVendorId
# sort key: storeId
# gsi name: ExternalVendorIdInfoByVendorId-index
# gsi primary key: vendorId

# query pattern :
# 1. get by vendorId that is based on gsi
# 2. get by externalVendorId and storeId"""

new_table_details = """table name: CRS_VENDING_STORE
primary key: IDENTIFIER_1
gsi name: IDENTIFIER_2-GSI
gsi primary key: IDENTIFIER_2

query pattern : 
1. get by IDENTIFIER_2 that is based on gsi
2. get by IDENTIFIER_1"""


RoleArn = "arn:aws:iam::761159391633:role/bedrock_access"
# RoleArn = "arn:aws:iam::327107733065:role/bedrock_access"
