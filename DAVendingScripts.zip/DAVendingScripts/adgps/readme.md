- create a venv (recommended, else install dependencies globally)

```
python3 -m virtualenv venv
source venv/bin/activate
pip3 install -r requirements.txt
```

- install node dependencies

```
cd code_analysis/ts && npm i
```

- checkout `ADGProductService` and `ADGProductDatapathViewsApp` packages ( doesn't matter where, just has to be in your local)
- checkout the new java package for which you want to generate the datapath files ( doesn't matter where, just has to be in your local)
- make sure you have bedrock access and it has access to claude granted and note the iam role arn
- update the `config.py` file , mainly the below fields

```
sample_java_class_base_path
sample_ts_class_base_path
new_java_class_path
new_java_activity_name
new_table_details
RoleArn
```

- assume the iam role mentioned above , using `ada` maybe
- run the script

```
python3 app.py
```
- script will ask for some confirmation and your final files will be created in `output/` directory 
- copy the files to your datapath package, build, validate, test, etc
