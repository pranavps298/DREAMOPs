#!/bin/bash

# Function to display usage
usage() {
    echo "Usage: $0 --service SERVICE --region REGION --requests REQUESTS --sqs-queue-url SQS_QUEUE_URL [--debug]"
    echo "  --service SERVICE         Specify the service name"
    echo "  --region REGION           Specify the region (NA, EU, or FE)"
    echo "  --requests REQUESTS       Specify the number of requests"
    echo "  --sqs-queue-url URL       Specify the SQS queue URL"
    echo "  --debug                   Enable debug mode (optional)"
    echo "  --help                    Display this help message"
    exit 1
}

# Initialize variables
SERVICE=""
REGION=""
REQUESTS=""
SQS_QUEUE_URL="https://sqs.us-east-1.amazonaws.com/891376999957/adg-load-test"
DEBUG=false

# Parse command line options
while [[ $# -gt 0 ]]; do
    case $1 in
        --service)
            SERVICE="$2"
            shift 2
            ;;
        --region)
            REGION="$2"
            shift 2
            ;;
        --requests)
            REQUESTS="$2"
            shift 2
            ;;
        --sqs-queue-url)
            SQS_QUEUE_URL="$2"
            shift 2
            ;;
        --debug)
            DEBUG=true
            shift
            ;;
        --help)
            usage
            ;;
        *)
            echo "Unknown option: $1"
            usage
            ;;
    esac
done

# Validate required arguments
if [ -z "$SERVICE" ] || [ -z "$REGION" ] || [ -z "$REQUESTS" ] || [ -z "$SQS_QUEUE_URL" ]; then
    echo "Error: Missing required arguments"
    usage
fi

# Validate REGION
if [[ ! "$REGION" =~ ^(NA|EU|FE)$ ]]; then
    echo "Error: REGION must be NA, EU, or FE"
    usage
fi

# Construct the Python command
CMD="python src/main.py --service \"$SERVICE\" --region \"$REGION\" --requests \"$REQUESTS\" --sqs-queue-url \"$SQS_QUEUE_URL\""

# Add debug flag if enabled
if [ "$DEBUG" = true ]; then
    CMD="$CMD --debug"
fi

# Print the command being executed
echo "Executing: $CMD"

# Execute the Python script
eval $CMD