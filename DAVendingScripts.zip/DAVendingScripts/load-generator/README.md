# Load Generator

## Overview

This tool is designed to generate and manage load for API testing across different services and regions. It allows for the simulation of various API calls with configurable distribution across different endpoints and data files.

## Features

- Configurable load distribution across multiple APIs and data files
- Support for different regions (NA, EU, FE)
- Customizable transformers for payload manipulation
- Asynchronous processing for improved performance
- Integration with Amazon SQS for message publishing
- Detailed logging and distribution analysis

## Prerequisites

- Python 3.7+
- pip (Python package installer)

## Installation

1. Install the required dependencies:
   ```
pip install -r requirements.txt
   ```

## Configuration

1. Create a service configuration file in `config/<service_name>/serviceConfig.json`:
   ```json
   {
     "name": "ExampleService",
     "apis": {
       "api1": {
         "percentage": 60,
         "data_files": [
           {
             "file": "api1_data1.csv",
             "percentage": 70
           },
           {
             "file": "api1_data2.csv",
             "percentage": 30
           }
         ],
         "model_file": "api1_model.json",
         "transformer": "API1Transformer"
       },
       "api2": {
         "percentage": 40,
         "data_files": [
           {
             "file": "api2_data.csv",
             "percentage": 100
           }
         ],
         "model_file": "api2_model.json"
       }
     }
   }
   ```

2. Create API model files in `config/<service_name>/api_model/`:
   ```json
   {
     "serviceName": "ExampleService",
     "operation": "getExample",
     "request": {
       "id": "${example.id}"
     }
   }
   ```

3. Prepare your CSV data files and place them in `data/<service_name>/<region>/`.

Q4 2024 Load Test Data - https://drive.corp.amazon.com/folders/digital-catalog-vending/Load%20Testing%20Q4%202024%20Data

4. If needed, create custom transformers in `src/transformers/<service_name>/`.

## Usage

You can run the load test using the provided shell script:

bash
Note - Run ADA Command in a separate terminal, so it will automatically refresh credentials
```
ada credentials update --account=891376999957 --provider=conduit --role=IibsAdminAccess-DO-NOT-DELETE
```

```
./run_load_test.sh --service my_service --region NA --requests 100000 --sqs-queue-url "https://sqs.us-east-1.amazonaws.com/123456789012/my-queue"
```
Or directly run via python3

```
python3 src/main.py -s <service_name> -r <region> -n <number_of_requests> [-d]
```


## Project Structure

```
api-load-testing-tool/
│
├── config/
│   └── <service_name>/
│       ├── serviceConfig.json
│       └── api_model/
│           ├── api1_model.json
│           └── api2_model.json
│
├── data/
│   └── <service_name>/
│       ├── NA/
│       │   ├── api1_data1.csv
│       │   ├── api1_data2.csv
│       │   └── api2_data.csv
│       ├── EU/
│       └── FE/
│
├── src/
│   ├── main.py
│   ├── load_generator.py
│   ├── data_reader.py
│   ├── payload_constructor.py
│   ├── sqs_publisher.py
│   └── transformers/
│       └── <service_name>/
│           ├── api1_transformer.py
│           └── api2_transformer.py
│
├── requirements.txt
├── run_load_test.sh
└── README.md
```

## Logging

The tool provides detailed logging, including:
- Progress updates during load generation
- Actual request distribution across APIs and data files
- Comparison between intended and actual distribution
- Overall distribution accuracy

Debug logging can be enabled using the `-d` flag in the run script.

## Extending the Tool

To add support for a new service:
1. Create a new service configuration file
2. Add necessary API model files
3. Prepare CSV data files
4. Implement custom transformers if required

## Troubleshooting

- Ensure that your AWS credentials are properly configured for SQS access
- Use --debug arg to log at DEBUG level