import json
import re
from aiobotocore.session import get_session
from typing import Dict, List
import asyncio

class SQSPublisher:
    def __init__(self, queue_url: str, batch_size: int = 10, max_concurrent_batches: int = 200):
        self.queue_url = queue_url
        self.region = self.extract_region_from_queue_url(queue_url)
        self.session = get_session()
        self.batch_size = min(batch_size, 10)  # Ensure batch_size is not more than 10
        self.message_batch = []
        self.max_concurrent_batches = max_concurrent_batches
        self.semaphore = asyncio.Semaphore(max_concurrent_batches)

    def extract_region_from_queue_url(self, url: str) -> str:
        match = re.search(r'sqs\.([a-z0-9-]+)\.amazonaws\.com', url)
        if match:
            return match.group(1)
        raise ValueError(f"Unable to extract region from SQS URL: {url}")

    async def publish(self, message: Dict):
        self.message_batch.append(message)
        if len(self.message_batch) >= self.batch_size:
            await self.flush()

    async def flush(self):
        tasks = []
        while self.message_batch:
            batch = self.message_batch[:10]
            self.message_batch = self.message_batch[10:]
            tasks.append(self._send_batch(batch))

        await asyncio.gather(*tasks)

    async def _send_batch(self, batch: List[Dict]):
        async with self.semaphore:
            async with self.session.create_client('sqs', region_name=self.region) as client:
                await client.send_message_batch(
                    QueueUrl=self.queue_url,
                    Entries=[
                        {
                            'Id': str(i),
                            'MessageBody': json.dumps(message)
                        } for i, message in enumerate(batch)
                    ]
                )
            pass

    async def close(self):
        await self.flush()