import csv
import aiofiles
import logging
from typing import Dict, List

logger = logging.getLogger(__name__)

class DataReader:
    @staticmethod
    async def read_csv(file_path: str) -> List[Dict]:
        logger.debug(f"Reading CSV file: {file_path}")
        async with aiofiles.open(file_path, mode='r', encoding='utf-8-sig') as afp:
            content = await afp.read()
            reader = csv.DictReader(content.splitlines())
            data = list(reader)
            logger.debug(f"Read {len(data)} rows from {file_path}")
            return data