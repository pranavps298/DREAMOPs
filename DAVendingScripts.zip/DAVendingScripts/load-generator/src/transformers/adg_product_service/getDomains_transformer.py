import logging
from typing import Dict, List
import copy

logger = logging.getLogger(__name__)


class GetDomainsTransformer:
    @staticmethod
    async def transform(model: Dict, combined_rows: List[Dict[str, str]], file: str) -> Dict:
        transformed_payload = copy.deepcopy(model)
        transformed_payload['request']['domainList'] = []
        for row in combined_rows:
            transformed_payload['request']['domainList'].append(row['domain.id'])
        return transformed_payload
