import logging
from typing import Dict, List
import copy

logger = logging.getLogger(__name__)


class GetProductRevisionDocumentsTransformer:
    @staticmethod
    async def transform(model: Dict, combined_rows: List[Dict[str, str]], file: str) -> Dict:
        transformed_payload = copy.deepcopy(model)
        transformed_payload['request']['revisionIds'] = []
        for row in combined_rows:
            transformed_payload['request']['revisionIds'].append(row['revisionId'])
        return transformed_payload
