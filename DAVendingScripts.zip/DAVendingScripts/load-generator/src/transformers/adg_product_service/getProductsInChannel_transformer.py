import logging
from typing import Dict, List
import copy

logger = logging.getLogger(__name__)


class GetProductsInChannelTransformer:
    @staticmethod
    async def transform(model: Dict, combined_rows: List[Dict[str, str]], file: str) -> Dict:
        transformed_payload = copy.deepcopy(model)
        for row in combined_rows:

            transformed_payload['request']['products'].append({
                "productId": None if row['productId'] == "" else row['productId'],
                "channelId": None if row['channelId'] == "" else row['channelId']
            })
        return transformed_payload
