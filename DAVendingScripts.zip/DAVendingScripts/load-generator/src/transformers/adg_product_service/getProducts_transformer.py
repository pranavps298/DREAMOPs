import logging
from typing import Dict, List
import copy

logger = logging.getLogger(__name__)


class GetProductsTransformer:
    @staticmethod
    async def transform(model: Dict, combined_rows: List[Dict[str, str]], file: str) -> Dict:
        transformed_payload = copy.deepcopy(model)
        for row in combined_rows:
            transformed_payload['request']['products'].append({
                "productId": None if row['product.id'] == "" else row['product.id'],
                "asin": None if row['product.asin'] == "" else row['product.asin']
            })
        return transformed_payload
