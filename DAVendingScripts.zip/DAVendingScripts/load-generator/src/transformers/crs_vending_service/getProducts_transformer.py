import json
import logging
from typing import Dict, List
import copy

logger = logging.getLogger(__name__)


class GetProductsTransformer:
    @staticmethod
    async def transform(model: Dict, combined_rows: List[Dict[str, str]], file: str) -> Dict:
        transformed_payload = copy.deepcopy(model)
        row = combined_rows[0]
        transformed_payload['request']['catalogModelName'] = row['catalogModelName']
        transformed_payload['request']['queries'] = []
        if 'queryList' in row:
            queryList = json.loads(row['queryList'])
            for queryItem in queryList:
                query = {
                    'marketPlaceId': None if queryItem['marketplaceID'] == "null" else int(queryItem['marketplaceID']),
                    'isPrimaryIdentifier': True if queryItem['identifierType'][
                                                       'isPrimaryIdentifier'] == "true" else False,
                    'type': queryItem['identifierType']['type'], 'identifiers': queryItem['identifiers'].split(', ')
                }
                transformed_payload['request']['queries'].append(query)
        else:
            query = {'marketPlaceId': row['marketplaceID'],
                     'isPrimaryIdentifier': True if row['isPrimaryIdentifier'] == "TRUE" else False,
                     'type': row['type'],
                     'identifiers': row['identifiers'].split(', ')
                     }
            transformed_payload['request']['queries'].append(query)
        return transformed_payload
