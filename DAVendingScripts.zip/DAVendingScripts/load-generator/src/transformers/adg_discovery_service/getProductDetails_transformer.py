import logging
from typing import Dict, List
import copy

logger = logging.getLogger(__name__)


class GetProductDetailsTransformer:
    marketplaceIdToObfuscatedIdMap = {
        1: ("ATVPDKIKX0DER", "US"),
        3: ("A1F83G8C2ARO7P", "GB"),
        4: ("A1PA6795UKMFR9", "DE"),
        5: ("A13V1IB3VIYZZH", "FR")
    }

    @staticmethod
    async def transform(model: Dict, combined_rows: List[Dict[str, str]], file: str) -> Dict:
        transformed_payload = copy.deepcopy(model)
        docket_id = file.split('-')[0] + '.json'

        if not combined_rows:
            logger.warning("No combined rows provided")
            return transformed_payload

        marketplace_id = int(combined_rows[0].get('marketplace_id', 0))
        obfuscated_id, cor = GetProductDetailsTransformer.marketplaceIdToObfuscatedIdMap.get(marketplace_id)

        if not obfuscated_id or not cor:
            logger.error(f"Invalid marketplace_id: {marketplace_id}")
            return transformed_payload

        transformed_payload['request'].update({
            'docketId': docket_id,
            'pfm': obfuscated_id,
            'cor': cor,
            'asins': [row['asin'] for row in combined_rows if 'asin' in row]
        })

        return transformed_payload
