import os
import random
import asyncio
import logging
from asyncio import Semaphore
from typing import Dict, List, Tuple
from data_reader import DataReader
from payload_constructor import PayloadConstructor
from sqs_publisher import SQSPublisher

logger = logging.getLogger(__name__)

class LoadGenerator:
    """
    A class used to generate and manage load for API testing.

    This class handles the process of loading test data, distributing requests
    across different APIs and data files, and sending messages to an SQS queue.

    Attributes:
        config (Dict): Configuration dictionary for the service being tested.
        service_name (str): Name of the service being tested.
        region (str): Region for which the test is being conducted (e.g., 'NA', 'EU', 'FE').
        sqs_publisher (SQSPublisher): Instance of SQSPublisher for sending messages to SQS.
        base_path (str): Base path for locating configuration and data files.
        api_data (Dict): Dictionary to store loaded API data.
        api_data_locks (Dict): Dictionary of locks for thread-safe access to API data.
        request_counter (int): Counter for the number of requests processed.
        log_frequency (int): Frequency of logging progress updates.

    Methods:
        load_api_data(): Loads and prepares the API data for testing.
        calculate_request_distribution(): Calculates the distribution of requests across APIs and files.
        create_api_sequence(): Creates a sequence of API requests based on the calculated distribution.
        get_next_row(): Retrieves the next row of data for a given API and file.
        process_single_request(): Processes a single API request.
        generate_load(): Main method to generate the load for testing.
    """

    def __init__(self, config: Dict, service_name: str, region: str, sqs_queue_url: str):
        """
        Initializes the LoadGenerator with the given configuration.

        Args:
            config (Dict): Configuration dictionary for the service.
            service_name (str): Name of the service being tested.
            region (str): Region for which the test is being conducted.
        """
        self.config = config
        self.service_name = service_name
        self.region = region
        self.sqs_publisher = SQSPublisher(sqs_queue_url)
        self.base_path = os.path.dirname(os.path.dirname(__file__))
        self.api_data = {}
        self.api_data_locks = {}
        self.request_counter = 0
        self.log_frequency = 1000
        self.semaphore = Semaphore(200)
        logger.debug(f"LoadGenerator initialized for service: {service_name}, region: {region}")

    async def load_api_data(self):
        """
        Loads API data from CSV files and initializes locks for thread-safe access.

        This method reads data for each API and file combination specified in the
        configuration, shuffles the data, and sets up locks for concurrent access.
        """
        for api, api_config in self.config['apis'].items():
            self.api_data[api] = {}
            self.api_data_locks[api] = {}
            for file_config in api_config['data_files']:
                file_path = os.path.join(self.base_path, 'data', self.service_name, self.region, file_config['file'])
                self.api_data[api][file_config['file']] = await DataReader.read_csv(file_path)
                random.shuffle(self.api_data[api][file_config['file']])
                self.api_data_locks[api][file_config['file']] = asyncio.Lock()

    def calculate_request_distribution(self) -> List[Tuple[str, str, float]]:
        """
        Calculates the distribution of requests across APIs and their data files.

        This method determines how the total load should be distributed across different
        APIs and their associated data files. It takes into account the percentage
        specified for each API in the configuration, as well as the percentages
        specified for individual data files within each API.

        The calculation process involves the following steps:
        1. Calculate the total percentage across all APIs to normalize the API-level percentages.
        2. For each API:
           a. Calculate its ratio based on its percentage of the total.
           b. If the API has multiple data files:
              - Calculate the total percentage across all files for this API.
              - For each file, calculate its ratio of the API's total requests.
           c. If the API doesn't have multiple data files, treat it as a single file with 100% of the API's requests.
        3. Combine the API-level and file-level ratios to get the overall ratio for each (API, file) combination.

        The resulting distribution ensures that:
        - The relative proportions of requests between different APIs are maintained as specified in the configuration.
        - Within each API, the relative proportions of requests between different data files are maintained.
        - The sum of all ratios equals 1, representing 100% of the total requests.

        Returns:
            List[Tuple[str, str, float]]: A list of tuples, each containing:
                - API name (str)
                - File name (str)
                - Ratio of total requests for this (API, file) combination (float)

        Example:
            If the configuration specifies:
            - API1: 60% of total requests
              - File1: 70% of API1's requests
              - File2: 30% of API1's requests
            - API2: 40% of total requests
              - File3: 100% of API2's requests

            The resulting distribution might be:
            [
                ('API1', 'File1', 0.42),  # 60% * 70% = 42% of total requests
                ('API1', 'File2', 0.18),  # 60% * 30% = 18% of total requests
                ('API2', 'File3', 0.40)   # 40% * 100% = 40% of total requests
            ]

        Note:
            The actual number of requests generated for each combination will be based on
            these ratios, but may vary slightly due to rounding when converting ratios to
            integer numbers of requests.
        """
        distribution = []
        total_api_percentage = sum(api_config['percentage'] for api_config in self.config['apis'].values())

        for api, api_config in self.config['apis'].items():
            api_ratio = api_config['percentage'] / total_api_percentage

            if 'data_files' in api_config:
                total_file_percentage = sum(file_config['percentage'] for file_config in api_config['data_files'])
                for file_config in api_config['data_files']:
                    file_ratio = file_config['percentage'] / total_file_percentage
                    overall_ratio = api_ratio * file_ratio
                    distribution.append((api, file_config['file'], overall_ratio))
            else:
                distribution.append((api, api_config.get('file', f"{api}_data.csv"), api_ratio))

        logger.debug(f"Calculated request distribution: {distribution}")
        return distribution

    def create_api_sequence(self, distribution: List[Tuple[str, str, float]], total_requests: int) -> List[Tuple[str, str]]:
        """
        Creates a sequence of API requests based on the calculated distribution.

        Args:
            distribution (List[Tuple[str, str, float]]): The calculated request distribution.
            total_requests (int): Total number of requests to generate.

        Returns:
            List[Tuple[str, str]]: A list of (api, file) tuples representing the request sequence.
        """
        sequence = []
        for api, file, ratio in distribution:
            api_file_requests = max(1, int(ratio * total_requests))
            sequence.extend([(api, file)] * api_file_requests)

        random.shuffle(sequence)
        logger.debug(f"Created API sequence with {len(sequence)} requests")
        return sequence[:total_requests]

    async def get_next_row(self, api: str, file: str) -> Dict:
        """
        Retrieves the next row of data for a given API and file.

        This method ensures thread-safe access to the data and reloads the file if necessary.

        Args:
            api (str): The API name.
            file (str): The data file name.

        Returns:
            Dict: A dictionary representing the next row of data.
        """
        async with self.api_data_locks[api][file]:
            if not self.api_data[api][file]:
                logger.debug(f"Reloading data for API: {api}, File: {file}")
                file_path = os.path.join(self.base_path, 'data', self.service_name, self.region, file)
                self.api_data[api][file] = await DataReader.read_csv(file_path)
                random.shuffle(self.api_data[api][file])
            return self.api_data[api][file].pop()

    async def process_single_request(self, api: str, file: str):
        async with self.semaphore:
            api_config = self.config['apis'][api]
            model_file = os.path.join(self.base_path, 'config', self.service_name, 'api_model', api_config['model_file'])

            file_config = next(f for f in api_config['data_files'] if f['file'] == file)
            rows_to_combine = self.determine_rows_to_combine(file_config)

            transformer = api_config.get('transformer')
            if rows_to_combine > 1:
                if not transformer:
                    raise ValueError(f"Transformer is required when combining rows for API: {api}")

            combined_rows = []
            for _ in range(rows_to_combine):
                row = await self.get_next_row(api, file)
                combined_rows.append(row)

            payload = await PayloadConstructor.construct_payload(combined_rows, model_file, transformer, self.service_name, api, file)

            self.request_counter += 1
            if self.request_counter % self.log_frequency == 0:
                logger.info(f"Processed {self.request_counter} requests")

            await self.sqs_publisher.publish(payload)

    def determine_rows_to_combine(self, file_config):
        if 'row_combination' not in file_config:
            return 1

        rand = random.random() * 100
        cumulative = 0
        for combo in file_config['row_combination']:
            cumulative += combo['percentage']
            if rand <= cumulative:
                return combo['rows']
        return 1  # Default to 1 if percentages don't add up to 100

    async def generate_load(self, total_requests: int):
        """
        Main method to generate the load for testing.

        This method orchestrates the entire load generation process, including loading
        data, creating the request sequence, and processing all requests.

        Args:
            total_requests (int): Total number of requests to generate.
        """
        logger.info(f"Generating load for {total_requests} requests")
        await self.load_api_data()
        distribution = self.calculate_request_distribution()
        api_sequence = self.create_api_sequence(distribution, total_requests)

        tasks = []
        for api, file in api_sequence:
            task = self.process_single_request(api, file)
            tasks.append(task)

        logger.info(f"Processing {len(tasks)} requests")
        await asyncio.gather(*tasks)
        await self.sqs_publisher.close()
        logger.info("Load generation completed")