import json
import argparse
import os
import asyncio
import uvloop
import aiofiles
import logging
from typing import Dict
import subprocess

from load_generator import LoadGenerator

class Main:
    @staticmethod
    async def load_config(service_name: str) -> Dict:
        config_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'config', service_name, 'serviceConfig.json')
        async with aiofiles.open(config_path, 'r') as f:
            return json.loads(await f.read())

    @staticmethod
    async def run():
        parser = argparse.ArgumentParser(description='Generate load test data for a specific service')
        parser.add_argument('--service', help='Name of the service to test')
        parser.add_argument('--region', choices=['NA', 'EU', 'FE'], help='Region to test (NA, EU, or FE)')
        parser.add_argument('--requests', type=int, default=100000, help='Total number of requests to generate')
        parser.add_argument('--debug', action='store_true', help='Enable debug logging')
        parser.add_argument('--sqs-queue-url', help='SQS queue URL for publishing messages')

        args = parser.parse_args()

        # Set up logging
        log_level = logging.DEBUG if args.debug else logging.INFO
        logging.basicConfig(level=log_level, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        logger = logging.getLogger(__name__)

        logger.info(f"Starting load test for service: {args.service}, region: {args.region}, requests: {args.requests}")
        config = await Main.load_config(args.service)
        logger.debug(f"Loaded config: {config}")

        load_generator = LoadGenerator(config, args.service, args.region, args.sqs_queue_url)
        await load_generator.generate_load(args.requests)
        logger.info("Load test completed")

if __name__ == "__main__":
    uvloop.install()
    asyncio.run(Main.run())