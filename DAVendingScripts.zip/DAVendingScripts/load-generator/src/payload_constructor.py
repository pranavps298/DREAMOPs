import json
import importlib
import aiofiles
import logging
from typing import Dict, Any, List

logger = logging.getLogger(__name__)


class PayloadConstructor:
    model_cache: Dict[str, Dict] = {}

    @staticmethod
    async def construct_payload(combined_rows: List[Dict[str, str]], model_file: str, transformer: str, service_name: str, api_name: str, file: str) -> Dict:
        if model_file not in PayloadConstructor.model_cache:
            logger.debug(f"Loading model file: {model_file}")
            async with aiofiles.open(model_file, 'r') as f:
                content = await f.read()
                PayloadConstructor.model_cache[model_file] = json.loads(content)

        model = PayloadConstructor.model_cache[model_file]

        if len(combined_rows) > 1 or transformer:
            try:
                module = importlib.import_module(f"transformers.{service_name}.{api_name}_transformer")
                transformer_class = getattr(module, transformer)
                payload = await transformer_class.transform(model, combined_rows, file)
            except ImportError:
                logger.error(f"Failed to import transformer: {transformer}")
                raise
            except AttributeError:
                logger.error(f"Failed to find transformer class: {transformer}")
                raise
            except Exception as e:
                logger.error(f"Error applying transformer {transformer}: {str(e)}")
                raise
        else:
            # If only one row and no transformer specified, use the default placeholder replacement
            payload = PayloadConstructor.replace_placeholders(model, combined_rows[0])

        logger.info(f"Constructed payload: {json.dumps(payload)}")
        return payload

    @staticmethod
    def replace_placeholders(model: Any, row: Dict[str, str]) -> Any:
        if isinstance(model, str):
            if model.startswith('%REPLACE_VAR:') and model.endswith('%'):
                data_type = model[13:16]
                key = model[17:-1]
                value = PayloadConstructor.get_value_or_null(row, key)
                return PayloadConstructor.convert_value(value, data_type)
            return model
        elif isinstance(model, dict):
            return {k: PayloadConstructor.replace_placeholders(v, row) for k, v in model.items()}
        elif isinstance(model, list):
            return [PayloadConstructor.replace_placeholders(item, row) for item in model]
        else:
            return model

    @staticmethod
    def get_value_or_null(row: Dict[str, str], key: str) -> Any:
        value = row.get(key, '').strip()
        if value == '' or value.lower() == 'null':
            return None
        return value

    @staticmethod
    def convert_value(value: str, type_hint: str) -> Any:
        if value is None:
            return None
        if type_hint == 'str':
            return str(value)
        elif type_hint == 'int':
            return int(value)
        elif type_hint == 'float':
            return float(value)
        elif type_hint == 'bool':
            return value.lower() == 'true'
        else:
            raise ValueError(f"Unsupported type hint: {type_hint}")