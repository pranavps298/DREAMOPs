import subprocess

import asyncio
import json


async def execute_curl(curl_command):
    process = await asyncio.create_subprocess_shell(
        curl_command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE
    )
    output, error = await process.communicate()
    if process.returncode != 0:
        return {"error": error.decode("utf-8")}
    return output.decode("utf-8")


async def create_ticket(title, body, category, type, item, watchers):
    categorization = [
        {"key": "category", "value": category},
        {"key": "type", "value": type},
        {"key": "item", "value": item},
    ]
    return await execute_curl(
        """aws tickety --region us-west-2 --endpoint-url https://us-west-2.api.tickety.amazon.dev create-ticket --ticket '{  "title": \""""
        + title
        + """\", "severity": "SEV_4" ,"description" : """
        + json.dumps(body)
        + """ ,"watchers" : """
        + json.dumps(watchers)
        + """ ,"categorization" : """
        + json.dumps(categorization)
        + """  ,"descriptionContentType": "text/amz-markdown-sim" }' --aws-account-id Default --ticketing-system-name Default"""
    )


async def comment_on_ticket(ticket_id, comment, thread_name="CORRESPONDENCE"):

    return await execute_curl(
        """aws tickety --region us-west-2 --endpoint-url https://us-west-2.api.tickety.amazon.dev create-ticket-comment --message \""""
        + comment
        + """\" --ticket-id """
        + ticket_id
        + """ --thread-name """
        + thread_name
        + """ --aws-account-id Default --ticketing-system-name Default"""
    )
