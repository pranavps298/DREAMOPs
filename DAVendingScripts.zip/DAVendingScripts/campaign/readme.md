1. setup tickety cli : https://code.amazon.com/packages/TicketyServiceCliExamples/trees/mainline

```
mcurl 'https://code.amazon.com/packages/TicketyServiceModel/releases/1.0/latest_artifact?version_set=TicketyService/live&path=model/tickety-2022-07-25.normal.json&download=true' > tickety-2022-07-25.normal.json

aws configure add-model --service-name tickety --service-model file://./tickety-2022-07-25.normal.json
```

2. We are using adg-dev-team-beta account to cut tickets. Ticketing application: https://t.corp.amazon.com/settings/applications/catalog-vending-ticketing-app. Reference used for onboarding: https://w.amazon.com/bin/view/IssueManagement/SIMTicketing/TicketyAPI/GettingStarted

3. use ada to assume the above onboarded aws accounts admin role
```
ada credentials update --account=707956163901 --provider=conduit --role=IibsAdminAccess-DO-NOT-DELETE --once
```

4. update the `clients` map in `app.py` and the `title` an `body` section in `main()` method in `app.py`

5. run the script 
```
python3 app.py
```