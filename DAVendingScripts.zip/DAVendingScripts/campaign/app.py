import asyncio
import logging
import argparse
from typing import List, Dict
from datetime import datetime
from ticketly_ticket import create_ticket
import os

OUTPUT_FOLDER = "output"


def setup_logging(log_level: str) -> str:
    """Setup logging configuration"""
    log_filename = f'{OUTPUT_FOLDER}/ticket_creation_{datetime.now().strftime("%Y%m%d_%H%M%S")}.log'

    level = getattr(logging, log_level.upper())
    logging.basicConfig(
        level=level,
        format="%(asctime)s - %(levelname)s - %(message)s",
        handlers=[logging.FileHandler(log_filename), logging.StreamHandler()],
    )
    return log_filename


# Constants
TICKET_TITLE = "[ADGDISCO] Docket Package Crux Rule Modification"
TICKET_TEMPLATE = """
**Why are you receiving this ticket?** 
We are from Digital Catalog Team currently owning the service **ADGDiscoveryService** and we are in the process of security review of the service. One of the action items from the review is to update the crux rule for the below mentioned docket packages to have our team `adg-client-discovery` as one of the mandatory reviewers. This is because the groovy script used in dockets does not have any checks and they can execute arbitrary code. 

**What needs to be done?** 
Simply update the crux rule for the below mentioned docket packages to have our team `adg-client-discovery` as one of the mandatory reviewers.

- Package List : `{service_name}`"""

TICKET_CONTACTS = [
    {"id": "kmarxlh@amazon.com", "type": "email"},
    {"id": "digital-catalog-vending@amazon.com", "type": "email"},
    {"id": "da-catalog-vending@amazon.com", "type": "email"},
]


def get_client_list():
    """Get list of clients to create tickets for."""
    return [
        {
            "Service": "ADGDiscoveryDocketsTempo",
            "Category": "Tempo",
            "Type": "Client Services",
            "Item": "General",
        },
        {
            "Service": "ADGDiscoveryDocketsDigitalGoods",
            "Category": "Appstore",
            "Type": "Digital Goods",
            "Item": "ADGDiscoveryService",
        },
        {
            "Service": "ADGDiscoveryDocketsA2SGUI",
            "Category": "Alexa",
            "Type": "Customer Journeys",
            "Item": "Catalog",
        },
        {
            "Service": "ADGDiscoveryDocketsDeviceSubs",
            "Category": "Website",
            "Type": "Amazon Devices",
            "Item": "SubsCX",
        },
        {
            "Service": "ADGDiscoveryDocketsMonera,ADGDiscoveryDocketsMoneraCore",
            "Category": "Appstore",
            "Type": "Digital Goods",
            "Item": "Monera",
        },
        {
            "Service": "AlexaMonDiscoveryDockets,AlexaMonDiscoveryDockets",
            "Category": "Alexa",
            "Type": "Digital Sales",
            "Item": "AlexaDigitalCommerceAPI",
        },
        {
            "Service": "ADGDiscoveryDocketsAlexaDigitalCommerceMobileService",
            "Category": "Alexa",
            "Type": "Digital Sales",
            "Item": "AlexaDigitalCommerceMobileService",
        },
        {
            "Service": "ADGDiscoveryDocketsAlexaLists",
            "Category": "Alexa",
            "Type": "Shopping List",
            "Item": "DeeAppListProxy",
        },
        {
            "Service": "ADGDiscoveryDocketsDTBPortal",
            "Category": "APS",
            "Type": "MobileWebPodZ",
            "Item": "General",
        },
        {
            "Service": "ADGDiscoveryDocketsFireTVAppstore",
            "Category": "Fire TV",
            "Type": "Apps & Games",
            "Item": "Services",
        },
        {
            "Service": "ADGDiscoveryDocketsFireTVDAP",
            "Category": "IT Dev",
            "Type": "New Ad Products",
            "Item": "Device Services",
        },
        {
            "Service": "ADGDiscoveryDocketsKidStore",
            "Category": "Kids and Family",
            "Type": "Stores",
            "Item": "Auto-cuts",
        },
        {
            "Service": "ADGDiscoveryDocketsMarIOPush",
            "Category": "Kindle Tablet",
            "Type": "MarIO",
            "Item": "Valkyrie",
        },
        {
            "Service": "ADGDiscoveryDocketsMultiAgentHandoffServiceVPC",
            "Category": "Digital Media Technology",
            "Type": "AlexaMultiAgent",
            "Item": "HandoffService",
        },
        {
            "Service": "ADGDiscoveryDocketsP11Vending,ADGDiscoveryDocketsP11Vending",
            "Category": "Digital Media Technology",
            "Type": "DPE",
            "Item": "Vending-Dev",
        },
        {
            "Service": "ADGDiscoveryDocketsSASSDS",
            "Category": "Alexa",
            "Type": "Skills Store",
            "Item": "Skill Arbitration",
        },
        {
            "Service": "ADGDiscoveryDocketsSamusCatalog",
            "Category": "Twitch",
            "Type": "Prime",
            "Item": "Boosters",
        },
        {
            "Service": "FireTVNewsDiscoveryDockets",
            "Category": "Fire TV",
            "Type": "Podium Engine Platform",
            "Item": "Hedwig Backend",
        },
        {
            "Service": "SonicDiscoveryDockets",
            "Category": "Amazon Game Studios",
            "Type": "Amazon Games App",
            "Item": "Client",
        },
    ]


async def create_single_ticket(client: Dict, dry_run: bool = False) -> Dict:
    """Create a single ticket for a client."""
    try:
        logger.info(f"Creating ticket for service: {client['Service']}")

        if dry_run:
            logger.info(f"DRY RUN: Would create ticket for {client['Service']}")
            ticket_id = f"DRY_RUN_{client['Service']}"
        else:
            ticket_id = await create_ticket(
                TICKET_TITLE,
                TICKET_TEMPLATE.format(service_name=client["Service"]),
                client["Category"],
                client["Type"],
                client["Item"],
                TICKET_CONTACTS,
            )

        logger.info(f"Successfully created ticket {ticket_id} for {client['Service']}")
        return {
            "service_name": client["Service"],
            "ticket_id": ticket_id,
            "status": "SUCCESS",
        }

    except Exception as ex:
        logger.error(f"Failed to create ticket for {client['Service']}: {str(ex)}")
        return {"service_name": client["Service"], "error": str(ex), "status": "FAILED"}


async def create_tickets_batch(
    clients: List[Dict], batch_size: int = 5, dry_run: bool = False
) -> List[Dict]:
    """Create tickets in batches."""
    results = []
    for i in range(0, len(clients), batch_size):
        batch = clients[i : i + batch_size]
        logger.info(f"Processing batch {(i//batch_size) + 1}, size: {len(batch)}")

        batch_results = await asyncio.gather(
            *(create_single_ticket(client, dry_run) for client in batch)
        )
        results.extend(batch_results)

    return results


def summarize_results(results: List[Dict]):
    """Log summary of results."""
    successful = [r for r in results if r["status"] == "SUCCESS"]
    failed = [r for r in results if r["status"] == "FAILED"]

    logger.info("====== EXECUTION SUMMARY ======")
    logger.info(f"Total services processed: {len(results)}")
    logger.info(f"Successfully created tickets: {len(successful)}")
    logger.info(f"Failed tickets: {len(failed)}")

    if successful:
        logger.info("\nSuccessfully created tickets:")
        for result in successful:
            logger.info(
                f"Service: {result['service_name']} -> Ticket ID: {result['ticket_id']}"
            )

    if failed:
        logger.info("\nFailed ticket creations:")
        for result in failed:
            logger.info(
                f"Service: {result['service_name']} -> Error: {result['error']}"
            )


async def main(args):
    """Main execution function."""
    try:

        client_list = get_client_list()
        logger.info(f"Starting ticket creation process for {len(client_list)} services")
        if args.dry_run:
            logger.info("Running in DRY RUN mode - no actual tickets will be created")

        # Create tickets in batches
        results = await create_tickets_batch(
            client_list, batch_size=args.batch_size, dry_run=args.dry_run
        )

        # Summarize results
        summarize_results(results)

        results_filename = f'{OUTPUT_FOLDER}/ticket_results_{datetime.now().strftime("%Y%m%d_%H%M%S")}.txt'

        with open(results_filename, "w") as f:
            for result in results:
                f.write(f"{str(result)}\n")

        logger.info(f"\nResults saved to {results_filename}")

        return results

    except Exception as ex:
        logger.error(f"Fatal error in main execution: {str(ex)}")
        raise


def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        description="Create tickets for API migration campaign"
    )
    parser.add_argument(
        "--batch-size",
        type=int,
        default=5,
        help="Number of tickets to create simultaneously (default: 5)",
    )
    parser.add_argument(
        "--dry-run", action="store_true", help="Run without creating actual tickets"
    )
    return parser.parse_args()


if __name__ == "__main__":
    if not os.path.exists(OUTPUT_FOLDER):
        os.makedirs(OUTPUT_FOLDER)
    args = parse_arguments()
    log_filename = setup_logging("INFO")
    logger = logging.getLogger(__name__)
    asyncio.run(main(args))
