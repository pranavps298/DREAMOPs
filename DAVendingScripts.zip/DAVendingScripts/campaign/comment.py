import asyncio
from ticketly_ticket import post_comment_on_ticket_from_maxis
import json
import logging
import re
import time

logging.basicConfig(level=logging.INFO)

COMMENT_TEXT = """_This is a friendly reminder to check the status of the progress for the datapath migration as mentioned in the original ticket._
**Please note that the codigo read api's are scheduled to be deprecated by Q1 2025 end and you are expected to migrate to datapath within the said timeline.**
- For detailed steps please check out the original ticket or this quip : https://quip-amazon.com/2rgqAjQ0uP3Y/Vending-Service-API-to-Datapath-Migration 
- For any support comment on this sim or reach out to us via slack channel `#digicat-deprecation`

**Service : `{}`**

_If you have  already completed the migration please mention the same on this sim._"""


async def comment_on_ticket():
    # read file as ticket_data/input/vendor_sims.json
    ticket_data = {}
    with open("ticket_data/input/vendor_sims.json", "r") as f:
        ticket_data = json.load(f)
    logging.info(f"found tickets in file : [{len(ticket_data)}]")

    # uncomment if you want to remove duplicates

    # ticket_data = [
    #     ticket_data[i]
    #     for i in range(len(ticket_data))
    #     if ticket_data[i]["Tracking Sim"]
    #     not in [ticket_data[j]["Tracking Sim"] for j in range(i)]
    # ]
    logging.info(f"processing for tickets : [{len(ticket_data)}]")
    success = []
    failure = []
    commented_responses = []
    for ticket in ticket_data:
        try:
            logging.info(
                f"\n\n------\nprocessing ticket for : [{ticket.get('Service')}]"
            )
            tracking_sim = ticket.get("Tracking Sim")
            if tracking_sim and re.search(
                "issues\.amazon\.com|sim\.amazon\.com",
                tracking_sim,
                flags=re.IGNORECASE,
            ):
                ticket_id = tracking_sim.split("/")[-1]
                logging.info(f"adding comment for ticket id : [{ticket_id}]")
                print(COMMENT_TEXT.format(ticket.get("Service")))
                resp = await post_comment_on_ticket_from_maxis(
                    ticket_id,
                    COMMENT_TEXT.format(ticket.get("Service")),
                )

                commented_responses.append(resp)
                success.append(ticket)
            else:
                logging.info(
                    f"skipping ticket for : [{ticket.get('Service')}] due to empty tracking sim."
                )
                failure.append(ticket)
                continue
        except Exception as e:
            logging.error(
                f"error while processing ticket : [{ticket.get('Service')}]\n{e}"
            )
            failure.append(ticket)
            continue

    logging.info(f"\n\n\success : [{len(success)}], failure : [{len(failure)}]")
    with open(f"ticket_data/output/commented_responses_{time.time()}.json", "w") as f:
        json.dump(commented_responses, f)


asyncio.run(comment_on_ticket())
