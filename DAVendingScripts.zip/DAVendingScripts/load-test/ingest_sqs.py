from get_data import generate_data, generate_random_data
from itertools import islice
import uuid
import logging

# drop in replacement for asyncio, much much much faster than default asyncio
import uvloop
uvloop.install()

try:
    import aioboto3
    import asyncio
except Exception as e:
    pass

logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')
 
logger = logging.getLogger()
logger.setLevel(logging.INFO)

CHUNK_SIZE = 10 # sqs supports 10 messages in one batch
QUEUE_URL = "https://sqs.us-east-1.amazonaws.com/891376999957/adg-load-test"


def _chunks(data, size):
    it = iter(data)
    for first in it:
        yield [first] + list(islice(it, size - 1))


async def send_message(sqs_client, chunk_message_body):
    try:
        # uncomment below code to single message in one call
        # response = await sqs_client.send_message(
        #     QueueUrl=QUEUE_URL, MessageBody=message_body
        # )
        # return response["MessageId"]

        #batch enqueueing messages
        response = await sqs_client.send_message_batch(
            QueueUrl=QUEUE_URL,
            Entries=[
                {"Id": f"{uuid.uuid4()}", "MessageBody": message_body}
                for message_body in chunk_message_body
            ],
        )
        return len(response.get("Successful", []))
    except Exception as e:
        print(f"Failed to send message: {e}")
        return None


async def send_messages(messages, region_name="us-east-1"):
    session = aioboto3.Session()
    async with session.client("sqs", region_name=region_name) as sqs_client:
        tasks = [
            send_message(sqs_client, msg_chunk)
            for msg_chunk in _chunks(messages, CHUNK_SIZE)
        ]
        results = await asyncio.gather(*tasks)
        return results


async def run():
    # payload_data = generate_data("A1VC38T7YXB528", "JP", 20000, "Appstore")
    payload_data = generate_data("A1F83G8C2ARO7P", "GB", 20000, "Appstore")
    # payload_data = generate_random_data(
    #     "A1VC38T7YXB528",
    #     "JP",
    #     20000,
    # )
    logger.info(f"payload_data_size {len(payload_data)}")
    for count, _ in enumerate(range(20)):
        logger.info(f"sending messages : {count+1}")
        await send_messages(payload_data)
        logger.info("done")


asyncio.run(run())
