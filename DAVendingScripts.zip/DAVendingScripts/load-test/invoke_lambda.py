import json
import boto3

import uvloop
uvloop.install()

FUNCTION_NAME = "DAVendingServices-Prod-IA-CoralLambdaEndpointLambd-F0HekQMPLCEL"


lambda_client = boto3.client(
    "lambda",
    region_name="us-east-1",
)

def invokeApiBasedOnPayLoad(payload):
    callService(payload)

def callService(payload):
    data = {
        "resource": "/" + payload["api"],
        "path": "/" + payload["api"],
        "httpMethod": "POST",
        "requestContext": {
            "resourcePath": "/" + payload["api"],
            "operationName": payload["operationName"],
            "httpMethod": "POST",
        },
        "body": json.dumps(payload["request"]),
    }
    print(json.dumps(data, default=str))
    try:
        response = lambda_client.invoke(
            FunctionName=FUNCTION_NAME,
            InvocationType="RequestResponse",
            LogType="Tail",
            Payload=json.dumps(data, default=str),
        )
        # resp = json.loads(response["Payload"].read().decode("utf-8"))
        return True
    except Exception as ex:
        print("Exception : ", ex)
        return False

def lambda_handler(event, context):
    for record in event["Records"]:
        body = json.loads(record["body"])
        invokeApiBasedOnPayLoad(body)
