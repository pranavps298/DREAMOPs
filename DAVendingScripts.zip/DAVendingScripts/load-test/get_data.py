import csv
import json
import string
import random

file_name = "adg_100k_asins.csv"
TOKEN = ""

DOCKETS_LIST = {
    "alexa": [
        "moneraAlexaSkillDetailPageV2.json",
        "alexaMonISPDetailFromISPS.json",
        "a2sguiSkillDetailPage.json",
        "alexaMonISPDetailFromADGPSWithPaidSkill.json",
        "alexaMonPurchaseDraftISPDetails.json",
        "digitalGoodOrderingAlexaInSkillProductDocket.json",
    ],
    "appstore": [
        "appstoreMobileApplicationProduct.json",
        "appstoreLocalisedMobileApplicationProduct.json",
        "appstoreMerchantWithOffer.json",
    ],
    "common": ["adgCoreProductServiceWithChannel.json", "zeroesCoinsProduct.json"],
}


def csv_to_json(csv_file_path):
    data = []
    with open(csv_file_path, mode="r", encoding="utf-8") as csv_file:
        csv_reader = csv.DictReader(csv_file)
        data = list(csv_reader)
    return data


def generate_random_string(length=10):
    characters = string.ascii_letters + string.digits
    random_string = "".join(random.choice(characters) for _ in range(length))
    return random_string.upper()


def get_payload(random_asins, docketId, pfm, cor):
    return {
        "token": TOKEN,
        "preferredLocale": {"pfm": pfm, "cor": cor},
        "pfm": pfm,
        "cor": cor,
        "language": "en_US",
        "useListApi": True,
        "docketId": docketId,
        "asins": random_asins,
    }


def generate_data(pfm, cor, n=100000, business=None):
    asins = csv_to_json(file_name)

    common_dockets = DOCKETS_LIST["common"]
    asins_to_docket = [
        {
            "asin": asin["asin"],
            "productLine": asin["ProductLine"],
            "docketId": random.choice(
                common_dockets + DOCKETS_LIST["appstore"]
                if "Appstore" in asin["ProductLine"]
                else DOCKETS_LIST["alexa"]
            ),
        }
        for asin in asins
    ]
    appstore_data = [
        item if "Appstore" in item["productLine"] else None for item in asins_to_docket
    ]
    appstore_data = list(filter(lambda x: x is not None, appstore_data))
    alexa_data = [
        item if "Appstore" not in item["productLine"] else None
        for item in asins_to_docket
    ]
    alexa_data = list(filter(lambda x: x is not None, alexa_data))
    payload = []
    for item in asins_to_docket:
        if not business:
            payload.append(
                json.dumps(get_payload([item["asin"]], item["docketId"], pfm, cor))
            )
        else:
            if business in item["productLine"]:
                payload.append(
                    json.dumps(get_payload([item["asin"]], item["docketId"], pfm, cor))
                )
    return payload


def generate_random_data(pfm, cor, n=100000):
    asins = csv_to_json(file_name)

    common_dockets = DOCKETS_LIST["common"]
    asins_to_docket = [
        {
            "asin": asin["asin"],
            "productLine": asin["ProductLine"],
            "docketId": random.choice(
                common_dockets + DOCKETS_LIST["appstore"]
                if "Appstore" in asin["ProductLine"]
                else DOCKETS_LIST["alexa"]
            ),
        }
        for asin in asins
    ]
    appstore_asins = [
        item["asin"] if "Appstore" in item["productLine"] else None
        for item in asins_to_docket
    ]
    appstore_asins = list(filter(lambda x: x is not None, appstore_asins))
    alexa_asins = [
        item["asin"] if "Appstore" not in item["productLine"] else None
        for item in asins_to_docket
    ]
    alexa_asins = list(filter(lambda x: x is not None, alexa_asins))
    payload = []
    for docket in DOCKETS_LIST["alexa"]:
        for _ in range(n // 2):
            payload.append(
                json.dumps(
                    get_payload(
                        random.sample(alexa_asins, random.randint(2, 15)),
                        docket,
                        pfm,
                        cor,
                    )
                )
            )

    for docket in DOCKETS_LIST["appstore"]:
        for _ in range(n // 2):
            payload.append(
                json.dumps(
                    get_payload(
                        random.sample(appstore_asins, random.randint(2, 15)),
                        docket,
                        pfm,
                        cor,
                    )
                )
            )

    for docket in DOCKETS_LIST["common"]:
        for _ in range(n // 3):
            payload.append(
                json.dumps(
                    get_payload(
                        random.sample(
                            appstore_asins + alexa_asins, random.randint(2, 15)
                        ),
                        docket,
                        pfm,
                        cor,
                    )
                )
            )

    for docket in DOCKETS_LIST["common"]:
        for _ in range(n // 4):
            random_asins = [
                generate_random_string(10) for _ in range(random.randint(2, 15))
            ]
            payload.append(
                json.dumps(
                    get_payload(
                        random.sample(
                            appstore_asins + alexa_asins + random_asins,
                            random.randint(2, 15),
                        ),
                        docket,
                        pfm,
                        cor,
                    )
                )
            )
    return payload
