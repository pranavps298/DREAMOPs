i=0
while [ $i -lt 5 ]
do
    i=$((i+1))
    ada credentials update --account=891376999957 --provider=conduit --role=IibsAdminAccess-DO-NOT-DELETE --once
    python3 ingest_sqs.py
done 
